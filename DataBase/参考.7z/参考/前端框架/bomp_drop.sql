-- ----------------------------
-- ɾ��ģ��Լ��
-- ----------------------------
ALTER TABLE `page` DROP FOREIGN KEY fk_page_tenant_id;
ALTER TABLE `page` DROP FOREIGN KEY fk_page_parent_id;

ALTER TABLE `page_position` DROP FOREIGN KEY fk_page_position_page_id;

ALTER TABLE `widget` DROP FOREIGN KEY fk_widget_position_id;

ALTER TABLE `widget_event` DROP FOREIGN KEY fk_widget_event_widget_id;

ALTER TABLE `service` DROP FOREIGN KEY fk_service_tenant_id;

ALTER TABLE `user` DROP FOREIGN KEY fk_user_tenant_id;

ALTER TABLE `role` DROP FOREIGN KEY fk_role_tenant_id;

ALTER TABLE `resource` DROP FOREIGN KEY fk_resource_tenant_id;

ALTER TABLE `user_role` DROP FOREIGN KEY fk_user_role_tenant_id;
ALTER TABLE `user_role` DROP FOREIGN KEY fk_user_role_user_id;
ALTER TABLE `user_role` DROP FOREIGN KEY fk_user_role_role_id;

ALTER TABLE `role_resource` DROP FOREIGN KEY fk_role_resource_tenant_id ;
ALTER TABLE `role_resource` DROP FOREIGN KEY fk_role_resource_role_id;
ALTER TABLE `role_resource` DROP FOREIGN KEY fk_role_resource_resource_id;

ALTER TABLE `menu` DROP FOREIGN KEY fk_menu_tenant_id;
ALTER TABLE `menu` DROP FOREIGN KEY fk_menu_parent_id;

ALTER TABLE `user_menu` DROP FOREIGN KEY fk_user_menu_tenant_id;
ALTER TABLE `user_menu` DROP FOREIGN KEY fk_user_menu_user_id;
ALTER TABLE `user_menu` DROP FOREIGN KEY fk_user_menu_menu_id;

ALTER TABLE `parameter` DROP FOREIGN KEY fk_parameter_tenant_id;

ALTER TABLE `service_field` DROP FOREIGN KEY fk_service_field_service_id;

ALTER TABLE `show_config_group` DROP FOREIGN KEY fk_show_config_group_tenant_id;

ALTER TABLE `show_config` DROP FOREIGN KEY fk_show_config_tenant_id;
ALTER TABLE `show_config` DROP FOREIGN KEY fk_show_config_group_id;

ALTER TABLE `show_config_field` DROP FOREIGN KEY fk_show_config_field_show_config_id;

ALTER TABLE `log` DROP FOREIGN KEY fk_log_tenant_id;
ALTER TABLE `log` DROP FOREIGN KEY fk_log_user_id;


ALTER TABLE `area` DROP FOREIGN KEY fk_area_tenant_id;
ALTER TABLE `area` DROP FOREIGN KEY fk_area_parent_id;

ALTER TABLE `group` DROP FOREIGN KEY fk_group_tenant_id;
ALTER TABLE `group` DROP FOREIGN KEY fk_group_parent_id;
ALTER TABLE `group` DROP FOREIGN KEY fk_group_area_id;

ALTER TABLE  `user_group` DROP FOREIGN KEY fk_user_group_tenant_id;
ALTER TABLE  `user_group` DROP FOREIGN KEY fk_user_group_group_id;
ALTER TABLE  `user_group` DROP FOREIGN KEY  fk_user_group_user_id;


-- ALTER TABLE `fastquery_user` DROP FOREIGN KEY fk_fastquery_user_tenant_id;
-- ALTER TABLE `fastquery_user` DROP FOREIGN KEY fk_fastquery_user_menu_id;
-- ALTER TABLE `fastquery_user` DROP FOREIGN KEY fk_fastquery_user_user_id;
-- ALTER TABLE `workmap_user` DROP FOREIGN KEY fk_workmap_user_tenant_id;

-- ALTER TABLE `workmap_user` DROP FOREIGN KEY fk_workmap_user_menu_id;
-- ALTER TABLE `workmap_user` DROP FOREIGN KEY fk_workmap_user_user_id;
-- ALTER TABLE `agencydata_user` DROP FOREIGN KEY fk_agencydata_user_tenant_id;
-- ALTER TABLE `agencydata_user` DROP FOREIGN KEY fk_agencydata_user_user_id;

-- ALTER TABLE  `report` DROP FOREIGN KEY  fk_report_tenant_id;

-- ALTER TABLE  `show_config_field_user`  DROP FOREIGN KEY  fk_show_config_field_user_tenant_id ;
-- ALTER TABLE  `show_config_field_user`  DROP FOREIGN KEY  fk_show_config_field_user_show_config_field_id ;
-- ALTER TABLE  `show_config_field_user`  DROP FOREIGN KEY  fk_show_config_field_user_id ;


-- ALTER TABLE  `systemlog` DROP FOREIGN KEY  fk_systemlog_tenant_id;
-- ALTER TABLE  `systemlog` DROP FOREIGN KEY  fk_systemlog_user_id;
-- ALTER TABLE  `systemlogdetail` DROP FOREIGN KEY  fk_systemlogdetail_systemlog_id;
-- ALTER TABLE  `systemlogfielddetail` DROP FOREIGN KEY  fk_systemlogfielddetail_systemlogdetail_id;

-- ALTER TABLE  `systemlog_his` DROP FOREIGN KEY  fk_systemlog_his_tenant_id;
-- ALTER TABLE  `systemlog_his` DROP FOREIGN KEY  fk_systemlog_his_user_id;
-- ALTER TABLE  `systemlogdetail_his` DROP FOREIGN KEY  fk_systemlogdetail_his_systemlog_his_id;
-- ALTER TABLE  `systemlogfielddetail_his` DROP FOREIGN KEY  fk_systemlogfielddetail_his_systemlogdetail_his_id;
-- ALTER TABLE  `role_fundcode` DROP FOREIGN KEY  fk_role_fundcode_role_id;
-- ALTER TABLE  `role_fundcode` DROP FOREIGN KEY  fk_role_fundcode_tenant_id;
-- ALTER TABLE  `role_manager` DROP FOREIGN KEY  fk_role_manager_tenant_id;
-- ALTER TABLE  `role_manager` DROP FOREIGN KEY  fk_role_manager_role_id;
-- ----------------------------
-- ɾ������
-- ----------------------------
drop index unique_index_area on area;


drop index unique_index_menu on menu ;

drop index unique_index_parameter on parameter ;

drop index  unique_index_resource on resource ;

drop  index unique_index_role on role ;

drop  index unique_index_service on service ;

drop  index unique_index_show_config on show_config ;

drop  index unique_index_show_config_group on show_config_group ;

drop  index unique_index_tenant on tenant ;

drop  index unique_index_user on `user`;
-- drop  index uidx_tdeallock on `ta_tdeallock`;
-- drop  index unique_index_sysparameter on `sysparameter`;
-- drop  index unique_index_show_config_field_user  on `show_config_field_user`;
-- drop  index unique_index_role_fundcode on `role_fundcode`;
-- drop  index unique_index_role_manager on `role_manager`;
-- drop  index uidx_treportfaxcust on `treportfaxcust`;
-- drop  index uidx_tfaxsendinfo on `tfaxsendinfo`;

-- ----------------------------
-- ɾ��ģ��
-- ----------------------------
DROP TABLE IF EXISTS  `ta_tdeallock` ;
DROP TABLE IF EXISTS `role_fundcode`;
DROP TABLE IF EXISTS `role_manager`;
DROP TABLE IF EXISTS `role_department`;
drop table if exists  agencydata_user ;
drop table if exists  workmap_user ;
drop table if exists  fastquery_user ;
drop table if exists notice;
drop table if exists workmap_menu;
DROP TABLE IF EXISTS `show_config_field_user`;
DROP TABLE IF EXISTS `query`;
DROP TABLE IF EXISTS `query_in`;
DROP TABLE IF EXISTS `query_out`;
DROP TABLE IF EXISTS `update`;
DROP TABLE IF EXISTS `update_in`;
DROP TABLE IF EXISTS `update_out`;

DROP TABLE IF EXISTS `page`;
DROP TABLE IF EXISTS `page_position`;
DROP TABLE IF EXISTS `widget`;
DROP TABLE IF EXISTS `widget_event`;

DROP TABLE IF EXISTS `user_role`;
DROP TABLE IF EXISTS `role_resource`;
DROP TABLE IF EXISTS `resource_auth`;
DROP TABLE IF EXISTS `role_ta`;
DROP TABLE IF EXISTS `user_resource`;
DROP TABLE IF EXISTS `user_password_his`;
DROP TABLE IF EXISTS `role`;
DROP TABLE IF EXISTS `resource`;

DROP TABLE IF EXISTS `menu`;
DROP TABLE IF EXISTS `user_menu`;

DROP TABLE IF EXISTS `parameter`;

DROP TABLE IF EXISTS `service`;
DROP TABLE IF EXISTS `service_field`;

DROP TABLE IF EXISTS `show_config_group`;
DROP TABLE IF EXISTS `show_config`;
DROP TABLE IF EXISTS `show_config_field`;


DROP TABLE IF EXISTS `area`;

DROP TABLE IF EXISTS `log`;

DROP TABLE IF EXISTS `group`;

DROP TABLE IF EXISTS `user_group`;
DROP TABLE IF EXISTS `sysparameter`;

DROP TABLE IF EXISTS `report`;
DROP TABLE IF EXISTS `treportfaxcust`;
DROP TABLE IF EXISTS `tfaxsendinfo`;


DROP TABLE IF EXISTS `other_service_field`;
DROP TABLE IF EXISTS `other_show_config_field`;


DROP TABLE IF EXISTS `systemlogfielddetail`;
DROP TABLE IF EXISTS `systemlogdetail`;
DROP TABLE IF EXISTS `systemlog`;



DROP TABLE IF EXISTS `systemlogfielddetail_his`;
DROP TABLE IF EXISTS `systemlogdetail_his`;
DROP TABLE IF EXISTS `systemlog_his`;

DROP TABLE IF EXISTS  taapi_request_data_api;
DROP TABLE IF EXISTS  taapi_request_data_detail_api;
DROP TABLE IF EXISTS  taapi_filteroptions_api;

DROP TABLE IF EXISTS  report_field;
DROP TABLE IF EXISTS  report_field_user;
DROP TABLE IF EXISTS  show_config_functions;


DROP TABLE IF EXISTS `user`;
DROP TABLE IF EXISTS `tenant`;

DROP TABLE IF EXISTS  `filedefinition`;




DROP TABLE IF EXISTS `taapi_sync_status`;
DROP TABLE IF EXISTS `taapi_request_flow_api`;
DROP TABLE IF EXISTS `taapi_action_recode_api`;
DROP TABLE IF EXISTS `taapi_content_log_api`;
DROP TABLE IF EXISTS `taapi_function`;
DROP TABLE IF EXISTS `taapi_function_auth`;

DROP TABLE IF EXISTS `ta_tfundinfo_api`;
DROP TABLE IF EXISTS `ta_tfundinfoprecision_api`;
DROP TABLE IF EXISTS `ta_tfundsetupinfo_api`;
DROP TABLE IF EXISTS `ta_tarlimit_api`;
DROP TABLE IF EXISTS `ta_tsalequalify_api`;
DROP TABLE IF EXISTS `ta_tfundbelongasset_api`;
DROP TABLE IF EXISTS `ta_tfaarlimit_api`;
DROP TABLE IF EXISTS `ta_textparameter_api`;

