
-- ----------------------------
-- �⻧ģ��
-- ----------------------------
CREATE TABLE `tenant` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `code` VARCHAR (50) NOT NULL COMMENT '�⻧����',
  `name` VARCHAR (50) NOT NULL COMMENT '�⻧����',
  `country` VARCHAR(20) COMMENT '����',
  `province` VARCHAR(20) COMMENT 'ʡ��',
  `city` VARCHAR(20) COMMENT '����',
  `contact` VARCHAR(20) COMMENT '��ϵ��',
  `phone` VARCHAR(15) COMMENT '�绰',
  `mobile` VARCHAR(15) COMMENT '�ֻ�',
  `fax` VARCHAR(15) COMMENT '����',
  `address` VARCHAR(200) COMMENT '��ַ',
  `status` INT(1) DEFAULT 0 COMMENT '״̬',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ҳ��ģ��
-- ----------------------------
CREATE TABLE `page` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `parent_id` INT(11) COMMENT '�̳�',
  `layout` VARCHAR(50) COMMENT '����',
  `title` VARCHAR(50) NOT NULL COMMENT '����',
  `path` VARCHAR(200) NOT NULL COMMENT '·��',
  `resources` VARCHAR(100) COMMENT '·��',
  `type` INT(1) DEFAULT 0 COMMENT '����',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ҳ��λ��ģ��
-- ----------------------------
CREATE TABLE `page_position` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `page_id` INT(11) NOT NULL COMMENT '�̳�',
  `name` VARCHAR (50) NOT NULL COMMENT '����',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ���ģ��
-- ----------------------------
CREATE TABLE `widget` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `position_id` INT(11) NOT NULL COMMENT 'λ��',
  `path` VARCHAR(200) NOT NULL COMMENT '·��',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- �¼�ģ��
-- ----------------------------
CREATE TABLE `widget_event` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `widget_id` INT(11) NOT NULL COMMENT '���',
  `name` VARCHAR(20) NOT NULL COMMENT '����',
  `expression` VARCHAR(200) NOT NULL COMMENT '����ʽ',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- �û�ģ��
-- ----------------------------
CREATE TABLE `user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `username` VARCHAR(20) NOT NULL COMMENT '�˺�',
  `password` VARCHAR(60) NOT NULL COMMENT '����',
  `email` VARCHAR(50) COMMENT '����',
  `mobile` VARCHAR(15) COMMENT '�ֻ�',
  `phone` VARCHAR(15) COMMENT '�绰',
  `address` VARCHAR(200) COMMENT '��ַ',
  `status` INT(1) DEFAULT 0 COMMENT '״̬',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ��ɫģ��
-- ----------------------------
CREATE TABLE `role` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `code` VARCHAR(200) NOT NULL COMMENT '����',
  `name` VARCHAR(200) NOT NULL COMMENT '����',
  `description` VARCHAR(200) COMMENT '����',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ��Դģ��
-- ----------------------------
CREATE TABLE `resource` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `code` VARCHAR(50) NOT NULL COMMENT '����',
  `name` VARCHAR(200) NOT NULL COMMENT '����',
  `category` VARCHAR(200) COMMENT '����',
  `description` VARCHAR(200) COMMENT '����',
  PRIMARY KEY (`id`)
);


-- ----------------------------
-- �û���ɫ��ϵģ��
-- ----------------------------
CREATE TABLE `user_role` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `user_id` INT(11) NOT NULL COMMENT '�û�',
  `role_id` INT(11) NOT NULL COMMENT '��ɫ',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ��ɫ��Դ��ϵģ��
-- ----------------------------
CREATE TABLE `role_resource` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `role_id` INT(11) NOT NULL COMMENT '��ɫ',
  `resource_id` INT(11) NOT NULL COMMENT '��Դ',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- �˵�ģ��
-- ----------------------------
CREATE TABLE `menu` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `parent_id` INT(11) COMMENT '���˵�',
  `refer_id` INT(11) COMMENT '���ò˵�',
  `code` VARCHAR(50) COMMENT '����',
  `name` VARCHAR(50) COMMENT '����',
  `url` VARCHAR(200) COMMENT 'URL',
  `order` INT(2) DEFAULT 0 COMMENT '˳��',
  `resource_code` VARCHAR(500) COMMENT '��Դ����',
  `queryString` VARCHAR(1000) COMMENT '��ѯ�ֶ�',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- �û��˵�ģ��
-- ----------------------------
CREATE TABLE `user_menu` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `user_id` INT(11) NOT NULL COMMENT '��ɫ',
  `menu_id` INT(11) NOT NULL COMMENT '�˵�',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ����ģ��
-- ----------------------------
CREATE TABLE `service`(
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `code` VARCHAR(100) NOT NULL COMMENT '����',
  `name` VARCHAR(100) NOT NULL COMMENT '����',
  `mode` VARCHAR(10) NOT NULL COMMENT 'ģʽ',
  `command` TEXT NOT NULL COMMENT 'ָ��',
  `version` VARCHAR(20) COMMENT '�汾,��ǰʹ�õİ汾',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- �����ֶ�ģ��
-- ----------------------------
CREATE TABLE `service_field` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `service_id` INT(11)  NOT NULL COMMENT '����',
  `name` VARCHAR(50) NOT NULL COMMENT '�����',
  `order` int(3) DEFAULT 0 COMMENT '����',
  `type` VARCHAR(20) NOT NULL COMMENT '����',
  `mode` VARCHAR(20) NOT NULL COMMENT 'ģʽ��in Ϊ��Σ�out Ϊ����',
  PRIMARY KEY (`id`)
);


-- ----------------------------
-- ��ʾ������ģ��
-- ----------------------------
CREATE TABLE `show_config_group` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `code` VARCHAR(100) NOT NULL COMMENT '����',
  `name` VARCHAR(50) NOT NULL COMMENT '����',
  `version` VARCHAR(50) COMMENT '�汾',
  PRIMARY KEY (`id`)
);


-- ----------------------------
-- ��ʾ����ģ��
-- ----------------------------
CREATE TABLE `show_config` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `show_config_group_id` INT(11) COMMENT '��ʾ������',
  `code` VARCHAR(50) NOT NULL COMMENT '����',
  `name` VARCHAR(50) NOT NULL COMMENT '����',
  `version` VARCHAR(50) COMMENT '�汾',
  `services` VARCHAR(500) COMMENT '������',
  `template` VARCHAR(200) COMMENT 'ģ��',
  `parameter` VARCHAR(1000) COMMENT '����',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ��ʾ�����ֶ�ģ��
-- ----------------------------
CREATE TABLE `show_config_field` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `show_config_id` INT(11) COMMENT '��ʾ����',
  `name` VARCHAR(50) NOT NULL COMMENT '����',
  `label` VARCHAR(50) NOT NULL COMMENT '��ʾ��',
  `type` VARCHAR(50) NOT NULL COMMENT '����',
  `mode` VARCHAR(10) NOT NULL COMMENT 'ģʽ',
  `format` VARCHAR(100) COMMENT '��ʽ',
  `order` INT(3) DEFAULT 0 COMMENT '˳��',
  `width` INT(4) DEFAULT 0 COMMENT '����',
  `category` VARCHAR(10) COMMENT '����',
  `editable` INT(1) COMMENT '�ɱ༭',
  `orderable` INT(1) COMMENT '������',
  `visible` INT(1) COMMENT '����',
  `searchable` INT(1) COMMENT '������',
  `dict_name` VARCHAR(200) COMMENT '�ֵ���',
  `default_value` VARCHAR(1000) COMMENT 'Ĭ��ֵ',
  `rules` VARCHAR(500) COMMENT '����',
  `messages` VARCHAR(500) COMMENT '��ʾ��Ϣ',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ����ģ��
-- ----------------------------
-- ϵͳ������
-- ����type
-- 0����������ֵ1:true 0:false
-- 1��ѡ��������valuebound����������ʽΪ��
-- 1:xxx;2:yyy;3:zzzz
-- 1,2,3û�г��Ȼ����͵�����
-- 2������ valuebound��ֵ�򣬸�ʽΪ��n1;n2����ʾ>=n1,<=n2��
-- Ϊ�ձ�ʾ������
-- 3��������valuebound��ֵ�򣬸�ʽΪ��n1;n2����ʾ>=n1,<=n2��
-- Ϊ�ձ�ʾ������
-- 4���ַ��� valuebound�ǳ������ƣ���ʽΪ��n1;n2;
-- Ϊ�ձ�ʾ������
-- 5������
-- 6��·��
CREATE TABLE `parameter` (
`id` INT(11) NOT NULL AUTO_INCREMENT,
`tenant_id` INT(11) COMMENT '�⻧',
`tenant_code` VARCHAR(50) COMMENT '�⻧����',
`c_category` VARCHAR(50) NOT NULL COMMENT '���',
`c_subcategory` VARCHAR(50) NOT NULL COMMENT '�����',
`c_item` VARCHAR(50) NOT NULL COMMENT '������',
`c_type` VARCHAR(50) NOT NULL COMMENT '����',
`c_value` VARCHAR(100) COMMENT 'ֵ',
`c_valuebound` VARCHAR(200) COMMENT 'ֵ��',
`l_order` INT(2) DEFAULT 0 COMMENT '˳��',
`c_description` VARCHAR(200) COMMENT '����',
`c_modifymode` INT(3) COMMENT '�޸�ģʽ', -- (0�����ɼ�; 1�����޸� 2��ֻ��)
PRIMARY KEY (`id`)
);




-- ----------------------------
-- ��־ģ��
-- ----------------------------
CREATE TABLE `log` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `user_id` INT(11) NOT NULL COMMENT '�û�',
  `module` VARCHAR(100) NOT NULL COMMENT 'ģ��',
  `function` VARCHAR(100) NOT NULL COMMENT '����',
  `level` VARCHAR(20) NOT  NULL COMMENT '����',
  `time` DATE  NOT NULL COMMENT 'ʱ��',
  `content` VARCHAR (1000) NOT NULL COMMENT '����',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ����ģ��
-- ----------------------------
CREATE TABLE `area` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` INT(11) COMMENT '�⻧',
  `parent_id` INT(11) COMMENT '��Id',
  `code` VARCHAR(100) NOT NULL COMMENT '����',
  `type` VARCHAR(100) NOT NULL COMMENT '����',
  `name` VARCHAR(100) NOT NULL COMMENT '����',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ����ģ��
-- ----------------------------
CREATE TABLE `group` (
  `id`  INT(11) NOT NULL  AUTO_INCREMENT ,
  `tenant_id`  INT(11)  COMMENT '�⻧ID' ,
  `parent_id`  INT(11)   COMMENT '���ڵ�ID' ,
  `area_id`  INT(11)  COMMENT '����ID' ,
  `code`  VARCHAR(20) NOT NULL  COMMENT '����' ,
  `type`  VARCHAR(20) COMMENT '���ͣ���Ʒ�����з�����' ,
  `name`  VARCHAR(20) COMMENT '����' ,
  PRIMARY KEY (`id`)
);




-- ----------------------------
-- �û�����ģ��
-- ----------------------------
CREATE TABLE `user_group` (
  `id`  INT(11) NOT NULL  AUTO_INCREMENT ,
  `tenant_id`  INT(11)  COMMENT '�⻧' ,
  `user_id`  INT(11)   COMMENT '�û�' ,
  `group_id`  INT(11)  COMMENT '����' ,
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ϵͳ����ģ��
-- ----------------------------
CREATE TABLE `sysparameter` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
	`paramitem` VARCHAR(40) NOT NULL ,
	`paramvalue` VARCHAR(255) NOT NULL  ,
	`paramtype` VARCHAR(20)  ,
	`valuebound` VARCHAR(100)  ,
	`usermodify` VARCHAR(1)  DEFAULT '0' ,
	`describe` VARCHAR(100) ,
	`showclass` VARCHAR(20)  ,
	`showsubclass` VARCHAR(40)  ,
	`order` INT(11) NOT NULL DEFAULT '0',
	PRIMARY KEY (`id`)
);

-- ----------------------------
-- ����ģ��
-- ----------------------------
CREATE TABLE `report` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`tenant_id` INT(11) COMMENT '�⻧����',
	`c_rptcode` VARCHAR(10) COMMENT '��������',
	`c_rptname` VARCHAR(60) COMMENT '��������',
	`l_rptorder` INT(4) COMMENT '���',
	`c_rpttype` VARCHAR(8) COMMENT '��������',
	`c_url` VARCHAR(100) COMMENT '·��',
	`c_describe` VARCHAR(200) COMMENT '����',
	PRIMARY KEY (`id`)
);


-- ----------------------------
-- ��־ת��ģ��
-- ----------------------------
CREATE TABLE filedefinition(
id INT(11) NOT NULL AUTO_INCREMENT,
filedname VARCHAR(100) NOT NULL  COMMENT '�ֶ���',
fileddescribe VARCHAR(100) NOT NULL COMMENT '�ֶκ���',
memo VARCHAR(200) DEFAULT '' COMMENT '�ֶα�ע',
PRIMARY KEY(id)
);


-- ----------------------------
-- ҳ��ģ��Լ��
-- ----------------------------
ALTER TABLE `page` ADD CONSTRAINT fk_page_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `page` ADD CONSTRAINT fk_page_parent_id FOREIGN KEY (`parent_id`) REFERENCES `page` (`id`);

-- ----------------------------
-- ҳ��λ��ģ��Լ��
-- ----------------------------
ALTER TABLE `page_position` ADD CONSTRAINT fk_page_position_page_id FOREIGN KEY (`page_id`) REFERENCES `page` (`id`);

-- ----------------------------
-- ���ģ��Լ��
-- ----------------------------
ALTER TABLE `widget` ADD CONSTRAINT fk_widget_position_id FOREIGN KEY (`position_id`) REFERENCES `page_position` (`id`);

-- ----------------------------
-- �¼�ģ��Լ��
-- ----------------------------
ALTER TABLE `widget_event` ADD CONSTRAINT fk_widget_event_widget_id FOREIGN KEY (`widget_id`) REFERENCES `widget` (`id`);

-- ----------------------------
-- �û�ģ��Լ��
-- ----------------------------
ALTER TABLE `user` ADD CONSTRAINT fk_user_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);

-- ----------------------------
-- ��ɫģ��Լ��
-- ----------------------------
ALTER TABLE `role` ADD CONSTRAINT fk_role_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);

-- ----------------------------
-- ��Դģ��Լ��
-- ----------------------------
ALTER TABLE `resource` ADD CONSTRAINT fk_resource_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);

-- ----------------------------
-- �û���ɫ��ϵģ��Լ��
-- ----------------------------
ALTER TABLE `user_role` ADD CONSTRAINT fk_user_role_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `user_role` ADD CONSTRAINT fk_user_role_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
ALTER TABLE `user_role` ADD CONSTRAINT fk_user_role_role_id FOREIGN KEY (`role_id`) REFERENCES `role` (`id`);

-- ----------------------------
-- ��ɫ��Դ��ϵģ��Լ��
-- ----------------------------
ALTER TABLE `role_resource` ADD CONSTRAINT fk_role_resource_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `role_resource` ADD CONSTRAINT fk_role_resource_role_id FOREIGN KEY (`role_id`) REFERENCES `role` (`id`);
ALTER TABLE `role_resource` ADD CONSTRAINT fk_role_resource_resource_id FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`);

-- ----------------------------
-- �˵�ģ��
-- ----------------------------
ALTER TABLE `menu` ADD CONSTRAINT fk_menu_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `menu` ADD CONSTRAINT fk_menu_parent_id FOREIGN KEY (`parent_id`) REFERENCES `menu` (`id`);

-- ----------------------------
-- �û��˵�ģ��
-- ----------------------------
ALTER TABLE `user_menu` ADD CONSTRAINT fk_user_menu_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `user_menu` ADD CONSTRAINT fk_user_menu_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
ALTER TABLE `user_menu` ADD CONSTRAINT fk_user_menu_menu_id FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`);

-- ----------------------------
-- �����˵�ģ��
-- ----------------------------
ALTER TABLE `parameter` ADD CONSTRAINT fk_parameter_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
-- ----------------------------
-- ����ģ��Լ��
-- ----------------------------
ALTER TABLE `service` ADD CONSTRAINT fk_service_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);

-- ----------------------------
-- �����ֶ�ģ��Լ��
-- ----------------------------
ALTER TABLE `service_field` ADD CONSTRAINT fk_service_field_service_id FOREIGN KEY (`service_id`) REFERENCES `service` (`id`);

-- ----------------------------
-- ��ʾ������ģ��
-- ----------------------------
ALTER TABLE `show_config_group` ADD CONSTRAINT fk_show_config_group_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);

-- ----------------------------
-- ��ʾ����ģ��
-- ----------------------------
ALTER TABLE `show_config` ADD CONSTRAINT fk_show_config_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `show_config` ADD CONSTRAINT fk_show_config_group_id FOREIGN KEY (`show_config_group_id`) REFERENCES `show_config_group` (`id`);

-- ----------------------------
-- ��ʾ�����ֶ�ģ��
-- ----------------------------

ALTER TABLE `show_config_field` ADD CONSTRAINT fk_show_config_field_show_config_id FOREIGN KEY (`show_config_id`) REFERENCES `show_config` (`id`);

-- ----------------------------
-- ��־ģ��
-- ----------------------------
ALTER TABLE `log` ADD CONSTRAINT fk_log_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `log` ADD CONSTRAINT fk_log_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

-- ----------------------------
-- ����ģ��
-- ----------------------------
ALTER TABLE `area` ADD CONSTRAINT fk_area_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `area` ADD CONSTRAINT fk_area_parent_id FOREIGN KEY (`parent_id`) REFERENCES `area` (`id`);
-- ----------------------------
-- ����ģ��Լ��
-- ----------------------------
ALTER TABLE `group` ADD CONSTRAINT fk_group_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `group` ADD CONSTRAINT fk_group_parent_id FOREIGN KEY (`parent_id`) REFERENCES `group` (`id`);
ALTER TABLE `group` ADD CONSTRAINT fk_group_area_id FOREIGN KEY (`area_id`) REFERENCES `area` (`id`);
-- ----------------------------
-- �û�����ģ��Լ��
-- ----------------------------
ALTER TABLE `user_group` ADD CONSTRAINT `fk_user_group_group_id` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`);
ALTER TABLE `user_group` ADD CONSTRAINT `fk_user_group_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `user_group` ADD CONSTRAINT `fk_user_group_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
-- ----------------------------
-- ����ģ��Լ��
-- ----------------------------
ALTER TABLE `report` ADD CONSTRAINT `fk_report_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);

-- ----------------------------
-- ����ģ��Ψһ������
-- ----------------------------
create unique index unique_index_area on area (tenant_id,code);


-- ----------------------------
-- �˵�ģ��Ψһ������
-- ----------------------------
create unique index unique_index_menu on menu (tenant_id,code);

-- ----------------------------
-- ����ģ��Ψһ������
-- ----------------------------
create unique index unique_index_parameter on parameter (tenant_id,c_item,c_value);

-- ----------------------------
-- ��Դģ��Ψһ������
-- ----------------------------
create unique index unique_index_resource on resource (tenant_id,code);

-- ----------------------------
-- ��ɫģ��Ψһ������
-- ----------------------------
create unique index unique_index_role on role (tenant_id,code);

-- ----------------------------
-- ����ģ��Ψһ������
-- ----------------------------
create unique index unique_index_service on service (tenant_id,code);

-- ----------------------------
-- ��ʾ����ģ��Ψһ������
-- ----------------------------
create unique index unique_index_show_config on show_config (tenant_id,code);

-- ----------------------------
-- ��ʾ������ģ��Ψһ������
-- ----------------------------
create unique index unique_index_show_config_group on show_config_group (tenant_id,code);

-- ----------------------------
-- �⻧ģ��Ψһ������
-- ----------------------------
create unique index unique_index_tenant on tenant (code);

-- ----------------------------
-- �û�ģ��Ψһ������
-- ----------------------------
create unique index unique_index_user on user (tenant_id,username);

-- ----------------------------
-- ϵͳ����ģ��Ψһ������
-- ----------------------------
create unique index unique_index_sysparameter ON sysparameter(paramitem );

-- ----------------------------
-- ����ģ��Ψһ������
-- ----------------------------
create unique index unique_index_report ON report(tenant_id,c_rptcode);

-- ----------------------------
-- ��־ת��ģ��Ψһ������
-- ----------------------------
CREATE UNIQUE INDEX unique_index_filedefinition ON filedefinition(filedname);




-- ----------------------------
-- ������Ϣģ��
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
create table notice (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`tenant_id` int(11) NOT NULL COMMENT '�⻧id',
	`user_id` int(11) NOT NULL COMMENT '�û�id',
	`creatdate` VARCHAR (8)  NOT NULL COMMENT '����ʱ��',
	`senddate` VARCHAR (8)   COMMENT '����ʱ��',
  `content` VARCHAR (1000) NOT NULL COMMENT '����',
  `title` VARCHAR (1000) NOT NULL COMMENT '����',
  `sendflag` int(2) NOT NULL COMMENT '���ͱ��',
  `author` VARCHAR (100) NOT NULL COMMENT '����',
	PRIMARY KEY (`id`)
);

-- ----------------------------
-- ���ٲ�ѯ�û���ϵģ��
-- ----------------------------
DROP TABLE IF EXISTS `fastquery_user`;
create table fastquery_user(
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`tenant_id` int(11) NOT NULL COMMENT '�⻧id',
	`menu_id` int(11) NOT NULL COMMENT '�˵�id',
	`user_id` int(11) NOT NULL COMMENT '�û�id',
	PRIMARY KEY (`id`)
);

-- ----------------------------
-- ������ͼ�û���ϵģ��
-- ----------------------------
DROP TABLE IF EXISTS `workmap_user`;
create table workmap_user(
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`tenant_id` int(11) NOT NULL COMMENT '�⻧id',
	`workmap_menu_id` int(11) NOT NULL COMMENT '������ͼ�˵�id',
	`user_id` int(11) NOT NULL COMMENT '�û�id',
	PRIMARY KEY (`id`)
);

-- ----------------------------
-- ������ͼ�˵�ģ��
-- ----------------------------
DROP TABLE IF EXISTS `workmap_menu`;
create table workmap_menu(
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`tenant_id` int(11)  NULL COMMENT '�⻧id',
	`menu_id` int(11) NOT NULL COMMENT '�˵�id',
	`category` int(3) NOT NULL COMMENT '����',
	`order` int(3) NOT NULL COMMENT '����',
	PRIMARY KEY (`id`)
);

-- ----------------------------
-- �������û���ϵģ��
-- ----------------------------
DROP TABLE IF EXISTS `agencydata_user`;
create table agencydata_user(
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`tenant_id` int(11) NOT NULL COMMENT '�⻧id',
	`agencyno` VARCHAR(9) NOT NULL COMMENT '�����̴���',
	`user_id` int(11) NOT NULL COMMENT '�û�id',
	PRIMARY KEY (`id`)
);

-- ----------------------------
-- ��ʾ�����û���ϵģ��
-- ----------------------------
DROP TABLE IF EXISTS `show_config_field_user`;
CREATE TABLE `show_config_field_user` (
	`id` INT(11) NOT NULL AUTO_INCREMENT,
	`show_config_field_id` INT(11) NULL DEFAULT NULL COMMENT '��ʾ�����ֶ�id',
	`user_id` INT(11) NULL DEFAULT NULL COMMENT '�û�id',
	`order` INT(3) NULL DEFAULT '0' COMMENT '˳��',
	`visible` INT(1) NULL DEFAULT NULL COMMENT '����',
	`tenant_id` int(11) NOT NULL COMMENT '�⻧id',
	PRIMARY KEY (`id`)
);


-- ----------------------------
-- ��־ģ��
-- ----------------------------
DROP TABLE IF EXISTS `systemlogfielddetail`;
create table systemlogfielddetail(
`id` INT(11) NOT NULL AUTO_INCREMENT,
`systemlogdetail_id` INT(11) COMMENT 'ϵͳ��־��ϸ',
`filedname` VARCHAR (100)  COMMENT '�ֶ�����',
`oporder` int(11)  COMMENT '����˳��',
`oldvalue` VARCHAR (200)  COMMENT '�޸�ǰ��ֵ',
`newvalue` VARCHAR (200)  COMMENT '�޸ĺ��ֵ',
  PRIMARY KEY (`id`)
);
DROP TABLE IF EXISTS `systemlogdetail`;
create table systemlogdetail(
`id` INT(11) NOT NULL AUTO_INCREMENT,
`systemlog_id` INT(11) COMMENT 'ϵͳ��־',
`oporder` INT(11)   COMMENT '����˳��',
`optype` INT(11)  COMMENT '��������',
`sqlid` VARCHAR (100) NOT NULL COMMENT 'sql��id',
PRIMARY KEY (`id`)
);
DROP TABLE IF EXISTS `systemlog`;
create table systemlog(
`id` INT(11) NOT NULL AUTO_INCREMENT,
`tenant_id` INT(11) COMMENT '�⻧',
`user_id` INT(11) COMMENT '�û�',
`firstmenu` VARCHAR (100)  COMMENT 'һ���˵�',
`seconmenu` VARCHAR (100)  COMMENT '�����˵�',
`threemenu` VARCHAR (100)  COMMENT '�����˵�',
`operationtype` int(11) NOT NULL COMMENT '��������',
`pagename` VARCHAR (100) COMMENT 'ҳ������',
`methodtype` INT(11) NOT NULL COMMENT '��������',
`ip` VARCHAR (100) NOT NULL COMMENT 'ip��ַ',
`time` datetime NOT NULL COMMENT '����ʱ��',
`remark` VARCHAR (200) COMMENT '��ע',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ��־�鵵ģ��
-- ----------------------------
DROP TABLE IF EXISTS `systemlogfielddetail_his`;
create table systemlogfielddetail_his(
`id` INT(11) NOT NULL,
`systemlogdetail_his_id` INT(11) COMMENT 'ϵͳ��־��ϸ',
`filedname` VARCHAR (100)  COMMENT '�ֶ�����',
`oporder` int(11)  COMMENT '����˳��',
`oldvalue` VARCHAR (200)  COMMENT '�޸�ǰ��ֵ',
`newvalue` VARCHAR (200)  COMMENT '�޸ĺ��ֵ',
  PRIMARY KEY (`id`)
);
DROP TABLE IF EXISTS `systemlogdetail_his`;
create table systemlogdetail_his(
`id` INT(11) NOT NULL,
`systemlog_his_id` INT(11) COMMENT 'ϵͳ��־',
`oporder` INT(11)   COMMENT '����˳��',
`optype` INT(11)  COMMENT '��������',
`sqlid` VARCHAR (100) NOT NULL COMMENT 'sql��id',
PRIMARY KEY (`id`)
);

DROP TABLE IF EXISTS `systemlog_his`;
create table systemlog_his(
`id` INT(11) NOT NULL,
`tenant_id` INT(11) COMMENT '�⻧',
`user_id` INT(11) COMMENT '�û�',
`firstmenu` VARCHAR (100)  COMMENT 'һ���˵�',
`seconmenu` VARCHAR (100)  COMMENT '�����˵�',
`threemenu` VARCHAR (100)  COMMENT '�����˵�',
`operationtype` int(11) NOT NULL COMMENT '��������',
`pagename` VARCHAR (100) COMMENT 'ҳ������',
`methodtype` INT(11) NOT NULL COMMENT '��������',
`ip` VARCHAR (100) NOT NULL COMMENT 'ip��ַ',
`time` datetime NOT NULL COMMENT '����ʱ��',
`remark` VARCHAR (200) COMMENT '��ע',
  PRIMARY KEY (`id`)
);




-- ----------------------------
-- ��ɫ�����˹�ϵģ��
-- ----------------------------
DROP TABLE IF EXISTS `role_manager`;
CREATE TABLE `role_manager` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
	`tenant_id` INT(11) NOT NULL COMMENT '�⻧id',
  `role_id` INT(11) NOT NULL COMMENT '��ɫid',
  `mangercode` VARCHAR(10) NOT NULL COMMENT '�����˴���',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ���ٲ�ѯ�û���ϵģ��Լ��
-- ----------------------------
ALTER TABLE `fastquery_user` ADD CONSTRAINT fk_fastquery_user_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `fastquery_user` ADD CONSTRAINT fk_fastquery_user_menu_id FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`);
ALTER TABLE `fastquery_user` ADD CONSTRAINT fk_fastquery_user_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

-- ----------------------------
-- ������ͼ�û�ģ��Լ��
-- ----------------------------
ALTER TABLE `workmap_user` ADD CONSTRAINT fk_workmap_user_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `workmap_user` ADD CONSTRAINT fk_workmap_user_workmap_menu_id FOREIGN KEY (`workmap_menu_id`) REFERENCES `workmap_menu` (`id`);
ALTER TABLE `workmap_user` ADD CONSTRAINT fk_workmap_user_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

-- ----------------------------
-- ���������ݹ�ϵģ��Լ��
-- ----------------------------
ALTER TABLE `agencydata_user` ADD CONSTRAINT fk_agencydata_user_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `agencydata_user` ADD CONSTRAINT fk_agencydata_user_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

-- ----------------------------
-- ��־ģ��Լ��
-- ----------------------------
ALTER TABLE `notice` ADD CONSTRAINT fk_notice_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `notice` ADD CONSTRAINT fk_notice_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
-- ----------------------------
-- ������ͼ�˵�ģ��Լ��
-- ----------------------------

ALTER TABLE `workmap_menu` ADD CONSTRAINT fk_workmap_menu_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `workmap_menu` ADD CONSTRAINT fk_workmap_menu_menu_id FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`);

-- ----------------------------
-- ��ʾ�����û���ϵģ��Լ��
-- ----------------------------
ALTER TABLE `show_config_field_user` ADD CONSTRAINT fk_show_config_field_user_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `show_config_field_user` ADD CONSTRAINT fk_show_config_field_user_show_config_field_id FOREIGN KEY (`show_config_field_id`) REFERENCES `show_config_field` (`id`);
ALTER TABLE `show_config_field_user` ADD CONSTRAINT fk_show_config_field_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

create unique index unique_index_show_config_field_user on show_config_field_user (tenant_id,user_id,show_config_field_id);


-- ----------------------------
-- ��־ģ��Լ��
-- ----------------------------
ALTER TABLE `systemlog` ADD CONSTRAINT fk_systemlog_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `systemlog` ADD CONSTRAINT fk_systemlog_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
ALTER TABLE `systemlogdetail` ADD CONSTRAINT fk_systemlogdetail_systemlog_id FOREIGN KEY (`systemlog_id` ) REFERENCES `systemlog` (`id`);
ALTER TABLE `systemlogfielddetail` ADD CONSTRAINT fk_systemlogfielddetail_systemlogdetail_id FOREIGN KEY (`systemlogdetail_id`) REFERENCES `systemlogdetail` (`id`);

-- ----------------------------
-- ��־�鵵ģ��Լ��
-- ----------------------------
ALTER TABLE `systemlog_his` ADD CONSTRAINT fk_systemlog_his_tenant_id FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `systemlog_his` ADD CONSTRAINT fk_systemlog_his_user_id FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
ALTER TABLE `systemlogdetail_his` ADD CONSTRAINT fk_systemlogdetail_his_systemlog_his_id FOREIGN KEY (`systemlog_his_id` ) REFERENCES `systemlog_his` (`id`);
ALTER TABLE `systemlogfielddetail_his` ADD CONSTRAINT fk_systemlogfielddetail_his_systemlogdetail_his_id FOREIGN KEY (`systemlogdetail_his_id`) REFERENCES `systemlogdetail_his` (`id`);


-- ----------------------------
-- ��ɫ�����˹�ϵģ��Լ��
-- ----------------------------
ALTER TABLE `role_manager` ADD CONSTRAINT `fk_role_manager_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `role_manager` ADD CONSTRAINT fk_role_manager_role_id FOREIGN KEY (`role_id`) REFERENCES `role` (`id`);

create unique index unique_index_role_manager on role_manager (tenant_id,role_id,mangercode);



-- add by tuojg12929 2016-08-09
alter table show_config modify services varchar(1000);

-- ----------------------------
-- ҵ��������
-- ----------------------------
DROP TABLE IF EXISTS  `ta_tdeallock` ;
CREATE TABLE `ta_tdeallock` (
  `l_rowid` int(11) NOT NULL AUTO_INCREMENT,
  `c_tenantid` varchar(20) NOT NULL,
  `c_dealtype` varchar(20) NOT NULL,
  `c_dealcode` varchar(20) NOT NULL,
  `c_dealvalue` varchar(20) NOT NULL,
  `c_lock` varchar(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`l_rowid`)
);
CREATE UNIQUE INDEX uidx_tdeallock ON ta_tdeallock(c_tenantid ASC ,c_dealtype ASC ,c_dealcode ASC ,c_dealvalue ASC);


alter table show_config add column `order` INT(3) NULL DEFAULT '0' COMMENT '˳��';

ALTER  TABLE systemlogfielddetail MODIFY  oldvalue VARCHAR(1000) COMMENT '�޸�ǰ��ֵ' ;
ALTER  TABLE systemlogfielddetail MODIFY  newvalue VARCHAR(1000) COMMENT '�޸ĺ��ֵ' ;
ALTER  TABLE systemlogfielddetail_his MODIFY  oldvalue VARCHAR(1000) COMMENT '�޸�ǰ��ֵ' ;
ALTER  TABLE systemlogfielddetail_his MODIFY  newvalue VARCHAR(1000) COMMENT '�޸ĺ��ֵ' ;


ALTER TABLE `systemlog`   
CHANGE `operationtype` `operationtype` INT(11) NULL  COMMENT '��������',
ADD COLUMN `operationname` VARCHAR(20) NULL  COMMENT '��������' AFTER `operationtype`;
  
  
ALTER TABLE `systemlog_his`   
CHANGE `operationtype` `operationtype` INT(11) NULL  COMMENT '��������',
ADD COLUMN `operationname` VARCHAR(20) NULL  COMMENT '��������' AFTER `operationtype`;

alter table fastquery_user add column `showConfig_code` varchar(100)  COMMENT '��ʾ����';

-- ----------------------------
-- �û�������ʷ��
-- ----------------------------
DROP TABLE IF EXISTS  `user_password_his` ;
CREATE TABLE `user_password_his`(  
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `tenand_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL COMMENT '�û�id',
  `password` VARCHAR(60) NOT NULL COMMENT '����',
  `modifytime` DATETIME NOT NULL COMMENT '�޸�ʱ��',
  PRIMARY KEY (`id`)
);

ALTER TABLE `user`   
  ADD COLUMN `realname` VARCHAR(20) NULL  COMMENT '�û�����' AFTER `password`,
  ADD COLUMN `login_failure_count` INT(4) DEFAULT 0  NULL  COMMENT '��¼ʧ�ܴ���',
  ADD COLUMN `first_login_flag` INT(1) DEFAULT 0  NULL  COMMENT '�״ε�¼���������ã����',
  ADD COLUMN `pass_modifytime` DATETIME NULL  COMMENT '�����޸�ʱ��',
  ADD COLUMN `pass_chartype` VARCHAR(15) NULL  COMMENT '������������',
  ADD COLUMN `pass_percent` INT(4) DEFAULT 0  NULL  COMMENT '���밲ȫ����';
  
ALTER TABLE `sysparameter`
  ADD COLUMN `tenant_id` INT(11) NULL COMMENT '�⻧id' AFTER `id`,
  ADD COLUMN `paramlevel` INT(1) DEFAULT 0 NOT NULL COMMENT '��������0ϵͳ1�⻧' AFTER `tenant_id`,
  ADD COLUMN `c_rules` VARCHAR(255) NULL,
  ADD COLUMN `c_messages` VARCHAR(255) NULL ;
  
ALTER TABLE `sysparameter`   
  CHANGE `paramtype` `paramtype` VARCHAR(50) CHARSET gbk COLLATE gbk_bin NULL;
ALTER TABLE `sysparameter`   
  DROP INDEX `unique_index_sysparameter`,
  ADD  UNIQUE INDEX `unique_index_sysparameter` (`paramitem`, `tenant_id`);

-- ---------------------------
-- ��ɫȨ��ά����������ɫ���ű����ڽ�ɫ����һ��ά���ֶΣ�0-�����˺Ͳ���ά����1-��Ʒά��
-- ---------------------------
ALTER TABLE role ADD COLUMN permissionsettype VARCHAR(1);

DROP TABLE IF EXISTS `role_department`;
CREATE TABLE `role_department` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
`tenant_id` INT(11) NOT NULL COMMENT '�⻧id',
  `role_id` INT(11) NOT NULL COMMENT '��ɫid',
  `department` VARCHAR(2) NOT NULL COMMENT '���Ŵ���',
  PRIMARY KEY (`id`)
);

-- ----------------------------
-- ��ɫ�����˹�ϵģ��Լ��
-- ----------------------------
ALTER TABLE `role_department` ADD CONSTRAINT `fk_role_department_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `role_department` ADD CONSTRAINT fk_role_department_role_id FOREIGN KEY (`role_id`) REFERENCES `role` (`id`);
create unique index unique_index_role_department on role_department (tenant_id,role_id,department);



-- ----------------------------
-- �û���ɫΨһ����
-- ----------------------------
create unique index unique_index_user_role on user_role (tenant_id,user_id,role_id);


ALTER  TABLE systemlogfielddetail MODIFY  oldvalue VARCHAR(2048) COMMENT '�޸�ǰ��ֵ' ;
ALTER  TABLE systemlogfielddetail MODIFY  newvalue VARCHAR(2048) COMMENT '�޸ĺ��ֵ' ;
ALTER  TABLE systemlogfielddetail_his MODIFY  oldvalue VARCHAR(2048) COMMENT '�޸�ǰ��ֵ' ;
ALTER  TABLE systemlogfielddetail_his MODIFY  newvalue VARCHAR(2048) COMMENT '�޸ĺ��ֵ' ;





-- ----------------------------
-- �û����޸�
-- ----------------------------
ALTER TABLE `user`   
  ADD COLUMN `api_flag` INT(1) DEFAULT 0 NULL AFTER `pass_percent`,
  ADD COLUMN `api_password` VARCHAR(64) NULL AFTER `api_flag`;

-- ----------------------------
-- �ӿ�ͬ��״̬��
-- ----------------------------
CREATE TABLE taapi_sync_status (
	`low_id` VARCHAR(20) NOT NULL DEFAULT '',
	`sync_user_id` INT(11) NOT NULL DEFAULT 0,
	`sync_date` INT(8) NOT NULL DEFAULT 0 ,
	`sync_status` INT(1) NOT NULL DEFAULT 0,
	PRIMARY KEY (`low_id`)
);

-- ----------------------------
-- �ӿ�������ˮ��
-- ----------------------------
CREATE TABLE `taapi_request_flow_api`(  
	`low_id` VARCHAR(20) NOT NULL COMMENT '�ӿ���ˮid',
	`tenant_id` INT(11) COMMENT '�⻧��',
	`c_content` TEXT COMMENT '�ӿ�����',
	`c_result` TEXT COMMENT '���ؽ��',
	`create_date` DATETIME COMMENT '����ʱ��',
	PRIMARY KEY (`low_id`)
);

-- ----------------------------
-- �ӿڲ�����¼��
-- ----------------------------
CREATE TABLE `taapi_action_recode_api` (
	`low_id` varchar(20) NOT NULL,
	`tenant_id` int(11) DEFAULT NULL,
	`user_id` int(11) DEFAULT NULL,
	`c_function` varchar(64) DEFAULT NULL,
	`c_action` varchar(8) DEFAULT NULL,
	`c_group` varchar(1) DEFAULT NULL,
	`c_content` text ,
	`d_effective_date` int(8) DEFAULT NULL,
	`d_create_date` int(8) DEFAULT NULL,
	`modify_flg` int(1) DEFAULT '0',
	`modify_user_id` int(11) DEFAULT NULL,
	`modify_date` int(8) DEFAULT NULL,
	`status` int(1) DEFAULT '1',
	PRIMARY KEY (`low_id`)
); 

-- ----------------------------
-- �ӿ������޸���־��
-- ----------------------------
CREATE TABLE taapi_content_log_api (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR(20) NOT NULL DEFAULT '',
	`content_last` text ,
	`modify_user_id` int(11) DEFAULT NULL,
	`modify_date` int(8) DEFAULT NULL,
	PRIMARY KEY (`id`)
);

-- ----------------------------
-- �ӿڹ��ܱ�
-- ----------------------------
CREATE TABLE `taapi_function` (
	`tenant_id` int(11) NOT NULL,
	`c_function` varchar(64) NOT NULL,
	`c_function_name` varchar(64) NOT NULL,
	PRIMARY KEY (`tenant_id`,`c_function`)
);

-- ----------------------------
-- �û��ӿڹ���Ȩ�ޱ�
-- ----------------------------
CREATE TABLE `taapi_function_auth` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`user_id` int(11) NOT NULL,
	`c_function` varchar(64) NOT NULL,
	PRIMARY KEY (`id`)
);


-- ----------------------------
-- ��Ʒ��Ϣ��ʱ��
-- ----------------------------
CREATE TABLE `ta_tfundinfo_api` (
	`l_rowid` INT NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR (20) DEFAULT ' ' NULL,
	`d_create_date` INT (8) DEFAULT 0 NOT NULL,
	`d_effective_date` INT (8) DEFAULT 0 NULL,
	`c_tenantid` VARCHAR (20) NOT NULL DEFAULT ' ',
	`c_tacode` VARCHAR (2) NULL DEFAULT ' ',
	`c_fundcode` VARCHAR (12) NOT NULL DEFAULT ' ',
	`c_fundname` VARCHAR (40) NULL DEFAULT ' ',
	`c_fundcharacter` VARCHAR (80) NULL DEFAULT ' ',
	`c_fundstatus` VARCHAR (1) NULL DEFAULT ' ',
	`c_managercode` VARCHAR (10) NULL DEFAULT ' ',
	`c_trusteecode` VARCHAR (3) NULL DEFAULT ' ',
	`c_subtemplatecode` VARCHAR (12) NULL DEFAULT ' ',
	`c_fundtype` VARCHAR (1) NULL DEFAULT ' ',
	`c_netvaluetype` VARCHAR (1) NULL DEFAULT ' ',
	`c_launchtype` VARCHAR (1) NULL DEFAULT '1',
	`c_investorientation` VARCHAR (1) NULL DEFAULT ' ',
	`c_sharetypes` VARCHAR (2) NULL DEFAULT 'A',
	`c_isetf` VARCHAR (1) NULL DEFAULT ' ',
	`c_isqdii` VARCHAR (1) NULL DEFAULT ' ',
	`c_isforeigncurrency` VARCHAR (1) NULL DEFAULT ' ',
	`c_isyuebao` VARCHAR (1) NULL DEFAULT ' ',
	`c_isshortcyclefinance` VARCHAR (1) NULL DEFAULT ' ',
	`c_isguarantedfund` VARCHAR (1) NULL DEFAULT ' ',
	`c_isstructed` VARCHAR (1) NULL DEFAULT ' ',
	`c_isgraded` VARCHAR (1) NULL DEFAULT ' ',
	`c_fundenglishname` VARCHAR (40) NULL DEFAULT ' ',
	`c_moneytype` VARCHAR (3) NULL DEFAULT '156',
	`l_netprecision` INT (11) NULL DEFAULT '4',
	`c_risklevel` VARCHAR (1) NULL DEFAULT ' ',
	`f_issueprice` DECIMAL (7, 4) NULL DEFAULT '1.0000',
	`d_issuedate` INT (11) NULL DEFAULT '0',
	`d_issueenddate` INT (11) NULL DEFAULT '0',
	`d_setupdate` INT (11) NULL DEFAULT '0',
	`f_maxissuebala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_minissuebala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`l_minaccocount` INT (11) NULL DEFAULT '0',
	`l_maxaccocount` INT (11) NULL DEFAULT '0',
	`f_maxredeemratio` DECIMAL (9, 8) NULL DEFAULT '0.10000000',
	`c_issuetype` VARCHAR (1) NULL DEFAULT ' ',
	`f_factcollect` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`d_failuredate` INT (11) NULL DEFAULT '0',
	`f_allotratio` DECIMAL (9, 8) NULL DEFAULT '0.00000000',
	`c_bonustype` VARCHAR (1) NULL DEFAULT '1',
	`c_sharedetail` VARCHAR (1) NULL DEFAULT '1',
	`d_verificationdate` INT (11) NULL DEFAULT '0',
	`d_lastverificationdate` INT (11) NULL DEFAULT '0',
	`c_exptzjysetupdata` VARCHAR (1) NULL DEFAULT ' ',
	`c_changefifo` VARCHAR (1) NULL DEFAULT '1',
	`c_fixeddividway` VARCHAR (1) NULL DEFAULT ' ',
	`c_autosetupflag` VARCHAR (1) NULL DEFAULT '1',
	`f_maxallotasset` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_maxallotshares` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_maxallot` DECIMAL (9, 8) NULL DEFAULT '0.00000000',
	`c_excessallot` VARCHAR (1) NULL DEFAULT ' ',
	`c_extradealtype` VARCHAR (1) NULL DEFAULT ' ',
	`c_exceedpart` VARCHAR (1) NULL DEFAULT ' ',
	`f_maxaddbalance` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`c_exceedflag` VARCHAR (1) NULL DEFAULT ' ',
	`d_lastsubdate` INT (11) NULL DEFAULT '0',
	`c_orifundstatus` VARCHAR (1) NULL DEFAULT ' ',
	`c_checknetvalue` VARCHAR (1) NULL DEFAULT ' ',
	`c_checkshare` VARCHAR (1) NULL DEFAULT ' ',
	`c_liqbatchno` VARCHAR (1) NULL DEFAULT '1',
	`f_parvalue` DECIMAL (7, 4) NULL DEFAULT '1.0000',
	`c_factcollectresult` VARCHAR (1) NULL DEFAULT ' ',
	`d_alimitenddate` INT (11) NULL DEFAULT '0',
	`d_contractbegdate` INT (11) NULL DEFAULT '0',
	`d_appenddate` INT (11) DEFAULT '0',
	`d_lastmodify` INT (11) DEFAULT '0',
	`f_managerratio` DECIMAL (9, 8) NULL DEFAULT '0.00000000',
	`f_minasset` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`c_department` VARCHAR (2) NULL DEFAULT ' ',
	`c_nominalhold` VARCHAR (1) NULL DEFAULT ' ',
	`l_slimitday` INT (11) NULL DEFAULT '0',
	`c_ispublishtotalvalue` VARCHAR (1) NULL DEFAULT '1',
	PRIMARY KEY(l_rowid),
	UNIQUE KEY `uidx_tfundinfo` (
		`c_fundcode`,
		`c_tenantid`,
		`d_create_date`
	),
	KEY `idx_tfundinfo_fundstatus` (
		`c_fundstatus`,
		`c_liqbatchno`,
		`c_tenantid`
	)
);

-- ----------------------------
-- ��Ʒ������ʱ��
-- ----------------------------
CREATE TABLE `ta_tfundinfoprecision_api` (
	`l_rowid` INT NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR (20) DEFAULT ' ' NULL,
	`d_create_date` INT (8) DEFAULT 0 NOT NULL,
	`d_effective_date` INT (8) DEFAULT 0 NULL,
	`c_tenantid` VARCHAR (20) NOT NULL DEFAULT ' ',
	`c_tacode` VARCHAR (2) NULL DEFAULT ' ',
	`c_fundcode` VARCHAR (12) NOT NULL DEFAULT ' ',
	`c_farecltprecision` VARCHAR (1) NULL DEFAULT ' ',
	`c_balanceprecision` VARCHAR (1) NULL DEFAULT ' ',
	`c_shareprecision` VARCHAR (1) NULL DEFAULT ' ',
	`c_bonusprecision` VARCHAR (1) NULL DEFAULT ' ',
	`c_interestprecision` VARCHAR (1) NULL DEFAULT ' ',
	`c_assetprecision` VARCHAR (1) NULL DEFAULT ' ',
	PRIMARY KEY(l_rowid),
	UNIQUE KEY `uidx_tfundinfoprecision` (
		`c_fundcode`,
		`c_tenantid`,
		`d_create_date`
	)
);

-- ----------------------------
-- ��Ʒ������Ϣ��ʱ��
-- ----------------------------
CREATE TABLE `ta_tfundsetupinfo_api` (
	`l_rowid` INT NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR (20) DEFAULT ' ' NULL,
	`d_create_date` INT (8) DEFAULT 0 NOT NULL,
	`d_effective_date` INT (8) DEFAULT 0 NULL,
	`c_tenantid` VARCHAR (20) NOT NULL DEFAULT ' ',
	`c_fundcode` VARCHAR (12) NOT NULL DEFAULT ' ',
	`c_agencyno` VARCHAR (9) NULL DEFAULT ' ',
	`c_interesttype` VARCHAR (1) NULL DEFAULT ' ',
	`l_intereststartday` INT (11) NULL DEFAULT '0',
	`d_interestenddate` INT (11) NULL DEFAULT '0',
	`d_distributedate` INT (11) NULL DEFAULT '0',
	PRIMARY KEY(l_rowid),
	UNIQUE KEY `uidx_tfundsetupinfo` (
		`c_fundcode`,
		`c_agencyno`,
		`c_tenantid`,
		`d_create_date`
  )
);

-- ----------------------------
-- ��������������ʱ��
-- ----------------------------
CREATE TABLE `ta_tarlimit_api` (
	`l_rowid` INT NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR (20) DEFAULT ' ' NULL,
	`d_create_date` INT (8) DEFAULT 0 NOT NULL,
	`d_effective_date` INT (8) DEFAULT 0 NULL,
	`c_tenantid` VARCHAR (20) NOT NULL DEFAULT ' ',
	`c_tacode` VARCHAR (2) NULL DEFAULT ' ',
	`c_fundcode` VARCHAR (12) NOT NULL DEFAULT ' ',
	`c_custtype` VARCHAR (1) NULL DEFAULT ' ',
	`c_agencyno` VARCHAR (9) NULL DEFAULT ' ',
	`f_ominbala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_stepbala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_omaxbala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_hmaxratio` DECIMAL (9, 8) NULL DEFAULT '0.00000000',
	`f_hmaxbala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_rminshares` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_hminshares` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_cminshares` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_rationminbala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_switchinbala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_rationredeemmin` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_gradediff` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_hminbala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_maxbidsamount` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_maxsumbidsamount` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_maxredsvol` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_maxsumredsvol` DECIMAL (16, 2) NULL DEFAULT '0.00',
	`f_rationmaxbala` DECIMAL (16, 2) NULL DEFAULT '0.00',
	PRIMARY KEY(l_rowid),
	UNIQUE KEY `uidx_tarlimit` (
		`c_fundcode`,
		`c_agencyno`,
		`c_custtype`,
		`c_tacode`,
		`c_tenantid`,
		`d_create_date`
	)
);

-- ----------------------------
-- ������ϵ��ʱ��
-- ----------------------------
CREATE TABLE `ta_tsalequalify_api` (
	`l_rowid` INT NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR (20) DEFAULT ' ' NULL,
	`d_create_date` INT (8) DEFAULT 0 NOT NULL,
	`d_effective_date` INT (8) DEFAULT 0 NULL,
	`c_tenantid` VARCHAR (20) NOT NULL DEFAULT ' ',
	`c_tacode` VARCHAR (2) NULL DEFAULT ' ',
	`c_fundcode` VARCHAR (12) NOT NULL DEFAULT ' ',
	`c_agencyno` VARCHAR (9) NULL DEFAULT ' ',
	`c_issaleflag` VARCHAR (1) NULL DEFAULT ' ',
	`c_subtemplatecode` VARCHAR (12) NULL DEFAULT ' ',
	PRIMARY KEY(l_rowid),
	UNIQUE KEY `uidx_tsalequalify` (
		`c_fundcode`,
		`c_agencyno`,
		`c_tenantid`,
		`d_create_date`
	)
);

-- ----------------------------
-- ������ʲ�����
-- ----------------------------
CREATE TABLE `ta_tfundbelongasset_api` (
	`l_rowid` INT NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR (20) DEFAULT ' ' NULL,
	`d_create_date` INT (8) DEFAULT 0 NOT NULL,
	`d_effective_date` INT (8) DEFAULT 0 NULL,
	`c_tenantid` VARCHAR(20) NOT NULL DEFAULT ' ',
	`c_tacode` VARCHAR(2) NULL DEFAULT ' ',
	`c_fundcode` VARCHAR(12) NOT NULL DEFAULT ' ',
	`c_businflag` VARCHAR(2) NULL DEFAULT ' ',
	`c_othercode` VARCHAR(12) NULL DEFAULT '*',
	`l_minday` INT(11) NULL DEFAULT '0',
	`l_maxday` INT(11) NULL DEFAULT '0',
	`f_ratio` DECIMAL(9,8) NULL DEFAULT '0.00000000',
	`c_agencyno` VARCHAR(9) NULL DEFAULT '*',
	PRIMARY KEY(l_rowid),
	UNIQUE KEY `uidx_tfundbelongasset` (`c_fundcode`,`c_businflag`,`c_othercode`,c_agencyno, `l_minday`,`l_maxday`,`c_tenantid`,d_create_date)
);

-- ----------------------------
-- �������Ʊ�
-- ----------------------------
CREATE TABLE `ta_tfaarlimit_api` (
	`l_rowid` int(11) NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR (20) DEFAULT ' ' NULL,
	`d_create_date` INT (8) DEFAULT 0 NOT NULL,
	`d_effective_date` INT (8) DEFAULT 0 NULL,
	`c_tenantid` varchar(20) NOT NULL DEFAULT ' ',
	`c_tacode` varchar(2) NULL DEFAULT ' ',
	`c_fundcode` varchar(12) NOT NULL DEFAULT ' ',
	`c_custtype` varchar(1) NOT NULL DEFAULT ' ',
	`c_faaragencytype` varchar(1) NOT NULL DEFAULT ' ',
	`c_agencyno` varchar(9) NOT NULL DEFAULT ' ',
	`f_maxallotbala` decimal(16,2) NULL DEFAULT '0.00',
	`c_largechangelimit` varchar(1) NULL DEFAULT ' ',
	PRIMARY KEY (`l_rowid`),
	UNIQUE KEY `uidx_tfaarlimit` (`c_fundcode`,`c_custtype`,`c_agencyno`,`c_faaragencytype`,`c_tenantid`, d_create_date)
);

-- ----------------------------
-- ��չ������ʱ��
-- ----------------------------
CREATE TABLE `ta_textparameter_api` (
	`l_rowid` INT NOT NULL AUTO_INCREMENT,
	`low_id` VARCHAR (20) DEFAULT ' ' NULL,
	`d_create_date` INT (8) DEFAULT 0 NOT NULL,
	`d_effective_date` INT (8) DEFAULT 0 NULL,
	`c_tenantid` VARCHAR (20) NOT  NULL DEFAULT ' ',
	`c_paramitem` VARCHAR (40) NULL DEFAULT ' ',
	`c_paramvalue` VARCHAR (255) NULL DEFAULT ' ',
	`c_tacode` VARCHAR (2) NULL DEFAULT '*',
	`c_managercode` VARCHAR (10) NULL DEFAULT '*',
	`c_fundcode` VARCHAR (12) NULL DEFAULT '*',
	`c_agencyno` VARCHAR (9) NULL DEFAULT '*',
	`c_describe`   VARCHAR (100)    DEFAULT ' '   NULL,
	PRIMARY KEY(l_rowid),
	UNIQUE KEY `uidx_textparameter` (
		`c_paramitem`,
		`c_fundcode`,
		`c_agencyno`,
		`c_managercode`,
		`c_tacode`,
		`c_tenantid`,
		`d_create_date`
	)
);


-- ----------------------------
-- �ӿڲ�����¼���޸�
-- ----------------------------
ALTER TABLE `taapi_action_recode_api`   
  ADD COLUMN `ip` VARCHAR(100) NULL AFTER `status`;


-- ----------------------------
-- �ӿڹ��ܱ��޸�
-- ----------------------------
ALTER TABLE `taapi_function`   
  ADD COLUMN `id` INT(11) NOT NULL AUTO_INCREMENT FIRST,
  CHANGE `tenant_id` `c_tenantid` VARCHAR(20) NULL, 
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (`id`);
  
ALTER TABLE `taapi_function_auth`   
  ADD COLUMN `tenant_id` INT(11) NOT NULL AFTER `id`;
  
  
  
  -- M201708180345 begin
CREATE TABLE `user_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `resource_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_user_resource` (`user_id`,`resource_id`,`tenant_id`),
  KEY `fk_user_resource_resource_id` (`resource_id`),
  KEY `fk_user_resource_tenant_id` (`tenant_id`),
  CONSTRAINT `fk_user_resource_resource_id` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `fk_user_resource_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`),
  CONSTRAINT `fk_user_resource_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ;


-- M201708180345 end


-- ��Ȩҳ���
DROP TABLE IF EXISTS resource_auth;
CREATE TABLE resource_auth
(
	id                     			INT(11)     		NOT NULL 			AUTO_INCREMENT,		
	c_tenantid                      VARCHAR(20)     	DEFAULT ' '     	NOT NULL,
	c_code                        	VARCHAR(50)      	DEFAULT ' '     	NOT NULL,
	c_name                     		VARCHAR(50)      	DEFAULT ' '        	NOT NULL,
	c_category                   	VARCHAR(50)      	DEFAULT ' '        	NOT NULL,
	d_authable                		INT(1)          	DEFAULT 0         	NOT NULL,
	c_description              		VARCHAR(100)     	DEFAULT ' '        	NOT NULL,
PRIMARY KEY(id)
);

-- ��־��
ALTER TABLE systemlog 		ADD 	auth_user_id		INT(11)   	DEFAULT 0		NOT NULL;
-- ��ʷ��־��
ALTER TABLE systemlog_his	ADD 	auth_user_id		INT(11)   	DEFAULT 0		NOT NULL;




ALTER TABLE role_manager ADD tacode VARCHAR(2) NOT NULL DEFAULT '';
ALTER TABLE `role_manager` drop foreign key `fk_role_manager_tenant_id` ;
ALTER TABLE `role_manager` drop foreign key fk_role_manager_role_id ;


ALTER TABLE role_manager DROP INDEX unique_index_role_manager;
ALTER TABLE role_manager ADD UNIQUE KEY unique_index_role_manager(tenant_id,role_id,mangercode,tacode);

ALTER TABLE `role_manager` ADD CONSTRAINT `fk_role_manager_tenant_id` FOREIGN KEY (`tenant_id`) REFERENCES `tenant` (`id`);
ALTER TABLE `role_manager` ADD CONSTRAINT fk_role_manager_role_id FOREIGN KEY (`role_id`) REFERENCES `role` (`id`);





-- ----------------------------
-- ���������Ϣ��
-- ----------------------------
DROP TABLE IF EXISTS treportfaxcust;
CREATE TABLE treportfaxcust (
	l_rowid 		VARCHAR(32) 	NOT NULL,
	c_tenantid 		VARCHAR(20) 	DEFAULT ' ' 	NOT NULL COMMENT '�⻧����',
	c_tacode 		VARCHAR(10) 	DEFAULT ' ' 	NOT NULL COMMENT 'TA����',
	c_type 			VARCHAR(1) 		DEFAULT ' ' 	NOT NULL COMMENT '�����������',
	c_faxcustno 	VARCHAR(9) 		DEFAULT ' ' 	NOT NULL COMMENT '������/�й��д���',
	c_faxno 		VARCHAR(80) 	DEFAULT ' ' 	NOT NULL COMMENT '�������',
	PRIMARY KEY (l_rowid)
);
CREATE UNIQUE INDEX uidx_treportfaxcust ON treportfaxcust(c_faxcustno ASC, c_type ASC, c_tacode ASC, c_tenantid ASC);


-- ----------------------------
-- ���淢����־��
-- ----------------------------
DROP TABLE IF EXISTS tfaxsendinfo;
CREATE TABLE tfaxsendinfo (
	l_rowid 		VARCHAR(32) 	NOT NULL,
	c_tenantid 		VARCHAR(20) 	DEFAULT ' ' 	NOT NULL COMMENT '�⻧����',
	c_tacode 		VARCHAR(10) 	DEFAULT ' ' 	NOT NULL COMMENT 'TA����',
	c_type 			VARCHAR(1) 		DEFAULT ' ' 	NOT NULL COMMENT '�����������', 
	c_faxcustno 	VARCHAR(9) 		DEFAULT ' ' 	COMMENT '������/�й��д���',
	c_rptcode 		VARCHAR(10) 	DEFAULT ' ' 	NOT NULL COMMENT '��������',
	c_faxno 		VARCHAR(20) 	DEFAULT ' ' 	NOT NULL COMMENT '�������',
	c_businessdate 	VARCHAR(8) 		DEFAULT ' ' 	COMMENT 'ҵ������',        
	c_sender 		VARCHAR(20) 	DEFAULT ' ' 	COMMENT '������',
	c_senddate 		VARCHAR(20) 	DEFAULT ' ' 	COMMENT '��������',
	c_filePath 		VARCHAR(200) 	DEFAULT ' ' 	COMMENT '�����ļ�',
	c_addressee 	VARCHAR(40) 	DEFAULT ' ' 	COMMENT '�ռ���',
	c_getdate 		VARCHAR(20) 	DEFAULT ' ' 	COMMENT '�ռ�ʱ��',
	l_status 		INT(2) 			NOT NULL 		COMMENT '����״̬',
	c_message 		VARCHAR(80) 	DEFAULT ' ' 	COMMENT '������Ϣ',	
	c_reportparam 	VARCHAR(1000) 	DEFAULT ' ' 	COMMENT '��������',
	PRIMARY KEY (l_rowid)
);
