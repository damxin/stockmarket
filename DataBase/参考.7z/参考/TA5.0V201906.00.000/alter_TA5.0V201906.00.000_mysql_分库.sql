

-- ɾ����������
call RELIEVEFLASHBACK();



DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tconfirm' 
			   and column_name='f_usdmonthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm ADD f_usdmonthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tconfirm_70' 
			   and column_name='f_usdmonthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm_70 ADD f_usdmonthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tconfirm_71' 
			   and column_name='f_usdmonthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm_71 ADD f_usdmonthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tconfirm_7071' 
			   and column_name='f_usdmonthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm_7071 ADD f_usdmonthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_taccorequest' and column_name='c_importflag';
			if v_rowcount = 0 then
				ALTER TABLE ta_taccorequest ADD c_importflag                char(1)         DEFAULT ' '        ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tconfirm' and column_name='f_mgrincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm ADD f_mgrincome DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tconfirm_70' and column_name='f_mgrincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm_70 ADD f_mgrincome DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tconfirm_71' and column_name='f_mgrincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm_71 ADD f_mgrincome DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tconfirm_7071' and column_name='f_mgrincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm_7071 ADD f_mgrincome DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.views where table_schema= database_name and table_name='ta_tcheckresults' ;
			if v_rowcount >= 1 then
				drop view  ta_tcheckresults;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            DECLARE database_name VARCHAR(100);
            SELECT DATABASE() INTO database_name;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= database_name AND table_name='ta_tcheckresults';
            IF v_rowcount = 0 THEN
               create table ta_tcheckresults
                           (c_tenantid        varchar(20) not null,
                            c_tacode          varchar(2) not null,
                            d_cdate           int(8),
                            c_type            char(1),
                            c_databaseno      varchar(5),
                            c_requestno       varchar(24) not null,
                            c_fundacco        varchar(12),
                            c_businflag       varchar(2),
                            c_netno           varchar(9),
                            c_agencyno        varchar(9) not null,
                            c_memo            varchar(60),
                            c_fundcode        varchar(12),
                            l_shardingno      int(11),
                            c_liqbatchno      int(11),
                            f_failedbalance   DECIMAL(16,2),
                            f_failedshares    DECIMAL(16,2),
                            c_chkstatus       char(1),
                            c_manualdealflag  varchar(1) default ' ',
                            c_nodealflag      varchar(1),
                            c_cause           varchar(4) default ' ',
                            f_backfareagio    DECIMAL(5,4),
                            f_tradefare       DECIMAL(16,2),
                            f_confirmratio    DECIMAL(9,8),
                            f_agio            DECIMAL(5,4),
                            f_price           DECIMAL(16,8),
                            d_requestdate     int(8) not null,
                            f_manualtradefare DECIMAL(16,2),
                            f_otherprice      DECIMAL(16,8), 
               PRIMARY KEY(c_agencyno, d_requestdate, c_requestno, c_tacode, c_tenantid)
               );
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

-- ������ begin
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= DATABASE() AND table_name='ta_tjointly';
            IF v_rowcount = 0 THEN
                create table ta_tjointly
                (
                  c_tenantid        varchar(20) not null default ' ',
                  c_tacode          varchar(2) not null default ' ',
                  c_outbusinflag     varchar(3),
                  d_requestdate       int(8) default 0,
                  d_requesttime       int(6) default 0,
                  c_requestno        varchar(24),
                  c_agencyno         varchar(9),
                  c_netno            varchar(9),
                  c_bankcustno       varchar(7),
                  c_fundacco         varchar(12),
                  c_custname         varchar(120),
                  c_shortname        varchar(20),
                  c_custtype         varchar(1),
                  c_identitytype     varchar(1),
                  c_identityno       varchar(30),
                  c_mobileno         varchar(32),
                  f_balance          decimal(16,2),
                  f_confirmbalance   decimal(16,2),
                  c_fundcode         varchar(6),
                  c_bankacco         varchar(28),
                  d_cdate             int(8) default 0,
                  c_cserialno        varchar(20),
                  c_fundaccoinfund   varchar(12),
                  c_custnameinfund   varchar(120),
                  c_identitynoinfund varchar(30),
                  c_taflag           varchar(1),
                  c_status           varchar(1),
                  c_cause            varchar(36),
                  c_institutionno    varchar(3),
                  c_tradeacco        varchar(24),
                  c_childnetno       varchar(9),
                  c_idcard18len      varchar(1),
                  d_factdate         int(8) default 0,
                  c_cardbusinflag    varchar(3),
                  PRIMARY KEY (d_requestdate, c_requestno, c_agencyno, c_netno,c_tacode,c_tenantid)
                );
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= DATABASE() AND table_name='ta_tjointlycust';
            IF v_rowcount = 0 THEN
                create table ta_tjointlycust
                (
                  c_tenantid        varchar(20) not null default ' ',
                  c_tacode          varchar(2) not null default ' ',
                  d_cdate         int(8),
                  c_fundacco      varchar(12),
                  c_agencyno      varchar(9),
                  c_netno         varchar(9),
                  c_tradeacco     varchar(24),
                  c_institutionno varchar(3),
                  c_bankacco      varchar(30),
                  c_childnetno    varchar(9),
                  d_lastmodify      int(8),
                  c_custtype      varchar(1),
                  c_accostatus    varchar(1),
                  PRIMARY KEY (c_fundacco, c_agencyno, c_netno, c_tacode, c_tenantid)
                );
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= DATABASE() AND table_name='ta_tcustjointlyfile';
            IF v_rowcount = 0 THEN
               create table ta_tcustjointlyfile
                    (
                      c_tacode        varchar(2) default ' ',
                      c_tenantid      varchar(20) default ' ',
                      c_fundacco      VARCHAR(12) default ' ',
                      c_agencyno      VARCHAR(9) default ' ',
                      c_tradeacco     VARCHAR(24) default ' ',
                      c_netno         VARCHAR(9) default ' ',
                      c_bankacco      VARCHAR(28) default ' ',
                      c_outbusinflag  CHAR(3) default ' ',
                      c_institutionno VARCHAR(3) default ' ',
                      c_childnetno    VARCHAR(9) default ' ',
                      d_requestdate   int(8) default 0,
                      d_requesttime   int(8) default 0,
                      d_cdate         int(8) default 0,
                      c_custtype      CHAR(1)default ' ',
                      c_managercode   VARCHAR(10) default ' ',
                      c_fundcode      VARCHAR(6) default ' ',
                      c_partition     VARCHAR(32) GENERATED ALWAYS AS (concat(c_tenantid,'_',c_tacode)) VIRTUAL,
                      KEY idx_tcustjointlyfile (c_managercode)
                    )PARTITION BY LIST  COLUMNS(c_partition)
                    (PARTITION `*` VALUES IN ('*'));
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;
-- ������ end

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='c_isincomeinvestdate';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD c_isincomeinvestdate char(1) DEFAULT '';
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='f_fundtotalincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD f_fundtotalincome DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='l_incomemount';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD l_incomemount int(11) DEFAULT 0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='f_totalshares';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD f_totalshares DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='l_minusincomemount';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD l_minusincomemount int(11) DEFAULT 0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int; declare v_tablecount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_tablecount FROM information_schema.tables WHERE table_schema= database_name AND table_type <> 'view' AND table_name='ta_tagencyinfo';
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tagencyinfo' and column_name='c_isnettradeacco';
			if v_tablecount = 1 and v_rowcount = 0 then 
				ALTER TABLE ta_tagencyinfo ADD c_isnettradeacco CHAR(1) DEFAULT '0';
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

-- ta_tuntrdtsfacrossrequest�����ֶ�c_databaseno
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			DECLARE v_rowcount INT;
			DECLARE database_name VARCHAR(100);
			SELECT DATABASE() INTO database_name;
			SELECT COUNT(1) INTO v_rowcount FROM information_schema.columns WHERE table_schema= database_name AND table_name='ta_tuntrdtsfacrossrequest' AND column_name='c_databaseno';
			IF v_rowcount = 0 THEN
				ALTER TABLE ta_tuntrdtsfacrossrequest ADD c_databaseno  varchar(5)  DEFAULT ' ' NOT NULL;
			END IF;
		END$$
DELIMITER ;
	CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= DATABASE() AND table_name='ta_taccotrdnumstat';
            IF v_rowcount = 0 THEN
                create table ta_taccotrdnumstat(
                    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
                    c_tenantid                     varchar(20)     DEFAULT ' '       NOT NULL,
                    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
                    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
                    l_volofbus                     int             DEFAULT 0          NOT NULL,
                    PRIMARY KEY(c_fundacco, c_fundcode, c_tenantid));
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tsalestattoday_td' 
			   and column_name='f_monthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tsalestattoday_td ADD f_monthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        declare v_count INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tsaleyebstat_td' ;
        IF v_isexist > 0 then
            SELECT COUNT(1) INTO v_count FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tsaleyebstat_td' AND CONSTRAINT_NAME = 'PRIMARY' ;
            if v_count > 0 then
                alter table ta_tsaleyebstat_td drop primary key;
				alter table ta_tsaleyebstat_td add primary key(d_holddate, d_cdate, c_fundcode, c_agencyno, c_partnerid, c_tacode, c_tenantid, c_databaseno);
            end if;
        end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;




DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_trequest_tmp' and column_name='f_balsubsed';
			if v_rowcount = 0 then
				ALTER TABLE ta_trequest_tmp ADD f_balsubsed DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_trequest_imp_tmp' and column_name='f_balsubsed';
			if v_rowcount = 0 then
				ALTER TABLE ta_trequest_imp_tmp ADD f_balsubsed DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

-- ���½�����������
call REBUILDFLASHBACK();
commit;

