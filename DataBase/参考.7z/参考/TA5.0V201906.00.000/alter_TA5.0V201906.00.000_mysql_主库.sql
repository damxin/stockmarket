

UPDATE  sys_sysparameter SET param_value = 'TA5.0V201906.00.000' WHERE param_item = 'DatabaseVer' and tenant_code  ='*';

-- ɾ����������
call RELIEVEFLASHBACK();


DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tfundconver_td' ;
        IF v_isexist = 0 THEN
        create table ta_tfundconver_td
        (
        	c_tenantid           varchar(20)    default ' '        not null,
        	c_tacode             varchar(2)     default ' '        not null,
        	c_fundcode           varchar(12)    default ' '        not null,
        	c_othercode          varchar(12)    default ' '        not null,
            c_databaseno         varchar(5)     default ' '        not null,
            PRIMARY KEY(c_fundcode,c_othercode,c_databaseno,c_tacode,c_tenantid)
        );
    	end if;
    END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='TA_TCUSTREGISTERINFO' ;
        IF v_isexist = 0 THEN
        create table TA_TCUSTREGISTERINFO
        (
         c_tenantid        varchar(20),
         c_tacode          varchar(2) ,
         c_fundacco        varchar(12),
         c_agencyno        varchar(9) ,
         c_netno           varchar(9) ,
         c_tradeacco       varchar(24),
         c_tradeaccostatus CHAR(1),
         c_specialaccoflag CHAR(1),
         c_custtype        CHAR(1),
         c_custname        varchar(120),
         c_identitype      CHAR(1),
         c_idcard18len     CHAR(1),
         c_identityno      varchar(30),
         c_accostatus      CHAR(1),
         c_birthday        varchar(8),
	     c_identitynoend   CHAR(1),
		 PRIMARY KEY(C_TACODE, C_TENANTID, c_fundacco,c_agencyno,c_netno,c_tradeacco,c_tradeaccostatus)
		);
    	end if;
    END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='TA_TCUSTREGISTERINFO_today' ;
        IF v_isexist = 0 THEN
        create table TA_TCUSTREGISTERINFO_today
        (
         c_tenantid        varchar(20),
         c_tacode          varchar(2) ,
         c_fundacco        varchar(12),
         c_agencyno        varchar(9) ,
         c_netno           varchar(9) ,
         c_tradeacco       varchar(24),
         c_tradeaccostatus CHAR(1),
         c_specialaccoflag CHAR(1),
         c_custtype        CHAR(1),
         c_custname        varchar(120),
         c_identitype      CHAR(1),
         c_idcard18len     CHAR(1),
         c_identityno      varchar(30),
         c_accostatus      CHAR(1),
         c_birthday        varchar(8),
	     c_identitynoend  CHAR(1),
		 PRIMARY KEY(C_TACODE, C_TENANTID, c_fundacco,c_agencyno,c_netno,c_tradeacco,c_tradeaccostatus)
		);
    	end if;
    END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


truncate table  TA_TCUSTREGISTERINFO;
DROP PROCEDURE IF EXISTS addtacustinfo;
DELIMITER $$
CREATE PROCEDURE addtacustinfo()
BEGIN
  DECLARE v_c_tacode CHAR(2) DEFAULT '*';
  DECLARE v_c_taname CHAR(60) DEFAULT ' ';
  DECLARE v_c_web CHAR(30) DEFAULT ' ';
  DECLARE v_c_tel CHAR(30) DEFAULT ' ';
  DECLARE v_c_des CHAR(100) DEFAULT ' ';
  DECLARE v_dbalias CHAR(32);
  DECLARE v_sql TEXT;
  DECLARE v_cols TEXT;
  DECLARE done INT DEFAULT FALSE;
  DECLARE v_cur CURSOR FOR
  select c_dbalias from ta_tpoolinfo where c_pooltype = '1' and c_isused ='1' ;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  OPEN v_cur;
  table_loop:LOOP
    FETCH v_cur INTO v_dbalias;
    IF done THEN
       LEAVE table_loop;
    END IF;  
  SET v_sql= CONCAT('insert into TA_TCUSTREGISTERINFO
                       (   C_TENANTID,   C_TACODE,   C_FUNDACCO,       C_AGENCYNO,
                        C_NETNO,      C_TRADEACCO,C_TRADEACCOSTATUS,  c_specialaccoflag,
                        C_CUSTTYPE,   C_CUSTNAME, C_IDENTITYPE,     C_IDCARD18LEN,
                        C_IDENTITYNO, C_ACCOSTATUS,c_birthday,c_identitynoend
                      )
                     select  b.C_TENANTID,   b.C_TACODE,  b.C_FUNDACCO,  b.C_AGENCYNO,
                      b.C_NETNO,      b.C_TRADEACCO,b.C_TRADEACCOSTATUS,b.c_specialaccoflag,
                      c.C_CUSTTYPE,   c.C_CUSTNAME,  c.C_IDENTITYPE, c.C_IDCARD18LEN,
                      c.C_IDENTITYNO, c.C_ACCOSTATUS ,d.c_birthday,
                   case when substr(c.c_identityno,-1) between ''0'' and ''9'' then substr(c.c_identityno,-1) else ''0'' end c_identitynoend
                    from hs_',v_dbalias,'.ta_tacconet  b,hs_',v_dbalias,'.ta_taccoinfo  c,hs_',v_dbalias,'.ta_tcustomerinfo d
                  where   b.c_tacode =   c.c_tacode
                    and  b.c_tenantid = c.c_tenantid
                    and  b.c_fundacco = c.c_fundacco
                    and  b.c_fundacco = d.c_fundacco');
    PREPARE stmt FROM v_sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END LOOP;
  CLOSE v_cur;
  COMMIT;
END $$
DELIMITER ;
CALL addtacustinfo();


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '590001041' and function_name = 'LS_���ݻؿ�_ת����ϵ���ؿ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '590001041' and function_name = 'LS_���ݻؿ�_ת����ϵ���ؿ�';
            select id into v_taskid from sys_process_task where task_code = 'AccoCheck' and parent_task_code = 'AccoPreDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '510000102' and function_name = 'LS_�ؿ�����_3���˻����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '510000102' and function_name = 'LS_�ؿ�����_3���˻����';    
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '520000001' and function_name = 'LS_�ļ����_���˻�����(���)';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '520000001' and function_name = 'LS_�ļ����_���˻�����(���)';    
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '530000000' and function_name = 'LS_FTP����_�ļ��ϴ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '530000000' and function_name = 'LS_FTP����_�ļ��ϴ�';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '530000001' and function_name = 'LS_FTP����_�ļ�����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '530000001' and function_name = 'LS_FTP����_�ļ�����';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.baseConCtrlStat' and function_name = 'LS_��������_�����ж�����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.baseConCtrlStat' and function_name = 'LS_��������_�����ж�����';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeConCtrlStat' and function_name = 'LS_��������_���жȹ��߷ֿ�ͳ��';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeConCtrlStat' and function_name = 'LS_��������_���жȹ��߷ֿ�ͳ��';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.sharecommit.api.ShareCommitService.accoTempDeal' and function_name = '�˻�����ǰ��ʱ����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.sharecommit.api.ShareCommitService.accoTempDeal' and function_name = '�˻�����ǰ��ʱ����';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


call add_process_service('com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeConCtrlStat', 'LS_��������_���жȹ��߷ֿ�ͳ��', '0', 'LS_��������_���жȹ��߷ֿ�ͳ��', '2', '{"flag":"0"}', 'liqBatchNo;tenantCode;longTaCode;flag;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.baseConCtrlStat', 'LS_��������_���ж�����ռ���ж�', '0', 'LS_��������_���ж�����ռ���ж�', '1', '{"type":"0"}', 'longTaCode;tenantCode;flag;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.inputreqdata.api.InputReqDataService.checkResultsDataDeleteSub', '��ս�������ʷ���������-�ֿ�', '0', '��ս�������ʷ���������-�ֿ�', '2', '', 'tenantCode;longTaCode;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');



call add_process_service('510000102', 'LS_�ؿ�����_�ͻ��Ǽ�UFT����ؿ�', '0', '', '3', '', 'tenantCode;longTaCode', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode', '');
call add_process_service('520000001', 'LS_�ļ����_�ͻ��Ǽ���Ϣ����', '0', '', '5', '', 'tenantCode;longTaCode', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode', '');
call add_process_service('com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.custRegisterInfoDelete', '�����ʷ�ͻ��Ǽ���Ϣ��ʱ����', '0', '�����ʷ�ͻ��Ǽ���Ϣ��ʱ����', '1', '', 'tenantCode;fundAcco;longTaCode;liqBatchNo;requestDate;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.custRegisterInfoSubToBase', 'ͳ�ƿͻ��Ǽ���Ϣ���ݵ�����', '0', 'ͳ�ƿͻ��Ǽ���Ϣ���ݵ�����', '2', '', 'tenantCode;fundAcco;longTaCode;liqBatchNo;requestDate;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.custRegisterInfoUpdate', '���¿ͻ��Ǽ���Ϣ����', '0', '���¿ͻ��Ǽ���Ϣ����', '1', '', 'tenantCode;fundAcco;longTaCode;liqBatchNo;requestDate;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

call add_process_task_service('AccoPreDealStart','*','com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.custRegisterInfoDelete','�����ʷ�ͻ��Ǽ���Ϣ��ʱ����','','19.2');
call add_process_task_service('AccoPreDealStart','*','510000102','LS_�ؿ�����_�ͻ��Ǽ�UFT����ؿ�','','20');
call add_process_task_service('AccoPreDealStart','*','com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.custRegisterInfoUpdate','���¿ͻ��Ǽ���Ϣ����','','20.6');
call add_process_task_service('AccoPreDealStart','*','520000001','LS_�ļ����_�ͻ��Ǽ���Ϣ����','','23');
call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.custRegisterInfoDelete','�����ʷ�ͻ��Ǽ���Ϣ��ʱ����','','147.2');
call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.custRegisterInfoSubToBase','ͳ�ƿͻ��Ǽ���Ϣ���ݵ�����','','147.4');
call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.custRegisterInfoUpdate','���¿ͻ��Ǽ���Ϣ����','','147.6');  

call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.commonflow.inputreqdata.api.InputReqDataService.checkResultsDataDeleteSub','��ս�������ʷ���������-�ֿ�','','68.1');


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        declare v_count INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tlargeholdprofit' ;
        IF v_isexist > 0 then
            SELECT COUNT(1) INTO v_count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tlargeholdprofit' AND column_name = 'f_addshares' ;
            if v_count = 0 then
                ALTER TABLE ta_tlargeholdprofit ADD f_addshares decimal(16,2) default 0;
            end if;
        end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

-- ���ת���Ż�(�����)��Ϣ�༭
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_investorientation', 'Ͷ�ʷ���', 'DictTextView', 'in', null, 10, null, 0, null, null,'C20010', null, 1,null,'1',null,'0',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_businflag', 'ҵ������', 'DictTextView', 'in', null, 11, null, 0, null, null,'dynamicDictionary_bsflag4FundBelongAsset', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_agencyno', '������', 'DictTextView', 'in', null, 12, null, 0, null, null,'dynamicDictionary_selectAllAgencysWithOutTA0', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_fundmethod', '�ʽ�ʽ', 'DictTextView', 'in', null, 13, null, 0, null, null,'C20057', null, 1,null,'1',null,'0',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_tradetype', '���׷�ʽ', 'DictTextView', 'in', null, 14, null, 0, null, null,'C20043', null, 1,null,'1',null,'0',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_orisource', '�ݶ�ԭʼ��Դ', 'DictTextView', 'in', null, 15, null, 0, null, null,'dynamicDictionary_selectAllOrisource', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_sourcetype', '�ݶ���Դ', 'DictTextView', 'in', null, 16, null, 0, null, null,'dynamicDictionary_selectAllSource', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_faretype', '��������', 'DictTextView', 'in', null, 17, null, 0, null, null,'dynamicDictionary_selectFaretype', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_favortype', '�Ż�����', 'DictTextView', 'in', null, 18, null, 0, null, null,'C20170', null, 1,null,'1',null,'0',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_fundPropFavourEdit',  'c_otherinvorit', '�Է�Ͷ�ʷ���', 'DictTextView', 'in', null, 19, null, 0, null, null,'C20010', null, 1,null,'1',null,'0',null,null,null,null,null,null,null);

-- �����Ż���Ϣ�༭
call add_show_component(null, 'sysinfo_saleAgioEdit', 'c_sharetype', '�ݶ����', 'DictTextView', 'in', null, 22, null, 0, null, null,'dynamicDictionary_selectAllShareType', null, 1, null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_saleAgioEdit', 'c_agencyno', '������', 'DictTextView', 'in', null, 24, null, 0, null, null,'dynamicDictionary_selectAllAgencysWithOutTA0ByTA', null, 1, null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_saleAgioEdit', 'c_netno', '����', 'DictTextView', 'in', null, 26, null, 0, null, null,'dynamicDictionary_selectALLNetInfos', null, 1, null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_saleAgioEdit', 'c_businflag', 'ҵ������', 'DictTextView', 'in', null, 35, null, 0, null, null,'dynamicDictionary_selectBusinFlag4saleAgio', null, 1, null,'1',null,'1',null,null,null,null,null,null,null);

-- ���ת���Ż�(������)��Ϣ�༭
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_sharetype', '�ݶ����', 'DictTextView', 'in', null, 13, null, 0, null, null,'dynamicDictionary_selectAllShareType', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_agencyno', '������', 'DictTextView', 'in', null, 14, null, 0, null, null,'dynamicDictionary_selectAllAgencysWithOutTA0', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_businflag', 'ҵ������', 'DictTextView', 'in', null, 15, null, 0, null, null,'dynamicDictionary_bsflag4FundBelongAsset', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_fundmethod', '�ʽ�ʽ', 'DictTextView', 'in', null, 16, null, 0, null, null,'C20057', null, 1,null,'1',null,'0',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_tradetype', '���׷�ʽ', 'DictTextView', 'in', null, 17, null, 0, null, null,'C20043', null, 1,null,'1',null,'0',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_orisource', '�ݶ�ԭʼ��Դ', 'DictTextView', 'in', null, 18, null, 0, null, null,'dynamicDictionary_selectAllOrisource', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_sourcetype', '�ݶ���Դ', 'DictTextView', 'in', null, 19, null, 0, null, null,'dynamicDictionary_selectAllSource', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_faretype', '��������', 'DictTextView', 'in', null, 20, null, 0, null, null,'dynamicDictionary_selectFaretype', null, 1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null, 'sysinfo_specFundFavourEdit', 'c_favortype', '�Ż�����', 'DictTextView', 'in', null, 21, null, 0, null, null,'C20170', null, 1,null,'1',null,'0',null,null,null,null,null,null,null);


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_tablecount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_tablecount FROM information_schema.tables WHERE table_schema= database_name AND table_type <> 'view' AND table_name='ta_tagencybizlimitdate';
			if v_tablecount = 0 then 
				CREATE TABLE ta_tagencybizlimitdate (
					l_rowid              int(11)        NOT NULL   AUTO_INCREMENT,
					c_tenantid           varchar(20)    DEFAULT ' '       NOT NULL,
					c_tacode             varchar(2)     DEFAULT ' '       NOT NULL,
					c_outbusinflag       varchar(3)     DEFAULT ' '       NOT NULL,
					c_agencyno           varchar(9)     DEFAULT ' '       NOT NULL,
					c_netno              varchar(9)     DEFAULT ' '       NOT NULL,
					c_fundcode           varchar(12)    DEFAULT ' '        NOT NULL,
					c_sharetype          char(1)    	DEFAULT ' '       NOT NULL,
					d_bgndate 	 	 int 			default 0,
					d_enddate      		 int 			default 0, 
					PRIMARY KEY (l_rowid) 
				);
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


delete from SYS_DICTIONARY where dict_code = 'C20678' and dict_item in ('037','038');
call add_dictionary(null,'C20678','037','��TAת����','13',null,null);
call add_dictionary(null,'C20678','038','��TAת����','14',null,null);

-- ɾ������ta_trequestyebnet��ͼ��ͬ��
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.views where table_schema= database_name and table_name='ta_trequestyebnet' ;
			if v_rowcount >= 1 then
				drop view  ta_trequestyebnet;
			end if;
			delete  from  ta_tsynctableinfo  where   upper(c_tablename)=upper('ta_trequestyebnet');
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tfundinfo' and column_name='d_monthcdate';
			if v_rowcount = 0 then
				ALTER TABLE ta_tfundinfo ADD d_monthcdate                   int             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tfundinfo' and column_name='l_investdate';
			if v_rowcount = 0 then
				ALTER TABLE ta_tfundinfo ADD l_investdate                   int             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tfundinfo' and column_name='c_siglecurrency';
			if v_rowcount = 0 then
				ALTER TABLE ta_tfundinfo ADD c_siglecurrency                char(1)         DEFAULT ' '        ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_taccorequest' and column_name='c_importflag';
			if v_rowcount = 0 then
				ALTER TABLE ta_taccorequest ADD c_importflag                char(1)         DEFAULT ' '        ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tstaticsharesstat_td' 
			   and column_name='f_monthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tstaticsharesstat_td ADD f_monthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tstaticsharesstat' 
			   and column_name='f_monthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tstaticsharesstat ADD f_monthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tstaticsharesdis' 
			   and column_name='f_monthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tstaticsharesdis ADD f_monthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tconfirmstatdetail_td' 
			   and column_name='f_usdmonthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirmstatdetail_td ADD f_usdmonthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tconfirmstatdetail' 
			   and column_name='f_usdmonthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirmstatdetail ADD f_usdmonthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tliquidatetrusteedetail' 
			   and column_name='f_usdmonthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tliquidatetrusteedetail ADD f_usdmonthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tconfirmstat' 
			   and column_name='f_usdmonthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirmstat ADD f_usdmonthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tsalestat' 
			   and column_name='f_monthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tsalestat ADD f_monthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns 
			 where table_schema= database_name 
			   and table_name='ta_tsalestattoday_td' 
			   and column_name='f_monthincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tsalestattoday_td ADD f_monthincome                   decimal(16,2)             DEFAULT 0          ;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='c_isincomeinvestdate';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD c_isincomeinvestdate char(1) DEFAULT '';
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='f_fundtotalincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD f_fundtotalincome DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='l_incomemount';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD l_incomemount int(11) DEFAULT 0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='f_totalshares';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD f_totalshares DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tincomeinvest_fund' and column_name='l_minusincomemount';
			if v_rowcount = 0 then
				ALTER TABLE ta_tincomeinvest_fund ADD l_minusincomemount int(11) DEFAULT 0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


CALL add_show_component(NULL, 'query_comfirmDataExportQuery', 'c_tacode', 'TA����','string', 'out', NULL,5,100,0,1,1, NULL, NULL, 1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component(NULL,'query_quotationInfoQuery','C_TACODE','TA����','string','out',NULL,5,100,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_requestConfirmQuery','c_tacode','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestConfirmQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_subsConfirmQuery','C_TACODE','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_subsConfirmQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_confirmDetailQuery','C_TACODE','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_confirmDetailQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_accountConfirmQuery','c_tacode','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_accountConfirmQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component(NULL, 'query_tradeBeforeQuery', 'c_tacode', 'TA����','string', 'out', NULL,0,100,0,1,1,null, NULL, 1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL, 'query_tradeBeforeQuery', 'c_fundcode', '�������','string', 'out', NULL,1,100,0,1,1,null, NULL, 1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL, 'query_tradeBeforeQuery', 'fundname','��������','string','out',NULL,5,100,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL, 'query_tradeBeforeQuery', 'c_agencyno', '������','string', 'out', NULL,10,100,0,1,1, NULL, NULL, 1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component(NULL, 'query_batchStatisQuery', 'c_tacode', 'TA����','string', 'out', NULL,0,100,0,1,1, null, NULL, 1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL, 'query_batchStatisQuery', 'c_fundcode', '�������','string', 'out', NULL,1,100,0,1,1, null, NULL, 1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL, 'query_batchStatisQuery', 'fundname','��������','string','out',NULL,5,100,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL, 'query_batchStatisQuery', 'c_agencyno', '������','string', 'out', NULL,10,100,0,1,1, NULL, NULL, 1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_staticShareInfoQuery','C_TACODE','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_staticShareInfoQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_shareDetailQuery','C_TACODE','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_shareDetailQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_historyShareQuery','c_tacode','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_historyShareQuery','c_fundacco','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_shareCurrentInfoQuery','C_TACODE','TA','string','out',NULL,5,100,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_shareCurrentInfoQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component(NULL,'query_frozenDetailQuery','C_TACODE','TA','string','out',NULL,5,100,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_frozenDetailQuery','c_fundacco','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component(NULL,'query_accountInfoQuery','c_tacode','TA','string','out',NULL,5,100,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_accountInfoQuery','c_fundacco','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component(NULL,'query_availableNetQuery','c_tacode','TA����','string','out',NULL,5,100,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_availableNetQuery','c_fundacco','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_TACODE','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_dealedAccountRequestQueryQuery','C_TACODE','TA����','string','out',NULL,5,70,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedAccountRequestQueryQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,105,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

call add_show_component (null,'query_accountRequestTodayQueryQuery','c_tacode','ta����','string','out',null,5,70,0,1,1,null,null,1, null,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_accountRequestTodayQueryQuery','c_fundacco','�����˺�','string','out',NULL,10,105,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_requestInfoTodayQuery','c_tacode','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoTodayQuery','c_fundacco','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_accountRequestQueryQuery','C_TACODE','TA����','string','out',NULL,5,70,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_accountRequestQueryQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,105,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_requestInfoQuery','C_TACODE','TA����','string','out',NULL,5,65,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_unsendDividendQuery','C_TACODE','TA����','string','out',NULL,5,100,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_unsendDividendQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_dividendDetailQuery','C_TACODE','TA����','string','out',NULL,5,100,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dividendDetailQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,110,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);

DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tliqtrusteet0dxmxfile' ;
        IF v_isexist = 1 THEN
        drop table ta_tliqtrusteet0dxmxfile;
        create table ta_tliqtrusteet0dxmxfile
        (
        	c_tenantid                     varchar(20)     ,
        	c_tacode                       varchar(2)      ,
        	d_date                         varchar(8)      ,
        	c_custname                     varchar(120)    ,
        	c_tradeacco                    varchar(24)     ,
        	c_fundcode                     varchar(6)      ,
        	c_fundacco                     varchar(12)     ,
        	f_confirmshares                decimal(16,2)   ,
        	f_confirmbalance               decimal(16,2)   ,
            c_identifier                   varchar(2)      ,
            c_bankserialno                 varchar(3)      ,
            c_bankacconame                 varchar(60)     ,
            c_bankname                     varchar(60)     ,
            c_bankacco                     varchar(28)     ,
            c_t0accocode                   varchar(3)      ,
        	c_requestno                    varchar(24)     ,
        	c_moneytype                    varchar(3)      ,
        	d_factdate                     varchar(14)     ,
        	c_agencyno                     varchar(9)      ,
            c_databaseno                   varchar(5)      ,
            PRIMARY KEY(c_tenantid, c_tacode, c_databaseno, c_requestno, c_fundacco, c_tradeacco, c_fundcode, c_agencyno, f_confirmshares, f_confirmbalance)
        );
    	end if;
    END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tconfirm' and column_name='f_mgrincome';
			if v_rowcount = 0 then
				ALTER TABLE ta_tconfirm ADD f_mgrincome DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

-- ta_tfielddict �ⲿ�ӿ��ֶ�����
delete from ta_tfielddict where l_idno = 90510 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 90510, 'CUSTNAME', '1', 60, 0, '�ͻ�����');
delete from ta_tfielddict where l_idno = 90513 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 90513, 'C_TRADEACCO', '1', 20, 0, '�����˺�');
delete from ta_tfielddict where l_idno = 90505 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 90505, 'C_IDENTIFIER', '1', 2, 0, '���');
delete from ta_tfielddict where l_idno = 90506 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 90506, 'C_BANKSERIALNO', '1', 3, 0, '���б��');
delete from ta_tfielddict where l_idno = 90507 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 90507, 'C_BANKACCONAME', '1', 60, 0, '�����˺�');
delete from ta_tfielddict where l_idno = 90508 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 90508, 'C_BANKNAME', '1', 60, 0, '��������');
delete from ta_tfielddict where l_idno = 60211 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 60211, 'c_bankacco', '1', 28, 0, '�����˺�');
delete from ta_tfielddict where l_idno = 90509 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 90509, 'C_T0ACCOCODE', '1', 3, 0, 'T0�˺Ŵ���');
delete from ta_tfielddict where l_idno = 60207 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 60207, 'c_moneytype', '1', 3, 0, '����');
delete from ta_tfielddict where l_idno = 90514 and c_tenantid = '*';
insert into ta_tfielddict (c_tenantid, l_idno, c_fieldcode, c_datatype, l_fieldlen, l_precision, c_fieldname) values ('*', 90514, 'D_FACTDATE', '3', 14, 0, 'ԭ��������');

-- ta_ttafielddict �ڲ��ӿ��ֶ�����
delete from ta_ttafielddict where l_taidno = 90513 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 90513, 'C_TRADEACCO', 20, '1', ' ', '�����˺�');
delete from ta_ttafielddict where l_taidno = 90505 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 90505, 'C_IDENTIFIER', 2, '1', ' ', '���');
delete from ta_ttafielddict where l_taidno = 90506 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 90506, 'C_BANKSERIALNO', 3, '1', ' ', '���б��');
delete from ta_ttafielddict where l_taidno = 90507 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 90507, 'C_BANKACCONAME', 60, '1', ' ', '�����˺�');
delete from ta_ttafielddict where l_taidno = 90508 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 90508, 'C_BANKNAME', 60, '1', ' ', '��������');
delete from ta_ttafielddict where l_taidno = 60211 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 60211, 'c_bankacco', 28, '1', ' ', '�����˺�');
delete from ta_ttafielddict where l_taidno = 90509 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 90509, 'C_T0ACCOCODE', 3, '1', ' ', 'T0�˺Ŵ���');
delete from ta_ttafielddict where l_taidno = 60207 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 60207, 'c_moneytype', 3, '1', ' ', '����');
delete from ta_ttafielddict where l_taidno = 90514 and c_tenantid = '*';
insert into ta_ttafielddict (c_tenantid, l_taidno, c_tafield, l_tafieldlen, c_isnull, c_default, c_tafieldname) values ('*', 90514, 'D_FACTDATE', 14, '1', ' ', 'ԭ��������');
 


CALL add_show_component (NULL,'query_shareDetailQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_historyShareQuery','d_cdate','�ݶ�����','DateTimeInput','in',NULL,15,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_shareCurrentInfoQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1,NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component(NULL,'query_frozenDetailQuery','d_frozendate','��������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1,NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_accountRequestQueryQuery','D_DATE','��������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectRequestDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_dealedAccountRequestQueryQuery','C_TACODE','TA����','NoBlockSelect','in',NULL,0,100,1,1,1,'dynamicDictionary_selectTAInfoUserSet1',NULL,1, NULL,'1','{"cascader":{"C_NETNO":"refresh","D_DATE":"refresh","C_INSTITUTIONTYPE":"refresh","TA400param":"refresh"}}','1',null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedAccountRequestQueryQuery','D_DATE','��������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectRequestDateByTaCode',NULL,1, NULL,'1',null,'1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_dealedRequestInfoQuery','D_DATE','��������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectRequestDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_requestInfoQuery','D_DATE','��������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectRequestDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_accountConfirmQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_requestConfirmQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_subsConfirmQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_confirmDetailQuery','C_TACODE','TA����','NoBlockSelect','in',NULL,0,100,1,1,1,'dynamicDictionary_selectTAInfo',NULL,1, NULL,'1','{"cascader":{"C_NETNO":"refresh","C_FUNDCODE":"refresh","D_CDATE":"setValue"}}','1',null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_confirmDetailQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,20,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_dividendDetailQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,15,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_unsendDividendQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,15,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1, NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);

CALL add_show_component(NULL,'query_quotationInfoQuery','D_CDATE','ȷ������','DateTimeSectionInput','in',NULL,10,100,1,1,1,'dynamicDictionary_selectSysDateByTaCode',NULL,1,NULL,'1','{"valueMapping":"key"}','1',null,null,null,null,null,null,null);


-- M201907110362 begin
CALL add_SubTemplatePara(null,'000000101','0','Account','CustnameCheckPolicy','1','NoBlockSelect','C20312','*','*','*','*','1','�ظ�������飬��У��ͻ�����','0','�˻�����','����/�����޸�',40820,'[{required:true, message:"����!"}]',' ');
CALL add_SubTemplatePara(null,'000000101','0','TADeal','SpecialProductsOldOnly','1','NoBlockSelect','C20080','*','*','*','*','1','��ͨר����Ʒ������ֻ�����Ͽͻ����빦��','0','ϵͳ','���ܿ���',70010,'[{required:true, message:"����!"}]',' ');
-- M201907110362 end

-- ������ begin
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= DATABASE() AND table_name='ta_tjointly';
            IF v_rowcount = 0 THEN
                create table ta_tjointly
                (
                  c_tenantid        varchar(20) not null default ' ',
                  c_tacode          varchar(2) not null default ' ',
                  c_outbusinflag     varchar(3),
                  d_requestdate       int(8) default 0,
                  d_requesttime       int(6) default 0,
                  c_requestno        varchar(24),
                  c_agencyno         varchar(9),
                  c_netno            varchar(9),
                  c_bankcustno       varchar(7),
                  c_fundacco         varchar(12),
                  c_custname         varchar(120),
                  c_shortname        varchar(20),
                  c_custtype         varchar(1),
                  c_identitytype     varchar(1),
                  c_identityno       varchar(30),
                  c_mobileno         varchar(32),
                  f_balance          decimal(16,2),
                  f_confirmbalance   decimal(16,2),
                  c_fundcode         varchar(6),
                  c_bankacco         varchar(28),
                  d_cdate             int(8) default 0,
                  c_cserialno        varchar(20),
                  c_fundaccoinfund   varchar(12),
                  c_custnameinfund   varchar(120),
                  c_identitynoinfund varchar(30),
                  c_taflag           varchar(1),
                  c_status           varchar(1),
                  c_cause            varchar(36),
                  c_institutionno    varchar(3),
                  c_tradeacco        varchar(24),
                  c_childnetno       varchar(9),
                  c_idcard18len      varchar(1),
                  d_factdate         int(8) default 0,
                  c_cardbusinflag    varchar(3),
                  PRIMARY KEY (d_requestdate, c_requestno, c_agencyno, c_netno,c_tacode,c_tenantid)
                );
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= DATABASE() AND table_name='ta_tjointlyinfo';
            IF v_rowcount = 0 THEN
                create table ta_tjointlyinfo
                (
                  l_rowid int(11) NOT NULL AUTO_INCREMENT,
                  c_tenantid        varchar(20) not null default ' ' ,
                  c_tacode          varchar(2) not null default ' ' ,
                  c_bankno       varchar(3),
                  c_bankname     varchar(36),
                  c_viragencyno  varchar(9),
                  l_priority     int(3),
                  c_ishaveshares varchar(1),
                  c_matchtype    varchar(1),
                  c_fifo         varchar(1),
                  c_sysrole      varchar(1),
                  PRIMARY KEY (l_rowid),
                  UNIQUE KEY uijointlyinfo (c_bankno,c_tacode,c_tenantid)
                );
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= DATABASE() AND table_name='ta_tjointlyfundagency';
            IF v_rowcount = 0 THEN
                create table ta_tjointlyfundagency
                (
                  l_rowid int(11) NOT NULL AUTO_INCREMENT,
                  c_tenantid        varchar(20) not null default ' ',
                  c_tacode          varchar(2) not null default ' ',
                  c_fundcode varchar(6),
                  c_agencyno varchar(9),
                  l_payno    int(3),
                  c_bankno   varchar(3),
                  PRIMARY KEY (l_rowid),
                  UNIQUE KEY uijointlyfundagency (c_fundcode, c_agencyno, c_tenantid)
                );
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
        BEGIN
            DECLARE v_rowcount INT;
            SELECT COUNT(1) INTO v_rowcount FROM information_schema.tables WHERE table_schema= DATABASE() AND table_name='ta_tjointlycust';
            IF v_rowcount = 0 THEN
                create table ta_tjointlycust
                (
                  c_tenantid        varchar(20) not null default ' ',
                  c_tacode          varchar(2) not null default ' ',
                  d_cdate         int(8),
                  c_fundacco      varchar(12),
                  c_agencyno      varchar(9),
                  c_netno         varchar(9),
                  c_tradeacco     varchar(24),
                  c_institutionno varchar(3),
                  c_bankacco      varchar(30),
                  c_childnetno    varchar(9),
                  d_lastmodify      int(8),
                  c_custtype      varchar(1),
                  c_accostatus    varchar(1),
                  PRIMARY KEY (c_fundacco, c_agencyno, c_netno, c_tacode, c_tenantid)
                );
            END IF;
        END$$
DELIMITER ;
CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;



delete from ta_tsynctableinfo where c_tablename in ('ta_tjointlyfundagency','ta_tjointlyinfo','ta_tjointly','ta_tjointlycust');
insert into ta_tsynctableinfo(c_tablename, c_syncdirection, c_refreshontime) values('ta_tjointlyfundagency', '0', ' ');
insert into ta_tsynctableinfo(c_tablename, c_syncdirection, c_refreshontime) values('ta_tjointlyinfo', '0', ' ');
insert into ta_tsynctableinfo(c_tablename, c_syncdirection, c_refreshontime) values('ta_tjointly', '3', ' ');
insert into ta_tsynctableinfo(c_tablename, c_syncdirection, c_refreshontime) values('ta_tjointlycust', '3', ' ');
delete from ta_treliqtable where c_tablename in ('ta_tjointly','ta_tjointlycust');
insert into ta_treliqtable (C_TABLENAME, C_POOLTYPE, C_TENANTID, C_TACODE, L_ORDER, C_BAKTABLETYPE) values ('ta_tjointly', '1', '*', '*', 113, '0');
insert into ta_treliqtable (C_TABLENAME, C_POOLTYPE, C_TENANTID, C_TACODE, L_ORDER, C_BAKTABLETYPE) values ('ta_tjointlycust', '1', '*', '*', 114, '0');
-- ������ end



-- M201907080819 start
call add_show_service(null,'dynamicDictionary_selectFictitiousAgencyInfo', '��Ӧ����������', 'dynamicDictionary.selectFictitiousAgencyInfo', null,null,'0', null, null, null, null, null, null,null,null);

call add_show_service(null,'dynamicDictionary_selectCreditCardNo', '���ÿ����б��', 'dynamicDictionary.selectCreditCardNo', null,null,'0', null, null, null, null, null, null,null,null);

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int; declare v_tablecount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_tablecount FROM information_schema.tables WHERE table_schema= database_name AND table_type <> 'view' AND table_name='ta_tagencyinfo';
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tagencyinfo' and column_name='c_isnettradeacco';
			if v_tablecount = 1 and v_rowcount = 0 then 
				ALTER TABLE ta_tagencyinfo ADD c_isnettradeacco CHAR(1) DEFAULT '0';
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

-- ����	  
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
      select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.accopredeal.api.AccoPreDealService.baseTradeAccoMultiCheck' and function_name = '�����˺��ظ����-����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.accopredeal.api.AccoPreDealService.baseTradeAccoMultiCheck' and function_name = '�����˺��ظ����-����';    
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.accopredeal.api.AccoPreDealService.baseTradeAccoMultiCheck', '�����˺��ظ����-����', '0', '�����˺��ظ����-����', '1', '', 'tenantCode;longTaCode;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_task_service('AccoPreDealStart','*','com.hundsun.ta.ta5.biz.commonflow.accopredeal.api.AccoPreDealService.baseTradeAccoMultiCheck','�����˺��ظ����-����','','16');


-- M201907080819 end

-- ta_tuntrdtsfacrossrequest�����ֶ�c_databaseno
DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			DECLARE v_rowcount INT;
			DECLARE database_name VARCHAR(100);
			SELECT DATABASE() INTO database_name;
			SELECT COUNT(1) INTO v_rowcount FROM information_schema.columns WHERE table_schema= database_name AND table_name='ta_tuntrdtsfacrossrequest' AND column_name='c_databaseno';
			IF v_rowcount = 0 THEN
				ALTER TABLE ta_tuntrdtsfacrossrequest ADD c_databaseno  varchar(5)  DEFAULT ' ' NOT NULL;
			END IF;
		END$$
DELIMITER ;
	CALL sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '520000024' and function_name = 'LS_�ļ����_�ǽ��׹����Է������˺Ų���';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '520000024' and function_name = 'LS_�ļ����_�ǽ��׹����Է������˺Ų���';
            select id into v_taskid from sys_process_task where task_code = 'AccoPreDealStart' and parent_task_code = 'AccoPreDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.accopredeal.api.AccoPreDealService.tradeUntrdBeforeDelete' and function_name = 'LS_��������_�ǽ��׹�������ؿ�ǰɾ��';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.accopredeal.api.AccoPreDealService.tradeUntrdBeforeDelete' and function_name = 'LS_��������_�ǽ��׹�������ؿ�ǰɾ��';
            select id into v_taskid from sys_process_task where task_code = 'AccoPreDealStart' and parent_task_code = 'AccoPreDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '520000025' and function_name = 'LS_�ļ����_�ǽ��׹�������ؿ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '520000025' and function_name = 'LS_�ļ����_�ǽ��׹�������ؿ�';
            select id into v_taskid from sys_process_task where task_code = 'AccoPreDealStart' and parent_task_code = 'AccoPreDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

-- -----------------------------------
-- ���������Ƿ�С�ڵ��ڵ�ǰϵͳȷ���գ�����TACode����жϣ�
-- -----------------------------------
CALL add_show_service(NULL,'validate_checkIsLowerANDEqualSysDateByTACode','���������Ƿ���ڵ��ڵ�ǰϵͳȷ����','ValidateService.selectIsLowerANDEqualSysDateByTACode','1.0',null,'0',null,null,null,null,null,null,'default',null);

CALL add_show_component(NULL, 'TALaunchBusiness_shareForceIncreaseEdit', 'f_income', '��������', 'TextInput', 'in', NULL, 180, NULL, 1, NULL, NULL,null, NULL,NULL, '[{"required":true,"message":"����������ݶ�!"},{"num":true,"message":"�����ݶ�Ϊ����!"},{"validator":"greaterEqThanZero","params":["f_income"],"message":"��������Ҫ���ڵ���0��"},{"validator":"max","message":"�������治�ܴ���1000000000.00��"},{"validator":"floatLengthCheck","params":["16","2"],"message":"��������Ϊ�Ϸ�����λС����"}]','1',null,null,null,'ǿ����Ϣ',null,2,null,null,null);
CALL add_show_component(NULL, 'TALaunchBusiness_shareUnFrozenEdit', 'c_freezeno', '�����ļ���', 'TextInput', 'in', NULL, 30, NULL, 1, NULL, NULL,null, NULL,NULL,'[{"required":true,"message":"�����뷨�������!"},{"validator":"trimRequired","message":"�����뷨���ļ���"},{"validator":"maxlength","params":["128"],"message":"�����ļ��ų��Ȳ��ܳ���128λ��"},{"validator":"checkShareFreezeno","message":"�����ļ����붳��ʱ��һ�£�"}]','1',null,null,null,'��Ҫ��Ϣ',null,1,null,null,null);
-- 201907120212 begin
call add_show_button(null,'specialHandling_LiquidationSchemeSetDealConfirm', 'TaButton','submit', 'ȷ��','action',1,'specialHandling_LiquidationDealUserEvent',null,null,'checkLiquidationSchemeSetDealed','{"type":"primary","selectType":"multiple"}','specialHandling_LiquidationSchemeSetDeal:edit','LiquidationDealHintUpdate',null);
-- 201907120212 end

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.afterstat.api.AfterStatService.baseReliqStatUserStore', 'LS_�ظ�����_�ظ�������ͣ״̬�ָ�����ͳ�ƺ�', '0', 'LS_�ظ�����_�ظ�������ͣ״̬�ָ�����ͳ�ƺ�', '1', '{"flag":"1"}', 'tenantCode;longTaCode;liqBatchNo;reLiqType;flowNo;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('com.hundsun.ta.ta5.biz.commonflow.afterstat.api.AfterStatService.baseReliqStatUserStore', 'LS_�ظ�����_�ظ�������ͣ״̬�ָ������ദ����', '0', 'LS_�ظ�����_�ظ�������ͣ״̬�ָ�����ͳ��ǰ', '1', '{"flag":"0"}', 'tenantCode;longTaCode;liqBatchNo;reLiqType;flowNo;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('com.hundsun.ta.ta5.biz.processback.api.ProcessBackService.beforeFundReliqDeal', '��Ʒ����ǰ����', '0', '��Ʒ����ǰ����', '1', '', 'tenantCode;longTaCode;liqBatchNo;reLiqType;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('com.hundsun.ta.ta5.biz.processback.api.ProcessBackService.baseTableRecovery', '������ָ�', '0', '������ָ�', '1', '', 'tenantCode;longTaCode;liqBatchNo;reLiqType;flowNo;uuid;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('com.hundsun.ta.ta5.biz.processback.api.ProcessBackService.tradeTableRecovery', '�ֿ���ָ�', '0', '�ֿ���ָ�', '2', '', 'tenantCode;longTaCode;liqBatchNo;reLiqType;flowNo;uuid;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('com.hundsun.ta.ta5.biz.processback.api.ProcessBackService.baseProcessInstanceDefinitionRecovery', '����ʵ��������', '0', '�ֿ���ָ�', '1', '', 'tenantCode;longTaCode;liqBatchNo;reLiqType;flowNo;uuid;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('580002001', '�ظ�����_����UFT���ݻָ�', '0', '�ظ�����_����UFT���ݻָ�', '4', '{"sysnode_type":"4"}', 'tenantCode;longTaCode;liqBatchNo;reLiqType;flowNo;uuid;shardingNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;liqBatchNo-c_liqbatchno;reLiqType-c_reliqtype;flowNo-c_flowno;uuid-c_uuid;shardingNo-l_shardingno', '');
call add_process_service('580002001', '�ظ�����_�˻�UFT���ݻָ�', '0', '�ظ�����_�˻�UFT���ݻָ�', '3', '{"sysnode_type":"3"}', 'tenantCode;longTaCode;liqBatchNo;reLiqType;flowNo;uuid;shardingNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;liqBatchNo-c_liqbatchno;reLiqType-c_reliqtype;flowNo-c_flowno;uuid-c_uuid;shardingNo-l_shardingno', '');
call add_process_service('580002001', '�ظ�����_���UFT���ݻָ�', '0', '�ظ�����_���UFT���ݻָ�', '5', '{"sysnode_type":"5"}', 'tenantCode;longTaCode;liqBatchNo;reLiqType;flowNo;uuid;shardingNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;liqBatchNo-c_liqbatchno;reLiqType-c_reliqtype;flowNo-c_flowno;uuid-c_uuid;shardingNo-l_shardingno', '');

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.fundpub.api.FlowService.businTableDeleteBeforeBackLibrary' and function_name = '����Ҹ�ҵ������λؿ�ǰɾ��';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.fundpub.api.FlowService.businTableDeleteBeforeBackLibrary' and function_name = '����Ҹ�ҵ������λؿ�ǰɾ��';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.tradeFundChIncomeLoad', '����Ҹ���Ʒ����', '0', '����Ҹ���Ʒ����', '2', '{"flowStep":"SchemeDeal2","loadStyle":"i","dataStyle":"Finv"}', 'tenantCode;longTaCode;flowNo;liqBatchNo;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

call add_process_service('510000238', 'LS_���ݼ���_����Ҹ���Ʒ����', '0', 'LS_���ݼ���_����Ҹ���Ʒ����', '4', '{"c_flowstep":"SchemeDeal2","c_loadstyle":"i","c_datastyle":"Finv"}', 'tenantCode;longTaCode;liqBatchNo;shardingNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;liqBatchNo-c_liqbatchno;shardingNo-l_shardingno', '');

call add_process_service('com.hundsun.ta.ta5.biz.fundpub.api.FlowService.baseTableDeleteBeforeBackLibrary', '����Ҹ�ҵ������λؿ�ǰɾ��', '0', '����Ҹ�ҵ������λؿ�ǰɾ��', '2', '{"flowStep":"SchemeDeal2","loadStyle":"i","dataStyle":"Finv","isShardingFlag":"0"}', 'tenantCode;longTaCode;liqBatchNo;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

call add_process_service('590001027', '����Ҹ�ҵ������λؿ�', '0', '����Ҹ�ҵ������λؿ�', '4', '', 'tenantCode;longTaCode;shardingNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;shardingNo-l_shardingno', '');

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.confirmInfoSuppleMent', '����Ҹ�����ȷ�ϱ���Ϣ����', '0', '����Ҹ�����ȷ�ϱ���Ϣ����', '2', '{"flowType":"0"}', 'tenantCode;longTaCode;flowNo;liqBatchNo;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');


call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.tradeFundChIncomeLoad','����Ҹ���Ʒ����','','112.3');
call add_process_task_service('SchemeDeal2','*','510000238','LS_���ݼ���_����Ҹ���Ʒ����','','112.31');
call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.baseUseReventJudge','LS_UFT����_�˹������¼��ж�','','112.32');
call add_process_task_service('SchemeDeal2','*','580003502','����Ҹ���Ʒ����','','112.33');
call add_process_task_service('SchemeDeal2','*','580003801','������������Ҹ�','','112.34');
call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.fundpub.api.FlowService.baseTableDeleteBeforeBackLibrary','����Ҹ�ҵ������λؿ�ǰɾ��','','112.35');
call add_process_task_service('SchemeDeal2','*','590001027','����Ҹ�ҵ������λؿ�','','112.36');
call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.confirmInfoSuppleMent','����Ҹ�����ȷ�ϱ���Ϣ����','','112.37');

-- ɾ������ķ���������ϵͳ�ڵĲ�����
delete from sys_process_task_service where service_id in 
(select id from sys_process_service a
where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqpredeal.service.ReqPreDealService.tradeCheckResultSyncBase');

delete from sys_process_service
where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqpredeal.service.ReqPreDealService.tradeCheckResultSyncBase';

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeCheckResultSyncBase', '�ֿ���ƺ�������ͬ��������-�ֿ�', '0', '�ֿ���ƺ�������ͬ��������-�ֿ�', '2', '', 'tenantCode;longTaCode;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '580003660' and function_name = '�������뽻�׼����ͳ�ƴ���';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '580003660' and function_name = '�������뽻�׼����ͳ�ƴ���';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '590001029' and function_name = 'LS_��������_����ͳ�ƻؿ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '590001029' and function_name = 'LS_��������_����ͳ�ƻؿ�';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.tradeGatherRequest' and function_name = 'Ԥ��������������ͳ��-�ֿ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.tradeGatherRequest' and function_name = 'Ԥ��������������ͳ��-�ֿ�';  
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


call add_process_service('com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeGatherRequest', 'Ԥ��������������ͳ��-�ֿ�', '0', 'Ԥ��������������ͳ��-�ֿ�', '2', '', 'tenantCode;longTaCode;liqBatchNo;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');


call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.commonflow.inputreqdata.api.InputReqDataService.checkResultsDataDelete','LS_ϵͳ����_�����ʷ���������','','64');
call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.commonflow.inputreqdata.api.InputReqDataService.checkResultsDataDeleteSub','��ս�������ʷ���������-�ֿ�','','65');
call add_process_task_service('ReqCheck','*','580000031','LS_����UFT_Ԥ����������ؿ�','','66');
call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.updateTradeRequstStatus','����������״̬����','','67');
call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeCheckResultSyncBase','�ֿ���ƺ�������ͬ��������-�ֿ�','','69');
call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeGatherRequest','Ԥ��������������ͳ��-�ֿ�','','70');
call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.baseReqSumStat','LS_UFT����_����ͳ�����ݻ���','','71');
call add_process_task_service('ReqCheck','*','790001210','�ڴ����Ƽ���','','72');
call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.fundpub.api.FlowService.flowLogStatusUpdate','�ڵ�״̬����','','73');

call add_SubTemplatePara(NULL, '000000101', '0', 'Interface', 'InterfaceNumPerPage', '10000', 'TextInput', '', '*', '*', '*', '*', '1', '�ӿڷ�ҳ��С', '0', '�ӿ�����', '��������', 0, '{required:true}','{required:"����!"}');

call add_process_task('Initial','Initial','*','�ڵ�������ʼ��','�ڵ�������ʼ��','0','','','','','manual');
call add_process_task_service('Initial','*','510000227','LS_���ݼ���_�ֿ���Ϣ������','','1');
call add_process_task_service('Initial','*','510000233','���׻���ID����','','2');
call add_process_task_service('Initial','*','510000043','������Ϣ����_����������','','3');
call add_process_task_service('Initial','*','510000222','LS_���ݼ���_��Ʒ������Ϣ������','','4');
call add_process_task_service('Initial','*','510000038','LS_���ݼ���_����������','','5');
call add_process_task_service('Initial','*','510000224','LS_���ݼ���_��Ʒ��ֵ��ˮ������','','6');

delete from ta_tbaseexcludetables;

insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('ta_tbaseexcludetables', '0','0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_TENANT', '0','0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_USER', '0','0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_ROLE', '0','0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_RESOURCE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_USER_ROLE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_ROLE_RESOURCE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_MENU', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_USER_MENU', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_SERVICE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_SERVICE_FIELD', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_SHOW_CONFIG_GROUP', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_SHOW_CONFIG', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_SHOW_CONFIG_FIELD', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_SYSPARAMETER', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('REPORT', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_FILEDEFINITION', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_SHOW_CONFIG_FIELD_USER', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_SYSTEMLOGFIELDDETAIL', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_SYSTEMLOGDETAIL', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_SYSTEMLOG', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_SYSTEMLOGFIELDDETAIL_HIS', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_SYSTEMLOGDETAIL_HIS', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_SYSTEMLOG_HIS', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_ROLE_MANAGER', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_USER_PASSWORD_HIS', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_ROLE_DEPARTMENT', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_SYNC_STATUS', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_REQUEST_FLOW_API', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_ACTION_RECODE_API', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_CONTENT_LOG_API', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_FUNCTION', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_FUNCTION_AUTH', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_USER_RESOURCE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_RESOURCE_AUTH', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('REPORT_FAXCUST', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('REPORT_FAXSEND_INFO', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_OTHER_SHOW_CONFIG_FIELD', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_OTHER_SERVICE_FIELD', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_ROLE_TA', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_ROLE_FUNDCODE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('REPORT_FIELD', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('REPORT_FIELD_USER', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_FILTEROPTIONS_API', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_REQUEST_DATA_DETAIL_API', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TAAPI_REQUEST_DATA_API', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_DEAL_LOCK', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_SHOW_CONFIG_FUNCTIONS', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('DB_BACKUPRESTORE_INFO', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TASYS_SHOW_CONFIG_LINKED', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_FLASHBACKARCHIVETABLES', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('SYS_DICTIONARY', '0', '0');

insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM02FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM04FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM05FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM12FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM25FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM06FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM09FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYNAV07FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM26FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM10FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYCFM11FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYNAVC1FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYNAVC2FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYNAVC3FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYNAVC4FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYNAVC5FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TAGENCYNAVC6FILE', '0', '0');


insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZE92FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZE94FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZE95FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZE96FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZET1FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZET2FILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZEQ2FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZEQ5FILE', '0', '1');

insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZEZ2FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZEZ4FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZEZ5FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZEZ6FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZES2FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZES5FILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZETMFILE', '0', '0');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCENTRALIZETNFILE', '0', '0');

insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTSHAREDETAILFILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTACCOFILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTACCONETFILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTACCOREQUESTFILE', '1', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTREQUESTFILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTCONFIRMFILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTSHAREFILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTDIVIDENDFILE', '0', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype, c_pooltype) values('TA_TCUSTSHARECURRENTSFILE', '0', '1');

insert into ta_tbaseexcludetables(table_name, c_objecttype) values('SEQ_ID', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('SEQ_LOG', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('SEQ_INSTANCEDEFINITION_ID', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('ATTACHMENT_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('AUDIT_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('BAM_TASK_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('BOOLEANEXPR_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('COMMENT_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('CONTENT_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('CONTEXT_MAPPING_INFO_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('CORRELATION_KEY_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('CORRELATION_PROP_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('DEADLINE_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('DEPLOY_STORE_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('EMAILNOTIFHEAD_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('ERROR_INFO_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('ESCALATION_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('I18NTEXT_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('NODE_INST_LOG_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('NOTIFICATION_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('PROCESS_INSTANCE_INFO_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('PROC_INST_LOG_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('REASSIGNMENT_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('REQUEST_INFO_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('SESSIONINFO_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('TASK_DEF_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('TASK_EVENT_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('TASK_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('VAR_INST_LOG_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('WORKITEMINFO_ID_SEQ', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('SEQ_TASK_ID', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('SEQ_FIELD_ID', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('SEQ_TASK_SERVICE_ID', '1');
insert into ta_tbaseexcludetables(table_name, c_objecttype) values('SEQ_TASKLOG_ID', '1');
commit;

delete from ta_treliqtable where c_tablename in ('ta_tcustregisterinfo');
insert into ta_treliqtable (C_TABLENAME, C_POOLTYPE, C_TENANTID, C_TACODE, L_ORDER, C_BAKTABLETYPE) values ('ta_tcustregisterinfo', '0', '*', '*', 115, '0');
commit;

delete from ta_thintinfo where c_code = 'HI00029' and c_tacode = '*' and c_tenantid = '*';
insert into ta_thintinfo (c_tenantid, c_tacode, c_flowno, c_flowstep, c_hinttime, l_order, c_code, c_hintlevel, c_databasetype, c_hintdescribe, c_hintopturl, c_hintoptmode)
values ('*', '*', 'flow_tabatch_mainflow', 'SchemeDeal2', '2', 0, 'HI00029', '2', '0', '���»�����ʧ��,���ֶ�ȷ�ϴ�����
�������', CONCAT(CONCAT('/tamaintain/info/queryTabs.ftl?tabCode=specialHandling_productFailedList','&'),'templateCode=/ta-template/sub-list'), '2');

delete from ta_tsql where c_code = 'HI00029' and c_tenantid = '*';
insert into ta_tsql (c_tenantid, c_code, c_usetype, l_serialno, c_sql)
values ('*', 'HI00029', '4', 1, 'select a.c_fundcode from ta_tfundinfo a where a.c_tenantid = ''#TenantID'' and a.c_tacode = ''#TACode'' and a.c_fundstatus not in (''6'', ''9'') and a.c_factcollectresult = ''1'' and a.d_failuredate = 0 and a.d_setupdate = #CfmDate and not exists (select 1 from ta_tliqdealflag d where d.c_fundcode = a.c_fundcode and d.c_tacode = a.c_tacode and d.c_tenantid = a.c_tenantid and d.c_status = ''0'')');

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '580004311' and function_name = 'LS_���жȿ���_���жȿ����Ϲ�ȷ�ϱ�����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '580004311' and function_name = 'LS_���жȿ���_���жȿ����Ϲ�ȷ�ϱ�����';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '580004300' and function_name = 'LS_���жȿ���_�Ϲ����ж��ж�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '580004300' and function_name = 'LS_���жȿ���_�Ϲ����ж��ж�';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqdeal.api.DealScaleService.conCtrlTableBackDeal' and function_name = 'LS_��Ʒ����_���жȿ��Ʊ��ؿ�ǰɾ��';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqdeal.api.DealScaleService.conCtrlTableBackDeal' and function_name = 'LS_��Ʒ����_���жȿ��Ʊ��ؿ�ǰɾ��';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.fundpub.api.SystemPublicService.generateServiceOfAuditHints' and function_name = '�Ϲ��ڼ��жȿ��Ƴ�������ʾ';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.fundpub.api.SystemPublicService.generateServiceOfAuditHints' and function_name = '�Ϲ��ڼ��жȿ��Ƴ�������ʾ';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqdeal.api.ReqDealService.conCtrlCommUserEventCheck' and function_name = 'LS_��������_�Ϲ��ڼ��жȿ���ͨ���û��¼����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqdeal.api.ReqDealService.conCtrlCommUserEventCheck' and function_name = 'LS_��������_�Ϲ��ڼ��жȿ���ͨ���û��¼����';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqdeal.api.ReqDealService.structUpdateSubsConfirm' and function_name = 'LS_��������_���жȿ��Ƹ����Ϲ�ȷ�ϱ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqdeal.api.ReqDealService.structUpdateSubsConfirm' and function_name = 'LS_��������_���жȿ��Ƹ����Ϲ�ȷ�ϱ�';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.fundEndEventAdd' and function_name = 'LS_��������_������ʧ���û��¼�����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.fundEndEventAdd' and function_name = 'LS_��������_������ʧ���û��¼�����';
            select id into v_taskid from sys_process_task where task_code = 'SchemeDeal2' and parent_task_code = 'SchemeDeal2';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '580004300' and function_name = 'LS_���жȿ���_�Ϲ����ж��ж�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '580004300' and function_name = 'LS_���жȿ���_�Ϲ����ж��ж�';
            select id into v_taskid from sys_process_task where task_code = 'SchemeDeal2' and parent_task_code = 'SchemeDeal2';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.fundEndEventCheck' and function_name = 'LS_��������_������ʧ���û��¼����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.fundEndEventCheck' and function_name = 'LS_��������_������ʧ���û��¼����';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '580004300' and function_name = 'LS_���жȿ���_�Ϲ����ж��ж�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '580004300' and function_name = 'LS_���жȿ���_�Ϲ����ж��ж�';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

call add_process_service('com.hundsun.ta.ta5.biz.fundpub.api.SystemPublicService.generateServiceOfAuditHints', '����ļ��ʧ����ʾ��������', '0', '����ļ��ʧ����ʾ��������', '1', '{"hintNo":"HI00029","hintTime":"2"}', 'tenantCode;longTaCode;liqBatchNo;databaseNo;instanceId;flowStep', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('590003023', '������Ϣļ���������', '0', '������Ϣļ���������', '4', '', 'tenantCode;longTaCode;liqBatchNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;liqBatchNo-c_liqbatchno', '');

call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.fundEndEventAdd','LS_��������_������ʧ���û��¼�����','','116.11');
call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.fundpub.api.SystemPublicService.generateServiceOfAuditHints','����ļ��ʧ����ʾ��������','','116.12');
call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.fundEndEventCheck','LS_��������_������ʧ���û��¼����','','116.13');
call add_process_task_service('SchemeDeal2','*','590003023','������Ϣļ���������','','116.14');


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '580000007' and function_name = '���������������';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '580000007' and function_name = '���������������';    
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '580000023' and function_name = 'LS_����UFT_���׼����������';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '580000023' and function_name = 'LS_����UFT_���׼����������';    
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


call add_process_service('com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeLargeTradeLimit', '�������Ƽ��-�ֿ�', '0', '�������Ƽ��-�ֿ�', '2', '', 'tenantCode;longTaCode;liqBatchNo;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

call add_process_task_service('ReqCheck','*','com.hundsun.ta.ta5.biz.commonflow.reqpredeal.api.ReqPreDealService.tradeLargeTradeLimit','�������Ƽ��-�ֿ�','','67.1');

delete from ta_tsynctableinfo where c_tablename = 'ta_tfaarlimit';
insert into ta_tsynctableinfo(c_tablename, c_syncdirection, c_refreshontime) values('ta_tfaarlimit', '0', ' ');


DELIMITER $$
    CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='sys_free_query' ;
        IF v_isexist = 0 THEN
		CREATE TABLE sys_free_query(
		id                             bigint          NOT NULL AUTO_INCREMENT,
		tenant_code                    varchar(50)     DEFAULT '*'        NOT NULL,
		query_code                     varchar(100)    DEFAULT ' '        ,
		query_group_code               varchar(100)    DEFAULT ' '        ,
		query_name                     varchar(100)    DEFAULT ' '        ,
		query_desc                     varchar(1000)   DEFAULT ' '        NOT NULL,
		is_visible                     char(1)         DEFAULT ' '        NOT NULL,
		sql_code                       varchar(64)     DEFAULT ' '        ,
		sum_sql_code                   varchar(64) ,
		sql_datasource                 varchar(64)     DEFAULT 'query'  NOT NULL,
		parameters                     varchar(500) ,
		PRIMARY KEY(id)
		);
		CREATE UNIQUE INDEX unique_index_free_query ON sys_free_query(query_code ASC ,tenant_code ASC );
    	end if;
    END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS add_free_query;

DELIMITER $$
create procedure add_free_query(in tenantCode varchar(50),
                                in query_code varchar(100),
                                in query_group_code varchar(100),
                                in query_name varchar(100),
								in query_desc varchar(1000),
								in is_visible char(1),
								in sql_code varchar(64),
                                in sql_datasource varchar(64),
								in sum_sql_code varchar(64),
								in parameters varchar(500))
  BEGIN
     declare tenantId varchar(2);
     declare whereSql varchar(70);
    SET @tenantCode = tenantCode;
    SET @query_code = query_code;
    SET @query_group_code = query_group_code;
    SET @query_name = query_name;
    SET @query_desc = query_desc;
    SET @is_visible = is_visible;
    SET @sql_code = sql_code;
    SET @sum_sql_code = sum_sql_code;
    SET @sql_datasource = sql_datasource;
    SET @parameters = parameters;
    SET @sum_sql_code = sum_sql_code;
    SET @flag = true;
    call getTenantId(@tenantCode,'tenant_code',@tenantId, @whereSql ,@flag  );
    if @flag then
      -- ����
      SET @insertSql = CONCAT('insert into sys_free_query(tenant_code,query_code,query_group_code,query_name,query_desc,is_visible,sql_code,sum_sql_code,sql_datasource,parameters) values(?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE parameters = parameters');
      PREPARE stmtInsert FROM @insertSql;
      EXECUTE stmtInsert USING @tenantCode,@query_code,@query_group_code,@query_name,@query_desc,@is_visible,@sql_code,@sum_sql_code,@sql_datasource,@parameters;
      DEALLOCATE PREPARE stmtInsert;
    end if;
    commit;
  END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        declare v_count INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tsaleyebstat_td' ;
        IF v_isexist > 0 then
            SELECT COUNT(1) INTO v_count FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tsaleyebstat_td' AND CONSTRAINT_NAME = 'PRIMARY' ;
            if v_count > 0 then
                alter table ta_tsaleyebstat_td drop primary key;
				alter table ta_tsaleyebstat_td add primary key(d_holddate, d_cdate, c_fundcode, c_agencyno, c_partnerid, c_tacode, c_tenantid, c_databaseno);
            end if;
        end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

call add_process_service('com.hundsun.ta.ta5.biz.backup.api.BackUpService.tradeReBuildView', '�ֿ��ؽ���ͼ', '0', '�ֿ��ؽ���ͼ', '2', '', 'databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.tradeStatIssueGroup', 'ͳ�ƻ����з�����Ϣ��-�ֿ�', '0', 'ͳ�ƻ����з�����Ϣ��-�ֿ�', '2', '', 'tenantCode;longTaCode;liqBatchNo;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

call add_process_service('com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.baseStatIssueGroup', 'ͳ�ƻ����з�����Ϣ��-����', '0', 'ͳ�ƻ����з�����Ϣ��-����', '1', '', 'liqBatchNo;longTaCode;tenantCode;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqdeal.api.ReqDealService.subsStatPreDel' and function_name = '�Ϲ���ͳ��ǰ����ɾ��';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.reqdeal.api.ReqDealService.subsStatPreDel' and function_name = '�Ϲ���ͳ��ǰ����ɾ��';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '590003010' and function_name = '��Ʒ�Ϲ���ͳ��';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '590003010' and function_name = '��Ʒ�Ϲ���ͳ��';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '590001017' and function_name = '�Ϲ���ͳ�ƻؿ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '590001017' and function_name = '�Ϲ���ͳ�ƻؿ�';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '590001012' and function_name = '��Ʒ�Ϲ���ͳ�ƻ�����Ϣ��ʱ���ؿ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '590001012' and function_name = '��Ʒ�Ϲ���ͳ�ƻ�����Ϣ��ʱ���ؿ�';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.fundinfoBackUpdate' and function_name = '��Ʒ�Ϲ���ͳ�ƻ�����Ϣ����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.fundinfoBackUpdate' and function_name = '��Ʒ�Ϲ���ͳ�ƻ�����Ϣ����';
            select id into v_taskid from sys_process_task where task_code = 'TradeBatchDeal' and parent_task_code = 'ReqDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


call add_process_task_service('TradeBatchDeal','*','590001007','�Ϲ����ݻؿ�','','10.1');

call add_process_task_service('TradeBatchDeal','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.tradeStatIssueGroup','ͳ�ƻ����з�����Ϣ��-�ֿ�','','54');
call add_process_task_service('TradeBatchDeal','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.FundSetupService.baseStatIssueGroup','ͳ�ƻ����з�����Ϣ��-����','','55');
call add_process_task_service('TradeBatchDeal','*','590003023','������Ϣļ���������','','56');

CALL add_show_component(NULL, 'TALaunchBusiness_shareForceIncreaseEdit', 'c_sharetype', '�ݶ����', 'DictionarySelect', 'in', NULL, 130, NULL, 1, NULL, NULL,'control_selectShareTypes', NULL,NULL, '[{"required":true,"message":"������ݶ����!"}]','1','{"cascader":{"f_remainshares":"setValue","f_remainincome":"setValue"}}','1',null,'ǿ����Ϣ',null,2,null,null,null);
CALL add_show_component(NULL, 'TALaunchBusiness_shareForceIncreaseEdit', 'f_remainincome', '�������', 'TextInput', 'in', NULL, 175, NULL, 0, NULL, NULL,'control_selectTotalStaticShares', NULL,NULL,NULL,'1','{"valueMapping":"f_income"}',null,null,'ǿ����Ϣ',null,2,null,null,null);
CALL add_show_component(NULL, 'TALaunchBusiness_shareForceIncreaseEdit', 'f_income', '��������', 'TextInput', 'in', NULL, 180, NULL, 1, NULL, NULL,null, NULL,NULL, '[{"required":true,"message":"�������������!"},{"num":true,"message":"��������Ϊ����!"},{"validator":"greaterEqThanZero","params":["f_income"],"message":"��������Ҫ���ڵ���0��"},{"validator":"max","message":"�������治�ܴ���1000000000.00��"},{"validator":"floatLengthCheck","params":["16","2"],"message":"��������Ϊ�Ϸ�����λС����"}]','1',null,null,null,'ǿ����Ϣ',null,2,null,null,null);

CALL add_show_component (NULL,'query_requestInfoQuery','C_CUSTNAME','�ͻ�����','string','out',NULL,15,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_AGENCYNO','������','string','out',NULL,20,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_NETNO','����','string','out',NULL,25,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_BUSINFLAG','ҵ������','string','out',NULL,35,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','FUNDNAME','��������','string','out',NULL,60,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_CAUSE','ʧ��ԭ��','string','out',NULL,95,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_EXCEEDFLAG','�޶���ش�����־','string','out',NULL,145,150,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_CUSTTYPE','�ͻ�����','string','out',NULL,305,100,1,1,1,'C20026',NULL,1, NULL,'1',null,'0',null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','OLD_C_CUSTTYPE','�ͻ�����','string','out',NULL,310,100,1,1,1,NULL,NULL,0, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_IDENTITYPE','֤������','string','out',NULL,320,100,1,1,1,'{"trans_field": "OLD_C_CUSTTYPE", "trans_dict": {"0":"C20023","1":"C20022","2":"C20379"}}',NULL,1, NULL,'1',null,'0',null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_IDENTITYNO','֤������','string','out',NULL,325,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);

CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_CUSTNAME','�ͻ�����','string','out',NULL,15,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_AGENCYNO','������','string','out',NULL,20,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_NETNO','����','string','out',NULL,25,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_BUSINFLAG','ҵ������','string','out',NULL,35,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','FUNDNAME','��������','string','out',NULL,60,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_CAUSE','ʧ��ԭ��','string','out',NULL,95,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_EXCEEDFLAG','�޶���ش�����־','string','out',NULL,145,150,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_CUSTTYPE','�ͻ�����','string','out',NULL,305,100,1,1,1,'C20026',NULL,1, NULL,'1',null,'0',null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','OLD_C_CUSTTYPE','�ͻ�����','string','out',NULL,310,100,1,1,1,NULL,NULL,0, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_IDENTITYPE','֤������','string','out',NULL,320,100,1,1,1,'{"trans_field": "OLD_C_CUSTTYPE", "trans_dict": {"0":"C20023","1":"C20022","2":"C20379"}}',NULL,1, NULL,'1',null,'0',null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_IDENTITYNO','֤������','string','out',NULL,325,100,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);

CALL add_show_component(NULL,'query_quotationInfoDetail','c_todaystatus','���ջ���״̬','TextInput','out',NULL,70,100,0,1,1,'C20021',NULL,1,NULL,'1',null,'0',null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_quotationInfoDetail','c_vastflag','�޶���ر�־','TextInput','out',NULL,130,100,0,1,1,'C20080',NULL,1,NULL,'1',null,'0',null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_quotationInfoDetail','c_excessflag','�����깺��־','TextInput','out',NULL,160,100,0,1,1,'C20080',NULL,1,NULL,'1',null,'0',null,null,null,null,null,null,null);

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
        DECLARE v_isexist INT;
        declare v_count INT;
        SELECT COUNT(1) INTO v_isexist FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tagencybizlimitdate' ;
        IF v_isexist > 0 then
            SELECT COUNT(1) INTO v_count FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='ta_tagencybizlimitdate' AND CONSTRAINT_NAME = 'uidx_tagencybizlimitdate' ;
            if v_count = 0 then 
				CREATE UNIQUE INDEX uidx_tagencybizlimitdate ON ta_tagencybizlimitdate(c_outbusinflag ASC ,c_agencyno ASC ,c_netno ASC ,c_fundcode ASC ,c_sharetype ASC ,d_bgndate ASC,d_enddate ASC,c_tacode ASC ,c_tenantid ASC );
            end if;
        end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

delete from ta_tsynctableinfo where c_tablename = 'ta_tagencybizlimitdate';
insert into ta_tsynctableinfo(c_tablename, c_syncdirection, c_refreshontime) values('ta_tagencybizlimitdate', '2', ' ');


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '510000210' and function_name = 'δ������Ʒ�Ϲ�����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '510000210' and function_name = 'δ������Ʒ�Ϲ�����';    
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '510000211' and function_name = '�Ϲ�ȷ�ϱ����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '510000211' and function_name = '�Ϲ�ȷ�ϱ����';    
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service_field where service_id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
			SET @sqlstr := CONCAT('delete from sys_process_service where id = ', v_serviceid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_tsubsconfirm' and column_name='f_balsubsed';
			if v_rowcount = 0 then
				ALTER TABLE ta_tsubsconfirm ADD f_balsubsed DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_trequest_tmp' and column_name='f_balsubsed';
			if v_rowcount = 0 then
				ALTER TABLE ta_trequest_tmp ADD f_balsubsed DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
	CREATE PROCEDURE sp_db_mysql()
		BEGIN
			declare v_rowcount int;
			declare database_name VARCHAR(100);
			select database() into database_name;
			select count(1) into v_rowcount from information_schema.columns where table_schema= database_name and table_name='ta_trequest_imp_tmp' and column_name='f_balsubsed';
			if v_rowcount = 0 then
				ALTER TABLE ta_trequest_imp_tmp ADD f_balsubsed DECIMAL(16,2) DEFAULT 0.0;
			end if;
		END$$
DELIMITER ;
	call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;
DROP PROCEDURE IF EXISTS sp_db_mysql;

DELIMITER $$
CREATE PROCEDURE sp_db_mysql()
BEGIN
    DECLARE v_rowcount INT;
    
    SELECT COUNT(1) INTO v_rowcount FROM information_schema.statistics WHERE table_schema= DATABASE() AND table_name='TA_TNONRESIRREQUEST' AND index_name ='PRIMARY';
    IF v_rowcount > 0 THEN
       ALTER TABLE TA_TNONRESIRREQUEST DROP PRIMARY KEY;
       ALTER TABLE TA_TNONRESIRREQUEST ADD CONSTRAINT PK_TNONRESIRREQUEST PRIMARY KEY(C_REQUESTNO, C_TENANTID,C_AGENCYNO);
    END IF; 

END$$
DELIMITER ;
CALL sp_db_mysql();
delete from ta_treliqtable where c_tablename in ('ta_tliqdealflag');
insert into ta_treliqtable (C_TABLENAME, C_POOLTYPE, C_TENANTID, C_TACODE, L_ORDER, C_BAKTABLETYPE) values ('ta_tliqdealflag', '1', '*', '*', 116, '0');
insert into ta_treliqtable (C_TABLENAME, C_POOLTYPE, C_TENANTID, C_TACODE, L_ORDER, C_BAKTABLETYPE) values ('ta_tliqdealflag', '0', '*', '*', 117, '0');


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '510000200' and function_name = 'LS_���ݼ���_���UFT��ʼ��';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '510000200' and function_name = 'LS_���ݼ���_���UFT��ʼ��';
            select id into v_taskid from sys_process_task where task_code = 'ShareCommit' and parent_task_code = 'ShareCommit';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

call add_process_task_service('ExportNav','*','510000200','LS_���ݼ���_���UFT��ʼ��','','1.1');
call add_process_task_service('InputReqData','*','510000200','LS_���ݼ���_���UFT��ʼ��','','3.1');

delete from sys_process_task_service
 where service_id in (select id from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.fundpub.api.InterfaceBaseService.interfaceFileDownload');


call add_process_task_service('AccoPreDealStart','*','510000101','LS_�ؿ�����_�˻������UFT�ؿ�','','21');
call add_process_task_service('AccoPreDealStart','*','com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.updateAccoTable','LS_�˻�����_�˻��������','','21.1');
call add_process_task_service('AccoPreDealStart','*','590001015','������Ϣ�ؿ�_�˻�����','','21.2');
call add_process_task_service('AccoPreDealStart','*','com.hundsun.ta.ta5.biz.fundpub.api.FlowService.updateAccoSerialNo','������Ϣ������_�˻�����','','21.3');
call add_process_task_service('AccoPreDealStart','*','590001059','�˻�ͨ�����б��ؿ�','','21.4');
call add_process_task_service('AccoPreDealStart','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.commonSerialnoCurUpdate','ͨ�����кű�����','','21.5');
call add_process_task_service('AccoPreDealStart','*','510000103','LS_�ؿ�����_���˻�����','','21.6');
call add_process_task_service('AccoPreDealStart','*','520000019','LS_�ļ����_�˻�����������','','22');


call add_process_task_service('AccoPreDealStart','*','520000018','LS_�ļ����_���׵���������','','36.1');


call add_process_task_service('AccoCheck','*','com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.tradeFundaccoRefill','LS_��������_�����˺Ų���','','1.1');


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '510000101' and function_name = 'LS_�ؿ�����_�˻������UFT�ؿ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '510000101' and function_name = 'LS_�ؿ�����_�˻������UFT�ؿ�';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.updateAccoTable' and function_name = 'LS_�˻�����_�˻��������';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.updateAccoTable' and function_name = 'LS_�˻�����_�˻��������';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '590001015' and function_name = '������Ϣ�ؿ�_�˻�����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '590001015' and function_name = '������Ϣ�ؿ�_�˻�����';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.fundpub.api.FlowService.updateAccoSerialNo' and function_name = '������Ϣ������_�˻�����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.fundpub.api.FlowService.updateAccoSerialNo' and function_name = '������Ϣ������_�˻�����';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.tradeFundaccoRefill' and function_name = 'LS_��������_�����˺Ų���';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.accodeal.api.AccoDealService.tradeFundaccoRefill' and function_name = 'LS_��������_�����˺Ų���';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '520000018' and function_name = 'LS_�ļ����_���׵���������';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '520000018' and function_name = 'LS_�ļ����_���׵���������';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '520000019' and function_name = 'LS_�ļ����_�˻�����������';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '520000019' and function_name = 'LS_�ļ����_�˻�����������';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '590001059' and function_name = '�˻�ͨ�����б��ؿ�';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '590001059' and function_name = '�˻�ͨ�����б��ؿ�';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.commonSerialnoCurUpdate' and function_name = 'ͨ�����кű�����';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = 'com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.commonSerialnoCurUpdate' and function_name = 'ͨ�����кű�����';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '790001210' and function_name = '�˻��ڵ��ڴ����Ƽ���';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '790001210' and function_name = '�˻��ڵ��ڴ����Ƽ���';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;

DROP PROCEDURE IF EXISTS sp_db_mysql;
DELIMITER $$
  CREATE PROCEDURE sp_db_mysql()
    BEGIN
      declare v_rowcount int;
      declare v_serviceid int;
      declare v_taskid int;
            select count(1) into v_rowcount from sys_process_service where function_no = '580002000' and function_name = '�ظ�����_�˻�UFT���ݱ���';
      if v_rowcount > 0 then
            select id into v_serviceid from sys_process_service where function_no = '580002000' and function_name = '�ظ�����_�˻�UFT���ݱ���';
            select id into v_taskid from sys_process_task where task_code = 'AccoDeal' and parent_task_code = 'AccoDeal';
                
            SET @sqlstr := CONCAT('delete from sys_process_task_service where service_id = ', v_serviceid, ' and task_id = ', v_taskid);
            PREPARE stmt FROM @sqlstr;
            EXECUTE stmt;
      end if;
    END$$
DELIMITER ;
  call sp_db_mysql();
DROP PROCEDURE IF EXISTS sp_db_mysql;


call add_show_button(null,'sysinfo_saleAgioList','TaButton', 'add', '����','action',1,null,null,'sysinfo_saleAgioAdd',null,'{"selectType":"form"}','sysinfo_saleAgio:edit',null,null);
call add_show_button(null,'sysinfo_specFundFavourList','TaButton', 'add', '����','action',1,null,null,'sysinfo_specFundFavourAdd',null,'{"selectType":"form"}','sysinfo_specFundFavour:edit',null,null);
call add_show_button(null,'sysinfo_fundPropFavourList','TaButton', 'add', '����','action',1,null,null,'sysinfo_fundPropFavourAdd',null,'{"selectType":"form"}','sysinfo_fundPropFavour:edit',null,null);


call add_process_service('580002000', '�ظ�����_����UFT���ݱ���', '0', '�ظ�����_����UFT���ݱ���', '4', '{"sysnode_type":"4"}', 'tenantCode;longTaCode;flowNo;liqBatchNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;liqBatchNo-c_liqbatchno;flowNo-c_flowno', '');
call add_process_service('580002000', '�ظ�����_�˻�UFT���ݱ���', '0', '�ظ�����_�˻�UFT���ݱ���', '3', '{"sysnode_type":"3"}', 'tenantCode;longTaCode;flowNo;liqBatchNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;liqBatchNo-c_liqbatchno;flowNo-c_flowno', '');
call add_process_service('580002000', '�ظ�����_���UFT���ݱ���', '0', '�ظ�����_���UFT���ݱ���', '5', '{"sysnode_type":"5"}', 'tenantCode;longTaCode;flowNo;liqBatchNo', '', '', '', '', '0', 't2', '', '', '', '', '', '1', 'tenantCode-c_tenantid;longTaCode-c_longtacode;liqBatchNo-c_liqbatchno;flowNo-c_flowno', '');

-- ɾ�� ļ��ʧ��ȷ��ҳ��
CALL delete_Menu('specialHandling_productFailedConfirm');
CALL delete_resource(NULL,'specialHandling_productFailedConfirm:view',NULL,NULL,NULL);
CALL delete_resource(NULL,'specialHandling_productFailedConfirm:edit',NULL,NULL,NULL);

--  ����ļ��ʧ�� ҳ�����Ӳ�Ʒ����ȷ��

CALL add_show_service(NULL,'specialHandling_productFailedSetup','��Ʒ����ȷ��','specialHandling.productFailed.updateFundinfoFactcollect,specialHandling.productFailed.updateHintReadStatus','1.0',null,'0',null,null,null,null,null,null,'default','list');
call add_show_button(null,'specialHandling_productFailedList','TaButton','openPage','��Ʒ����ȷ��','action',2,null,null,'specialHandling_productSetUpConfirm',null,'{"selectType":"multiple"}','specialHandling_productFailed:edit',null,'setUpConfirm');

-- ����ļ��ʧ������  ��Ʒ����ȷ��ȷ��
call add_show_tab(NULL,'specialHandling_productSetUpConfirm', '�Ƿ���в�Ʒ����ȷ�ϣ�', '1.0','ta-template/confirm',null,1,null,'specialHandling_productSetUpConfirm',null,'specialHandling_productFailed:edit');
call add_show_button(null,'specialHandling_productSetUpConfirm', 'TaButton','submit', 'ȷ��','action',1,'specialHandling_productFailedSetup',null,null,null,'{"type":"primary","selectType":"multiple"}','specialHandling_productFailed:edit','productFailedHitUpdate',null);


delete from sys_show_button where tab_code ='sysinfo_saleAgioList' and  BUTTON_BIZ_CODE ='openPage';
delete from sys_show_button where tab_code ='sysinfo_specFundFavourList' and  BUTTON_BIZ_CODE ='openPage';
delete from sys_show_button where tab_code ='sysinfo_fundPropFavourList' and  BUTTON_BIZ_CODE ='openPage';
call add_show_button(null,'sysinfo_saleAgioList','TaButton', 'add', '����','action',1,null,null,'sysinfo_saleAgioAdd',null,'{"selectType":"form"}','sysinfo_saleAgio:edit',null,null);
call add_show_button(null,'sysinfo_specFundFavourList','TaButton', 'add', '����','action',1,null,null,'sysinfo_specFundFavourAdd',null,'{"selectType":"form"}','sysinfo_specFundFavour:edit',null,null);
call add_show_button(null,'sysinfo_fundPropFavourList','TaButton', 'add', '����','action',1,null,null,'sysinfo_fundPropFavourAdd',null,'{"selectType":"form"}','sysinfo_fundPropFavour:edit',null,null);

call add_process_task_service('SchemeDeal2','*','com.hundsun.ta.ta5.biz.commonflow.schemedeal2.api.AfterBatchDealService.commonSerialnoCurUpdate','ͨ�����кű�����','','150.15');

delete from sys_process_task_service
 where task_id in (select id from sys_process_task where task_code = 'processBack' and parent_task_code = 'processBack')
   and service_id in (select id from sys_process_service
                       where function_no = '580002001'
                         and function_name in ('�ظ�����_����UFT���ݻָ�', '�ظ�����_�˻�UFT���ݻָ�', '�ظ�����_���UFT���ݻָ�'));


delete from sys_process_task_service
 where task_id in (select id from sys_process_task where task_code = 'Initial' and parent_task_code = 'Initial');
   
call add_process_task_service('Initial','*','580002001','�ظ�����_����UFT���ݻָ�','','1');
call add_process_task_service('Initial','*','580002001','�ظ�����_�˻�UFT���ݻָ�','','2');
call add_process_task_service('Initial','*','580002001','�ظ�����_���UFT���ݻָ�','','3');

delete from ta_tsql where c_tenantid = '*' and c_code='HI00029';
insert into ta_tsql (c_tenantid, c_code, c_usetype, l_serialno, c_sql)
    values ('*', 'HI00029', '4', 1, 'select a.c_fundcode parm1 from ta_tfundinfo a, ta_tissuegroup b, ta_tpoolinfo c where a.c_tenantid = ''#TenantID'' and a.c_tacode = ''#TACode'' and a.c_fundstatus not in (''6'',''9'') and a.c_fundcode = b.c_fundcode and a.c_tenantid = b.c_tenantid and (a.l_minaccocount > b.l_havesubaccomount or a.f_minissuebala > b.f_havesubmount) and b.c_databaseno = c.c_databaseno and c.c_isused = ''1'' and c.c_pooltype = ''0'' and a.d_setupdate = #CfmDate and a.c_autosetupflag = ''0'' AND NOT EXISTS (SELECT 1 FROM ta_tliqdealflag d WHERE d.c_fundcode = a.c_fundcode AND d.c_tacode = a.c_tacode AND d.c_tenantid = a.c_tenantid AND d.c_status = ''0'')  union all select a.c_fundcode parm1 from ta_tfundinfo a where a.c_tenantid = ''#TenantID'' and a.c_tacode = ''#TACode'' and a.c_factcollectresult = ''1'' and a.c_fundstatus not in (''6'', ''9'') and a.d_setupdate = #CfmDate and a.c_autosetupflag = ''0'' and a.c_fundcode not in(select b.c_fundcode from ta_tissuegroup b where b.c_tenantid = a.c_tenantid and b.c_tacode = a.c_tacode) and NOT EXISTS (SELECT 1 FROM ta_tliqdealflag d WHERE d.c_fundcode = a.c_fundcode AND d.c_tacode = a.c_tacode AND d.c_tenantid = a.c_tenantid AND d.c_status = ''0'')');
 
call add_show_service(null, 'control_checkLiqStatusOnTATransaction2', '�������̨ҵ�����̿���','ControlService.selectCheckLiqStatusOnTATransaction2', '1.0',null,'0',null,'{"noticeType":"error","noticeMessage":"1��TA����ҵ������ȷ��ʱ����ҵ��ֻ�������������֮������ͳ������֮ǰ����2��TA����ҵ�������ȷ��ʱ���������̽ڵ�״̬���������ҵ��1�����鸴�����֮����ǰ��������֮ǰ��2�����������֮������ͳ������֮ǰ��"}',null,null,null,null,'default',null);
--  ����TA����ɸѡ״̬��6��9����ĵ�ǰ���ζ������ƻ���
CALL add_show_service(NULL,'dynamicDictionary_selectShortCycleFundByTaCode','����TA����ɸѡ״̬��6��9����ĵ�ǰ���ζ������ƻ���','dynamicDictionary.selectShortCycleFundByTaCode','1.0',null,'0',null, null, null, null, null, null,null,null);

 -- M201907260084 begin
call add_show_component(null,'sysinfo_discountLimitImport','c_fundcode','�������','VARCHAR','file_template',null,1,null,null,null,null,'dynamicDictionary_selectFundinfoUnionCrossTAFund',null,1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null,'sysinfo_discountLimitImport','c_sharetype','�ݶ����','VARCHAR','file_template',null,5,null,null,null,null,'dynamicDictionary_selectDLShareType',null,1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null,'sysinfo_discountLimitImport','c_agencyno','������','VARCHAR','file_template',null,10,null,null,null,null,'dynamicDictionary_selectAllAgencysWithOutTA0ByTA',null,1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null,'sysinfo_discountLimitImport','c_businflag','ҵ�����','VARCHAR','file_template',null,20,null,null,null,null,'dynamicDictionary_selectDLBusinflag',null,1,null,'1',null,'1',null,null,null,null,null,null,null);
call add_show_component(null,'sysinfo_discountLimitImport','c_faretype','��������','VARCHAR','file_template',null,30,null,null,null,null,'C20015',null,1,null,'1',null,'0',null,null,null,null,null,null,null);
call add_show_component(null,'sysinfo_discountLimitImport','f_agencyagio','����������ۿ�','VARCHAR','file_template',null,35,null,null,null,null,null,null,1,null,'1',null,null,null,null,null,null,null,null,null);
-- M201907260084 end

-- M201907260084 begin
delete from sys_show_component where tab_code = 'sysinfo_trusteeInfoImport4Override';
CALL add_show_service(NULL, 'specialHandling_SelectDuplicate4TrusteeInfo', '�й�����Ϣ��ͻ��ѯ', 'sysinfo.trusteeInfo.selectDuplicate', '1.0',null,'0','insertBatchTrusteeInfo',null,null,null,null,null,'default','map');
call add_show_button(null,'sysinfo_trusteeInfoImport4Override','TaButton', 'reserve', '����ԭ������','action',1,'specialHandling_SelectDuplicate4TrusteeInfo',null,null,null,'{"type":"primary"}','sysinfo_trusteeInfo:import',null,null);
call add_show_button(null,'sysinfo_trusteeInfoImport4Override','TaButton', 'cover', '����ԭ������','action',2,'sysinfo_trusteeInfoBatchInsert',null,null,null,null,'sysinfo_trusteeInfo:import',null,null);
call add_show_button(null,'sysinfo_trusteeInfoImport','TaButton', 'submit', 'ȷ��','action',4,'specialHandling_SelectDuplicate4TrusteeInfo',null,'sysinfo_trusteeInfoImport4Override',null,'{"type":"primary"}','sysinfo_trusteeInfo:import',null,null);
call add_show_component(null,'sysinfo_trusteeInfoImport4Override','c_tacode','TA����','TextInput','out',null,10,150,null,1,1,null,null,1, null,'1',null,null,null,null,null,null,null,null,null);
call add_show_component(null,'sysinfo_trusteeInfoImport4Override','c_trusteecode','�й��д���','TextInput','out',null,20,150,null,1,1,null,null,1, null,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'sysinfo_trusteeInfoImport','c_tacode','TA����','TextInput','file_template',NULL,'10',NULL,NULL,NULL,NULL,'dynamicDictionary.selectTAInfo',NULL,NULL,null,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'sysinfo_trusteeInfoImport','c_trusteecode','�й���','TextInput','file_template',NULL,'20',NULL,NULL,NULL,NULL,'C20044',NULL,NULL,null,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(null,'sysinfo_trusteeInfoImport','c_trusteename','�й�������','TextInput','file_template',null,'30',null,null,null,null,null,null,null,null,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'sysinfo_trusteeInfoImport','c_iversion','�ӿڰ汾','TextInput','file_template',NULL,'40',NULL,NULL,NULL,NULL,'C20066',NULL,NULL,null,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'sysinfo_trusteeInfoImport','c_format','��ƽӿ��ļ�����ʽ','TextInput','file_template',NULL,'50',NULL,NULL,NULL,NULL,'C20067',NULL,NULL,null,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'sysinfo_trusteeInfoImport','c_norexpnoliqdata','��ƽӿڹ���û�н��׵�����','TextInput','file_template',NULL,'60',NULL,NULL,NULL,NULL,'C20080',NULL,NULL,null,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'sysinfo_trusteeInfoImport','c_t5ismultimgr','T5�Ƿ�֧�ֶ������','TextInput','file_template',NULL,'70',NULL,NULL,NULL,NULL,'C20080',NULL,NULL,null,'1',null,null,null,null,null,null,null,null,null);
-- M201907260084 end

-- M201907260827 begin
CALL add_show_service(NULL, 'specialHandling_SelectDuplicate4TrusteeInfo', '�й�����Ϣ��ͻ��ѯ', 'sysinfo.trusteeInfo.selectDuplicate', '1.0',null,'0','sysinfo_trusteeInfoBatchInsert',null,null,null,null,null,'default','map');
-- M201907260827 end
-- M201907260620 begin
CALL add_show_component (NULL,'dailyDeal_AccoManualList','c_fundacco','�����˺�','string','out',NULL,10,120,NULL,1,1,null,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'dailyDeal_TradeManualList','c_fundacco','�����˺�','string','out',NULL,10,120,NULL,1,1,null,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'dailyDeal_SubsConfirmManualList','c_fundacco','�����˺�','string','out',NULL,10,120,1,1,1,null,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
call add_show_component (null,'dailyDeal_ManualSharedetailList','c_fundacco','�����˺�','string','out',null,10,120,0,1,1,null,null,1, null,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component(NULL, 'query_ecntrctRequestQuery', 'c_fundacco', '�����˺�','string', 'out', NULL,10,120,0,1,1, NULL, NULL, 1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_accountInfoQuery','c_fundacco','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_availableNetQuery','c_fundacco','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_staticShareInfoQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_shareDetailQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_shareCurrentInfoQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_frozenDetailQuery','c_fundacco','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_accountRequestQueryQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedAccountRequestQueryQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_OTHERACCO','�Է������˺�','string','out',NULL,120,120,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dealedRequestInfoQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_OTHERACCO','�Է������˺�','string','out',NULL,120,120,1,1,1,NULL,NULL,1, NULL,'1',null,null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestInfoQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_accountConfirmQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_requestConfirmQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_subsConfirmQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_confirmDetailQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_dividendDetailQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component (NULL,'query_unsendDividendQuery','C_FUNDACCO','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1, NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
CALL add_show_component(NULL,'query_nonresirRequestQuery','c_fundacco','�����˺�','string','out',NULL,10,120,0,1,1,NULL,NULL,1,NULL,'1','{"fixed":"left"}',null,null,null,null,null,null,null,null);
-- M201907260620 end

-- M201907270031 begin
call add_show_component(null, 'sysinfo_taInfoAdd', 'c_tacode', 'TA����', 'TextInput', 'in', null, 5, null, 1, null, null,null, null,null,'[{"required":true,"message":"������TA����"},{"validator":"maxlength","params":[2],"message":"TA���벻�ܳ���2λ"},{"validator":"checkTAInfoExist","params":[],"message":"��TA�����Ѵ���"},{"validator":"checkTACodeLength","params":[],"message":"TA���벻������2λ"}]','1',null,null,null,null,null,null,null,null,null);

-- ----------------------------------------------
-- ��ѯTA��Ϣ������
-- ----------------------------------------------
call add_show_service(null,'validate_checkTAInfoExist','��ѯTA��Ϣ������','ValidateService.selectTACodeExist','1.0',null,'0',null,null,null,null,null,null,'default',null);
-- M201907270031 end

call add_process_service('com.hundsun.ta.ta5.biz.liquidation.api.AgencyRequestImportService.checkAgencyImpFinish', '����������Ƿ��Ѿ�ȫ������', '1', '����������Ƿ��Ѿ�ȫ������', '1', '', 'tenantCode;longTaCode;liqBatchNo;databaseNo;instanceId', 'code', '0_succeed;2_skipped;-1_suspend;10_ready', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_task_service('InputReqData','*','com.hundsun.ta.ta5.biz.liquidation.api.AgencyRequestImportService.checkAgencyImpFinish','����������Ƿ��Ѿ�ȫ������','','7');


call add_process_service('com.hundsun.ta.ta5.biz.commonflow.inputreqdata.api.InputReqDataService.subRequestDataToBase', '�����������ݺ�˳������ͬ��������', '0', '', '2', '{"flowType":"0"}', 'tenantCode;longTaCode;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');
call add_process_service('com.hundsun.ta.ta5.biz.commonflow.inputreqdata.api.InputReqDataService.subRequestDataToBase', '��֤�����̽����������ݺ�˳������ͬ��������', '0', '��֤�����̽����������ݺ�˳������ͬ��������', '2', '{"flowType":"1"}', 'tenantCode;longTaCode;databaseNo', 'code', '0_succeed;2_skipped;-1_suspend', '', '', '1', 'dubbo', 'ta5', '1.0.0.0', '', '', '', '1', '', '');

-- �ô洢�������ڸ���TA������⻧���»������ݣ����������á�����ǰ�漯���������ṹ�䶯�ͻ������ݱ䶯��
CALL updatebasicdata();

-- ���½�����������
call REBUILDFLASHBACK();
commit;