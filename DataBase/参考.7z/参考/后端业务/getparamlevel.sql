DROP FUNCTION IF EXISTS getparamlevel;
DELIMITER ;;

create function getparamlevel(v_tenantid VARCHAR(20), v_item VARCHAR(40))
    RETURNS char DETERMINISTIC
begin
    DECLARE v_count INT DEFAULT 0;
    DECLARE v_level CHAR;

    SELECT a.c_paramlevel, COUNT(1) INTO v_level, v_count
      FROM ta_tsubtemplatepara a
     WHERE a.c_paramitem = v_item
       AND a.c_tenantid = v_tenantid;
       
    if v_count = 0 then
        return '-';
    else
        return v_level;
    end if;
end;;

DELIMITER ;

