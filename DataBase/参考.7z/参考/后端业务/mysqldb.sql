CREATE DATABASE IF NOT EXISTS hs_tabase DEFAULT CHARACTER SET gbk COLLATE gbk_bin;
GRANT ALL ON hs_tabase.* to 'hs_tabase'@'%' IDENTIFIED BY 'hs_tabase';
GRANT ALL ON hs_tabase.* to 'hs_tabase'@'127.0.0.1' IDENTIFIED BY 'hs_tabase';
GRANT ALL ON hs_tabase.* to 'hs_tabase'@'localhost' IDENTIFIED BY 'hs_tabase';
GRANT SELECT ON mysql.help_topic TO 'hs_tabase'@'%' IDENTIFIED BY 'hs_tabase';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tabase'@'%' IDENTIFIED BY 'hs_tabase';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tabase'@'127.0.0.1' IDENTIFIED BY 'hs_tabase';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tabase'@'localhost' IDENTIFIED BY 'hs_tabase';

CREATE DATABASE IF NOT EXISTS hs_tatrade1 DEFAULT CHARACTER SET gbk COLLATE gbk_bin;
GRANT ALL ON hs_tatrade1.* to 'hs_tatrade1'@'%' IDENTIFIED BY 'hs_tatrade1';
GRANT ALL ON hs_tatrade1.* to 'hs_tatrade1'@'127.0.0.1' IDENTIFIED BY 'hs_tatrade1';
GRANT ALL ON hs_tatrade1.* to 'hs_tatrade1'@'localhost' IDENTIFIED BY 'hs_tatrade1';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tatrade1'@'%' IDENTIFIED BY 'hs_tatrade1';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tatrade1'@'127.0.0.1' IDENTIFIED BY 'hs_tatrade1';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tatrade1'@'localhost' IDENTIFIED BY 'hs_tatrade1';

CREATE DATABASE IF NOT EXISTS hs_tatrade2 DEFAULT CHARACTER SET gbk COLLATE gbk_bin;
GRANT ALL ON hs_tatrade2.* to 'hs_tatrade2'@'%' IDENTIFIED BY 'hs_tatrade2';
GRANT ALL ON hs_tatrade2.* to 'hs_tatrade2'@'127.0.0.1' IDENTIFIED BY 'hs_tatrade2';
GRANT ALL ON hs_tatrade2.* to 'hs_tatrade2'@'localhost' IDENTIFIED BY 'hs_tatrade2';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tatrade2'@'%' IDENTIFIED BY 'hs_tatrade2';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tatrade2'@'127.0.0.1' IDENTIFIED BY 'hs_tatrade2';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tatrade2'@'localhost' IDENTIFIED BY 'hs_tatrade2';

CREATE DATABASE IF NOT EXISTS hs_tadatabk DEFAULT CHARACTER SET gbk COLLATE gbk_bin;
GRANT ALL ON hs_tadatabk.* to 'hs_tadatabk'@'%' IDENTIFIED BY 'hs_tadatabk';
GRANT ALL ON hs_tadatabk.* to 'hs_tadatabk'@'127.0.0.1' IDENTIFIED BY 'hs_tadatabk';
GRANT ALL ON hs_tadatabk.* to 'hs_tadatabk'@'localhost' IDENTIFIED BY 'hs_tadatabk';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tadatabk'@'%' IDENTIFIED BY 'hs_tadatabk';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tadatabk'@'127.0.0.1' IDENTIFIED BY 'hs_tadatabk';
GRANT PROCESS,FILE,SUPER,REPLICATION CLIENT,REPLICATION SLAVE  ON *.* to 'hs_tadatabk'@'localhost' IDENTIFIED BY 'hs_tadatabk';

CREATE DATABASE IF NOT EXISTS hs_taquery DEFAULT CHARACTER SET gbk COLLATE gbk_bin;
GRANT ALL ON hs_taquery.* to 'hs_taquery'@'%' IDENTIFIED BY 'hs_taquery';
GRANT ALL ON hs_taquery.* to 'hs_taquery'@'127.0.0.1' IDENTIFIED BY 'hs_taquery';
GRANT ALL ON hs_taquery.* to 'hs_taquery'@'localhost' IDENTIFIED BY 'hs_taquery';

GRANT SELECT ON hs_tabase.* to 'hs_tatrade1'@'%' IDENTIFIED BY 'hs_tatrade1';
GRANT SELECT ON hs_tabase.* to 'hs_tatrade1'@'127.0.0.1' IDENTIFIED BY 'hs_tatrade1';
GRANT SELECT ON hs_tabase.* to 'hs_tatrade1'@'localhost' IDENTIFIED BY 'hs_tatrade1';

GRANT SELECT ON hs_tabase.* to 'hs_tatrade2'@'%' IDENTIFIED BY 'hs_tatrade2';
GRANT SELECT ON hs_tabase.* to 'hs_tatrade2'@'127.0.0.1' IDENTIFIED BY 'hs_tatrade2';
GRANT SELECT ON hs_tabase.* to 'hs_tatrade2'@'localhost' IDENTIFIED BY 'hs_tatrade2';

GRANT SELECT ON hs_tabase.* to 'hs_taquery'@'%' IDENTIFIED BY 'hs_taquery';
GRANT SELECT ON hs_tabase.* to 'hs_taquery'@'127.0.0.1' IDENTIFIED BY 'hs_taquery';
GRANT SELECT ON hs_tabase.* to 'hs_taquery'@'localhost' IDENTIFIED BY 'hs_taquery';

GRANT SELECT ON hs_tatrade1.* to 'hs_tabase'@'%' IDENTIFIED BY 'hs_tabase';
GRANT SELECT ON hs_tatrade1.* to 'hs_tabase'@'127.0.0.1' IDENTIFIED BY 'hs_tabase';
GRANT SELECT ON hs_tatrade1.* to 'hs_tabase'@'localhost' IDENTIFIED BY 'hs_tabase';

GRANT SELECT ON hs_tatrade1.* to 'hs_taquery'@'%' IDENTIFIED BY 'hs_taquery';
GRANT SELECT ON hs_tatrade1.* to 'hs_taquery'@'127.0.0.1' IDENTIFIED BY 'hs_taquery';
GRANT SELECT ON hs_tatrade1.* to 'hs_taquery'@'localhost' IDENTIFIED BY 'hs_taquery';

GRANT SELECT ON hs_tatrade2.* to 'hs_tabase'@'%' IDENTIFIED BY 'hs_tabase';
GRANT SELECT ON hs_tatrade2.* to 'hs_tabase'@'127.0.0.1' IDENTIFIED BY 'hs_tabase';
GRANT SELECT ON hs_tatrade2.* to 'hs_tabase'@'localhost' IDENTIFIED BY 'hs_tabase';

GRANT SELECT ON hs_tatrade2.* to 'hs_taquery'@'%' IDENTIFIED BY 'hs_taquery';
GRANT SELECT ON hs_tatrade2.* to 'hs_taquery'@'127.0.0.1' IDENTIFIED BY 'hs_taquery';
GRANT SELECT ON hs_tatrade2.* to 'hs_taquery'@'localhost' IDENTIFIED BY 'hs_taquery';

