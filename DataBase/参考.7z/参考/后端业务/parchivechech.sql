DROP PROCEDURE IF EXISTS PCREATEVIEW;
delimiter ;;
CREATE PROCEDURE PCREATEVIEW(sTable1 VARCHAR(100),sTable2 VARCHAR(100),sView VARCHAR(100),nModified INT)
BEGIN
		DECLARE sColName VARCHAR(64);
		DECLARE sTmp     VARCHAR(3840);
		DECLARE nNext    INT;
		DECLARE sSql     VARCHAR(7200);
		DECLARE nCnt     INT;
		DECLARE nCreate  INT;
		DECLARE no_more_col INT DEFAULT 0;
		DECLARE cur      CURSOR FOR
				select COLUMN_NAME from ta_tcolumns_tmp where TABLE_SCHEMA = database() and table_name = sTable1;

		DECLARE CONTINUE HANDLER FOR NOT FOUND SET no_more_col = -1;

		SET nCnt = 0;
		SELECT count(*) INTO nCnt FROM information_schema.TABLES WHERE TABLE_SCHEMA = database() and table_name=sView AND table_type='view';
		SET nCreate = 0;
    IF (nCnt = 1) AND (nModified = 1) THEN
				SET sSql = CONCAT('DROP VIEW ',sView);
				SET @sql1 = sSql;
        PREPARE stmt1 FROM @sql1;
				EXECUTE stmt1;
				DEALLOCATE PREPARE stmt1;
				SET nCreate = 1;
		ELSEIF nCnt = 0 THEN
        SET nCreate = 1;
		END IF;
		IF nCreate = 1 THEN
				SET sTmp = '';
				SET nNext = 0;
				OPEN cur;
				read_loop:LOOP
						SET sColName = '';
						IF no_more_col = -1 THEN 
							LEAVE read_loop; 
						END IF;
						FETCH cur INTO sColName;
						IF nNext = 1 THEN
								SET sTmp = CONCAT(sTmp,',');
						END IF;
						SET sColName = TRIM(sColName);
						SET sTmp = CONCAT(sTmp,sColName);
						SET nNext = 1;
				END LOOP;
				CLOSE cur;
				SET sTmp = left(sTmp, length(sTmp)-1);
				SET sSql = CONCAT('CREATE VIEW ',sView,' AS SELECT ',sTmp,' FROM ',sTable1,' UNION ALL SELECT ',sTmp,' FROM ',sTable2);
				SET @sql1 = sSql;
				PREPARE stmt1 FROM @sql1;
				EXECUTE stmt1;
				DEALLOCATE PREPARE stmt1;
		END IF;
END;;
delimiter ;


DROP PROCEDURE IF EXISTS PCOLMDF;
delimiter ;;
CREATE PROCEDURE PCOLMDF(sTable1 VARCHAR(100),sTable2 VARCHAR(100))
BEGIN
		DECLARE nIsExist1   INT;
		DECLARE nIsExist2   INT;
		DECLARE sColName    VARCHAR(64);
		DECLARE sColDataType    VARCHAR(64);
		DECLARE sColType    VARCHAR(64);
		DECLARE sColDefault VARCHAR(64);
		DECLARE sColNull    VARCHAR(64);
		DECLARE sColName1    VARCHAR(64);
		DECLARE sColDataType1    VARCHAR(64);
		DECLARE sColType1    VARCHAR(64);
		DECLARE sColDefault1 VARCHAR(64);
		DECLARE sColNull1    VARCHAR(64);
		DECLARE sSql        VARCHAR(7200);
		DECLARE no_more_col INT DEFAULT 0;
		DECLARE cur_add     CURSOR FOR
				SELECT T1.COLUMN_NAME,T1.DATA_TYPE,T1.COLUMN_TYPE,T1.COLUMN_DEFAULT,T1.IS_NULLABLE
					FROM
					(select COLUMN_NAME,DATA_TYPE,COLUMN_TYPE,COLUMN_DEFAULT,IS_NULLABLE 
						from ta_tcolumns_tmp
						where TABLE_SCHEMA = database() 
							and table_name = sTable1) T1 
      left join
					(select COLUMN_NAME 
             from ta_tcolumns_tmp
            where TABLE_SCHEMA = database() 
              and table_name = sTable2) T2 
            on (T1.COLUMN_NAME = T2.COLUMN_NAME)
         where T2.COLUMN_NAME is null;

		DECLARE cur_mod     CURSOR FOR
				SELECT T1.COLUMN_NAME,T1.DATA_TYPE,T1.COLUMN_TYPE,T1.COLUMN_DEFAULT,T1.IS_NULLABLE,
							 T2.COLUMN_NAME COLUMN_NAME1,
               T2.DATA_TYPE DATA_TYPE1,
               T2.COLUMN_TYPE COLUMN_TYPE1,
               T2.COLUMN_DEFAULT COLUMN_DEFAULT1,
               T2.IS_NULLABLE IS_NULLABLE1
					FROM
					(select COLUMN_NAME,DATA_TYPE,COLUMN_TYPE,ifnull(COLUMN_DEFAULT,'NULL') COLUMN_DEFAULT,IS_NULLABLE
						from ta_tcolumns_tmp
						where TABLE_SCHEMA = database() 
							and table_name = sTable1) T1,
					(select COLUMN_NAME,DATA_TYPE,COLUMN_TYPE,ifnull(COLUMN_DEFAULT,'NULL') COLUMN_DEFAULT,IS_NULLABLE
             from ta_tcolumns_tmp
            where TABLE_SCHEMA = database() 
              and table_name = sTable2) T2 
         where T1.COLUMN_NAME = T2.COLUMN_NAME
           and (T1.COLUMN_NAME <> T2.COLUMN_NAME 
                OR T1.COLUMN_TYPE <> T2.COLUMN_TYPE 
						    OR T1.COLUMN_DEFAULT <> T2.COLUMN_DEFAULT
                OR T1.IS_NULLABLE <> T2.IS_NULLABLE);
		
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET no_more_col = 1;
		SET nIsExist1 = 0;
		SET nIsExist2 = 0;

		SELECT count(*) INTO nIsExist1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = database() and table_name=sTable1;
		SELECT count(*) INTO nIsExist2 FROM information_schema.TABLES WHERE TABLE_SCHEMA = database() and table_name=sTable2;
		IF (nIsExist1 = 1) AND (nIsExist2 = 0) THEN
				SET sSql = '';
        SET sSql = CONCAT('CREATE TABLE ',sTable2,' AS SELECT * FROM ',sTable1,' WHERE 1<>1 ');
				SET @sql1 = sSql;
        PREPARE stmt1 FROM @sql1;
				EXECUTE stmt1;
				DEALLOCATE PREPARE stmt1;
		ELSEIF (nIsExist1 = 1) AND (nIsExist2 = 1) THEN
				SET no_more_col = 0;
				OPEN cur_add;
				FETCH cur_add INTO sColName,sColDataType,sColType,sColDefault,sColNull;
				WHILE no_more_col<>1 do 
						IF sColDefault is NULL THEN
								SET sColDefault = ' ';
						ELSE
								IF sColDataType = 'varchar' THEN
										SET sColDefault = CONCAT(' DEFAULT ','\'',sColDefault,'\'');
								ELSE
										SET sColDefault = CONCAT(' DEFAULT ',sColDefault);
								END IF;
						END IF;
						IF sColNull = 'NO' THEN
								SET sColNull = 'NOT NULL';
						ELSE
								SET sColNull = '';
						END IF;

						SET sSql = CONCAT('ALTER TABLE ',sTable2,' ADD ',sColName,' ',sColType,sColDefault,' ',sColNull);

						SET @sql1 = sSql;
						PREPARE stmt1 FROM @sql1;
						EXECUTE stmt1;
						DEALLOCATE PREPARE stmt1;
						FETCH cur_add INTO sColName,sColDataType,sColType,sColDefault,sColNull;
				END WHILE;
				CLOSE cur_add;
				SET no_more_col = 0;
				OPEN cur_mod;
				FETCH cur_mod INTO sColName,sColDataType,sColType,sColDefault,sColNull,
                           sColName1,sColDataType1,sColType1,sColDefault1,sColNull1;
				WHILE no_more_col<>1 do 
						IF sColDefault = 'NULL' THEN
								SET sColDefault = ' ';
						ELSE
								IF sColDataType = 'varchar' THEN
										SET sColDefault = CONCAT(' DEFAULT ','\'',sColDefault,'\'');
								ELSE
										SET sColDefault = CONCAT(' DEFAULT ',sColDefault);
								END IF;
						END IF;
						IF sColNull = 'NO' THEN
								SET sColNull = 'NOT NULL';
						ELSE
								SET sColNull = '';
						END IF;
						SET sSql = CONCAT('ALTER TABLE ',sTable2,' modify ',sColName,' ',sColType,sColDefault,' ',sColNull);

						SET @sql1 = sSql;
						PREPARE stmt1 FROM @sql1;
						EXECUTE stmt1;
						DEALLOCATE PREPARE stmt1;

						FETCH cur_mod INTO sColName,sColDataType,sColType,sColDefault,sColNull,
                           sColName1,sColDataType1,sColType1,sColDefault1,sColNull1;
				END WHILE;
				CLOSE cur_mod;
		END IF;
END;;
delimiter ;


DROP PROCEDURE IF EXISTS PARCHIVECHECK;
delimiter ;;
CREATE PROCEDURE PARCHIVECHECK()
BEGIN
		DECLARE sTableName      VARCHAR(64);
		DECLARE sHisTableName   VARCHAR(64);
		DECLARE sViewTableName  VARCHAR(64);
		DECLARE no_more_col     INT DEFAULT 0;
		DECLARE nCnt            INT DEFAULT 0;
		DECLARE cur             CURSOR FOR
				select c_tablename,c_histablename,c_viewtablename 
				  from ta_tbakconfig 
         where c_tabletype = 'P';
		DECLARE CONTINUE HANDLER FOR NOT FOUND SET no_more_col = 1;

		drop table if exists ta_tcolumns_tmp;
		create table ta_tcolumns_tmp AS
		select * from information_schema.COLUMNS;
		CREATE INDEX idx_columnname ON ta_tcolumns_tmp(COLUMN_NAME ASC );
		
		SET no_more_col = 0;
		OPEN cur;
		FETCH cur INTO sTableName,sHisTableName,sViewTableName;
		WHILE no_more_col<>1 do 
	        set sTableName = trim(sTableName);
	        set sHisTableName = trim(sHisTableName);
	        set sViewTableName = trim(sViewTableName);
	        SELECT count(*) INTO nCnt FROM information_schema.TABLES WHERE TABLE_SCHEMA = database() and table_name=sTableName; 
	        if (sTableName <> '') and (sHisTableName <> '') and (sViewTableName <> '') and (nCnt <> 0) then
				call PCOLMDF(sTableName,sHisTableName);
				call PCREATEVIEW(sTableName,sHisTableName,sViewTableName,1);
			end if;
			FETCH cur INTO sTableName,sHisTableName,sViewTableName;
		END WHILE;
		CLOSE cur;
		drop table if exists ta_tcolumns_tmp;
END;;
delimiter ;


