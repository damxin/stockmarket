DROP FUNCTION IF EXISTS add_date;
DELIMITER ;;
CREATE FUNCTION add_date(v_currentdate INT,n_offset INT)
	RETURNS INT(11)
BEGIN
     RETURN CAST(DATE_ADD(STR_TO_DATE(CONCAT(v_currentdate,''),'%Y%m%d'),INTERVAL n_offset DAY) AS SIGNED) ;
END;;

DELIMITER ;