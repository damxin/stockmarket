drop function if exists getrealdays;
delimiter ;;
create function getrealdays(v_tenantid varchar(20), v_fundcode varchar(6),v_agencyno varchar(9),v_currentdate int,n_offset int)
    returns int DETERMINISTIC
begin
    declare sworktype  char;
    declare sproperty  char;
    declare resultdate int default v_currentdate;
    declare isign      int default 1;
    declare abs_offset int default 0;
    declare lflag      int default 0;
    declare naturedate int default 0;
    declare fetchSeqOk boolean default false;
    declare cur cursor for select a.d_naturedate,
                      if(mod(min(case
                                     when a.c_fundcode = v_fundcode  and a.c_agencyno = v_agencyno then
                                      if(c_workflag=0, 0, 1)
                                     when a.c_fundcode = v_fundcode and a.c_agencyno = '*' then
                                      if(c_workflag=0, 2, 3)
                                     when a.c_fundcode = '*' and a.c_agencyno = v_agencyno then
                                      if(c_workflag=0, 4, 5)
                                     else
                                      if(c_workflag=0, 6, 7)
                                     end),2)=0,0,1) l_flag
                 from ta_topenday a
                where ((isign < 0 and a.d_naturedate < v_currentdate)
                      or (isign > 0 and a.d_naturedate > v_currentdate))
                  and c_tenantid = v_tenantid
                group by a.c_tenantid, a.d_naturedate
                order by a.d_naturedate * isign;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetchSeqOk = TRUE;

    if n_offset=0 then
        return(v_currentdate);
    end if;

    set abs_offset = abs(n_offset);

    if n_offset < 0 then
        set isign = -1;
    end if;

    open cur;
    read_loop:loop
        if fetchSeqOk then 
          leave read_loop; 
        end if;
        fetch cur into naturedate, lflag;
        if lflag = 1 then
            set abs_offset = abs_offset - 1;
        end if;
        set resultdate = naturedate ;
        if abs_offset = 0 then
            leave read_loop;
        end if;
    end loop;
    close cur;
    return(resultdate);
end;;

delimiter ;

