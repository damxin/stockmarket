
DROP FUNCTION IF EXISTS getsysvalue1;
DELIMITER ;;

CREATE FUNCTION getsysvalue1(v_tenantid VARCHAR(20), v_tacode VARCHAR(2), v_agencyno VARCHAR(9),
                            v_manager VARCHAR(10), v_fundcode VARCHAR(6), v_item VARCHAR(40),
                            v_default VARCHAR(255), v_level char)
    RETURNS VARCHAR(255) DETERMINISTIC
BEGIN
    DECLARE v_count INT DEFAULT 0;
    -- DECLARE v_level CHAR;
    DECLARE v_value VARCHAR(255) DEFAULT v_default;

    -- SELECT a.c_paramlevel, COUNT(1) INTO v_level, v_count
    --   FROM ta_tsubtemplatepara a
    --  WHERE a.c_paramitem = v_item
    --    AND a.c_tenantid = v_tenantid;
    
    IF v_level = '-' THEN
      RETURN (v_default);
    END IF;
    
    IF v_level = '0' THEN
      SELECT a.c_paramvalue, COUNT(1) INTO v_value, v_count
        FROM ta_textparameter a
       WHERE a.c_paramitem = v_item
         AND a.c_tacode = v_tacode
         AND a.c_tenantid = v_tenantid;
    ELSEIF v_level = '1' THEN
      SELECT a.c_paramvalue, COUNT(1) INTO v_value, v_count
        FROM ta_textparameter a
       WHERE a.c_paramitem = v_item
         AND a.c_managercode = v_manager 
         and a.c_tacode = v_tacode 
         AND a.c_tenantid = v_tenantid;
    ELSEIF v_level = '2' THEN
      SELECT a.c_paramvalue, COUNT(1) INTO v_value, v_count
        FROM ta_textparameter a
       WHERE a.c_paramitem = v_item
         AND a.c_fundcode = v_fundcode
         AND a.c_tenantid = v_tenantid;
    ELSEIF v_level = '3' THEN
      SELECT a.c_paramvalue, COUNT(1) INTO v_value, v_count
        FROM ta_textparameter a
       WHERE a.c_paramitem = v_item
         AND a.c_agencyno = v_agencyno 
         and a.c_tacode = v_tacode 
         AND a.c_tenantid = v_tenantid;
    ELSEIF v_level = '4' THEN
      SELECT a.c_paramvalue, COUNT(1) INTO v_value, v_count
        FROM ta_textparameter a
       WHERE a.c_paramitem = v_item
         AND a.c_fundcode = v_fundcode
         AND a.c_agencyno = v_agencyno
         AND a.c_tenantid = v_tenantid;
    ELSE
      SET v_count := 0;
      SET v_value := v_default;
    END IF;
    
    IF v_count = 0 THEN
      RETURN (v_default);
    ELSE
      RETURN (v_value);
    END IF;

END;;

DELIMITER ;

