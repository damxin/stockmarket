drop function if exists getliqdays;
delimiter ;;
create function getliqdays(v_tenantid varchar(20), v_fundcode varchar(6), v_agencyno varchar(9), v_currentdate  int, n_offset int, n_skip int)
  returns int
begin
  declare resultdays int default 0;
  declare iSign  int default 1;
  declare nDate  int;
  declare cWorkFlag  char;
  
  if n_offset = 0 then
    return 0;
  end if;

  if n_offset < 0 then
    set iSign = -1;
  end if;

  if n_skip = 0 then
    select date_format(date_add(v_currentdate, interval n_offset day),'%Y%m%d')
      into nDate
      from dual;

    select case mod(min(case when a.c_fundcode=v_fundcode and a.c_agencyno=v_agencyno then (case a.c_workflag when '0' then 0 else 1 end)
                when a.c_fundcode=v_fundcode and a.c_agencyno='*' then (case a.c_workflag when '0' then 2 else 3 end)
                when a.c_fundcode='*' and a.c_agencyno=v_agencyno then (case a.c_workflag when '0' then 4 else 5 end)
                when a.c_fundcode='*' and a.c_agencyno='*' then (case a.c_workflag when '0' then 6 else 7 end) end),2)
           when 1 then '1' else '0' end
      into cWorkFlag
      from ta_topenday a
     where a.d_naturedate = nDate
       and a.c_tenantid   = v_tenantid;

    if cWorkFlag = '0' then
      set nDate = getrealdays(v_tenantid, v_fundcode, v_agencyno, nDate, iSign);
    end if;
  else
    set nDate = getrealdays(v_tenantid,v_fundcode,v_agencyno,v_currentdate,n_offset);
  end if;

  select abs(datediff(v_currentdate,nDate))
    into resultdays
    from dual;
  return(resultdays);
end ;;
delimiter ;

drop function if exists gethkrealdays;
delimiter ;;
create function gethkrealdays(v_tenantid varchar(20),v_fundcode varchar(6),v_agencyno varchar(9),v_currentdate int,n_offset int)
    returns int
begin
    declare resultdate int default v_currentdate;
    declare iSign  int default 1;
    declare abs_offset  int default 0;
    declare lflag      int default 0;
    declare naturedate int default 0;
    declare fetchSeqOk boolean default false;
    declare cur cursor for select A.d_naturedate,
                     if(mod(min(case
                                    when A.C_FUNDCODE = v_fundcode  and A.C_AGENCYNO = v_agencyno then
                                     if(a.c_workflag='0', 0, 1)
                                    when A.C_FUNDCODE = v_fundcode and A.C_AGENCYNO = '*' then
                                     if(a.c_workflag='0', 2, 3)
                                    when A.C_FUNDCODE = '*' and A.C_AGENCYNO = v_agencyno then
                                     if(a.c_workflag='0', 4, 5)
                                    else
                                     if(a.c_workflag='0', 6, 7)
                                    end),2)=1,1,0) L_FLAG
                from (select c_tenantid,c_fundcode,c_agencyno,d_naturedate,c_workflag from ta_topenday union
                    select c_tenantid,c_fundcode,c_agencyno,d_naturedate,c_workflag from ta_thkopenday) A
               where ((iSign < 0 and A.d_naturedate < v_currentdate)
                  or (iSign > 0 and A.d_naturedate > v_currentdate))
                 and c_tenantid = v_tenantid
               group by a.c_tenantid, a.d_naturedate
               order by a.d_naturedate * iSign;
    declare continue handler for not found set fetchSeqOk = true;
    
    if n_offset=0 then
        return(resultdate);
    end if;

    set abs_offset = abs(n_offset);

    if n_offset < 0 then
        set iSign = -1;
    end if;

    open cur;
    read_loop:loop
        if fetchSeqOk then 
          leave read_loop; 
        end if;
        fetch cur into naturedate, lflag;
        if lflag = 1 then
            set abs_offset = abs_offset - 1;
        end if;
        set resultdate = naturedate ;
        if abs_offset = 0 then
            leave read_loop;
        end if;
    end loop;
    close cur;
    return(resultdate);
end ;;
delimiter ;

drop function if exists gethkliqdays;
delimiter ;;
create function gethkliqdays(v_tenantid varchar(20), v_fundcode varchar(6), v_agencyno varchar(9), v_currentdate  int, n_offset int, n_skip int)
  returns int
begin
  declare resultdays int default 0;
  declare iSign  int default 1;
  declare nDate  int;
  declare cWorkFlag  char;
  
  if n_offset = 0 then
    return 0;
  end if;

  if n_offset < 0 then
    set iSign := -1;
  end if;

  if n_skip = 0 then
    select date_format(date_add(v_currentdate, interval n_offset day),'%Y%m%d')
      into nDate
      from dual;
      
    select case mod(min(case when a.c_fundcode=v_fundcode and a.c_agencyno=v_agencyno then (case a.c_workflag when '0' then 0 else 1 end)
                when a.c_fundcode=v_fundcode and a.c_agencyno='*' then (case a.c_workflag when '0' then 2 else 3 end)
                when a.c_fundcode='*' and a.c_agencyno=v_agencyno then (case a.c_workflag when '0' then 4 else 5 end)
                when a.c_fundcode='*' and a.c_agencyno='*' then (case a.c_workflag when '0' then 6 else 7 end) end),2)
           when 1 then '1' else '0' end
      into cWorkFlag
      from (select c_tenantid,c_fundcode,c_agencyno,d_naturedate,c_workflag from ta_topenday
             union
            select c_tenantid,c_fundcode,c_agencyno,d_naturedate,c_workflag from ta_thkopenday) a
     where a.d_naturedate = nDate
       and a.c_tenantid   = v_tenantid;

    if cWorkFlag = '0' then
      set nDate := gethkrealdays(v_tenantid, v_fundcode, v_agencyno, nDate, iSign);
    end if;
  else
    set nDate := gethkrealdays(v_tenantid, v_fundcode, v_agencyno, v_currentdate, n_offset);
  end if;

  select abs(datediff(v_currentdate,nDate))
    into resultdays
    from dual;
  return(resultdays);
end ;;
delimiter ;

drop function if exists getintervaldays;
delimiter ;;
create function getintervaldays(v_tenantid varchar(20), v_fundcode varchar(6), v_agencyno varchar(9), v_currentdate  int, n_offset int, n_skip int, v_ageregion int)
  returns int DETERMINISTIC
begin
  declare resultdays int default 0;

  if v_ageregion = 1 then
    set resultdays = gethkliqdays(v_tenantid,v_fundcode,v_agencyno,v_currentdate,n_offset,n_skip);
  else
    set resultdays = getliqdays(v_tenantid,v_fundcode,v_agencyno,v_currentdate,n_offset,n_skip);
  end if;
  return(resultdays);
end;;
delimiter ;

drop function if exists getshrcfmdays;
delimiter ;;
create function getshrcfmdays(v_tenantid varchar(20), v_fundcode varchar(6), v_agencyno varchar(9), v_businflag  varchar(2))
  returns int
begin
  declare resultdays int default 1;
  declare vcount int default 0; 
  
  select l_tnconfirm,count(1)
    into resultdays,vcount
    from ta_tshrcfmschema
   where c_fundcode = v_fundcode
     and c_agencyno = v_agencyno
     and c_businflag = v_businflag
     and c_tenantid = v_tenantid;
  
  if vcount > 0 then
    return(resultdays);
  end if;
  
  select l_tnconfirm,count(1)
    into resultdays,vcount
    from ta_tshrcfmschema
   where c_fundcode = v_fundcode
     and c_agencyno = '*'
     and c_businflag = v_businflag
     and c_tenantid = v_tenantid;
     
  if vcount > 0 then
    return(resultdays);
  end if;
  
  select l_tnconfirm,count(1)
    into resultdays,vcount
    from ta_tshrcfmschema
   where c_fundcode = v_fundcode
     and c_agencyno = '*'
     and c_businflag = '*'
     and c_tenantid = v_tenantid;
     
  if vcount > 0 then
    return(resultdays);
  end if;
  
  set resultdays = 1;
  return(resultdays);
end;;
delimiter ;

commit;
