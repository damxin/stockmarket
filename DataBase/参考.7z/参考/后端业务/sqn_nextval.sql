drop FUNCTION if exists sqn_nextval;
delimiter ;;
create FUNCTION sqn_nextval(v_tenantid VARCHAR(20), v_tacode varchar(2), v_sqnname VARCHAR(20))
returns int
begin 
	declare lsqncurrval int;
	insert into ta_tsequence(c_tenantid,c_tacode,c_sqnname,l_sqncurrval)
       select v_tenantid,v_tacode,v_sqnname,0 from dual
        where not exists(select l_sqncurrval 
                           from ta_tsequence 
                          where c_tenantid = v_tenantid  
														and c_tacode = v_tacode
														and c_sqnname = v_sqnname);
	select l_sqncurrval into lsqncurrval  
	from ta_tsequence 
	where c_tenantid = v_tenantid  
		and c_tacode = v_tacode
		and c_sqnname = v_sqnname for update;

	update ta_tsequence set l_sqncurrval=l_sqncurrval+1 where c_tenantid = v_tenantid and c_tacode = v_tacode and c_sqnname = v_sqnname;
	set lsqncurrval=lsqncurrval+1;
  return lsqncurrval;
end ;;

delimiter ;

