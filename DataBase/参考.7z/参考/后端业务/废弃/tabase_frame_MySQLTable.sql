-- -------------------------------------------
-- SQLfile   : tabase_frame_MySQLTable.sql
-- Notes    : SQL�ű�
-- -------------------------------------------


-- ������ ta_topenday(��������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_topenday-��������Ϣ��...';
DROP TABLE IF EXISTS ta_topenday;
CREATE TABLE ta_topenday
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	d_naturedate                   int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_workflag                     varchar(1)      DEFAULT '0'        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_topenday ON ta_topenday(d_naturedate ASC ,c_fundcode ASC ,c_agencyno ASC ,c_tenantid ASC );

-- ������ ta_tpoolinfo(�ֿ���Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tpoolinfo-�ֿ���Ϣ��...';
DROP TABLE IF EXISTS ta_tpoolinfo;
CREATE TABLE ta_tpoolinfo
(
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	c_pooltype                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_isused                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_dbalias                      varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_databaseno)
);

-- ������ ta_terrormess(ҵ��ʧ��ԭ���)�ĵ�ǰ��
SELECT 'Create Table ta_terrormess-ҵ��ʧ��ԭ���...';
DROP TABLE IF EXISTS ta_terrormess;
CREATE TABLE ta_terrormess
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_cause                        varchar(4)      DEFAULT ' '        NOT NULL,
	c_outcause                     varchar(4)      DEFAULT '0000'     NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
	c_lang                         varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_cause, c_tenantid)
);

-- ������ ta_tbusinflag(ҵ���־��)�ĵ�ǰ��
SELECT 'Create Table ta_tbusinflag-ҵ���־��...';
DROP TABLE IF EXISTS ta_tbusinflag;
CREATE TABLE ta_tbusinflag
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_businname                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_type                         varchar(1)      DEFAULT ' '        NOT NULL,
	c_request                      varchar(1)      DEFAULT ' '        NOT NULL,
	c_confirm                      varchar(1)      DEFAULT ' '        NOT NULL,
	c_support                      varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_businflag, c_tenantid)
);

-- ������ ta_tbusinchangein(ҵ���־ת���)�ĵ�ǰ��
SELECT 'Create Table ta_tbusinchangein-ҵ���־ת���...';
DROP TABLE IF EXISTS ta_tbusinchangein;
CREATE TABLE ta_tbusinchangein
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_requestflag                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_businname                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_support                      varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_requestflag, c_tenantid)
);

-- ������ ta_tbusinchangeout(ҵ���־ת����)�ĵ�ǰ��
SELECT 'Create Table ta_tbusinchangeout-ҵ���־ת����...';
DROP TABLE IF EXISTS ta_tbusinchangeout;
CREATE TABLE ta_tbusinchangeout
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_confirmflag                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_requestflag                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_businname                    varchar(20)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_requestflag, c_businflag, c_tenantid)
);

-- ������ ta_tdatabaserule(�ֿ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tdatabaserule-�ֿ�����...';
DROP TABLE IF EXISTS ta_tdatabaserule;
CREATE TABLE ta_tdatabaserule
(
	c_tenantidmin                  varchar(20)     DEFAULT ' '        NOT NULL,
	c_tenantidmax                  varchar(20)     DEFAULT ' '        NOT NULL,
	c_fundaccomin                  varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundaccomax                  varchar(12)     DEFAULT ' '        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantidmin, c_tenantidmax, c_fundaccomin, c_fundaccomax, c_databaseno)
);

-- ������ ta_tinterestrate(������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tinterestrate-������Ϣ��...';
DROP TABLE IF EXISTS ta_tinterestrate;
CREATE TABLE ta_tinterestrate
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_interesttype                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_moneytype                    varchar(3)      DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	c_interestratio                decimal(16,8)   DEFAULT 0.0        NOT NULL,
	c_interesttaxratio             decimal(5,4)    DEFAULT 0.0        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tinterestrate ON ta_tinterestrate(c_interesttype ASC ,c_moneytype ASC ,d_begindate ASC ,d_enddate DESC ,c_tenantid ASC );

