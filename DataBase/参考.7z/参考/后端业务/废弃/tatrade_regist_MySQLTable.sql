-- -------------------------------------------
-- SQLfile   : tatrade_regist_MySQLTable.sql
-- Notes    : SQL�ű�
-- -------------------------------------------
-- �޸İ汾    �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                                                                                   ��ע         
-- V1.0.6.2    2017-08-15 10:39                                       ���б�ta_tprofitcurrents�������˱��ֶΣ�c_outfundcode����                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1    2017-07-04 17:25                                       ���б�ta_tstaticshares�������˱��ֶΣ�f_protectbalance����                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1    2016-07-29 20:08                                       ��ǰ��ta_tstaticshares������������ idx_tstatichsares_fnd:[c_fundcode]��;                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1    2017-08-15 10:35                                       ���б�ta_tsharedetail�������˱��ֶΣ�c_lastoutfundcode����                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1    2017-07-11 11:03                                       ���б�ta_tsharedetail�������˱��ֶΣ�f_costfare����                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1    2017-07-04 17:22                                       ���б�ta_tsharedetail�������˱��ֶΣ�f_evennetvalue�������б�ta_tsharedetail�������˱��ֶΣ�c_protectflag�������б�ta_tsharedetail�������˱��ֶΣ�f_backfare����                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1    2017-03-06 17:10                                       ���б�ta_tsharedetail�������˱��ֶΣ�f_orifareratio����                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1    2017-02-20 09:14                                       ���б�ta_tsharedetail�������˱��ֶΣ�f_apportionratio�������б�ta_tsharedetail�������˱��ֶΣ�f_fareratio�������б�ta_tsharedetail�������˱��ֶΣ�f_backfareratio�������б�ta_tsharedetail�������˱��ֶΣ�f_minbackratio����                                                                                                                                                                                                                                            
-- V1.0.6.1    2016-11-09 19:06                                       ���б�ta_tsharedetail�������˱��ֶΣ�f_lastmanagefare����                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1    2016-10-12 13:56                                       ���б�ta_tsharedetail�������˱��ֶΣ�f_costprice����                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1    2016-07-29 20:16                                       ��ǰ��ta_tsharedetail������������ idx_tsharedetail_dcate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1    2016-07-29 20:09                                       ��ǰ��ta_tsharedetail������������ idx_tsharedetail_fnd:[c_fundcode]��;                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1    2016-07-22 19:35                                       ��ǰ��ta_tsharedetail�����������ֶΣ�����idx_tsharedetail_6ele:�����������ֶΣ�c_tenantid����                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1    2017-07-20 19:43                                       ���ݱ�ta_tsharecurrents������������ idx_tsharecurrents_sctsno:[c_shrcrtserailno]��                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1    2017-07-20 19:42                                       ���ݱ�ta_tsharecurrents�����������ֶΣ�����idx_tsharecurrents_fndacco:�����������ֶΣ�c_tradeacco,c_fundcode,c_sharetype,c_agencyno,c_netno����                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1    2017-01-05 15:27                                       ���ݱ�ta_tsharecurrents������������ idx_tsharecurrents_fnd:[c_fundcode]��                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1    2017-07-11 11:08                                       ���б�ta_tdividenddetail�������˱��ֶΣ�c_memo����                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1    2016-11-09 19:14                                       ��ǰ��ta_tdividenddetail������������ idx_tdividenddetail_dbd:[d_distributedate]��;                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1    2016-08-11 15:57                                       ��ǰ��ta_tdividenddetail������������ idx_tdividenddetail_rvd:[d_reinvestdate]��;                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1    2016-08-11 13:01                   �״�                ���б�ta_tdividenddetail�������˱��ֶΣ�f_lastreinvestfare�������б�ta_tdividenddetail�������˱��ֶΣ�f_lastreinvestnetvalue�������б�ta_tdividenddetail�������˱��ֶΣ�f_lastreinvestshares�������б�ta_tdividenddetail�������˱��ֶΣ�f_lastfrozenshares�������б�ta_tdividenddetail�������˱��ֶΣ�d_orioutputdate�������б�ta_tdividenddetail�������˱��ֶΣ�c_oriregisterstatus�������б�ta_tdividenddetail�������˱��ֶΣ�f_lastdeductbalance����                 
-- V1.0.6.1    2016-07-29 20:34                                       ��ǰ��ta_tdividenddetail��ɾ�������ֶΣ�����idx_tdividenddetail_oputd:ɾ���������ֶΣ�c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1    2016-07-29 13:42                                       ��ǰ��ta_tdividenddetail������������ idx_tdividenddetail_oputd:[d_outputdate,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1    2016-08-11 15:57                                       ��ǰ��ta_tunsenddividend������������ idx_tunsenddividend_send:[d_senddate]��;                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1    2016-08-11 13:28                                       ���б�ta_tunsenddividend�����������ֶΣ�c_oridelaycase->c_oridelaycause����                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1    2016-08-11 13:09                   �״�                ���б�ta_tunsenddividend�������˱��ֶΣ�f_lastdeductbalance�������б�ta_tunsenddividend�������˱��ֶΣ�d_orioutputdate����                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1    2016-08-01 16:58                                       ���б�ta_tunsenddividend�������˱��ֶΣ�c_oridelaycase�������б�ta_tunsenddividend�������˱��ֶΣ�d_orisenddate�������б�ta_tunsenddividend�������˱��ֶΣ�f_lastfrozenbalance����                                                                                                                                                                                                                                                                                      
-- V1.0.6.1    2016-07-29 20:35                                       ��ǰ��ta_tunsenddividend��ɾ�������ֶΣ�����idx_tunsenddividend_oputd:ɾ���������ֶΣ�c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1    2016-07-29 13:45                                       ��ǰ��ta_tunsenddividend������������ idx_tunsenddividend_oputd:[d_outputdate,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1    2016-07-14 09:34                                       ���б�ta_tunsenddividend�������˱��ֶΣ�c_schemacode����                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1    2016-08-23 09:42                                       ���б�ta_tfrozendetail�������˱��ֶΣ�f_orilastbalance����                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1    2016-08-05 20:18                                       ��ǰ��ta_tfrozendetail��ɾ���˱�������idx_ta_tfrozendetail��;                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1    2016-08-05 20:17                                       ��ǰ��ta_tfrozendetail������������ idx_tfrozendetail_fnd:[c_fundcode]��;                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1    2016-08-05 19:26                                       ��ǰ��ta_tfrozendetail������������ idx_ta_tfrozendetail:[c_fundcode,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1    2017-08-08 18:42                                       ���б�ta_tassignsharedetail�������˱��ֶΣ�f_detailbackfare����                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1    2017-08-02 13:30                                       ���б�ta_tassignsharedetail�������˱��ֶΣ�f_costfare�������б�ta_tassignsharedetail�������˱��ֶΣ�f_interestshare����                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1    2017-07-04 17:27                                       ���б�ta_tassignsharedetail�������˱��ֶΣ�c_chargingflag����                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1    2017-03-27 13:45                                       ���б�ta_tassignsharedetail�������˱��ֶΣ�d_cycleenddate�������б�ta_tassignsharedetail�������˱��ֶΣ�d_cyclenextdate�������б�ta_tassignsharedetail�������˱��ֶΣ�d_cyclestartdate�������б�ta_tassignsharedetail�������˱��ֶΣ�l_cycle�������б�ta_tassignsharedetail�������˱��ֶΣ�f_assignedincome�������б�ta_tassignsharedetail�������˱��ֶΣ�f_chincome����                                                                                                
-- V1.0.6.1    2017-02-20 09:15                                       ���б�ta_tassignsharedetail�������˱��ֶΣ�f_oriagio�������б�ta_tassignsharedetail�������˱��ֶΣ�f_ruleagio�������б�ta_tassignsharedetail�������˱��ֶΣ�f_orinetvalue����                                                                                                                                                                                                                                                                                           
-- V1.0.6.1    2016-10-17 14:43                                       ���б�ta_tassignsharedetail�������˱��ֶΣ�d_dtlcfmdate����                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1    2016-10-12 13:52                                       ���б�ta_tassignsharedetail�������˱��ֶΣ�l_order����                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1    2016-09-05 14:18                                       ��ǰ��ta_tassignsharedetail������������ idx_tassignsharedetail:[c_fundcode]��;                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1    2016-09-26 15:04                                       �޸�������pk_tstaticshares2deal,�����ֶ��޸�Ϊ��(c_fundcode,c_specialcode,d_cdate,c_tacode,c_tenantid,c_fundacco,c_tradeacco,c_sharetype,c_agencyno,c_netno,c_cserialno),��������޸�Ϊ��null,����Ψһ���޸�Ϊ������Ψһ,��������������Ϊ:������.                                                                                                                                                                                                                       
-- V1.0.6.1    2016-07-23 15:08                                       ��ǰ��ta_tstaticshares2deal�����������ֶ�˳��Ϊ��c_fundcode,c_specialcode,d_cdate,c_tacode,c_tenantid,c_fundacco,c_tradeacco,c_sharetype,c_agencyno,c_netno����                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1    2016-08-11 15:51                                       ��ǰ��ta_tbonusfrozendetail������������ idx_tbonusfrzdetail_cdate:[d_cdate,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1    2016-08-03 14:16                                       ��ǰ��ta_tfloorbalasync�����������ֶ�˳��Ϊ��c_fundcode,c_flowstep,d_cdate,c_fundacco,c_tradeacco,c_cserialno,c_sharetype,c_agencyno,c_netno,c_tenantid����                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1    2016-08-03 14:09                                       ��ǰ��ta_tdisbalasync�����������ֶ�˳��Ϊ��c_fundcode,c_flowstep,c_fundacco,c_tradeacco,c_sharetype,c_agencyno,c_netno,c_cserialno,d_cdate,c_tenantid����                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1    2017-07-24 16:20                                       ���б�ta_tprofitcurrents�������˱��ֶΣ�c_calcflag����                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1    2016-08-05 13:40                                       ���б�ta_tprofitcurrents�������˱��ֶΣ�f_standardratio����                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1    2016-06-08 17:09                   �״�      �״�      ���б�ta_tstaticshares�������˱��ֶΣ�c_oribonustype����                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1    2016-06-05 10:52                                       ���б�ta_tstaticshares�������˱��ֶΣ�f_lastfloorbalance����                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1    2016-06-04 21:25                   �״�                ���б�ta_tstaticshares�������˱��ֶΣ�f_lastincome�������б�ta_tstaticshares�������˱��ֶΣ�f_lastfrozenincome�������б�ta_tstaticshares�������˱��ֶΣ�f_lastfrozenshares�������б�ta_tstaticshares�������˱��ֶΣ�d_orilastmodify����                                                                                                                                                                                                                                 
-- V1.0.5.1    2016-07-09 10:41                                       ���б�ta_tsharedetail�������˱��ֶΣ�d_orilastdeductdate����                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1    2016-06-18 10:45                                       ���б�ta_tsharedetail�������˱��ֶΣ�d_lastdeductdate����                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.1    2016-06-05 09:28                                       ���б�ta_tsharedetail�������˱��ֶΣ�f_lastincome����                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.1    2016-06-18 11:19                                       ���б�ta_tdividenddetail�������˱��ֶΣ�f_deductbalance����                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1    2016-06-18 11:19                                       ���б�ta_tunsenddividend�������˱��ֶΣ�f_deductbalance����                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1    2016-06-12 17:01                                       ���б�ta_tfrozendetail�������˱��ֶΣ�f_lastbalanceright�������б�ta_tfrozendetail�������˱��ֶΣ�f_lastshareright�������б�ta_tfrozendetail�������˱��ֶΣ�d_orilastmodify�������б�ta_tfrozendetail�������˱��ֶΣ�c_oriunfreezeflag����                                                                                                                                                                                                                              
-- V1.0.5.1    2016-06-05 09:32                                       ���б�ta_tfrozendetail�������˱��ֶΣ�f_lastfrozenincome�������б�ta_tfrozendetail�������˱��ֶΣ�f_lastfrozenshares����                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1    2016-06-18 10:03                                       ���б�ta_tassignsharedetail�������˱��ֶΣ�f_deductbalance����                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.1    2016-06-03 13:10                                       ���б�ta_tstaticshares2deal�������˱��ֶΣ�f_frozenincome����                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.1    2016-06-13 09:59                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.1    2016-06-22 20:16                                       ���б�ta_tprofitcurrents�������˱��ֶΣ�d_outputdate����                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1    2016-06-18 10:24                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- �޸İ汾    �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                                                                                   ��ע         
-- V1.0.6.2    2017-04-05 10:29                                       ���б�ta_tshortcyclefinance�������˱��ֶΣ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                                                                                ����ĵ��޸� 
-- �޸İ汾    �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                                                                                   ��ע         
-- �޸İ汾    �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                                                                                   ��ע         
-- V1.0.6.1    2016-10-12 19:54                                       ���б�ta_taccoinfo�������˱��ֶΣ�d_bakdate����                                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1    2016-07-26 15:02                             �״�      ���б�ta_taccoinfo�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1    2017-07-11 19:09                                       ���б�ta_tacconet�������˱��ֶΣ�c_officalcode����                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1    2016-10-12 19:55                                       ���б�ta_tacconet�������˱��ֶΣ�d_bakdate����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1    2016-08-09 10:00                                       ��ǰ��ta_tacconet������������ idx_tacconet_ta:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1    2016-08-09 09:33                                       ��ǰ��ta_tacconet������������ idx_tacconet_trade:[c_tradeacco,c_agencyno,c_netno]��;                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1    2016-07-26 15:16                             �״�      ���б�ta_tacconet�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1    2016-10-12 19:56                                       ���б�ta_tcustomerinfo�������˱��ֶΣ�d_bakdate����                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1    2016-07-26 15:19                             �״�      ���б�ta_tcustomerinfo�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1    2016-11-15 10:47                                       ���б�ta_tmergernet��ɾ���˱��ֶΣ�c_cause����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1    2016-11-15 10:46                                       ���б�ta_tmergernet�������˱��ֶΣ�c_memo����                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.1    2016-06-15 15:37                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.1    2016-07-23 14:34                   �ؽ���    �ؽ���    ���ݱ�ta_tnetinfo���������˱��ֶΣ�c_netregdate->d_netregdate��                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1    2016-06-27 19:07                   �ؽ���    �ؽ���    ���ݱ�ta_tnetinfo������������ pk_netinfo:[l_rowid],uidx_netinfo:[c_tenantid,c_agencyno,c_netno]��                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1    2016-06-27 19:05                   �ؽ���    �ؽ���    ���ݱ�ta_tnetinfo�������˱��ֶΣ�l_rowid,c_tenantid��                                                                                                                                                                                                                                                                                                                                                                                                                   


-- ������ ta_tstaticshares(��̬�ݶ��)�ĵ�ǰ��
SELECT 'Create Table ta_tstaticshares-��̬�ݶ��...';
DROP TABLE IF EXISTS ta_tstaticshares;
CREATE TABLE ta_tstaticshares
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	d_lastmodify                   int             DEFAULT 0          ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	c_invested                     varchar(1)      DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	d_shrsubmitdate                int             DEFAULT 0          ,
	f_pendsubmit02shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit03shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit50shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmitfrzshr             decimal(16,2)   DEFAULT 0.0        ,
	f_assignshare                  decimal(16,2)   DEFAULT 0.0        ,
	f_bonusunit                    decimal(16,2)   DEFAULT 0.0        ,
	f_floorbalance                 decimal(10,9)   DEFAULT 0.0        ,
	f_pendsubmit13shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit16shr              decimal(16,2)   DEFAULT 0.0        ,
	f_lastrealshares               decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit14shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit15shr              decimal(16,2)   DEFAULT 0.0        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	f_lastincome                   decimal(16,2)   DEFAULT 0.0        ,
	f_lastfrozenincome             decimal(16,2)   DEFAULT 0.0        ,
	f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        ,
	d_orilastmodify                int             DEFAULT 0          ,
	f_lastfloorbalance             decimal(10,9)   DEFAULT 0.0        ,
	c_oribonustype                 varchar(1)      DEFAULT ' '        ,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_paybasebala                  decimal(16,2)   DEFAULT 0.0        ,
	l_incserno                     bigint          DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_tradeacco, c_fundcode, c_sharetype, c_agencyno, c_netno, c_tenantid)
);
CREATE INDEX idx_tstatichsares_fnd ON ta_tstaticshares(c_fundcode ASC );

-- ������ ta_tsharedetail(�ݶ���ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tsharedetail-�ݶ���ϸ��...';
DROP TABLE IF EXISTS ta_tsharedetail;
CREATE TABLE ta_tsharedetail
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	f_remainshares                 decimal(16,2)   DEFAULT 0.0        ,
	d_registdate                   int             DEFAULT 0          ,
	f_oricfmbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_oricfmshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_orinetvalue                  decimal(7,4)    DEFAULT 0.0        ,
	c_orisource                    varchar(1)      DEFAULT ' '        ,
	f_ruleagio                     decimal(5,4)    DEFAULT 1.0        ,
	f_oriagio                      decimal(5,4)    DEFAULT 1.0        ,
	f_maxallotratio                decimal(5,4)    DEFAULT 0.0        ,
	f_minredeemratio               decimal(5,4)    DEFAULT 0.0        ,
	c_holdflag                     varchar(1)      DEFAULT ' '        ,
	c_acceptmode                   varchar(1)      DEFAULT ' '        ,
	c_actcode                      varchar(3)      DEFAULT ' '        ,
	c_firstcserailno               varchar(20)     DEFAULT ' '        ,
	c_fundmethod                   varchar(2)      DEFAULT ' '        ,
	c_bankno                       varchar(60)     DEFAULT ' '        ,
	c_subfundmethod                varchar(2)      DEFAULT ' '        ,
	f_managefare                   decimal(16,2)   DEFAULT 0.0        ,
	f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
	d_lastdeductdate               int             DEFAULT 0          ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	f_pendsubmit02shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit03shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit50shr              decimal(16,2)   DEFAULT 0.0        ,
	f_assignshare                  decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit13shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit16shr              decimal(16,2)   DEFAULT 0.0        ,
	f_lastremainshares             decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit14shr              decimal(16,2)   DEFAULT 0.0        ,
	f_pendsubmit15shr              decimal(16,2)   DEFAULT 0.0        ,
	f_lastincome                   decimal(16,2)   DEFAULT 0.0        ,
	d_orilastdeductdate            int             DEFAULT 0          ,
	f_costprice                    decimal(15,12)  DEFAULT 0.0        ,
	f_lastmanagefare               decimal(16,2)   DEFAULT 0.0        ,
	f_apportionratio               decimal(9,8)    DEFAULT 0.0        ,
	f_fareratio                    decimal(5,4)    DEFAULT 0.0        ,
	f_backfareratio                decimal(9,8)    DEFAULT 0.0        ,
	f_minbackratio                 decimal(5,4)    DEFAULT 0.0        ,
	f_orifareratio                 decimal(5,4)    DEFAULT 0.0        ,
	d_cyclestartdate               int             DEFAULT 0          ,
	d_cycleenddate                 int             DEFAULT 0          ,
	d_cyclenextdate                int             DEFAULT 0          ,
	l_cycle                        int             DEFAULT 0          ,
	f_evennetvalue                 decimal(7,4)    DEFAULT 0.0        ,
	c_protectflag                  varchar(1)      DEFAULT ' '        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_costfare                     decimal(16,2)   DEFAULT 0.0        ,
	c_lastoutfundcode              varchar(20)     DEFAULT ' '        ,
	f_redeemedbaseshr              decimal(16,2)   DEFAULT 0.0        ,
	l_incserno                     bigint          DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
CREATE INDEX idx_tsharedetail_6ele ON ta_tsharedetail(c_fundacco ASC ,c_agencyno ASC ,c_netno ASC ,c_tradeacco ASC ,c_fundcode ASC ,c_sharetype ASC ,c_tenantid ASC );
CREATE INDEX idx_tsharedetail_fnd ON ta_tsharedetail(c_fundcode ASC );
CREATE INDEX idx_tsharedetail_dcate ON ta_tsharedetail(d_cdate ASC );

-- ������ ta_tsharecurrents(�ݶ�仯��ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tsharecurrents-�ݶ�仯��ˮ��...';
DROP TABLE IF EXISTS ta_tsharecurrents;
CREATE TABLE ta_tsharecurrents
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	f_occurshares                  decimal(16,2)   DEFAULT 0.0        ,
	f_occurbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_lastshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_occurfreeze                  decimal(16,2)   DEFAULT 0.0        ,
	f_lastfreezeshares             decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_shrcrtserailno               varchar(14)     DEFAULT ' '        ,
	c_adjustcause                  varchar(1)      DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
CREATE INDEX idx_tsharecurrents_cdate ON ta_tsharecurrents(d_cdate ASC );
CREATE INDEX idx_tsharecurrents_fndacco ON ta_tsharecurrents(c_fundacco ASC ,c_tradeacco ASC ,c_fundcode ASC ,c_sharetype ASC ,c_agencyno ASC ,c_netno ASC );
CREATE INDEX idx_tsharecurrents_fnd ON ta_tsharecurrents(c_fundcode ASC );
CREATE INDEX idx_tsharecurrents_sctsno ON ta_tsharecurrents(c_shrcrtserailno ASC );

-- ������ ta_tsharecurrents_his(�ݶ�仯��ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tsharecurrents_his-�ݶ�仯��ˮ��...';
DROP TABLE IF EXISTS ta_tsharecurrents_his;
CREATE TABLE ta_tsharecurrents_his
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	f_occurshares                  decimal(16,2)   DEFAULT 0.0        ,
	f_occurbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_lastshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_occurfreeze                  decimal(16,2)   DEFAULT 0.0        ,
	f_lastfreezeshares             decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_shrcrtserailno               varchar(14)     DEFAULT ' '        ,
	c_adjustcause                  varchar(1)      DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
CREATE INDEX idx_tsharecurrents_cdate ON ta_tsharecurrents_his(d_cdate ASC );
CREATE INDEX idx_tsharecurrents_fndacco ON ta_tsharecurrents_his(c_fundacco ASC ,c_tradeacco ASC ,c_fundcode ASC ,c_sharetype ASC ,c_agencyno ASC ,c_netno ASC );
CREATE INDEX idx_tsharecurrents_fnd ON ta_tsharecurrents_his(c_fundcode ASC );
CREATE INDEX idx_tsharecurrents_sctsno ON ta_tsharecurrents_his(c_shrcrtserailno ASC );

-- ������ ta_tdividenddetail(�ֺ���ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tdividenddetail-�ֺ���ϸ��...';
DROP TABLE IF EXISTS ta_tdividenddetail;
CREATE TABLE ta_tdividenddetail
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	d_registerdate                 int             DEFAULT 0          ,
	d_distributedate               int             DEFAULT 0          ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	f_profittotalshares            decimal(16,2)   DEFAULT 0.0        ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	f_profittax                    decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestnetvalue             decimal(7,4)    DEFAULT 0.0        ,
	f_reinvestfare                 decimal(16,2)   DEFAULT 0.0        ,
	d_reinvestdate                 int             DEFAULT 0          ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	f_profitratio                  decimal(5,4)    DEFAULT 0.0        ,
	d_outputdate                   int             DEFAULT 0          ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_registerstatus               varchar(1)      DEFAULT ' '        ,
	c_frzdtlcserialno              varchar(20)     DEFAULT ' '        ,
	c_schemacode                   varchar(20)     DEFAULT ' '        ,
	f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_lastreinvestfare             decimal(16,2)   DEFAULT 0.0        ,
	f_lastreinvestnetvalue         decimal(7,4)    DEFAULT 0.0        ,
	f_lastreinvestshares           decimal(16,2)   DEFAULT 0.0        ,
	f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        ,
	d_orioutputdate                int             DEFAULT 0          ,
	c_oriregisterstatus            varchar(1)      DEFAULT ' '        ,
	f_lastdeductbalance            decimal(16,2)   DEFAULT 0.0        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
CREATE INDEX idx_tdividenddetail ON ta_tdividenddetail(c_fundacco ASC ,c_agencyno ASC ,c_netno ASC ,c_fundcode ASC ,c_sharetype ASC ,c_tradeacco ASC ,d_registerdate ASC ,c_tenantid ASC );
CREATE INDEX idx_tdividenddetail_cdate ON ta_tdividenddetail(d_cdate ASC );
CREATE INDEX idx_tdividenddetail_oputd ON ta_tdividenddetail(d_outputdate ASC );
CREATE INDEX idx_tdividenddetail_rvd ON ta_tdividenddetail(d_reinvestdate ASC );
CREATE INDEX idx_tdividenddetail_dbd ON ta_tdividenddetail(d_distributedate ASC );

-- ������ ta_tdividenddetail_his(�ֺ���ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tdividenddetail_his-�ֺ���ϸ��...';
DROP TABLE IF EXISTS ta_tdividenddetail_his;
CREATE TABLE ta_tdividenddetail_his
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	d_registerdate                 int             DEFAULT 0          ,
	d_distributedate               int             DEFAULT 0          ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	f_profittotalshares            decimal(16,2)   DEFAULT 0.0        ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	f_profittax                    decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestnetvalue             decimal(7,4)    DEFAULT 0.0        ,
	f_reinvestfare                 decimal(16,2)   DEFAULT 0.0        ,
	d_reinvestdate                 int             DEFAULT 0          ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	f_profitratio                  decimal(5,4)    DEFAULT 0.0        ,
	d_outputdate                   int             DEFAULT 0          ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_registerstatus               varchar(1)      DEFAULT ' '        ,
	c_frzdtlcserialno              varchar(20)     DEFAULT ' '        ,
	c_schemacode                   varchar(20)     DEFAULT ' '        ,
	f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_lastreinvestfare             decimal(16,2)   DEFAULT 0.0        ,
	f_lastreinvestnetvalue         decimal(7,4)    DEFAULT 0.0        ,
	f_lastreinvestshares           decimal(16,2)   DEFAULT 0.0        ,
	f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        ,
	d_orioutputdate                int             DEFAULT 0          ,
	c_oriregisterstatus            varchar(1)      DEFAULT ' '        ,
	f_lastdeductbalance            decimal(16,2)   DEFAULT 0.0        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
CREATE INDEX idx_tdividenddetail ON ta_tdividenddetail_his(c_fundacco ASC ,c_agencyno ASC ,c_netno ASC ,c_fundcode ASC ,c_sharetype ASC ,c_tradeacco ASC ,d_registerdate ASC ,c_tenantid ASC );
CREATE INDEX idx_tdividenddetail_cdate ON ta_tdividenddetail_his(d_cdate ASC );
CREATE INDEX idx_tdividenddetail_oputd ON ta_tdividenddetail_his(d_outputdate ASC );
CREATE INDEX idx_tdividenddetail_rvd ON ta_tdividenddetail_his(d_reinvestdate ASC );
CREATE INDEX idx_tdividenddetail_dbd ON ta_tdividenddetail_his(d_distributedate ASC );

-- ������ ta_tunsenddividend(δ���ŷֺ���ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tunsenddividend-δ���ŷֺ���ϸ��...';
DROP TABLE IF EXISTS ta_tunsenddividend;
CREATE TABLE ta_tunsenddividend
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_cserialnototal               varchar(20)     DEFAULT ' '        ,
	d_registerdate                 int             DEFAULT 0          ,
	d_distributedate               int             DEFAULT 0          ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	f_profittotalshares            decimal(16,2)   DEFAULT 0.0        ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_profittax                    decimal(16,2)   DEFAULT 0.0        ,
	f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestfare                 decimal(16,2)   DEFAULT 0.0        ,
	d_reinvestdate                 int             DEFAULT 0          ,
	f_reinvestnetvalue             decimal(7,4)    DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_profitratio                  decimal(5,4)    DEFAULT 0.0        ,
	c_delaycause                   varchar(1)      DEFAULT ' '        ,
	d_senddate                     int             DEFAULT 0          ,
	c_frozenno                     varchar(20)     DEFAULT ' '        ,
	d_outputdate                   int             DEFAULT 0          ,
	f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
	c_schemacode                   varchar(20)     DEFAULT ' '        ,
	c_oridelaycause                varchar(1)      DEFAULT ' '        ,
	d_orisenddate                  int             DEFAULT 0          ,
	f_lastfrozenbalance            decimal(16,2)   DEFAULT 0.0        ,
	f_lastdeductbalance            decimal(16,2)   DEFAULT 0.0        ,
	d_orioutputdate                int             DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
CREATE INDEX idx_tunsenddividend ON ta_tunsenddividend(c_fundacco ASC ,c_tradeacco ASC ,c_fundcode ASC ,c_sharetype ASC ,c_agencyno ASC ,c_netno ASC ,c_tenantid ASC ,c_frozenno ASC );
CREATE INDEX idx_tunsenddividend_oputd ON ta_tunsenddividend(d_outputdate ASC );
CREATE INDEX idx_tunsenddividend_send ON ta_tunsenddividend(d_senddate ASC );

-- ������ ta_tincome(��������)�ĵ�ǰ��
SELECT 'Create Table ta_tincome-��������...';
DROP TABLE IF EXISTS ta_tincome;
CREATE TABLE ta_tincome
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	d_duedate                      int             DEFAULT 0          ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_realshares_pre               decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares_pre             decimal(16,2)   DEFAULT 0.0        ,
	f_income_pre                   decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome_pre             decimal(16,2)   DEFAULT 0.0        ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
	c_detailflag                   varchar(1)      DEFAULT ' '        ,
	d_registdate                   int             DEFAULT 0          ,
	c_oricserialno                 varchar(20)     DEFAULT ' '        NOT NULL,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
PRIMARY KEY(d_cdate, c_fundacco, c_tradeacco, c_agencyno, c_netno, c_fundcode, c_sharetype, c_oricserialno, c_tenantid)
);

-- ������ ta_tincome_his(��������)�ĵ�ǰ��
SELECT 'Create Table ta_tincome_his-��������...';
DROP TABLE IF EXISTS ta_tincome_his;
CREATE TABLE ta_tincome_his
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	d_duedate                      int             DEFAULT 0          ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_realshares_pre               decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares_pre             decimal(16,2)   DEFAULT 0.0        ,
	f_income_pre                   decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome_pre             decimal(16,2)   DEFAULT 0.0        ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
	c_detailflag                   varchar(1)      DEFAULT ' '        ,
	d_registdate                   int             DEFAULT 0          ,
	c_oricserialno                 varchar(20)     DEFAULT ' '        NOT NULL,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
PRIMARY KEY(d_cdate, c_fundacco, c_tradeacco, c_agencyno, c_netno, c_fundcode, c_sharetype, c_oricserialno, c_tenantid)
);

-- ������ ta_tfrozendetail(������ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfrozendetail-������ϸ��...';
DROP TABLE IF EXISTS ta_tfrozendetail;
CREATE TABLE ta_tfrozendetail
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_frozendate                   int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	c_freezetype                   varchar(1)      DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_frozenrightflag              varchar(1)      DEFAULT ' '        ,
	f_balanceright                 decimal(16,2)   DEFAULT 0.0        ,
	f_shareright                   decimal(16,2)   DEFAULT 0.0        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_unfreezeflag                 varchar(1)      DEFAULT ' '        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
	d_appenddate                   int             DEFAULT 0          ,
	f_lastbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_lastfrozenincome             decimal(16,2)   DEFAULT 0.0        ,
	f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        ,
	f_lastbalanceright             decimal(16,2)   DEFAULT 0.0        ,
	f_lastshareright               decimal(16,2)   DEFAULT 0.0        ,
	d_orilastmodify                int             DEFAULT 0          ,
	c_oriunfreezeflag              varchar(1)      DEFAULT ' '        ,
	f_orilastbalance               decimal(16,2)   DEFAULT 0.0        ,
	l_incserno                     bigint          DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
CREATE INDEX idx_tfrozendetail_fnd ON ta_tfrozendetail(c_fundcode ASC );

-- ������ ta_tassignsharedetail(�ݶ���ϸ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tassignsharedetail-�ݶ���ϸ�����...';
DROP TABLE IF EXISTS ta_tassignsharedetail;
CREATE TABLE ta_tassignsharedetail
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_oricserialno                 varchar(20)     DEFAULT ' '        NOT NULL,
	f_assignshare                  decimal(16,2)   DEFAULT 0.0        ,
	f_oricfmbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_oricfmshares                 decimal(16,2)   DEFAULT 0.0        ,
	d_originaldate                 int             DEFAULT 0          ,
	c_firstcserailno               varchar(20)     DEFAULT ' '        ,
	d_lastdeductdate               int             DEFAULT 0          ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	f_othercfmshares               decimal(16,2)   DEFAULT 0.0        ,
	f_managefare                   decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_fundtraderatio               decimal(9,8)    DEFAULT 0.0        ,
	f_oritradefare                 decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
	c_fundmethod                   varchar(2)      DEFAULT ' '        ,
	c_acceptmode                   varchar(1)      DEFAULT ' '        ,
	c_orisource                    varchar(1)      DEFAULT ' '        ,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	f_takedincome                  decimal(16,2)   DEFAULT 0.0        ,
	f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
	l_order                        int             DEFAULT 0          ,
	d_dtlcfmdate                   int             DEFAULT 0          ,
	f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
	f_ruleagio                     decimal(5,4)    DEFAULT 0.0        ,
	f_orinetvalue                  decimal(7,4)    DEFAULT 0.0        ,
	d_cyclestartdate               int             DEFAULT 0          ,
	d_cycleenddate                 int             DEFAULT 0          ,
	d_cyclenextdate                int             DEFAULT 0          ,
	l_cycle                        int             DEFAULT 0          ,
	f_assignedincome               decimal(16,2)   DEFAULT 0.0        ,
	f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
	c_chargingflag                 varchar(1)      DEFAULT ' '        ,
	f_costfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
	f_detailbackfare               decimal(23,9)   DEFAULT 0.0        ,
	f_redeemedbaseshr              decimal(16,2)   DEFAULT 0.0        ,
	f_paybasebala                  decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_cserialno, c_oricserialno)
);
CREATE INDEX idx_tassignsharedetail ON ta_tassignsharedetail(c_fundcode ASC );

-- ������ ta_tstaticshares2deal(��̬�ݶ����)�ĵ�ǰ��
SELECT 'Create Table ta_tstaticshares2deal-��̬�ݶ����...';
DROP TABLE IF EXISTS ta_tstaticshares2deal;
CREATE TABLE ta_tstaticshares2deal
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_unbonusbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_unprecisionbalance           decimal(23,9)   DEFAULT 0.0        ,
	f_tail                         decimal(10,9)   DEFAULT 0.0        ,
	f_bonusbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbonusbalance           decimal(16,2)   DEFAULT 0.0        ,
	f_bonustotalshares             decimal(16,2)   DEFAULT 0.0        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	f_tax                          decimal(16,2)   DEFAULT 0.0        ,
	f_frozentax                    decimal(16,2)   DEFAULT 0.0        ,
	d_regdate                      int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_specialcode                  varchar(20)     DEFAULT ' '        NOT NULL,
	c_status                       varchar(1)      DEFAULT ' '        ,
	f_floorbalance                 decimal(10,9)   DEFAULT 0.0        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundcode, c_specialcode, d_cdate, c_tacode, c_tenantid, c_fundacco, c_tradeacco, c_sharetype, c_agencyno, c_netno, c_cserialno, d_regdate)
);
CREATE INDEX idx_tstashrdeal_fndacco ON ta_tstaticshares2deal(c_fundacco ASC );

-- ������ ta_tbonusfrozendetail(�ֺ춳����ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tbonusfrozendetail-�ֺ춳����ϸ��...';
DROP TABLE IF EXISTS ta_tbonusfrozendetail;
CREATE TABLE ta_tbonusfrozendetail
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_bonuscserailno               varchar(20)     DEFAULT ' '        ,
	c_frozencserailno              varchar(20)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_unfreezeflag                 varchar(1)      DEFAULT ' '        ,
	d_lastmodify                   int             DEFAULT 0          ,
	f_unfrozenshares               decimal(16,2)   DEFAULT 0.0        ,
	c_unfrozencserialno            varchar(20)     DEFAULT ' '        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
CREATE INDEX idx_tbonusfrzdetail_cdate ON ta_tbonusfrozendetail(d_cdate ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_ttailstatsync(�ֿ�β��ͳ��ͬ����)�ĵ�ǰ��
SELECT 'Create Table ta_ttailstatsync-�ֿ�β��ͳ��ͬ����...';
DROP TABLE IF EXISTS ta_ttailstatsync;
CREATE TABLE ta_ttailstatsync
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	f_assignmount                  decimal(16,2)   DEFAULT 0.0        ,
	f_assignmintail                decimal(9,8)    DEFAULT 0.0        ,
	f_assignminshare               decimal(16,2)   DEFAULT 0.0        ,
	f_assignminfloor               decimal(10,9)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_flowstep, c_databaseno, c_tenantid)
);

-- ������ ta_ttaildissync(����β�����ͬ����)�ĵ�ǰ��
SELECT 'Create Table ta_ttaildissync-����β�����ͬ����...';
DROP TABLE IF EXISTS ta_ttaildissync;
CREATE TABLE ta_ttaildissync
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	f_fundtotaltail                decimal(16,2)   DEFAULT 0.0        ,
	f_fundmintail                  decimal(9,8)    DEFAULT 0.0        ,
	f_fundminfloor                 decimal(10,9)   DEFAULT 0.0        ,
	f_fundminshare                 decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_fundcode, d_cdate, c_databaseno, c_flowstep, c_tenantid)
);

-- ������ ta_tfloorbalasync(�ֿ�β����ͬ����)�ĵ�ǰ��
SELECT 'Create Table ta_tfloorbalasync-�ֿ�β����ͬ����...';
DROP TABLE IF EXISTS ta_tfloorbalasync;
CREATE TABLE ta_tfloorbalasync
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	f_tail                         decimal(10,9)   DEFAULT 0.0        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_floorbalance                 decimal(10,9)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundcode, c_flowstep, d_cdate, c_fundacco, c_tradeacco, c_cserialno, c_sharetype, c_agencyno, c_netno, c_tenantid)
);

-- ������ ta_tincome_pre(�������Ԥ������)�ĵ�ǰ��
SELECT 'Create Table ta_tincome_pre-�������Ԥ������...';
DROP TABLE IF EXISTS ta_tincome_pre;
CREATE TABLE ta_tincome_pre
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
	c_detailflag                   varchar(1)      DEFAULT ' '        ,
	c_specialaccoflag              varchar(1)      DEFAULT ' '        ,
	c_oricserialno                 varchar(20)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(d_cdate, c_fundacco, c_tradeacco, c_agencyno, c_netno, c_fundcode, c_sharetype, c_oricserialno, c_tenantid)
);

-- ������ ta_tecontractinfo(���Ӻ�ͬ��Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tecontractinfo-���Ӻ�ͬ��Ϣ��...';
DROP TABLE IF EXISTS ta_tecontractinfo;
CREATE TABLE ta_tecontractinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_contracttype                 varchar(1)      DEFAULT ' '        ,
	c_contractno                   varchar(26)     DEFAULT ' '        NOT NULL,
	c_confirmstatusmanager         varchar(1)      DEFAULT ' '        ,
	c_confirmstatuscustod          varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_fundmanagercode              varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	d_signdate                     int             DEFAULT 0          ,
	d_signtime                     int             DEFAULT 0          ,
	c_signchannel                  varchar(1)      DEFAULT ' '        ,
	c_signmachine                  varchar(60)     DEFAULT ' '        ,
	c_opernetno                    varchar(22)     DEFAULT ' '        ,
	c_notesagent                   varchar(64)     DEFAULT ' '        ,
	c_notesmanager                 varchar(64)     DEFAULT ' '        ,
	c_notescustod                  varchar(64)     DEFAULT ' '        ,
	d_importdate                   int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_caption                      varchar(100)    DEFAULT ' '        ,
	c_encserialno                  varchar(12)     DEFAULT ' '        ,
	c_postzd                       varchar(1)      DEFAULT ' '        ,
	c_notes                        varchar(64)     DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_postcode                     varchar(10)     DEFAULT ' '        ,
	c_postemail                    varchar(48)     DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_telno                        varchar(32)     DEFAULT ' '        ,
	c_cardno                       varchar(22)     DEFAULT ' '        ,
	d_modifydatemanager            int             DEFAULT 0          ,
	d_modifydatecustod             int             DEFAULT 0          ,
	d_modifydateagent              int             DEFAULT 0          ,
	c_issignriskboard              varchar(1)      DEFAULT ' '        ,
	c_isriskmatching               varchar(1)      DEFAULT ' '        ,
	c_riskabilityresult            varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_srctype                      varchar(1)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_idcard18len                  varchar(1)      DEFAULT ' '        ,
	c_signtype                     varchar(1)      DEFAULT ' '        ,
	d_appenddate                   int             DEFAULT 0          ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_busincode                    varchar(3)      DEFAULT ' '        ,
PRIMARY KEY(c_contractno, c_tenantid, c_tacode)
);
CREATE INDEX idx_iecontractinfo ON ta_tecontractinfo(c_fundacco ASC ,c_fundcode ASC ,c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );
CREATE INDEX idx_custod ON ta_tecontractinfo(c_confirmstatuscustod ASC ,c_tenantid ASC );
CREATE INDEX idx_manager ON ta_tecontractinfo(c_confirmstatusmanager ASC ,c_tenantid ASC );

-- ������ ta_tecontractinfo_bak(���Ӻ�ͬ��Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tecontractinfo_bak-���Ӻ�ͬ��Ϣ��...';
DROP TABLE IF EXISTS ta_tecontractinfo_bak;
CREATE TABLE ta_tecontractinfo_bak
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_contracttype                 varchar(1)      DEFAULT ' '        ,
	c_contractno                   varchar(26)     DEFAULT ' '        NOT NULL,
	c_confirmstatusmanager         varchar(1)      DEFAULT ' '        ,
	c_confirmstatuscustod          varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_fundmanagercode              varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	d_signdate                     int             DEFAULT 0          ,
	d_signtime                     int             DEFAULT 0          ,
	c_signchannel                  varchar(1)      DEFAULT ' '        ,
	c_signmachine                  varchar(60)     DEFAULT ' '        ,
	c_opernetno                    varchar(22)     DEFAULT ' '        ,
	c_notesagent                   varchar(64)     DEFAULT ' '        ,
	c_notesmanager                 varchar(64)     DEFAULT ' '        ,
	c_notescustod                  varchar(64)     DEFAULT ' '        ,
	d_importdate                   int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_caption                      varchar(100)    DEFAULT ' '        ,
	c_encserialno                  varchar(12)     DEFAULT ' '        ,
	c_postzd                       varchar(1)      DEFAULT ' '        ,
	c_notes                        varchar(64)     DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_postcode                     varchar(10)     DEFAULT ' '        ,
	c_postemail                    varchar(48)     DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_telno                        varchar(32)     DEFAULT ' '        ,
	c_cardno                       varchar(22)     DEFAULT ' '        ,
	d_modifydatemanager            int             DEFAULT 0          ,
	d_modifydatecustod             int             DEFAULT 0          ,
	d_modifydateagent              int             DEFAULT 0          ,
	c_issignriskboard              varchar(1)      DEFAULT ' '        ,
	c_isriskmatching               varchar(1)      DEFAULT ' '        ,
	c_riskabilityresult            varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_srctype                      varchar(1)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_idcard18len                  varchar(1)      DEFAULT ' '        ,
	c_signtype                     varchar(1)      DEFAULT ' '        ,
	d_appenddate                   int             DEFAULT 0          ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_busincode                    varchar(3)      DEFAULT ' '        ,
PRIMARY KEY(c_contractno, c_tenantid, c_tacode)
);
CREATE INDEX idx_iecontractinfo ON ta_tecontractinfo_bak(c_fundacco ASC ,c_fundcode ASC ,c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );
CREATE INDEX idx_custod ON ta_tecontractinfo_bak(c_confirmstatuscustod ASC ,c_tenantid ASC );
CREATE INDEX idx_manager ON ta_tecontractinfo_bak(c_confirmstatusmanager ASC ,c_tenantid ASC );

-- ������ ta_tarchiveschema(�鵵������)�ĵ�ǰ��
SELECT 'Create Table ta_tarchiveschema-�鵵������...';
DROP TABLE IF EXISTS ta_tarchiveschema;
CREATE TABLE ta_tarchiveschema
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_archivedate                  int             DEFAULT 0          ,
	c_dealstatus                   varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX idx_archiv ON ta_tarchiveschema(d_cdate ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tdisbalasync(���������ͬ����)�ĵ�ǰ��
SELECT 'Create Table ta_tdisbalasync-���������ͬ����...';
DROP TABLE IF EXISTS ta_tdisbalasync;
CREATE TABLE ta_tdisbalasync
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	f_floorbalance                 decimal(10,9)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundcode, c_flowstep, c_fundacco, c_tradeacco, c_sharetype, c_agencyno, c_netno, c_cserialno, d_cdate, c_tenantid)
);

-- ������ ta_tbaseprofitstat(����������ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tbaseprofitstat-����������ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tbaseprofitstat;
CREATE TABLE ta_tbaseprofitstat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	f_fundtotalprofit              decimal(16,2)   DEFAULT 0.0        ,
	f_fundtotalshare               decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_fundcode, c_databaseno, d_cdate, c_flowstep, c_tenantid)
);

-- ������ ta_tprofitcurrents(ҵ�������ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitcurrents-ҵ�������ˮ��...';
DROP TABLE IF EXISTS ta_tprofitcurrents;
CREATE TABLE ta_tprofitcurrents
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_sortflag                     varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_cserialnototal               varchar(20)     DEFAULT ' '        ,
	c_oricserialno                 varchar(20)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_registdate                   int             DEFAULT 0          ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	d_begindate                    int             DEFAULT 0          ,
	f_orinav                       decimal(7,4)    DEFAULT 0.0        ,
	f_oritotalnav                  decimal(7,4)    DEFAULT 0.0        ,
	f_nav                          decimal(7,4)    DEFAULT 0.0        ,
	f_totalnav                     decimal(7,4)    DEFAULT 0.0        ,
	f_curratio                     decimal(16,8)   DEFAULT 0.0        ,
	f_yearratio                    decimal(16,8)   DEFAULT 0.0        ,
	f_ductmanagerfare              decimal(16,2)   DEFAULT 0.0        ,
	f_returnfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_oribalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_factbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_factshare                    decimal(16,2)   DEFAULT 0.0        ,
	f_bonusbalance                 decimal(16,2)   DEFAULT 0.0        ,
	d_date                         int             DEFAULT 0          ,
	l_holddays                     int             DEFAULT 0          ,
	d_outputdate                   int             DEFAULT 0          ,
	f_standardratio                decimal(11,8)   DEFAULT 0.0        ,
	c_calcflag                     varchar(1)      DEFAULT '0'        ,
	c_outfundcode                  varchar(12)     DEFAULT ' '        ,
	f_factductmanagerfare          decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_tenantid, c_cserialno)
);

