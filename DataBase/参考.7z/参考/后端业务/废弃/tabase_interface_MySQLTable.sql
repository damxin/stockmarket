-- -------------------------------------------
-- SQLfile   : tabase_interface_MySQLTable.sql
-- Notes    : SQL�ű�
-- -------------------------------------------
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                 ��ע 
-- V1.0.6.1     2016-10-15 11:05                                       ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_isreceivebroadcast����                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2016-09-07 15:29                                       ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_newnavdate����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-08-20 11:02                   �״�                ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_agencytype����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2017-04-14 19:27                                       ���б�ta_tcustexpbatch�������˱��ֶΣ�d_begindate�������б�ta_tcustexpbatch�������˱��ֶΣ�d_enddate����                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-11-14 19:57                                       ��ǰ��ta_tliqexpbatch�����������ֶ�˳��Ϊ��c_trusteecode,c_managercode,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2016-11-14 19:56                                       ��ǰ��ta_tliqexpbatch�����������ֶΣ�c_trusteecode����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1     2016-11-14 17:31                                       ��ǰ��ta_tliqexpbatch������������ c_managercode,c_tacode,c_tenanti��;                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2016-11-14 17:30                                       ��ǰ��ta_tliqexpbatch��ɾ���˱�������uidx_tliqexpbatch��;                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-06-16 10:59                                       ���б�ta_tcenterexpbatch�������˱��ֶΣ�d_zhzlcentralizedate����                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2017-06-15 16:05                                       ���б�ta_tcenterexpbatch�������˱��ֶΣ�c_centralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�c_zhcentralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�c_zhzlcentralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�d_zhcentralizedate����                                                                                                                                      
-- V1.0.6.1     2016-11-01 19:05                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�f_otherfee2����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-10-27 12:23                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-10-27 12:22                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-10-27 10:41                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-08-31 16:13                                       ���б�ta_tagencynavc4file�������˱��ֶΣ�f_unitprofittxt����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-08-31 16:13                                       ���б�ta_tagencynavc4file��ɾ���˱��ֶΣ�f_unitprofit����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-12-20 17:15                                       ���б�ta_tagencynav07file�������˱��ֶΣ�c_infundcode����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-05-22 18:45                                       ���б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_newtradeacco����                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-05-22 18:45                                       ���б�ta_tagencyreqnorstd01file��ɾ���˱��ֶΣ�c_othertradeacco����                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2017-05-17 15:41                                       ���б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_oriidentityno�������б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_oricontno�������б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_contidcard18len����                                                                                                                                                                                          
-- V1.0.6.1     2017-02-15 17:20                                       ���б�ta_tliqredeemfile�������˱��ֶΣ�f_deductmngfare����                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2017-02-16 09:37                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�f_rshares_ch�������б�ta_tliqadjustsharefile�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-02-16 09:31                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2017-02-16 09:30                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�f_rshares_ch����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2017-02-15 17:10                                       ���б�ta_tliqbonusfile�������˱��ֶΣ�f_aheadincome����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2017-02-16 14:26                                       ���б�ta_tliqswitchoutfile���޸��˱��ֶ������գ�f_otherfare����                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1     2017-02-16 14:22                                       ���б�ta_tliqswitchoutfile�������˱��ֶΣ�f_otherfare����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-02-16 14:27                                       ���б�ta_tliqswitchfile���޸��˱��ֶ������գ�f_otherfare����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2017-02-16 14:21                                       ���б�ta_tliqswitchfile�������˱��ֶΣ�f_otherfare����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1     2017-02-16 09:35                                       ���б�ta_tliqincomefile�������˱��ֶΣ�f_endaccumshares����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2017-02-16 09:23                                       ���б�ta_tliqincomefile�������˱��ֶΣ�f_endaccumshares����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2016-11-07 17:14                                       ���б�ta_tcustconfirmfile��ɾ���˱��ֶΣ�l_serialno����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-11-07 17:13                                       ���б�ta_tcustconfirmfile�������˱��ֶΣ�l_serialnumber����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2016-11-07 18:16                                       ���б�ta_tcustprofitcurrentfile��ɾ���˱��ֶΣ�l_serialno����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-11-07 18:14                                       ���б�ta_tcustprofitcurrentfile�������˱��ֶΣ�l_serialnumber����                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-06-01 17:28                                       ���б�ta_tcentralize92file�������˱��ֶΣ�c_nationality����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2017-05-31 17:13                                       ���б�ta_tcentralize96file�������˱��ֶΣ�f_deductfare�������б�ta_tcentralize96file�������˱��ֶΣ�c_deductflag����                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2017-06-01 18:33                                       ���б�ta_tcentralizeg1file�������˱��ֶΣ�f_taxratio�������б�ta_tcentralizeg1file�������˱��ֶΣ�d_ratiodate����                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-06-01 18:12                                       ���б�ta_tcentralizet1file�������˱��ֶΣ�c_formalfundcode�������б�ta_tcentralizet1file�������˱��ֶΣ�c_priorsequence�������б�ta_tcentralizet1file�������˱��ֶΣ�f_leveragemultiple�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadname�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadbuscode�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadmancode����         
-- V1.0.6.1     2017-06-01 18:30                                       ���б�ta_tcentralizet2file�������˱��ֶΣ�f_leveragerate�������б�ta_tcentralizet2file�������˱��ֶΣ�f_leveragemultiple����                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-10-24 16:35                                       ��ǰ��ta_tsalequalify_tmp������������ idx_tsalequalify_tmp:[c_fundcode,c_agencyno]��;                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2016-10-24 14:25                                       ���б�ta_tsalequalify_tmp�������˱��ֶΣ�c_dataflag����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-09-26 14:29                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-06-21 11:17                                       ��ǰ��ta_tfilefield�����������ֶΣ�l_taidno����                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.17    2016-08-05 21:50                                       �޸�������uidx_tmergercontrol,�����ֶ��޸�Ϊ��(c_gradefund,c_type,c_tenantid),��������޸�Ϊ��null,����Ψһ���޸�Ϊ����Ψһ,��������������Ϊ:��������.                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-08-05 21:49                                       ��ǰ��ta_tmergercontrol������������ uidx_tmergecontrol:[c_gradefund,c_type,c_tenantid]��;                                                                                                                                                                                                                                                                                                     
-- V1.0.5.17    2016-08-05 21:48                                       ��ǰ��ta_tmergercontrol��ɾ���˱�������uidx_mergercontrol��;                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.17    2016-06-18 15:53                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�f_tafare����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.17    2016-06-18 15:58                                       ���б�ta_tliqredeemfile�������˱��ֶΣ�f_ductmanagerfare�������б�ta_tliqredeemfile�������˱��ֶΣ�f_profitbalance����                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-06-18 15:56                                       ���б�ta_tliqbonusfile�������˱��ֶΣ�f_profitbalance����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.17    2016-06-04 15:50                                       ���б�ta_tcustfundinfofile�������˱��ֶΣ�c_pensionregistcode����                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.17    2016-06-03 17:44                                       ���б�ta_tcustaccofile�������˱��ֶΣ�c_risklevel����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.17    2016-06-03 17:43                                       ���б�ta_tcustaccorequestfile�������˱��ֶΣ�c_risklevel����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.17    2016-06-04 15:49                                       ���б�ta_tcustdividendfile�������˱��ֶΣ�f_unitprofit2����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.17    2016-06-23 16:27                                       ���б�ta_tcustecontractfile�����������ֶΣ�c_custodiancode->c_trusteecode����                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.17    2016-06-23 11:05                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-08-03 16:24                                       ��ǰ��ta_totccustinfo��ɾ���˱�������idx_totccustinfo��;                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.17    2016-08-03 15:50                                       ��ǰ��ta_totccustinfo������������ idx_totccustinfo:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.17    2016-08-03 16:24                                       ��ǰ��ta_totcshareinfo��ɾ���˱�������idx_totcshareinfo��;                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.17    2016-08-03 16:07                                       ��ǰ��ta_totcshareinfo������������ idx_totcshareinfo:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.14    2016-05-27 16:41                                       ���б�ta_tcentralize92file�������˱��ֶΣ�c_txtbillsendpass����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.13    2016-05-27 16:41                                       ���б�ta_tcentralize92file��ɾ���˱��ֶΣ�c_billsendpass����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.11    2016-05-26 11:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.8     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.7     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.6     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.5     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.4     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.3     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-21 16:40                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-17 20:49                                       ���б�ta_tcusttainfo_fundinfo�������˱��ֶΣ�l_netprecision����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.2     2016-05-18 16:10                                       ���б�ta_tcusttainfo_farezone�������˱��ֶΣ�f_maxbalance����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.2     2016-05-18 16:08                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.2     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-20 08:42                                       ���б�ta_totcshareinfo���޸��˱��ֶ������գ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-06-15 16:23                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-05-17 17:19                                       ���б�ta_totccustinfo��ɾ���˱��ֶΣ�c_databaseno����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-05-17 17:22                                       ���б�ta_totcshareinfo�������˱��ֶΣ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-05-17 17:20                                       ���б�ta_totcshareinfo��ɾ���˱��ֶΣ�c_databaseno����                                                                                                                                                                                                                                                                                                                                        


-- ������ ta_tinterfaceset(�ӿ����̹�����)�ĵ�ǰ��
SELECT 'Create Table ta_tinterfaceset-�ӿ����̹�����...';
DROP TABLE IF EXISTS ta_tinterfaceset;
CREATE TABLE ta_tinterfaceset
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_ioflow                       varchar(20)     DEFAULT ' '        NOT NULL,
	c_ioflowname                   varchar(50)     DEFAULT ' '        NOT NULL,
	c_ioflag                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_explain                      varchar(1024)   DEFAULT ' '        NOT NULL,
	c_pathdir                      varchar(1024)   DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_ioflow, c_tacode, c_tenantid)
);

-- ������ ta_tinterfaceclass(�ӿ����̷����)�ĵ�ǰ��
SELECT 'Create Table ta_tinterfaceclass-�ӿ����̷����...';
DROP TABLE IF EXISTS ta_tinterfaceclass;
CREATE TABLE ta_tinterfaceclass
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_ioflow                       varchar(20)     DEFAULT ' '        NOT NULL,
	c_flowcode                     varchar(3)      DEFAULT ' '        NOT NULL,
	c_code                         varchar(8)      DEFAULT ' '        NOT NULL,
	c_iversionsql                  varchar(1024)   DEFAULT ' '        NOT NULL,
	c_subdirname                   varchar(20)     DEFAULT ' '        NOT NULL,
	l_order                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_flowcode, c_ioflow, c_tacode, c_tenantid)
);

-- ������ ta_tinterfaceverinfo(�ӿ����ͱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tinterfaceverinfo-�ӿ����ͱ�...';
DROP TABLE IF EXISTS ta_tinterfaceverinfo;
CREATE TABLE ta_tinterfaceverinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_class                        varchar(3)      DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_filetype                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_taborsql                     varchar(30)     DEFAULT ' '        NOT NULL,
	c_needio                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_sqlldrtype                   varchar(1)      DEFAULT ' '        NOT NULL,
	l_order                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_filetype, c_iversion, c_class, c_tacode, c_tenantid)
);

-- ������ ta_tinterfacefiledefine(�ӿ��ļ����Ա�)�ĵ�ǰ��
SELECT 'Create Table ta_tinterfacefiledefine-�ӿ��ļ����Ա�...';
DROP TABLE IF EXISTS ta_tinterfacefiledefine;
CREATE TABLE ta_tinterfacefiledefine
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_flowcode                     varchar(3)      DEFAULT ' '        NOT NULL,
	c_class                        varchar(3)      DEFAULT ' '        NOT NULL,
	c_filetype                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_filename                     varchar(100)    DEFAULT ' '        NOT NULL,
	c_filehead                     varchar(500)    DEFAULT ' '        NOT NULL,
	c_filetail                     varchar(500)    DEFAULT ' '        NOT NULL,
	c_reclen                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_seperate                     varchar(5)      DEFAULT ' '        NOT NULL,
	c_quotes                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_filefmt                      varchar(1)      DEFAULT ' '        NOT NULL,
	c_writemode                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_dellastsql                   varchar(1024)   DEFAULT ' '        NOT NULL,
	c_filedescrib                  varchar(50)     DEFAULT ' '        NOT NULL,
	c_flowmode                     varchar(3)      DEFAULT ' '        NOT NULL,
	c_filedbtype                   varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_filetype, c_class, c_tacode, c_tenantid)
);

-- ������ ta_tfielddict(�ӿ��ֵ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfielddict-�ӿ��ֵ��...';
DROP TABLE IF EXISTS ta_tfielddict;
CREATE TABLE ta_tfielddict
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	l_idno                         int             DEFAULT 0          NOT NULL,
	c_fieldcode                    varchar(50)     DEFAULT ' '        NOT NULL,
	c_datatype                     varchar(1)      DEFAULT ' '        NOT NULL,
	l_fieldlen                     int             DEFAULT 0          NOT NULL,
	l_precision                    int             DEFAULT 0          NOT NULL,
	c_fieldname                    varchar(50)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_idno, c_tenantid)
);

-- ������ ta_tfilefield(�ӿ��ļ��ֶα�)�ĵ�ǰ��
SELECT 'Create Table ta_tfilefield-�ӿ��ļ��ֶα�...';
DROP TABLE IF EXISTS ta_tfilefield;
CREATE TABLE ta_tfilefield
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_class                        varchar(3)      DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_filetype                     varchar(20)     DEFAULT ' '        NOT NULL,
	l_idno                         int             DEFAULT 0          NOT NULL,
	l_taidno                       int             DEFAULT 0          NOT NULL,
	l_order                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_taidno, l_idno, c_filetype, c_iversion, c_class, c_tacode, c_tenantid)
);

-- ������ ta_ttafielddict(�ӿ��ֶζ�Ӧ��)�ĵ�ǰ��
SELECT 'Create Table ta_ttafielddict-�ӿ��ֶζ�Ӧ��...';
DROP TABLE IF EXISTS ta_ttafielddict;
CREATE TABLE ta_ttafielddict
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	l_taidno                       int             DEFAULT 0          NOT NULL,
	c_tafield                      varchar(50)     DEFAULT ' '        NOT NULL,
	l_tafieldlen                   int             DEFAULT 0          NOT NULL,
	c_isnull                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_tafieldname                  varchar(50)     DEFAULT ' '        NOT NULL,
	c_default                      varchar(30)     DEFAULT ' '        ,
PRIMARY KEY(l_taidno, c_tenantid)
);

-- ������ ta_tsql(SQL������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tsql-SQL������ñ�...';
DROP TABLE IF EXISTS ta_tsql;
CREATE TABLE ta_tsql
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_code                         varchar(8)      DEFAULT ' '        NOT NULL,
	c_usetype                      varchar(1)      DEFAULT ' '        NOT NULL,
	l_serialno                     bigint          DEFAULT 0          NOT NULL,
	c_sql                          varchar(2048)   DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_serialno, c_code, c_tenantid)
);

-- ������ ta_ttafundinfo(�Ǽǹ��������Ʒ��Ϣ��Ӧ��ϵ)�ĵ�ǰ��
SELECT 'Create Table ta_ttafundinfo-�Ǽǹ��������Ʒ��Ϣ��Ӧ��ϵ...';
DROP TABLE IF EXISTS ta_ttafundinfo;
CREATE TABLE ta_ttafundinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tacode, c_fundcode, c_tenantid)
);

-- ������ ta_ttaagency(�Ǽǹ������������̶�Ӧ��ϵ��)�ĵ�ǰ��
SELECT 'Create Table ta_ttaagency-�Ǽǹ������������̶�Ӧ��ϵ��...';
DROP TABLE IF EXISTS ta_ttaagency;
CREATE TABLE ta_ttaagency
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_isused                       varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tacode, c_agencyno, c_tenantid)
);

-- ������ ta_ttatrustee(�Ǽǹ��������й��ж�Ӧ��ϵ��)�ĵ�ǰ��
SELECT 'Create Table ta_ttatrustee-�Ǽǹ��������й��ж�Ӧ��ϵ��...';
DROP TABLE IF EXISTS ta_ttatrustee;
CREATE TABLE ta_ttatrustee
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_tacode, c_trusteecode)
);

-- ������ ta_tfundcodechange(�������ת����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundcodechange-�������ת����...';
DROP TABLE IF EXISTS ta_tfundcodechange;
CREATE TABLE ta_tfundcodechange
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_outfundcode                  varchar(12)     DEFAULT ' '        NOT NULL,
	c_outfundname                  varchar(40)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_sharetype, c_tenantid)
);

-- ������ ta_tinterindexfile(�ӿ�������)�ĵ�ǰ��
SELECT 'Create Table ta_tinterindexfile-�ӿ�������...';
DROP TABLE IF EXISTS ta_tinterindexfile;
CREATE TABLE ta_tinterindexfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_flowcode                     varchar(3)      DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_filename                     varchar(100)    DEFAULT ' '        NOT NULL,
	c_filetype                     varchar(20)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_tacode, c_flowcode, c_iversion, c_filetype)
);

-- ������ ta_tfundsharetype(����ݶ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundsharetype-����ݶ�����...';
DROP TABLE IF EXISTS ta_tfundsharetype;
CREATE TABLE ta_tfundsharetype
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_sharetype, c_tacode, c_tenantid)
);

-- ������ ta_tfunddate(�����������ڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tfunddate-�����������ڱ�...';
DROP TABLE IF EXISTS ta_tfunddate;
CREATE TABLE ta_tfunddate
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_requestdate                  int             DEFAULT 0          NOT NULL,
	c_type                         varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_tacode, c_tenantid)
);

-- ������ ta_taccountmergerfund(����ϲ���)�ĵ�ǰ��
SELECT 'Create Table ta_taccountmergerfund-����ϲ���...';
DROP TABLE IF EXISTS ta_taccountmergerfund;
CREATE TABLE ta_taccountmergerfund
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundname                     varchar(40)     DEFAULT ' '        NOT NULL,
	c_expfundcode                  varchar(6)      DEFAULT ' '        NOT NULL,
	c_expfundname                  varchar(40)     DEFAULT ' '        NOT NULL,
	d_requestdate                  int             DEFAULT 0          NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_t0liqudiate                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_mergeaccountmode             varchar(1)      DEFAULT ' '        NOT NULL,
	c_investorientation            varchar(1)      DEFAULT ' '        NOT NULL,
	c_sharetypes                   varchar(2)      DEFAULT ' '        NOT NULL,
	c_incomeintoshare              varchar(1)      DEFAULT ' '        NOT NULL
);
CREATE INDEX uidx_taccountmergerfund ON ta_taccountmergerfund(c_fundcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_ttrusteeverlist(�й��а汾���ձ�)�ĵ�ǰ��
SELECT 'Create Table ta_ttrusteeverlist-�й��а汾���ձ�...';
DROP TABLE IF EXISTS ta_ttrusteeverlist;
CREATE TABLE ta_ttrusteeverlist
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_norexpnoliqdata              varchar(1)      DEFAULT ' '        NOT NULL
);
CREATE INDEX uidx_ttrusteeverlist ON ta_ttrusteeverlist(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tinterfacelog(�ӿ���־��)�ĵ�ǰ��
SELECT 'Create Table ta_tinterfacelog-�ӿ���־��...';
DROP TABLE IF EXISTS ta_tinterfacelog;
CREATE TABLE ta_tinterfacelog
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_ioflow                       varchar(20)     DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_dealcode                     varchar(20)     DEFAULT ' '        NOT NULL,
	d_finishdate                   int             DEFAULT 0          NOT NULL,
	d_finishtime                   int             DEFAULT 0          NOT NULL,
	d_dealtime                     int             DEFAULT 0          NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_dealflag                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_ioflow, d_cdate, c_dealcode, c_managercode, c_liqbatchno, c_tacode, c_tenantid)
);

-- ������ ta_tmergercontrol(�����ϲ����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tmergercontrol-�����ϲ����Ʊ�...';
DROP TABLE IF EXISTS ta_tmergercontrol;
CREATE TABLE ta_tmergercontrol
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundname                     varchar(40)     DEFAULT ' '        NOT NULL,
	c_gradefund                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_type                         varchar(1)      DEFAULT ' '        NOT NULL,
	c_flag                         varchar(1)      DEFAULT ' '        NOT NULL,
	c_tzjycode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_mergeaccountmode             varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tmergercontrol ON ta_tmergercontrol(c_gradefund ASC ,c_type ASC ,c_tenantid ASC );

-- ������ ta_tagencyexpbatch(�����̵������α�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencyexpbatch-�����̵������α�...';
DROP TABLE IF EXISTS ta_tagencyexpbatch;
CREATE TABLE ta_tagencyexpbatch
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_isdetail                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_comparetype                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_sharetypes                   varchar(2)      DEFAULT ' '        NOT NULL,
	c_notexpparamfiles             varchar(1)      DEFAULT ' '        NOT NULL,
	c_agencytype                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_exportnavafterfailorend      varchar(1)      DEFAULT ' '        NOT NULL,
	c_agccfmexpflag                varchar(1)      DEFAULT ' '        NOT NULL,
	d_outputdate                   int             DEFAULT 0          NOT NULL,
	c_newnavdate                   varchar(1)      DEFAULT '0'        NOT NULL,
	c_isreceivebroadcast           varchar(1)      DEFAULT '0'        NOT NULL,
PRIMARY KEY(c_agencyno, c_liqbatchno, c_tacode, c_tenantid)
);

-- ������ ta_tnotimpreqdata(���������뵼����ɱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tnotimpreqdata-���������뵼����ɱ�...';
DROP TABLE IF EXISTS ta_tnotimpreqdata;
CREATE TABLE ta_tnotimpreqdata
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_agencyno, d_cdate, c_tacode, c_tenantid)
);

-- ������ ta_tcustexpbatch(�ͷ��������α�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustexpbatch-�ͷ��������α�...';
DROP TABLE IF EXISTS ta_tcustexpbatch;
CREATE TABLE ta_tcustexpbatch
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_managername                  varchar(60)     DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_managercode, c_tacode, c_tenantid)
);
CREATE INDEX idx_custexpbatch_tenantid ON ta_tcustexpbatch(c_tenantid ASC ,c_tacode ASC );

-- ������ ta_tcusttainfoexpfnd(�ͻ�TAINFO�赼����Ʒ��)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfoexpfnd-�ͻ�TAINFO�赼����Ʒ��...';
DROP TABLE IF EXISTS ta_tcusttainfoexpfnd;
CREATE TABLE ta_tcusttainfoexpfnd
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_tenantid)
);

-- ������ ta_tliqexpbatch(���㵼�����α�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqexpbatch-���㵼�����α�...';
DROP TABLE IF EXISTS ta_tliqexpbatch;
CREATE TABLE ta_tliqexpbatch
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_norexpnoliqdata              varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_trusteecode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tcenterexpbatch(���б��ݵ������α�)�ĵ�ǰ��
SELECT 'Create Table ta_tcenterexpbatch-���б��ݵ������α�...';
DROP TABLE IF EXISTS ta_tcenterexpbatch;
CREATE TABLE ta_tcenterexpbatch
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_centralizetype               varchar(1)      DEFAULT '0'        NOT NULL,
	c_zhcentralizetype             varchar(1)      DEFAULT '0'        NOT NULL,
	c_zhzlcentralizetype           varchar(1)      DEFAULT '0'        NOT NULL,
	d_zhzlcentralizedate           int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_tacode, c_tenantid)
);

-- ������ ta_tcfm05file_tmp(05ȷ���ļ��м���ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tcfm05file_tmp-05ȷ���ļ��м���ʱ��...';
DROP TABLE IF EXISTS ta_tcfm05file_tmp;
CREATE TABLE ta_tcfm05file_tmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	c_isdetail                     varchar(1)      DEFAULT ' '        ,
	c_iversion                     varchar(20)     DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
PRIMARY KEY(c_tradeacco, c_fundacco, c_agencyno, c_fundcode, c_netno, c_sharetype, c_tacode, c_tenantid)
);

-- ������ ta_tagencycfm02file(������02�˻�ȷ���ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm02file-������02�˻�ȷ���ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm02file;
CREATE TABLE ta_tagencycfm02file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_cause                        varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	c_othertradeacco               varchar(24)     DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_txterrordetail               varchar(60)     DEFAULT ' '        ,
	c_errordetail                  varchar(60)     DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	c_broadcastflag                varchar(1)      DEFAULT ' '        ,
	f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
	c_organiger                    varchar(9)      DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_order                        varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencycfm02file ON ta_tagencycfm02file(c_agencyno DESC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencycfm04file(������04����ȷ���ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm04file-������04����ȷ���ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm04file;
CREATE TABLE ta_tagencycfm04file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_exceedflag                   varchar(1)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_requestendflag               varchar(1)      DEFAULT ' '        ,
	f_agio                         decimal(5,4)    DEFAULT 0.0        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	f_sumfare                      decimal(16,2)   DEFAULT 0.0        ,
	f_agentfare                    decimal(16,2)   DEFAULT 0.0        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	d_hopedate                     int             DEFAULT 0          ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	c_oricserialno                 varchar(20)     DEFAULT ' '        ,
	c_specification                varchar(60)     DEFAULT ' '        ,
	c_otheragency                  varchar(9)      DEFAULT ' '        ,
	c_othernetno                   varchar(9)      DEFAULT ' '        ,
	c_othertradeacco               varchar(24)     DEFAULT ' '        ,
	c_changeflag                   varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_factinterest                 decimal(16,2)   DEFAULT 0.0        ,
	f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
	f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	f_othernetvalue                decimal(7,4)    DEFAULT 0.0        ,
	f_othercfmshares               decimal(16,2)   DEFAULT 0.0        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	c_detailflag                   varchar(1)      DEFAULT ' '        ,
	d_originaldate                 int             DEFAULT 0          ,
	c_txtothercode                 varchar(6)      DEFAULT ' '        ,
	c_otheracco                    varchar(12)     DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_targetchargetype             varchar(1)      DEFAULT ' '        ,
	c_protocolno                   varchar(20)     DEFAULT ' '        ,
	c_combcode                     varchar(6)      DEFAULT ' '        ,
	f_backbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_changefillfare               decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_profitcompensation           decimal(16,2)   DEFAULT 0.0        ,
	c_adjustflag                   varchar(1)      DEFAULT ' '        ,
	c_cserialnototal               varchar(20)     DEFAULT ' '        ,
	f_chincome_abs                 decimal(16,2)   DEFAULT 0.0        ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
	c_txterrordetail               varchar(60)     DEFAULT ' '        ,
	f_raiseinerest                 decimal(16,2)   DEFAULT 0.0        ,
	d_registdate                   int             DEFAULT 0          ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	f_changefare                   decimal(16,2)   DEFAULT 0.0        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_cause                        varchar(4)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	f_bsharefare                   decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
	f_otherfee2                    decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tagencycfm04file ON ta_tagencycfm04file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencycfm05file(������05�ݶ�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm05file-������05�ݶ�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm05file;
CREATE TABLE ta_tagencycfm05file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	f_availableshares              decimal(16,2)   DEFAULT 0.0        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_cdate                        int             DEFAULT 0          ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	d_registerdate                 int             DEFAULT 0          ,
	f_totalincome                  decimal(16,2)   DEFAULT 0.0        ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_validshares                  decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tagencycfm05file ON ta_tagencycfm05file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencycfm06file(������06�ֺ������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm06file-������06�ֺ������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm06file;
CREATE TABLE ta_tagencycfm06file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
	d_distributedate               int             DEFAULT 0          ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	d_registerdate                 int             DEFAULT 0          ,
	f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	f_unitdividend                 decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	f_fare                         decimal(16,2)   DEFAULT 0.0        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_tax                          decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	f_bonusunit                    decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_flag                         varchar(1)      DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	d_reinvestdate                 int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_regdate                      int             DEFAULT 0          ,
	c_dividendtype                 varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencycfm06file ON ta_tagencycfm06file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencycfm12file(������12ҵ��ȷ�ϻ����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm12file-������12ҵ��ȷ�ϻ����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm12file;
CREATE TABLE ta_tagencycfm12file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	l_recordnum                    int             DEFAULT 0          ,
	f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	l_failedcount                  int             DEFAULT 0          ,
	l_successcount                 int             DEFAULT 0          ,
	f_failedshares                 decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tagencycfm12file ON ta_tagencycfm12file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencycfm21file(������21�������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm21file-������21�������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm21file;
CREATE TABLE ta_tagencycfm21file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	c_flag                         varchar(1)      DEFAULT ' '        ,
	c_txtagencyno                  varchar(9)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencycfm21file ON ta_tagencycfm21file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencycfm25file(������25�ʽ������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm25file-������25�ʽ������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm25file;
CREATE TABLE ta_tagencycfm25file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          NOT NULL,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_liquidatetype                varchar(3)      DEFAULT ' '        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_vsflag                       varchar(1)      DEFAULT ' '        ,
	d_liquidate                    int             DEFAULT 0          ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	c_bourseflag                   varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencycfm25file ON ta_tagencycfm25file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );
CREATE INDEX pk_tagencycfm25file ON ta_tagencycfm25file(l_serialno ASC );

-- ������ ta_tagencynavc1file(�����̻�����������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynavc1file-�����̻�����������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynavc1file;
CREATE TABLE ta_tagencynavc1file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	c_txtfundname                  varchar(40)     DEFAULT ' '        ,
	c_fundshortname                varchar(20)     DEFAULT ' '        ,
	c_txtfundtype                  varchar(2)      DEFAULT ' '        ,
	c_fundtypename                 varchar(30)     DEFAULT ' '        ,
	c_protectfund                  varchar(1)      DEFAULT ' '        ,
	c_otherfund                    varchar(1)      DEFAULT ' '        ,
	c_qdiifund                     varchar(1)      DEFAULT ' '        ,
	f_redeemfareratio              decimal(5,4)    DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_sharedetail                  varchar(1)      DEFAULT ' '        ,
	f_upperamount                  decimal(16,2)   DEFAULT 0.0        ,
	f_pmaxshengou                  decimal(16,2)   DEFAULT 0.0        ,
	f_cstepbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_chminbala                    decimal(16,2)   DEFAULT 0.0        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	f_rationminbala                decimal(16,2)   DEFAULT 0.0        ,
	f_hminshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_issuedate                    int             DEFAULT 0          ,
	d_issueenddate                 int             DEFAULT 0          ,
	d_setupdate                    int             DEFAULT 0          ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_pstepbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_phminbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_maxbalance                   decimal(16,2)   DEFAULT 0.0        ,
	c_bourseflag                   varchar(1)      DEFAULT ' '        ,
	f_parvalue                     decimal(7,4)    DEFAULT 0.0        ,
	f_pomaxbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_eomaxbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_rminshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_cminshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_pissuetype                   varchar(1)      DEFAULT ' '        ,
	c_eissuetype                   varchar(1)      DEFAULT ' '        ,
	c_subscribemode                varchar(1)      DEFAULT ' '        ,
	c_faretype                     varchar(1)      DEFAULT ' '        ,
	f_pmaxbidsamount               decimal(16,2)   DEFAULT 0.0        ,
	f_cmaxbidsamount               decimal(16,2)   DEFAULT 0.0        ,
	f_pmaxsumbidsamount            decimal(16,2)   DEFAULT 0.0        ,
	f_cmaxsumbidsamount            decimal(16,2)   DEFAULT 0.0        ,
	f_pmaxsumredsvol               decimal(16,2)   DEFAULT 0.0        ,
	f_cmaxsumredsvol               decimal(16,2)   DEFAULT 0.0        ,
	f_pmaxredsvol                  decimal(16,2)   DEFAULT 0.0        ,
	f_cmaxredsvol                  decimal(16,2)   DEFAULT 0.0        ,
	c_taname                       varchar(60)     DEFAULT ' '        ,
	c_managername                  varchar(60)     DEFAULT ' '        ,
	c_servertel                    varchar(30)     DEFAULT ' '        ,
	c_website                      varchar(30)     DEFAULT ' '        ,
	c_flag                         varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_farecaltype                  varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencynavc1file ON ta_tagencynavc1file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencynavc2file(�����̻��������ϵ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynavc2file-�����̻��������ϵ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynavc2file;
CREATE TABLE ta_tagencynavc2file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	l_liquidateallot               int             DEFAULT 0          ,
	l_liquidateredeem              int             DEFAULT 0          ,
	l_liquidatechange              int             DEFAULT 0          ,
	l_liquidatebonus               int             DEFAULT 0          ,
	c_liquidatetype                varchar(3)      DEFAULT ' '        ,
	c_flag                         varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	d_operatedate                  int             DEFAULT 0          
);
CREATE INDEX pkg_tagencynavc2file ON ta_tagencynavc2file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencynavc3file(�����̻���ת����ϵ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynavc3file-�����̻���ת����ϵ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynavc3file;
CREATE TABLE ta_tagencynavc3file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	f_sharemin                     decimal(16,2)   DEFAULT 0.0        ,
	f_sharemax                     decimal(16,2)   DEFAULT 0.0        ,
	l_hold                         int             DEFAULT 0          ,
	c_txtothercode                 varchar(6)      DEFAULT ' '        ,
	c_targetchargetype             varchar(1)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_flag                         varchar(1)      DEFAULT ' '        ,
	d_operatedate                  int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          
);
CREATE INDEX pkg_tagencynavc3file ON ta_tagencynavc3file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencynavc4file(�����̻���ֺ췽���ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynavc4file-�����̻���ֺ췽���ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynavc4file;
CREATE TABLE ta_tagencynavc4file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	d_regdate                      int             DEFAULT 0          ,
	d_distributedate               int             DEFAULT 0          ,
	f_bonusunit                    decimal(16,2)   DEFAULT 0.0        ,
	c_xrtype                       varchar(1)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_flag                         varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	f_unitprofittxt                decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tagencynavc4file ON ta_tagencynavc4file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencynavc5file(�����̻�����������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynavc5file-�����̻�����������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynavc5file;
CREATE TABLE ta_tagencynavc5file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_targetsharetype              varchar(1)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_fareratioflag                varchar(1)      DEFAULT ' '        ,
	c_txtfaretype                  varchar(3)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	f_minbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_maxbalance                   decimal(16,2)   DEFAULT 0.0        ,
	l_minhold                      int             DEFAULT 0          ,
	l_maxhold                      int             DEFAULT 0          ,
	f_maxfare                      decimal(16,2)   DEFAULT 0.0        ,
	f_minfare                      decimal(16,2)   DEFAULT 0.0        ,
	f_ratio                        decimal(9,8)    DEFAULT 0.0        ,
	c_fareflag                     varchar(1)      DEFAULT ' '        ,
	c_flag                         varchar(1)      DEFAULT ' '        ,
	d_operatedate                  int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_txtothercode                 varchar(6)      DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencynavc5file ON ta_tagencynavc5file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencynav07file(������07����̬��Ϣ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynav07file-������07����̬��Ϣ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynav07file;
CREATE TABLE ta_tagencynav07file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	f_lastshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundstatus                   varchar(1)      DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	d_lastupdate                   int             DEFAULT 0          ,
	c_navtype                      varchar(1)      DEFAULT ' '        ,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        ,
	c_changestatus                 varchar(1)      DEFAULT ' '        ,
	c_rationstatus                 varchar(1)      DEFAULT ' '        ,
	c_ztgstatus                    varchar(1)      DEFAULT ' '        ,
	f_maxbalance                   decimal(16,2)   DEFAULT 0.0        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	c_announcflag                  varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_cstepbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_chminbala                    decimal(16,2)   DEFAULT 0.0        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	f_rationminbala                decimal(16,2)   DEFAULT 0.0        ,
	f_hminshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_issuedate                    int             DEFAULT 0          ,
	d_issueenddate                 int             DEFAULT 0          ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_pstepbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_phminbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_tradingprice                 decimal(7,4)    DEFAULT 0.0        ,
	f_parvalue                     decimal(7,4)    DEFAULT 0.0        ,
	d_xrdate                       int             DEFAULT 0          ,
	f_pomaxbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_eomaxbala                    decimal(16,2)   DEFAULT 0.0        ,
	f_rminshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_cminshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_pissuetype                   varchar(1)      DEFAULT ' '        ,
	c_eissuetype                   varchar(1)      DEFAULT ' '        ,
	c_subscribemode                varchar(1)      DEFAULT ' '        ,
	d_nexttradedate                int             DEFAULT 0          ,
	f_totalbonus                   decimal(7,4)    DEFAULT 0.0        ,
	f_incomeunit_abs               decimal(8,5)    DEFAULT 0.0        ,
	f_incomeunitflag               int             DEFAULT 0          ,
	f_incomeratio_abs              decimal(8,5)    DEFAULT 0.0        ,
	f_incomeratioflag              decimal(8,5)    DEFAULT 0.0        ,
	f_guaranteednav                decimal(7,4)    DEFAULT 0.0        ,
	f_ratio_abs                    decimal(8,5)    DEFAULT 0.0        ,
	f_ratioflag                    int             DEFAULT 0          ,
	f_pmaxbidsamount               decimal(16,2)   DEFAULT 0.0        ,
	f_cmaxbidsamount               decimal(16,2)   DEFAULT 0.0        ,
	f_pmaxsumbidsamount            decimal(16,2)   DEFAULT 0.0        ,
	f_cmaxsumbidsamount            decimal(16,2)   DEFAULT 0.0        ,
	f_pmaxsumredsvol               decimal(16,2)   DEFAULT 0.0        ,
	f_cmaxsumredsvol               decimal(16,2)   DEFAULT 0.0        ,
	f_pmaxredsvol                  decimal(16,2)   DEFAULT 0.0        ,
	f_cmaxredsvol                  decimal(16,2)   DEFAULT 0.0        ,
	f_incomeflag                   int             DEFAULT 0          ,
	f_income_abs                   decimal(16,2)   DEFAULT 0.0        ,
	c_txtfundtype                  varchar(2)      DEFAULT ' '        ,
	c_fundtypename                 varchar(30)     DEFAULT ' '        ,
	c_taname                       varchar(60)     DEFAULT ' '        ,
	c_managername                  varchar(60)     DEFAULT ' '        ,
	c_servertel                    varchar(30)     DEFAULT ' '        ,
	c_website                      varchar(30)     DEFAULT ' '        ,
	c_infundcode                   varchar(12)     DEFAULT ' '        
);
CREATE INDEX pkg_tagencynav07file ON ta_tagencynav07file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ nav_shares_tmp(������07����ݶ���Ϣ��ʱ��)�ĵ�ǰ��
SELECT 'Create Table nav_shares_tmp-������07����ݶ���Ϣ��ʱ��...';
DROP TABLE IF EXISTS nav_shares_tmp;
CREATE TABLE nav_shares_tmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_outfundcode                  varchar(12)     DEFAULT ' '        ,
	c_outfundname                  varchar(40)     DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tacode, c_tenantid, c_fundcode, c_sharetype, c_databaseno)
);

-- ������ ta_tagencycfm09file(������09���������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm09file-������09���������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm09file;
CREATE TABLE ta_tagencycfm09file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	f_bdividend                    decimal(16,2)   DEFAULT 0.0        ,
	f_fee                          decimal(16,2)   DEFAULT 0.0        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	f_totalreinvent                decimal(16,2)   DEFAULT 0.0        ,
	d_senddate                     int             DEFAULT 0          ,
	f_tax                          decimal(16,2)   DEFAULT 0.0        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        
);
CREATE INDEX uidx_ta_tagencycfm09file ON ta_tagencycfm09file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencynav08file(������08�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynav08file-������08�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynav08file;
CREATE TABLE ta_tagencynav08file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_bullcontent                  varchar(4000)   DEFAULT ' '        ,
	c_bullno                       varchar(20)     DEFAULT ' '        ,
	d_bulldate                     int             DEFAULT 0          ,
	c_bulltype                     varchar(1)      DEFAULT ' '        ,
	c_bulltitle                    varchar(255)    DEFAULT ' '        ,
	l_bulllength                   int             DEFAULT 0          
);

-- ������ ta_tagencycfm10file(������10�ս�������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm10file-������10�ս�������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm10file;
CREATE TABLE ta_tagencycfm10file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	f_allotbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_allotfare                    decimal(16,2)   DEFAULT 0.0        ,
	f_allotshares                  decimal(16,2)   DEFAULT 0.0        ,
	f_backbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_redeembalance                decimal(16,2)   DEFAULT 0.0        ,
	f_redeemshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_redeemfare                   decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX idx_tagencycfm10file ON ta_tagencycfm10file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencycfm11file(������11ҵ����������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm11file-������11ҵ����������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm11file;
CREATE TABLE ta_tagencycfm11file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	l_recordnum                    int             DEFAULT 0          
);
CREATE INDEX idx_tagencycfm11file ON ta_tagencycfm11file(c_tenantid ASC ,c_tacode ASC ,c_agencyno ASC );

-- ������ ta_tagencycfm26file(������26�ݶ���ϸ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfm26file-������26�ݶ���ϸ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfm26file;
CREATE TABLE ta_tagencycfm26file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	f_availableshares              decimal(16,2)   DEFAULT 0.0        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_cdate                        int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	d_registerdate                 int             DEFAULT 0          ,
	f_totalincome                  decimal(16,2)   DEFAULT 0.0        ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	d_allowredemptdate             int             DEFAULT 0          ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tagencycfm26file ON ta_tagencycfm26file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencynavc6file(��������������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynavc6file-��������������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynavc6file;
CREATE TABLE ta_tagencynavc6file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_txtfundcode                  varchar(6)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_chargetype                   varchar(1)      DEFAULT ' '        ,
	d_registerdate                 int             DEFAULT 0          ,
	d_allowredemptdate             int             DEFAULT 0          ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_addflag                      varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencynavc6file ON ta_tagencynavc6file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencyreqnorstd01file(�����̷Ǳ�׼�ӿ�01�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencyreqnorstd01file-�����̷Ǳ�׼�ӿ�01�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencyreqnorstd01file;
CREATE TABLE ta_tagencyreqnorstd01file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_distributorcode              varchar(9)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	c_status                       varchar(1)      DEFAULT '0'        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_idcard18len                  varchar(1)      DEFAULT ' '        ,
	c_bankno                       varchar(60)     DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_bankname                     varchar(255)    DEFAULT ' '        ,
	c_nameinbank                   varchar(60)     DEFAULT ' '        ,
	c_branchbank                   varchar(12)     DEFAULT ' '        ,
	c_bankprovince                 varchar(6)      DEFAULT ' '        ,
	c_bankcityno                   varchar(6)      DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_institutiontype              varchar(1)      DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	d_idnovaliddate                int             DEFAULT 0          ,
	c_risklevel                    varchar(1)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
	c_newbusinflag                 varchar(2)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	c_oriidentityno                varchar(30)     DEFAULT ' '        ,
	c_oricontno                    varchar(30)     DEFAULT ' '        ,
	c_contidcard18len              varchar(1)      DEFAULT ' '        ,
	c_newtradeacco                 varchar(24)     DEFAULT ' '        
);
CREATE INDEX pkg_tagencyreqnorstd01file ON ta_tagencyreqnorstd01file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencyreqnorstd03file(�����̷Ǳ�׼�ӿ�03�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencyreqnorstd03file-�����̷Ǳ�׼�ӿ�03�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencyreqnorstd03file;
CREATE TABLE ta_tagencyreqnorstd03file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_trustfileno                  varchar(30)     DEFAULT ' '        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	c_cashflag                     varchar(1)      DEFAULT ' '        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_agio                         decimal(5,4)    DEFAULT 0.0        ,
	c_exceedflag                   varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_distributorcode              varchar(9)      DEFAULT ' '        ,
	c_cfmresult                    varchar(1)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	c_status                       varchar(1)      DEFAULT '0'        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	d_reqsenddate                  int             DEFAULT 0          ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencyreqnorstd03file ON ta_tagencyreqnorstd03file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencycfmnorstd04file(�����̷Ǳ�׼�ӿ�04ȷ���ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencycfmnorstd04file-�����̷Ǳ�׼�ӿ�04ȷ���ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencycfmnorstd04file;
CREATE TABLE ta_tagencycfmnorstd04file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_trustfileno                  varchar(30)     DEFAULT ' '        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	c_cashflag                     varchar(1)      DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_agio                         decimal(5,4)    DEFAULT 0.0        ,
	c_exceedflag                   varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_distributorcode              varchar(9)      DEFAULT ' '        ,
	c_cfmresult                    varchar(1)      DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_status                       varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencycfmnorstd04file ON ta_tagencycfmnorstd04file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencynavnorstd07file(�����̷Ǳ�׼�ӿ�07�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencynavnorstd07file-�����̷Ǳ�׼�ӿ�07�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tagencynavnorstd07file;
CREATE TABLE ta_tagencynavnorstd07file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        
);
CREATE INDEX pkg_tagencynavnorstd07file ON ta_tagencynavnorstd07file(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqsubfile(�����Ϲ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqsubfile-�����Ϲ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqsubfile;
CREATE TABLE ta_tliqsubfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        ,
	f_totalbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_netbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_subratio                     decimal(9,8)    DEFAULT 0.0        ,
	f_subcancelbala                decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);
CREATE INDEX pkg_tliqsubfile ON ta_tliqsubfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqsfundsuccessfile(�����Ϲ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqsfundsuccessfile-�����Ϲ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqsfundsuccessfile;
CREATE TABLE ta_tliqsfundsuccessfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        ,
	f_totalbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_netbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_subratio                     decimal(9,8)    DEFAULT 0.0        ,
	f_subcancelbala                decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);
CREATE INDEX pkg_tliqsubfile ON ta_tliqsfundsuccessfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqfundfailfile(�����Ϲ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqfundfailfile-�����Ϲ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqfundfailfile;
CREATE TABLE ta_tliqfundfailfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        ,
	f_totalbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_netbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_subratio                     decimal(9,8)    DEFAULT 0.0        ,
	f_subcancelbala                decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);
CREATE INDEX pkg_tliqsubfile ON ta_tliqfundfailfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqallotfile(�����깺�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqallotfile-�����깺�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqallotfile;
CREATE TABLE ta_tliqallotfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_totalbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_netbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);
CREATE INDEX pkg_tliqallotfile ON ta_tliqallotfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqredeemfile(��������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqredeemfile-��������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqredeemfile;
CREATE TABLE ta_tliqredeemfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_totalbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare                    decimal(16,2)   DEFAULT 0.0        ,
	f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_netbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_ductmanagerfare              decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_deductmngfare                decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tliqredeemfile ON ta_tliqredeemfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqadjustsharefile(����ݶ�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqadjustsharefile-����ݶ�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqadjustsharefile;
CREATE TABLE ta_tliqadjustsharefile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_ashares                      decimal(16,2)   DEFAULT 0.0        ,
	f_rshares                      decimal(16,2)   DEFAULT 0.0        ,
	f_aincome                      decimal(16,2)   DEFAULT 0.0        ,
	f_rincome                      decimal(16,2)   DEFAULT 0.0        ,
	f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	f_abalance                     decimal(16,2)   DEFAULT 0.0        ,
	f_rbalance                     decimal(16,2)   DEFAULT 0.0        ,
	f_remainshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_rshares_ch                   decimal(16,2)   DEFAULT 0.0        ,
	c_adjustcause                  varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tliqadjustsharefile ON ta_tliqadjustsharefile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqbonusfile(����ֺ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqbonusfile-����ֺ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqbonusfile;
CREATE TABLE ta_tliqbonusfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_totalbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_tax                          decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_aheadincome                  decimal(16,2)   DEFAULT 0.0        
);

-- ������ ta_tliqchangeagencyfile(����ת�й��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqchangeagencyfile-����ת�й��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqchangeagencyfile;
CREATE TABLE ta_tliqchangeagencyfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_conshares_out                decimal(16,2)   DEFAULT 0.0        ,
	f_conshares_in                 decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	f_income_out                   decimal(16,2)   DEFAULT 0.0        ,
	f_income_in                    decimal(16,2)   DEFAULT 0.0        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);
CREATE INDEX pkg_tliqchangeagencyfile ON ta_tliqchangeagencyfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqswitchoutfile(�������ת�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqswitchoutfile-�������ת�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqswitchoutfile;
CREATE TABLE ta_tliqswitchoutfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_totalbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_netbalance                   decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_otherfare                    decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tliqswitchoutfile ON ta_tliqswitchoutfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqswitchinfile(�������ת�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqswitchinfile-�������ת�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqswitchinfile;
CREATE TABLE ta_tliqswitchinfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_netbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);
CREATE INDEX pkg_tliqswitchinfile ON ta_tliqswitchinfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqswitchfile(�������ת���ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqswitchfile-�������ת���ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqswitchfile;
CREATE TABLE ta_tliqswitchfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_othername                    varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_totalbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_netbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_chginshares                  decimal(16,2)   DEFAULT 0.0        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_otherfare                    decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tliqswitchfile ON ta_tliqswitchfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqunfrozenfile(�������������·��ʽ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqunfrozenfile-�������������·��ʽ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqunfrozenfile;
CREATE TABLE ta_tliqunfrozenfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);
CREATE INDEX pkg_tliqunfrozenfile ON ta_tliqunfrozenfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqincomefile(������������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqincomefile-������������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqincomefile;
CREATE TABLE ta_tliqincomefile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_unassign                     decimal(16,2)   DEFAULT 0.0        ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_endaccumshares               decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tliqincomefile ON ta_tliqincomefile(c_trusteecode DESC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqfarebelongfile(���������÷ֳɽӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqfarebelongfile-���������÷ֳɽӿڱ�...';
DROP TABLE IF EXISTS ta_tliqfarebelongfile;
CREATE TABLE ta_tliqfarebelongfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_requestdate                  int             DEFAULT 0          ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_agencyfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_registfare                   decimal(16,2)   DEFAULT 0.0        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);
CREATE INDEX uidx_tliqfarebelongfile ON ta_tliqfarebelongfile(c_trusteecode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqsaleservicefarefile(�������۷�����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqsaleservicefarefile-�������۷�����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqsaleservicefarefile;
CREATE TABLE ta_tliqsaleservicefarefile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_holddate                     int             DEFAULT 0          ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_servicefare                  decimal(16,2)   DEFAULT 0.0        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);

-- ������ ta_tliqinterestfarefile(�����Ϲ���Ϣ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqinterestfarefile-�����Ϲ���Ϣ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqinterestfarefile;
CREATE TABLE ta_tliqinterestfarefile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	f_interest                     decimal(16,2)   DEFAULT 0.0        ,
	f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        
);

-- ������ ta_tcustfundinfofile(�ͷ�����������Ϣ�ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustfundinfofile-�ͷ�����������Ϣ�ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustfundinfofile;
CREATE TABLE ta_tcustfundinfofile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	f_asucceed                     decimal(16,2)   DEFAULT 0.0        ,
	f_rsucceed                     decimal(16,2)   DEFAULT 0.0        ,
	c_todaystatus                  varchar(1)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_incomeunit                   decimal(10,5)   DEFAULT 0.0        ,
	f_incomeratio                  decimal(9,6)    DEFAULT 0.0        ,
	c_vastflag                     varchar(1)      DEFAULT ' '        ,
	f_lasttotalshare               decimal(16,2)   DEFAULT 0.0        ,
	f_encashratio                  decimal(9,8)    DEFAULT 1.0        ,
	f_changeratio                  decimal(9,8)    DEFAULT 1.0        ,
	c_excessflag                   varchar(1)      DEFAULT ' '        ,
	f_subscriberatio               decimal(9,8)    DEFAULT 1.0        ,
	f_lasttotalasset               decimal(16,2)   DEFAULT 0.0        ,
	f_servicefare                  decimal(16,2)   DEFAULT 0.0        ,
	f_growthrate                   decimal(9,8)    DEFAULT 0.0        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_pensionregistcode            varchar(12)     DEFAULT ' '        ,
	f_exchangerate                 decimal(7,4)    DEFAULT 0.0        
);
CREATE INDEX pkg_tcustfundinfofile ON ta_tcustfundinfofile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustaccofile(�ͷ��ͻ�������Ϣ�ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustaccofile-�ͷ��ͻ�������Ϣ�ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustaccofile;
CREATE TABLE ta_tcustaccofile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_accounttype                  varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_callcenter                   varchar(1)      DEFAULT ' '        ,
	c_internet                     varchar(1)      DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	c_nameinbank                   varchar(60)     DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_bankno                       varchar(60)     DEFAULT ' '        ,
	d_opendate                     int             DEFAULT 0          ,
	c_broker                       varchar(12)     DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	d_firstinvest                  int             DEFAULT 0          ,
	l_changetime                   int             DEFAULT 0          ,
	c_corpname                     varchar(40)     DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	c_actcode                      varchar(3)      DEFAULT ' '        ,
	c_password                     varchar(40)     DEFAULT ' '        ,
	c_billsendpass                 varchar(1)      DEFAULT ' '        ,
	c_recommender                  varchar(40)     DEFAULT ' '        ,
	c_recommendertype              varchar(1)      DEFAULT ' '        ,
	d_idnovaliddate                int             DEFAULT 0          ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_risklevel                    varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tcustaccofile ON ta_tcustaccofile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustacconetfile(�ͷ��˻��Ǽ���Ϣ�ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustacconetfile-�ͷ��˻��Ǽ���Ϣ�ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustacconetfile;
CREATE TABLE ta_tcustacconetfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_bankno                       varchar(60)     DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_nameinbank                   varchar(60)     DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	c_specialaccoflag              varchar(1)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_openflag                     varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tcustacconetfile ON ta_tcustacconetfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustaccorequestfile(�ͷ��˻������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustaccorequestfile-�ͷ��˻������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustaccorequestfile;
CREATE TABLE ta_tcustaccorequestfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_secretcode                   varchar(8)      DEFAULT ' '        ,
	c_shacco                       varchar(10)     DEFAULT ' '        ,
	c_szacco                       varchar(10)     DEFAULT ' '        ,
	c_callcenter                   varchar(1)      DEFAULT ' '        ,
	c_internet                     varchar(1)      DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	c_nameinbank                   varchar(60)     DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_bankno                       varchar(60)     DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_txterrordetail               varchar(60)     DEFAULT ' '        ,
	c_broker                       varchar(12)     DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_corpname                     varchar(40)     DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_recommender                  varchar(40)     DEFAULT ' '        ,
	c_recommendertype              varchar(1)      DEFAULT ' '        ,
	d_idnovaliddate                int             DEFAULT 0          ,
	c_acceptmode                   varchar(1)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_specialaccoflag              varchar(1)      DEFAULT ' '        ,
	c_newtradeacco                 varchar(24)     DEFAULT ' '        ,
	c_risklevel                    varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tcustaccorequestfile ON ta_tcustaccorequestfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustrequestfile(�ͷ����������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustrequestfile-�ͷ����������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustrequestfile;
CREATE TABLE ta_tcustrequestfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_othershare                   varchar(1)      DEFAULT ' '        ,
	c_otheracco                    varchar(12)     DEFAULT ' '        ,
	c_otheragency                  varchar(9)      DEFAULT ' '        ,
	c_othernetno                   varchar(9)      DEFAULT ' '        ,
	c_exceedflag                   varchar(1)      DEFAULT ' '        ,
	f_agio                         decimal(5,4)    DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_broker                       varchar(12)     DEFAULT ' '        ,
	c_actcode                      varchar(3)      DEFAULT ' '        ,
	c_acceptmode                   varchar(1)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_status                       varchar(1)      DEFAULT ' '        ,
	c_txterrordetail               varchar(60)     DEFAULT ' '        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_protocolno                   varchar(20)     DEFAULT ' '        ,
	d_protocolenddate              int             DEFAULT 0          ,
	c_rationterm                   varchar(8)      DEFAULT ' '        ,
	l_rationdate                   int             DEFAULT 0          ,
	c_fundmethod                   varchar(2)      DEFAULT ' '        ,
	c_bankno                       varchar(60)     DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_specialaccoflag              varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tcustrequestfile ON ta_tcustrequestfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustconfirmfile(�ͷ�����ȷ���ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustconfirmfile-�ͷ�����ȷ���ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustconfirmfile;
CREATE TABLE ta_tcustconfirmfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	d_confrimtime                  int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_othershare                   varchar(1)      DEFAULT ' '        ,
	c_otheracco                    varchar(12)     DEFAULT ' '        ,
	c_otheragency                  varchar(9)      DEFAULT ' '        ,
	c_othernetno                   varchar(9)      DEFAULT ' '        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	f_lasttotalshare               decimal(16,2)   DEFAULT 0.0        ,
	c_txterrordetail               varchar(60)     DEFAULT ' '        ,
	f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
	f_chshare                      decimal(16,2)   DEFAULT 0.0        ,
	f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	f_gainbalance                  decimal(16,2)   DEFAULT 0.0        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_agencyfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_registfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_interest                     decimal(16,2)   DEFAULT 0.0        ,
	c_adjustmemo                   varchar(30)     DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_specialaccoflag              varchar(1)      DEFAULT ' '        ,
	c_ghyhflag                     varchar(1)      DEFAULT ' '        ,
	l_serialnumber                 bigint          DEFAULT 0          
);
CREATE INDEX pkg_tcustconfirmfile ON ta_tcustconfirmfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustconfirmdetailfile(�ͷ�ȷ����ϸ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustconfirmdetailfile-�ͷ�ȷ����ϸ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustconfirmdetailfile;
CREATE TABLE ta_tcustconfirmdetailfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialnototal               varchar(20)     DEFAULT ' '        ,
	d_originaldate                 int             DEFAULT 0          ,
	c_oricserialno                 varchar(20)     DEFAULT ' '        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        
);
CREATE INDEX pkg_tcustconfirmdetailfile ON ta_tcustconfirmdetailfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustsharefile(�ͷ���̬�ݶ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustsharefile-�ͷ���̬�ݶ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustsharefile;
CREATE TABLE ta_tcustsharefile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	c_specialaccoflag              varchar(1)      DEFAULT ' '        ,
	f_paybasebala                  decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tcustsharefile ON ta_tcustsharefile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustsharedetailfile(�ͷ��ݶ���ϸ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustsharedetailfile-�ͷ��ݶ���ϸ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustsharedetailfile;
CREATE TABLE ta_tcustsharedetailfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	f_remainshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_orinetvalue                  decimal(7,4)    DEFAULT 0.0        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	d_registdate                   int             DEFAULT 0          ,
	f_ruleagio                     decimal(5,4)    DEFAULT 0.0        ,
	f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
	f_gainbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_oribalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_orishares                    decimal(16,2)   DEFAULT 0.0        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	d_cycleenddate                 int             DEFAULT 0          ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	c_protectflag                  varchar(1)      DEFAULT ' '        ,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_evennetvalue                 decimal(7,4)    DEFAULT 0.0        
);
CREATE INDEX pkg_tcustsharedetailfile ON ta_tcustsharedetailfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustdividendfile(�ͷ��ֺ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustdividendfile-�ͷ��ֺ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustdividendfile;
CREATE TABLE ta_tcustdividendfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
	c_flag                         varchar(1)      DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_fare                         decimal(16,2)   DEFAULT 0.0        ,
	f_tax                          decimal(16,2)   DEFAULT 0.0        ,
	f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	d_registerdate                 int             DEFAULT 0          ,
	d_date                         int             DEFAULT 0          ,
	d_lastdate                     int             DEFAULT 0          ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	f_reinvestbalance              decimal(16,2)   DEFAULT 0.0        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	f_unitprofit2                  decimal(7,4)    DEFAULT 0.0        
);
CREATE INDEX pkg_tcustdividendfile ON ta_tcustdividendfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustsharecurrentsfile(�ͷ��ݶ�仯��ˮ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustsharecurrentsfile-�ͷ��ݶ�仯��ˮ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustsharecurrentsfile;
CREATE TABLE ta_tcustsharecurrentsfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	f_occurshares                  decimal(16,2)   DEFAULT 0.0        ,
	f_occurbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_lasttotalshare               decimal(16,2)   DEFAULT 0.0        ,
	d_sharevaliddate               int             DEFAULT 0          
);
CREATE INDEX pkg_tcustsharecurrentsfile ON ta_tcustsharecurrentsfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_fundinfo(�ͷ����������Ϣ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_fundinfo-�ͷ����������Ϣ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_fundinfo;
CREATE TABLE ta_tcusttainfo_fundinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_parvalue                     decimal(7,4)    DEFAULT 0.0        ,
	f_issueprice                   decimal(7,4)    DEFAULT 0.0        ,
	d_issuedate                    int             DEFAULT 0          ,
	d_setupdate                    int             DEFAULT 0          ,
	c_managername                  varchar(60)     DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	c_trusteename                  varchar(40)     DEFAULT ' '        ,
	f_maxbalance                   decimal(16,2)   DEFAULT 0.0        ,
	f_minbalance                   decimal(16,2)   DEFAULT 0.0        ,
	l_elimitday                    int             DEFAULT 0          ,
	l_slimitday                    int             DEFAULT 0          ,
	l_alimitday                    int             DEFAULT 0          ,
	l_mincount                     int             DEFAULT 0          ,
	l_climitday                    int             DEFAULT 0          ,
	f_maxallot                     decimal(9,8)    DEFAULT 0.0        ,
	f_maxredeem                    decimal(9,8)    DEFAULT 0.0        ,
	c_fundcharacter                varchar(80)     DEFAULT ' '        ,
	c_fundstatus                   varchar(1)      DEFAULT ' '        ,
	c_subscribemode                varchar(1)      DEFAULT ' '        ,
	l_timelimit                    int             DEFAULT 0          ,
	c_sharetypes                   varchar(2)      DEFAULT ' '        ,
	c_issuetype                    varchar(1)      DEFAULT ' '        ,
	f_factcollect                  decimal(16,2)   DEFAULT 0.0        ,
	f_allotratio                   decimal(9,8)    DEFAULT 0.0        ,
	d_failuredate                  int             DEFAULT 0          ,
	c_feeratiotype1                varchar(1)      DEFAULT ' '        ,
	c_feeratiotype2                varchar(1)      DEFAULT ' '        ,
	c_feetype                      varchar(1)      DEFAULT ' '        ,
	c_exceedpart                   varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_interestdealtype             varchar(1)      DEFAULT ' '        ,
	f_redeemfareratio              decimal(5,4)    DEFAULT 0.0        ,
	f_changefareratio              decimal(5,4)    DEFAULT 0.0        ,
	f_managerfee                   decimal(5,4)    DEFAULT 0.0        ,
	c_property                     varchar(1)      DEFAULT ' '        ,
	f_totalbonus                   decimal(7,4)    DEFAULT 0.0        ,
	d_evendate                     int             DEFAULT 0          ,
	c_changefree                   varchar(1)      DEFAULT ' '        ,
	c_txtfundtype                  varchar(2)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_isyuebao                     varchar(1)      DEFAULT ' '        ,
	c_shortcyclefinance            varchar(1)      DEFAULT ' '        ,
	l_netprecision                 int             DEFAULT 0          
);
CREATE INDEX pkg_tcusttainfo_fundinfo ON ta_tcusttainfo_fundinfo(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_fundarlimit(�ͷ������������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_fundarlimit-�ͷ������������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_fundarlimit;
CREATE TABLE ta_tcusttainfo_fundarlimit
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	f_rationminbala                decimal(16,2)   DEFAULT 0.0        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_hminshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	f_omaxbala                     decimal(16,2)   DEFAULT 0.0        ,
	f_ominbala                     decimal(16,2)   DEFAULT 0.0        ,
	f_stepbala                     decimal(16,2)   DEFAULT 0.0        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	f_hmaxratio                    decimal(9,8)    DEFAULT 0.0        ,
	f_hmaxbala                     decimal(16,2)   DEFAULT 0.0        ,
	f_rminshares                   decimal(16,2)   DEFAULT 0.0        ,
	f_cminshares                   decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tcusttainfo_arlimit ON ta_tcusttainfo_fundarlimit(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_fundschema(�ͷ�����ֺ췽���ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_fundschema-�ͷ�����ֺ췽���ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_fundschema;
CREATE TABLE ta_tcusttainfo_fundschema
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	d_regdate                      int             DEFAULT 0          ,
	d_distributedate               int             DEFAULT 0          ,
	d_reinvestdate                 int             DEFAULT 0          ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	f_incometax                    decimal(16,2)   DEFAULT 0.0        ,
	c_describe                     varchar(100)    DEFAULT ' '        ,
	c_dealflag                     varchar(1)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        
);
CREATE INDEX pkg_tcusttainfo_fundschema ON ta_tcusttainfo_fundschema(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_netinfo(�ͷ��й������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_netinfo-�ͷ��й������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_netinfo;
CREATE TABLE ta_tcusttainfo_netinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_netname                      varchar(40)     DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	c_netaddress                   varchar(80)     DEFAULT ' '        ,
	c_netzipcode                   varchar(6)      DEFAULT ' '        ,
	c_netcontact                   varchar(8)      DEFAULT ' '        ,
	c_netphone                     varchar(40)     DEFAULT ' '        ,
	c_netfaxno                     varchar(40)     DEFAULT ' '        ,
	d_netregdate                   int             DEFAULT 0          
);
CREATE INDEX pkg_tcusttainfo_netinfo ON ta_tcusttainfo_netinfo(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_regioncode(�ͷ����������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_regioncode-�ͷ����������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_regioncode;
CREATE TABLE ta_tcusttainfo_regioncode
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	c_cityname                     varchar(16)     DEFAULT ' '        
);
CREATE INDEX pkg_tcusttainfo_regioncode ON ta_tcusttainfo_regioncode(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_salelimit(�ͷ����������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_salelimit-�ͷ����������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_salelimit;
CREATE TABLE ta_tcusttainfo_salelimit
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        
);
CREATE INDEX pkg_tcusttainfo_salelimit ON ta_tcusttainfo_salelimit(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_changelimit(�ͷ�ת�������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_changelimit-�ͷ�ת�������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_changelimit;
CREATE TABLE ta_tcusttainfo_changelimit
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        
);
CREATE INDEX pkg_tcusttainfochangelimit ON ta_tcusttainfo_changelimit(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_blacklist(�ͷ��������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_blacklist-�ͷ��������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_blacklist;
CREATE TABLE ta_tcusttainfo_blacklist
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	c_level                        varchar(1)      DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        
);
CREATE INDEX pkg_tcusttainfo_blacklist ON ta_tcusttainfo_blacklist(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_farezone(�ͷ����������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_farezone-�ͷ����������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_farezone;
CREATE TABLE ta_tcusttainfo_farezone
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_faretype                     varchar(1)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_saletype                     varchar(1)      DEFAULT ' '        ,
	l_minbalance                   int             DEFAULT 0          ,
	l_maxbalance                   int             DEFAULT 0          ,
	l_minpredays                   int             DEFAULT 0          ,
	l_maxpredays                   int             DEFAULT 0          ,
	l_minhold                      int             DEFAULT 0          ,
	l_maxhold                      int             DEFAULT 0          ,
	f_ratio                        decimal(9,8)    DEFAULT 0.0        ,
	f_minfare                      decimal(16,2)   DEFAULT 0.0        ,
	f_maxfare                      decimal(16,2)   DEFAULT 0.0        ,
	f_calculatenumeric             decimal(16,2)   DEFAULT 0.0        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_reserve                      varchar(1)      DEFAULT ' '        ,
	f_maxbalance                   decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tcusttainfo_farezone ON ta_tcusttainfo_farezone(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcusttainfo_agencyinfo(�ͷ��������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcusttainfo_agencyinfo-�ͷ��������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcusttainfo_agencyinfo;
CREATE TABLE ta_tcusttainfo_agencyinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_agencyname                   varchar(40)     DEFAULT ' '        ,
	c_fullname                     varchar(1024)   DEFAULT ' '        ,
	c_agencyaddress                varchar(80)     DEFAULT ' '        ,
	c_agencyzipcode                varchar(6)      DEFAULT ' '        ,
	c_agencycontact                varchar(8)      DEFAULT ' '        ,
	c_agencyphone                  varchar(40)     DEFAULT ' '        ,
	c_agencyfaxno                  varchar(40)     DEFAULT ' '        ,
	c_agencyemail                  varchar(40)     DEFAULT ' '        ,
	c_agencybankno                 varchar(3)      DEFAULT ' '        ,
	c_agencybankacco               varchar(30)     DEFAULT ' '        ,
	c_agencybankname               varchar(50)     DEFAULT ' '        ,
	c_agencytype                   varchar(1)      DEFAULT ' '        ,
	d_agencyregdate                int             DEFAULT 0          ,
	c_isdetail                     varchar(1)      DEFAULT ' '        ,
	c_sharetypes                   varchar(2)      DEFAULT ' '        ,
	l_liquidateredeem              int             DEFAULT 0          ,
	l_liquidatebonus               int             DEFAULT 0          ,
	l_liquidateallot               int             DEFAULT 0          ,
	l_liquidatesub                 int             DEFAULT 0          ,
	c_ztgonestep                   varchar(1)      DEFAULT ' '        ,
	c_preassign                    varchar(1)      DEFAULT ' '        ,
	l_cserialno                    int             DEFAULT 0          ,
	c_comparetype                  varchar(1)      DEFAULT ' '        ,
	c_liquidatetype                varchar(3)      DEFAULT ' '        ,
	c_multitradeacco               varchar(1)      DEFAULT ' '        ,
	c_iversion                     varchar(20)     DEFAULT ' '        ,
	c_imode                        varchar(1)      DEFAULT ' '        ,
	c_changeonstep                 varchar(1)      DEFAULT ' '        ,
	c_backfareallotratio           decimal(5,4)    DEFAULT 0.0        ,
	c_backfaresubratio             decimal(5,4)    DEFAULT 0.0        ,
	c_memo                         varchar(60)     DEFAULT ' '        
);
CREATE INDEX pkg_tcusttainfo_agencyinfo ON ta_tcusttainfo_agencyinfo(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustacconetfile_tmp(�ͷ��˻��Ǽ���Ϣ��ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tcustacconetfile_tmp-�ͷ��˻��Ǽ���Ϣ��ʱ��...';
DROP TABLE IF EXISTS ta_tcustacconetfile_tmp;
CREATE TABLE ta_tcustacconetfile_tmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_bankno                       varchar(60)     DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_nameinbank                   varchar(60)     DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_custno                       varchar(12)     DEFAULT ' '        ,
	c_specialaccoflag              varchar(1)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_openflag                     varchar(1)      DEFAULT ' '        
);

-- ������ ta_tcustcheckinifile(�ͷ��˶��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustcheckinifile-�ͷ��˶��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustcheckinifile;
CREATE TABLE ta_tcustcheckinifile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	l_validacconum                 int             DEFAULT 0          ,
	l_frozenacconum                int             DEFAULT 0          ,
	l_invalidacconum               int             DEFAULT 0          ,
	l_acconetnum                   int             DEFAULT 0          ,
	l_successconnum                int             DEFAULT 0          ,
	l_failconnum                   int             DEFAULT 0          ,
	l_successreqnum                int             DEFAULT 0          ,
	l_failreqnum                   int             DEFAULT 0          ,
	l_divcashnum                   int             DEFAULT 0          ,
	l_divsharenum                  int             DEFAULT 0          ,
	l_fundnum                      int             DEFAULT 0          
);

-- ������ ta_tcustprofitcurrentfile(�ͷ�ҵ�������ˮ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustprofitcurrentfile-�ͷ�ҵ�������ˮ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustprofitcurrentfile;
CREATE TABLE ta_tcustprofitcurrentfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_cserialnototal               varchar(20)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	d_originaldate                 int             DEFAULT 0          ,
	c_originalno                   varchar(20)     DEFAULT ' '        ,
	d_registdate                   int             DEFAULT 0          ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	f_beginasset                   decimal(16,2)   DEFAULT 0.0        ,
	f_endasset                     decimal(16,2)   DEFAULT 0.0        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        ,
	f_curratio                     decimal(16,8)   DEFAULT 0.0        ,
	f_yearratio                    decimal(16,8)   DEFAULT 0.0        ,
	f_ductmanagerfare              decimal(16,2)   DEFAULT 0.0        ,
	f_returnfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_factbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_factshare                    decimal(16,2)   DEFAULT 0.0        ,
	f_bonusbalance                 decimal(16,2)   DEFAULT 0.0        ,
	c_sortflag                     varchar(1)      DEFAULT ' '        ,
	d_begindate                    int             DEFAULT 0          ,
	l_hold                         int             DEFAULT 0          ,
	f_orinav                       decimal(7,4)    DEFAULT 0.0        ,
	f_oritotalnav                  decimal(7,4)    DEFAULT 0.0        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          
);

-- ������ ta_tcustecontractfile(�ͷ����Ӻ�ͬ��Ϣ�ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustecontractfile-�ͷ����Ӻ�ͬ��Ϣ�ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustecontractfile;
CREATE TABLE ta_tcustecontractfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_contracttype                 varchar(1)      DEFAULT ' '        ,
	c_contractno                   varchar(26)     DEFAULT ' '        ,
	c_confirmstatusmanager         varchar(1)      DEFAULT ' '        ,
	c_confirmstatuscustod          varchar(1)      DEFAULT ' '        ,
	c_distributorcode              varchar(9)      DEFAULT ' '        ,
	c_fundmanagercode              varchar(2)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	d_signdate                     int             DEFAULT 0          ,
	d_signtime                     int             DEFAULT 0          ,
	c_signchannel                  varchar(1)      DEFAULT ' '        ,
	c_signmachine                  varchar(60)     DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_notesagent                   varchar(64)     DEFAULT ' '        ,
	c_notesmanager                 varchar(64)     DEFAULT ' '        ,
	c_notescustod                  varchar(64)     DEFAULT ' '        ,
	d_modifydatemanager            int             DEFAULT 0          ,
	d_modifydatecustod             int             DEFAULT 0          ,
	d_modifydateagent              int             DEFAULT 0          ,
	c_issignriskboard              varchar(1)      DEFAULT ' '        ,
	c_isriskmatching               varchar(1)      DEFAULT ' '        ,
	c_riskabilityresult            varchar(1)      DEFAULT ' '        ,
	c_cardno                       varchar(22)     DEFAULT ' '        ,
	c_telno                        varchar(32)     DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_postcode                     varchar(10)     DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_confirmstaus                 varchar(1)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_notes                        varchar(64)     DEFAULT ' '        ,
	c_postzd                       varchar(1)      DEFAULT ' '        ,
	l_serialno                     bigint          DEFAULT 0          
);
CREATE INDEX pkg_tcustecontractfile ON ta_tcustecontractfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcustfundsharefile(�ͷ������ܷݶ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustfundsharefile-�ͷ������ܷݶ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcustfundsharefile;
CREATE TABLE ta_tcustfundsharefile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	d_holddate                     int             DEFAULT 0          ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_memo                         varchar(60)     DEFAULT ' '        
);
CREATE INDEX pkg_tcustfundsharefile ON ta_tcustfundsharefile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliqassetchgfile(Ͷ�ʽ����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tliqassetchgfile-Ͷ�ʽ����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tliqassetchgfile;
CREATE TABLE ta_tliqassetchgfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_tax                          decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare                    decimal(16,2)   DEFAULT 0.0        ,
	f_belongasset                  decimal(16,2)   DEFAULT 0.0        ,
	d_needdate                     int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	f_fundfare                     decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX pkg_tliqassetchgfile ON ta_tliqassetchgfile(c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tfundday_pubday(���鹫��������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundday_pubday-���鹫��������Ϣ��...';
DROP TABLE IF EXISTS ta_tfundday_pubday;
CREATE TABLE ta_tfundday_pubday
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	d_exportdate                   int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tfundday_pubday_tmp(���鹫�����м��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundday_pubday_tmp-���鹫�����м��...';
DROP TABLE IF EXISTS ta_tfundday_pubday_tmp;
CREATE TABLE ta_tfundday_pubday_tmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_navepublishfrequency         varchar(1)      DEFAULT ' '        ,
	c_navpublishmonth              varchar(2)      DEFAULT ' '        ,
	c_navpublishday                varchar(2)      DEFAULT ' '        ,
	c_calnavfrequencytype          varchar(1)      DEFAULT ' '        ,
	l_tnconfirm                    int             DEFAULT 0          ,
	c_fundtype                     varchar(1)      DEFAULT ' '        ,
	d_pubday                       int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tfundday_pubday_tmp1(���鹫�����м��1)�ĵ�ǰ��
SELECT 'Create Table ta_tfundday_pubday_tmp1-���鹫�����м��1...';
DROP TABLE IF EXISTS ta_tfundday_pubday_tmp1;
CREATE TABLE ta_tfundday_pubday_tmp1
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_navepublishfrequency         varchar(1)      DEFAULT ' '        ,
	d_setupdate                    int             DEFAULT 0          ,
	c_navpublishday                varchar(2)      DEFAULT ' '        ,
	c_navpublishmonth              varchar(2)      DEFAULT ' '        ,
	c_calnavfrequencytype          varchar(1)      DEFAULT ' '        ,
	c_fundtype                     varchar(1)      DEFAULT ' '        ,
	l_tnconfirm                    int             DEFAULT 0          ,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tfundday_open_tmp(�����������м��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundday_open_tmp-�����������м��...';
DROP TABLE IF EXISTS ta_tfundday_open_tmp;
CREATE TABLE ta_tfundday_open_tmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tfundday_close_tmp(����������м��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundday_close_tmp-����������м��...';
DROP TABLE IF EXISTS ta_tfundday_close_tmp;
CREATE TABLE ta_tfundday_close_tmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_navepublishfrequency         varchar(1)      DEFAULT ' '        ,
	d_setupdate                    int             DEFAULT 0          ,
	c_navpublishday                varchar(2)      DEFAULT ' '        ,
	c_navpublishmonth              varchar(2)      DEFAULT ' '        ,
	c_calnavfrequencytype          varchar(1)      DEFAULT ' '        ,
	c_fundtype                     varchar(1)      DEFAULT ' '        ,
	l_tnconfirm                    int             DEFAULT 0          ,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tfundday_pubday_month(���鰴�¹����м��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundday_pubday_month-���鰴�¹����м��...';
DROP TABLE IF EXISTS ta_tfundday_pubday_month;
CREATE TABLE ta_tfundday_pubday_month
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	l_tnconfirm                    int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_navepublishfrequency         varchar(1)      DEFAULT ' '        ,
	c_navpublishmonth              varchar(2)      DEFAULT ' '        ,
	c_navpublishday                varchar(2)      DEFAULT ' '        ,
	c_calnavfrequencytype          varchar(1)      DEFAULT ' '        ,
	c_fundtype                     varchar(1)      DEFAULT ' '        ,
	d_pubday                       int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tfundday_pubday_month1(���鰴�¹����м��1)�ĵ�ǰ��
SELECT 'Create Table ta_tfundday_pubday_month1-���鰴�¹����м��1...';
DROP TABLE IF EXISTS ta_tfundday_pubday_month1;
CREATE TABLE ta_tfundday_pubday_month1
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_navepublishfrequency         varchar(1)      DEFAULT ' '        ,
	c_navpublishmonth              varchar(2)      DEFAULT ' '        ,
	c_navpublishday                varchar(2)      DEFAULT ' '        ,
	c_calnavfrequencytype          varchar(1)      DEFAULT ' '        ,
	l_tnconfirm                    int             DEFAULT 0          ,
	c_fundtype                     varchar(1)      DEFAULT ' '        ,
	d_monfirstday                  int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tfundageliquidate_tmp(��������������������ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundageliquidate_tmp-��������������������ʱ��...';
DROP TABLE IF EXISTS ta_tfundageliquidate_tmp;
CREATE TABLE ta_tfundageliquidate_tmp
(
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_needflag                     varchar(1)      DEFAULT ' '        ,
	l_liquidateallot               int             DEFAULT 0          ,
	l_liquidatebonus               int             DEFAULT 0          ,
	l_liquidatesub                 int             DEFAULT 0          ,
	l_liquidatefail                int             DEFAULT 0          ,
	l_liquidateredeem              int             DEFAULT 0          ,
	l_liquidateend                 int             DEFAULT 0          ,
	l_liquidatechange              int             DEFAULT 0          
);
CREATE INDEX pk_tfundageliquidate_tmp ON ta_tfundageliquidate_tmp(c_tacode ASC ,c_tenantid ASC ,c_fundcode ASC ,c_agencyno ASC );

-- ������ ta_tcentralize92file(���б���92�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralize92file-���б���92�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralize92file;
CREATE TABLE ta_tcentralize92file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_cause                        varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	c_trademethod                  varchar(8)      DEFAULT ' '        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	c_billsendpass                 varchar(1)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_tradeaccostatus              varchar(1)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_investortype                 varchar(3)      DEFAULT ' '        ,
	c_investorprocode              varchar(6)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_txtbillsendpass              varchar(16)     DEFAULT ' '        ,
	c_othertradeacco               varchar(24)     DEFAULT ' '        
);

-- ������ ta_tcentralizeq2file(���б���92�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizeq2file-���б���92�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizeq2file;
CREATE TABLE ta_tcentralizeq2file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_cause                        varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	c_trademethod                  varchar(8)      DEFAULT ' '        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	c_billsendpass                 varchar(1)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_tradeaccostatus              varchar(1)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_investortype                 varchar(3)      DEFAULT ' '        ,
	c_investorprocode              varchar(6)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_txtbillsendpass              varchar(16)     DEFAULT ' '        ,
	c_othertradeacco               varchar(24)     DEFAULT ' '        
);

-- ������ ta_tcentralizez2file(���б���92�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizez2file-���б���92�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizez2file;
CREATE TABLE ta_tcentralizez2file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_cause                        varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	c_trademethod                  varchar(8)      DEFAULT ' '        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	c_billsendpass                 varchar(1)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_tradeaccostatus              varchar(1)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_investortype                 varchar(3)      DEFAULT ' '        ,
	c_investorprocode              varchar(6)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_txtbillsendpass              varchar(16)     DEFAULT ' '        ,
	c_othertradeacco               varchar(24)     DEFAULT ' '        
);

-- ������ ta_tcentralizes2file(���б���92�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizes2file-���б���92�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizes2file;
CREATE TABLE ta_tcentralizes2file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	d_freezeenddate                int             DEFAULT 0          ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_cause                        varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	c_trademethod                  varchar(8)      DEFAULT ' '        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	c_billsendpass                 varchar(1)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_tradeaccostatus              varchar(1)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_investortype                 varchar(3)      DEFAULT ' '        ,
	c_investorprocode              varchar(6)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_txtbillsendpass              varchar(16)     DEFAULT ' '        ,
	c_othertradeacco               varchar(24)     DEFAULT ' '        
);

-- ������ ta_tcentralize94file(���б���94�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralize94file-���б���94�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralize94file;
CREATE TABLE ta_tcentralize94file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_agentfare                    decimal(16,2)   DEFAULT 0.0        ,
	f_commision                    decimal(16,2)   DEFAULT 0.0        ,
	d_freezeenddate                int             DEFAULT 0          ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_interest                     decimal(16,2)   DEFAULT 0.0        ,
	c_exceedflag                   varchar(1)      DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_oricserialno                 varchar(20)     DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	c_otheragency                  varchar(9)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	c_othernetno                   varchar(9)      DEFAULT ' '        ,
	c_othertradeacco               varchar(24)     DEFAULT ' '        ,
	c_otheracco                    varchar(12)     DEFAULT ' '        ,
	f_othercfmshares               decimal(16,2)   DEFAULT 0.0        ,
	f_othernetvalue                decimal(7,4)    DEFAULT 0.0        ,
	f_agio                         decimal(5,4)    DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	d_orireqdate                   int             DEFAULT 0          ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_originaldate                 int             DEFAULT 0          ,
	c_hopeflag                     varchar(1)      DEFAULT ' '        ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
	c_othershare                   varchar(1)      DEFAULT ' '        ,
	f_bsharefare                   decimal(16,2)   DEFAULT 0.0        ,
	f_changefillfare               decimal(16,2)   DEFAULT 0.0        ,
	f_deductfare                   decimal(16,2)   DEFAULT 0.0        ,
	c_deductflag                   varchar(1)      DEFAULT ' '        ,
	c_crosstaflag                  varchar(3)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	d_hopedate                     int             DEFAULT 0          ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	c_specification                varchar(60)     DEFAULT ' '        
);

-- ������ ta_tcentralizez4file(���б���94�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizez4file-���б���94�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizez4file;
CREATE TABLE ta_tcentralizez4file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_agentfare                    decimal(16,2)   DEFAULT 0.0        ,
	f_commision                    decimal(16,2)   DEFAULT 0.0        ,
	d_freezeenddate                int             DEFAULT 0          ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_interest                     decimal(16,2)   DEFAULT 0.0        ,
	c_exceedflag                   varchar(1)      DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_oricserialno                 varchar(20)     DEFAULT ' '        ,
	c_orirequestno                 varchar(24)     DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	d_requesttime                  int             DEFAULT 0          ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	c_otheragency                  varchar(9)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_txtcause                     varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	c_othernetno                   varchar(9)      DEFAULT ' '        ,
	c_othertradeacco               varchar(24)     DEFAULT ' '        ,
	c_otheracco                    varchar(12)     DEFAULT ' '        ,
	f_othercfmshares               decimal(16,2)   DEFAULT 0.0        ,
	f_othernetvalue                decimal(7,4)    DEFAULT 0.0        ,
	f_agio                         decimal(5,4)    DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	c_taflag                       varchar(1)      DEFAULT ' '        ,
	d_orireqdate                   int             DEFAULT 0          ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	d_originaldate                 int             DEFAULT 0          ,
	c_hopeflag                     varchar(1)      DEFAULT ' '        ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
	c_othershare                   varchar(1)      DEFAULT ' '        ,
	f_bsharefare                   decimal(16,2)   DEFAULT 0.0        ,
	f_changefillfare               decimal(16,2)   DEFAULT 0.0        ,
	f_deductfare                   decimal(16,2)   DEFAULT 0.0        ,
	c_deductflag                   varchar(1)      DEFAULT ' '        ,
	c_crosstaflag                  varchar(3)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	d_hopedate                     int             DEFAULT 0          ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	c_specification                varchar(60)     DEFAULT ' '        
);

-- ������ ta_tcentralize95file(���б���95�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralize95file-���б���95�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralize95file;
CREATE TABLE ta_tcentralize95file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_availableshares              decimal(16,2)   DEFAULT 0.0        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	d_registdate                   int             DEFAULT 0          ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_cdate                        int             DEFAULT 0          ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        
);

-- ������ ta_tcentralizeq5file(���б���95�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizeq5file-���б���95�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizeq5file;
CREATE TABLE ta_tcentralizeq5file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_availableshares              decimal(16,2)   DEFAULT 0.0        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	d_registdate                   int             DEFAULT 0          ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_cdate                        int             DEFAULT 0          ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        
);

-- ������ ta_tcentralizez5file(���б���95�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizez5file-���б���95�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizez5file;
CREATE TABLE ta_tcentralizez5file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_availableshares              decimal(16,2)   DEFAULT 0.0        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	d_registdate                   int             DEFAULT 0          ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_cdate                        int             DEFAULT 0          ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        
);

-- ������ ta_tcentralizes5file(���б���95�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizes5file-���б���95�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizes5file;
CREATE TABLE ta_tcentralizes5file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_sourcetype                   varchar(1)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_datadetailflag               varchar(1)      DEFAULT ' '        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_availableshares              decimal(16,2)   DEFAULT 0.0        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	d_registdate                   int             DEFAULT 0          ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_cdate                        int             DEFAULT 0          ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_incomeflag                   varchar(1)      DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        
);

-- ������ ta_tcentralize96file(���б���96�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralize96file-���б���96�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralize96file;
CREATE TABLE ta_tcentralize96file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_date                         int             DEFAULT 0          ,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	d_reinvestdate                 int             DEFAULT 0          ,
	f_fare                         decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	d_regdate                      int             DEFAULT 0          ,
	c_cause                        varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_tax                          decimal(16,2)   DEFAULT 0.0        ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	f_deductfare                   decimal(16,2)   DEFAULT 0.0        ,
	c_deductflag                   varchar(1)      DEFAULT ' '        
);

-- ������ ta_tcentralizez6file(���б���96�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizez6file-���б���96�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizez6file;
CREATE TABLE ta_tcentralizez6file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	d_date                         int             DEFAULT 0          ,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	d_reinvestdate                 int             DEFAULT 0          ,
	f_fare                         decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	d_regdate                      int             DEFAULT 0          ,
	c_cause                        varchar(4)      DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_txtbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	f_tax                          decimal(16,2)   DEFAULT 0.0        ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_agecreditcode                varchar(18)     DEFAULT ' '        ,
	f_deductfare                   decimal(16,2)   DEFAULT 0.0        ,
	c_deductflag                   varchar(1)      DEFAULT ' '        
);

-- ������ ta_tcentralizeg1file(���б���G1�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizeg1file-���б���G1�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizeg1file;
CREATE TABLE ta_tcentralizeg1file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_marketflag                   varchar(1)      DEFAULT ' '        ,
	c_stockaccount                 varchar(10)     DEFAULT ' '        ,
	f_taxratio                     decimal(7,4)    DEFAULT 0.0        ,
	d_ratiodate                    int             DEFAULT 0          
);

-- ������ ta_tcentralizet1file(���б���T1�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizet1file-���б���T1�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizet1file;
CREATE TABLE ta_tcentralizet1file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_fundshortname                varchar(20)     DEFAULT ' '        ,
	c_publicflag                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_custodiancode                varchar(18)     DEFAULT ' '        ,
	c_registercode                 varchar(18)     DEFAULT ' '        ,
	c_fundcode2                    varchar(12)     DEFAULT ' '        ,
	c_regregioncode                varchar(2)      DEFAULT ' '        ,
	c_saleregioncode               varchar(2)      DEFAULT ' '        ,
	c_mainfundcode                 varchar(6)      DEFAULT ' '        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_destinationcode              varchar(6)      DEFAULT ' '        ,
	c_txtfundtype                  varchar(2)      DEFAULT ' '        ,
	c_isqdii                       varchar(1)      DEFAULT ' '        ,
	c_classflag                    varchar(1)      DEFAULT ' '        ,
	c_priorflag                    varchar(1)      DEFAULT ' '        ,
	d_setupdate                    int             DEFAULT 0          ,
	d_fundenddate                  int             DEFAULT 0          ,
	c_relationusage                varchar(2)      DEFAULT ' '        ,
	c_formalfundcode               varchar(6)      DEFAULT ' '        ,
	c_priorsequence                varchar(2)      DEFAULT ' '        ,
	f_leveragemultiple             decimal(10,4)   DEFAULT 0.0        ,
	c_investadname                 varchar(80)     DEFAULT ' '        ,
	c_investadbuscode              varchar(18)     DEFAULT ' '        ,
	c_investadmancode              varchar(18)     DEFAULT ' '        
);

-- ������ ta_tcentralizetmfile(���б���T1�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizetmfile-���б���T1�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizetmfile;
CREATE TABLE ta_tcentralizetmfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_fundshortname                varchar(20)     DEFAULT ' '        ,
	c_publicflag                   varchar(1)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_custodiancode                varchar(18)     DEFAULT ' '        ,
	c_registercode                 varchar(18)     DEFAULT ' '        ,
	c_fundcode2                    varchar(12)     DEFAULT ' '        ,
	c_regregioncode                varchar(2)      DEFAULT ' '        ,
	c_saleregioncode               varchar(2)      DEFAULT ' '        ,
	c_mainfundcode                 varchar(6)      DEFAULT ' '        ,
	c_moneytype                    varchar(3)      DEFAULT ' '        ,
	c_bonustype                    varchar(1)      DEFAULT ' '        ,
	c_destinationcode              varchar(6)      DEFAULT ' '        ,
	c_txtfundtype                  varchar(2)      DEFAULT ' '        ,
	c_isqdii                       varchar(1)      DEFAULT ' '        ,
	c_classflag                    varchar(1)      DEFAULT ' '        ,
	c_priorflag                    varchar(1)      DEFAULT ' '        ,
	d_setupdate                    int             DEFAULT 0          ,
	d_fundenddate                  int             DEFAULT 0          ,
	c_relationusage                varchar(2)      DEFAULT ' '        ,
	c_formalfundcode               varchar(6)      DEFAULT ' '        ,
	c_priorsequence                varchar(2)      DEFAULT ' '        ,
	f_leveragemultiple             decimal(10,4)   DEFAULT 0.0        ,
	c_investadname                 varchar(80)     DEFAULT ' '        ,
	c_investadbuscode              varchar(18)     DEFAULT ' '        ,
	c_investadmancode              varchar(18)     DEFAULT ' '        
);

-- ������ ta_tcentralizet2file(���б���T2�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizet2file-���б���T2�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizet2file;
CREATE TABLE ta_tcentralizet2file
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_fundstatus                   varchar(1)      DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	d_netvaluedate                 int             DEFAULT 0          ,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        ,
	f_totalbonus                   decimal(7,4)    DEFAULT 0.0        ,
	f_fundsize                     decimal(16,2)   DEFAULT 0.0        ,
	f_leveragerate                 decimal(16,4)   DEFAULT 0.0        ,
	f_leveragemultiple             decimal(10,4)   DEFAULT 0.0        
);

-- ������ ta_tcentralizetnfile(���б���T2�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcentralizetnfile-���б���T2�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_tcentralizetnfile;
CREATE TABLE ta_tcentralizetnfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_fundstatus                   varchar(1)      DEFAULT ' '        ,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
	d_netvaluedate                 int             DEFAULT 0          ,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        ,
	f_totalbonus                   decimal(7,4)    DEFAULT 0.0        ,
	f_fundsize                     decimal(16,2)   DEFAULT 0.0        ,
	f_leveragerate                 decimal(16,4)   DEFAULT 0.0        ,
	f_leveragemultiple             decimal(10,4)   DEFAULT 0.0        
);

-- ������ ta_totccustinfo(OTC�ͻ���Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_totccustinfo-OTC�ͻ���Ϣ��...';
DROP TABLE IF EXISTS ta_totccustinfo;
CREATE TABLE ta_totccustinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_otctacode                    varchar(8)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	d_idnovaliddate                int             DEFAULT 0          ,
	c_risklevel                    varchar(1)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
	c_accostatus                   varchar(1)      DEFAULT ' '        ,
	d_lastmodify                   int             DEFAULT 0          
);

-- ������ ta_totcshareinfo(OTC�ݶ���Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_totcshareinfo-OTC�ݶ���Ϣ��...';
DROP TABLE IF EXISTS ta_totcshareinfo;
CREATE TABLE ta_totcshareinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_outfundcode                  varchar(12)     DEFAULT ' '        ,
	c_issuecode                    varchar(8)      DEFAULT ' '        ,
	c_fundno                       varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_tradeacco                    varchar(24)     DEFAULT ' '        ,
	c_otctacode                    varchar(8)      DEFAULT ' '        ,
	f_availableshares              decimal(16,2)   DEFAULT 0.0        ,
	f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_cserialno                    varchar(20)     DEFAULT ' '        ,
	d_registdate                   int             DEFAULT 0          ,
	c_detailflag                   varchar(1)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	d_lastmodify                   int             DEFAULT 0          
);

-- ������ ta_tsalequalify_tmp(������ϵ�м��)�ĵ�ǰ��
SELECT 'Create Table ta_tsalequalify_tmp-������ϵ�м��...';
DROP TABLE IF EXISTS ta_tsalequalify_tmp;
CREATE TABLE ta_tsalequalify_tmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_dataflag                     varchar(1)      DEFAULT ' '        
);
CREATE INDEX idx_tsalequalify_tmp ON ta_tsalequalify_tmp(c_fundcode ASC ,c_agencyno ASC );

-- ������ ta_tinvestexpbatch(Ͷ�ʽ��׵������α�)�ĵ�ǰ��
SELECT 'Create Table ta_tinvestexpbatch-Ͷ�ʽ��׵������α�...';
DROP TABLE IF EXISTS ta_tinvestexpbatch;
CREATE TABLE ta_tinvestexpbatch
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tinterfaceerrlog(�ӿڴ�����־��)�ĵ�ǰ��
SELECT 'Create Table ta_tinterfaceerrlog-�ӿڴ�����־��...';
DROP TABLE IF EXISTS ta_tinterfaceerrlog;
CREATE TABLE ta_tinterfaceerrlog
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_ioflow                       varchar(20)     DEFAULT ' '        NOT NULL,
	c_errorcode                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_type                         varchar(1)      DEFAULT ' '        NOT NULL
);
CREATE INDEX idx_tinterfaceerrlog ON ta_tinterfaceerrlog(c_ioflow ASC ,c_liqbatchno ASC ,c_type ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_totcexpbatch(OTC�������α�)�ĵ�ǰ��
SELECT 'Create Table ta_totcexpbatch-OTC�������α�...';
DROP TABLE IF EXISTS ta_totcexpbatch;
CREATE TABLE ta_totcexpbatch
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL
);
CREATE INDEX idx_totcexpbatch ON ta_totcexpbatch(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tagencyimpbatch(�����̵������α�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencyimpbatch-�����̵������α�...';
DROP TABLE IF EXISTS ta_tagencyimpbatch;
CREATE TABLE ta_tagencyimpbatch
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_agencyexpbatch ON ta_tagencyimpbatch(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC ,c_liqbatchno ASC );

-- ������ ta_tinterfacefilerecord(�ӿ��ļ���¼��)�ĵ�ǰ��
SELECT 'Create Table ta_tinterfacefilerecord-�ӿ��ļ���¼��...';
DROP TABLE IF EXISTS ta_tinterfacefilerecord;
CREATE TABLE ta_tinterfacefilerecord
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_ioflow                       varchar(20)     DEFAULT ' '        NOT NULL,
	c_filetype                     varchar(20)     DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_dealcode                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	l_recordnum                    int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_ioflow, c_filetype, c_dealcode, c_managercode, d_cdate, c_tacode, c_tenantid)
);

