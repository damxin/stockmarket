-- -------------------------------------------
-- SQLfile   : tabase_product_MySQLTable.sql
-- Notes    : SQL�ű�
-- -------------------------------------------
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ��ע 
-- V1.0.6.3     2017-08-15 10:38                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_outfundcode����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.2     2017-08-04 09:48                                       ���б�ta_tagencyinfo�������˱��ֶΣ�c_preassign����                                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.2     2017-07-03 13:50                                       ���б�ta_tfundinfo�������˱��ֶΣ�l_periods����                                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.2     2017-06-05 14:47                                       ��ǰ��ta_tstructuredschema������������ uidx_childproduct:[c_tenantid,c_tacode,c_fundcodelist]��;                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.2     2017-06-05 14:46                                       ���б�ta_tstructuredschema�������˱��ֶΣ�c_fundcodelist����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.2     2017-06-05 14:46                                       ���б�ta_tstructuredschema��ɾ���˱��ֶΣ�c_fundcode����                                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.2     2017-06-05 14:45                                       ��ǰ��ta_tstructuredschema��ɾ���˱�������uidx_childproduct��;                                                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.2     2017-02-13 14:09                                       ��ǰ��ta_tstructuredschema��ɾ���˱�������uidx_tstructuredschema��;                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.2     2017-03-14 14:57                                       ���б�ta_tstructuredproduct�������˱��ֶΣ�f_add����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.2     2017-02-13 14:07                                       ���б�ta_tstructuredproduct�������˱��ֶΣ�c_recalnetvalue�������б�ta_tstructuredproduct�������˱��ֶΣ�f_reduce�������б�ta_tstructuredproduct�������˱��ֶΣ�c_ratiocltmethod����                                                                                                                                                                                                                                                                                                  
-- V1.0.6.2     2017-07-24 16:23                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_calconly����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.2     2017-07-21 10:40                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_indexcode�������б�ta_tprofitproj�������˱��ֶΣ�c_indexratiotozero�������б�ta_tprofitproj�������˱��ֶΣ�c_custincomemode����                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.2     2017-07-17 11:30                                       ���б�ta_tprofitzone�������˱��ֶΣ�f_minmultiple�������б�ta_tprofitzone�������˱��ֶΣ�f_maxmultiple�������б�ta_tprofitzone�������˱��ֶΣ�f_mindynamic�������б�ta_tprofitzone�������˱��ֶΣ�f_maxdynamic����                                                                                                                                                                                                                                                                    
-- V1.0.6.2     2017-07-06 14:42                                       ���б�ta_tprofitzone�������˱��ֶΣ�c_dynamicflag����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.2     2017-03-29 14:23                                       ���ݱ�ta_tagencyimpbatchschema��ɾ�������ֶΣ�����uidx_agencyexpbatch:ɾ���������ֶΣ�c_liqbatchno��                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.2     2017-03-29 09:40                                       ���ݱ�ta_tagencyimpbatchschema����������Ψһ�ԣ�����uidx_agencyexpbatch:Ψһ��                                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.2     2017-02-21 13:50                                       ���б�ta_tsubfundfare�����������ֶΣ�c_subfare->f_subfare����                                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.2     2017-03-30 13:40                                       ���б�ta_tnetvalueday�������˱��ֶΣ�f_offsetincome����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.2     2017-01-23 09:39                                       ���б�ta_tnetvalueday�������˱��ֶΣ�f_structuredtotalasset����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.2     2017-08-15 10:37                                       ���б�ta_tfundendproj�������˱��ֶΣ�c_outfundcode����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.2     2017-07-17 16:17                                       ��ǰ��ta_tfundendproj�����������ֶ�˳������uidx_fundendproj:������������ֶ�˳��Ϊ��c_fundcode,d_cdate,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.2     2017-07-17 16:16                                       ��ǰ��ta_tfundendproj�����������ֶΣ�����uidx_fundendproj:�����������ֶΣ�c_tacode����                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.2     2017-07-14 11:12                                       ���б�ta_tsplitschema�������˱��ֶΣ�c_splitreason����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.2     2017-06-14 10:37                                       ���б�ta_tstructureratioshares�������˱��ֶΣ�c_fundcodelist����                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.2     2017-03-02 13:44                                       ���б�ta_tstructureratioshares�������˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2016-09-09 10:57                                       ���б�ta_ttainfo�������˱��ֶΣ�d_archivedate����                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-07-16 15:22                                       ���б�ta_textparameter���޸��˱��ֶ����ͣ�c_paramtype����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2016-11-07 20:53                                       ���б�ta_tagencyinfo�������˱��ֶΣ�l_cserialno����                                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2016-11-07 20:52                                       ���б�ta_tagencyinfo�������˱��ֶΣ�c_changeonstep����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2016-10-15 11:01                                       ���б�ta_tagencyinfo�������˱��ֶΣ�c_isreceivebroadcast����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2016-09-07 15:22                                       ���б�ta_tagencyinfo�������˱��ֶΣ�c_newnavdate����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-07-16 15:08                                       ���б�ta_tagencyinfo�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-12-16 13:56                                       ���б�ta_tfundinfo�������˱��ֶΣ�c_ispublishtotalvalue����                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2016-11-08 20:42                                       ���б�ta_tfundinfo��ɾ���˱��ֶΣ�l_timelimit����                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-11-07 21:00                                       ���б�ta_tfundinfo�������˱��ֶΣ�l_timelimit����                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-11-07 20:55                                       ���б�ta_tfundinfo�������˱��ֶΣ�l_slimitday����                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-10-31 15:22                                       ���б�ta_tfundinfo�������˱��ֶΣ�c_nominalhold����                                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2016-09-26 10:58                                       ���ݱ�ta_tfundinfo�������˱��ֶΣ�c_department��                                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-09-20 19:04                                       ���б�ta_tfundinfo�������˱��ֶΣ�f_minasset����                                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-09-20 13:34                                       ���б�ta_tfundinfo�������˱��ֶΣ�f_managerratio����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-09-20 13:34                                       ���б�ta_tfundinfo��ɾ���˱��ֶΣ�f_managerfee����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2016-09-19 19:52                                       ���б�ta_tfundinfo�������˱��ֶΣ�f_managerfee����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2016-08-25 11:29                                       ���б�ta_tfundinfo�������˱��ֶΣ�d_appenddate�������б�ta_tfundinfo�������˱��ֶΣ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-08-18 10:44                                       ���ݱ�ta_tfundinfo�������˱��ֶΣ�d_contractbegdate��                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-08-10 16:50                                       ���б�ta_tfundinfo�������˱��ֶΣ�d_alimitenddate����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-07-20 15:29                                       ���б�ta_tfundinfo�������˱��ֶΣ�c_factcollectresult����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2016-07-16 15:06                                       ���б�ta_tfundinfo�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2016-07-15 13:34                                       ���ݱ�ta_tfundinfo�������˱��ֶΣ�f_parvalue��                                                                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1     2016-07-14 09:57                                       ���б�ta_tfundinfo�������˱��ֶΣ�c_checknetvalue����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-07-06 18:54                                       ���б�ta_tfundinfo�������˱��ֶΣ�c_checkshare����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2016-07-29 19:36                                       ��ǰ��ta_tsalequalify��ɾ���˱�������idx_tsalequalify_saleflag��;                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-07-29 13:25                                       ��ǰ��ta_tsalequalify������������ idx_tsalequalify_saleflag:[c_issaleflag,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-12-14 10:01                                       ���б�ta_tfundtrustee�������˱��ֶΣ�c_t5ismultimgr����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1     2016-09-06 16:09                                       ���б�ta_tfundbelongasset�������˱��ֶΣ�c_agencyno����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1     2016-07-16 15:24                                       ���б�ta_tsubtemplatepara���޸��˱��ֶ����ͣ�c_paramtype����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2016-08-05 16:11                                       ��ǰ��ta_tfundopenday������������ idx_tfundopenday_fundcode:[c_fundcode]��;                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2017-01-04 11:14                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_autodealflag����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2016-12-23 14:25                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_autodealflag����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2016-10-29 20:30                                       ��ǰ��ta_tprofitproj������������ uidx_ttprofitproj:[c_fundcode,d_dealdate,d_begindate,c_deductmode,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-10-29 20:21                                       ��ǰ��ta_tprofitproj��ɾ���˱�������uidx_ttprofitproj��;                                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2016-10-26 13:20                                       ���б�ta_tprofitproj�������˱��ֶΣ�f_firstdeductovernav����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2016-09-26 21:51                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_mtradeacco����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-09-26 11:34                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_profitbalancedealtype����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-09-26 11:33                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_profitfundcode����                                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2016-09-26 10:56                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_mgraccosharesdealtype����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-09-22 14:14                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_subsharepftfree����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2016-09-21 17:37                                       ���б�ta_tprofitproj�������˱��ֶΣ�f_overtotalnav����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2016-09-21 17:36                                       ���б�ta_tprofitproj�������˱��ֶΣ�f_fixedstandardnet����                                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-09-20 16:55                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_calcratiominuscapital����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-08-30 14:02                                       ���б�ta_tnetvalueday�������˱��ֶΣ�d_filedate�������б�ta_tnetvalueday�������˱��ֶΣ�f_filetotalshare����                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2016-07-29 20:59                                       ��ǰ��ta_tnetvalueday������������ idx_tnetvalueday_dcate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-07-29 20:43                                       ��ǰ��ta_tnetvalueday��ɾ���˱�������idx_tnetvalueday_1��;                                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-07-29 16:11                                       ��ǰ��ta_tnetvalueday������������ idx_tnetvalueday_1:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2016-07-19 17:03                                       ���б�ta_tnetvalueday�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-09-07 14:08                                       ���ݱ�ta_tfundstatusschema�������˱��ֶΣ�c_iscovernetvalue��                                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2016-09-12 17:53                                       ���б�ta_tfundendproj�������˱��ֶΣ�c_frozenfundend�������б�ta_tfundendproj�������˱��ֶΣ�c_isneeddeal����                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2017-02-20 09:08                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.9     2016-06-29 14:18                                       ���б�ta_textparameter�������˱��ֶΣ�c_rules�������б�ta_textparameter�������˱��ֶΣ�c_messages����                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.9     2016-06-30 10:05                                       ���б�ta_tshareclass�������˱��ֶΣ�f_maxshare����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.9     2016-06-30 10:05                                       ���б�ta_tshareclass��ɾ���˱��ֶΣ�f_maxshare����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.9     2016-06-29 14:20                                       ���б�ta_tsubtemplatepara�������˱��ֶΣ�c_rules�������б�ta_tsubtemplatepara�������˱��ֶΣ�c_messages����                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.9     2016-06-01 20:37                                       ���б�ta_tmpftschema�������˱��ֶΣ�c_ordermode����                                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.9     2016-07-05 11:27                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_calratiobytotalnet����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.9     2016-06-18 16:32                                       ���б�ta_tprofitproj�������˱��ֶΣ�c_deductname����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.9     2016-06-21 17:22                                       ���б�ta_tprofitzone�������˱��ֶΣ�c_deductmode����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.9     2016-06-05 09:34                                       ���б�ta_tnetvalueday�������˱��ֶΣ�f_lastunassign����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.9     2016-07-11 16:57                   �ؽ���    �ؽ���    ���ݱ�ta_tfundstatusschema�������˱��ֶΣ�f_netvalue��                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.9     2016-07-08 13:31                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.8     2016-05-27 19:36                                       ��ǰ��ta_tprofitzone������������ l_rowi��;                                                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.7     2016-05-27 19:33                                       ��ǰ��ta_tprofitproj������������ l_rowi��;                                                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.7     2016-05-27 19:13                                       ���б�ta_tprofitzone�������˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.6     2016-05-27 19:13                                       ���б�ta_tprofitzone��ɾ���˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.5     2016-05-27 19:11                                       ���б�ta_tprofitproj�������˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.4     2016-05-27 19:11                                       ���б�ta_tprofitproj��ɾ���˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.3     2016-05-26 18:53                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.2     2016-05-26 15:55                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-06-13 09:59                   �״�                ���б�ta_tfundinfo�������˱��ֶΣ�c_orifundstatus����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-06-01 09:57                                       ���б�ta_tfundinfo�������˱��ֶΣ�d_lastsubdate����                                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.1     2016-05-25 14:53                                       ���б�ta_tfundinfo��ɾ���˱��ֶΣ�f_maxredeem����                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2016-05-25 10:03                                       ���б�ta_tfundinfo�������˱��ֶΣ�f_maxallotasset�������б�ta_tfundinfo�������˱��ֶΣ�f_maxallotshares�������б�ta_tfundinfo�������˱��ֶΣ�f_maxallot�������б�ta_tfundinfo�������˱��ֶΣ�c_excessallot�������б�ta_tfundinfo�������˱��ֶΣ�c_extradealtype�������б�ta_tfundinfo�������˱��ֶΣ�c_exceedpart�������б�ta_tfundinfo�������˱��ֶΣ�f_maxaddbalance�������б�ta_tfundinfo�������˱��ֶΣ�f_maxredeem�������б�ta_tfundinfo�������˱��ֶΣ�c_exceedflag����         
-- V1.0.5.1     2016-05-19 10:52                                       ��ǰ��ta_totcfarezone������������ l_rowi��;                                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.1     2016-05-19 10:50                                       ���б�ta_totcfarezone�������˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-05-19 10:50                                       ���б�ta_totcfarezone��ɾ���˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-05-19 10:50                                       ��ǰ��ta_totcfarezone��ɾ���˱�����;                                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-05-19 10:57                                       ��ǰ��ta_totcliqudiate������������ l_rowi��;                                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.1     2016-05-19 10:56                                       ���б�ta_totcliqudiate�������˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2016-05-19 10:56                                       ���б�ta_totcliqudiate��ɾ���˱��ֶΣ�l_rowid����                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2016-05-19 10:55                                       ��ǰ��ta_totcliqudiate��ɾ���˱�����;                                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-06-17 13:54                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-05-25 10:36                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ��ע 
-- V1.0.5.6     2017-08-15 10:40                                       ���б�ta_tuserevent�������˱��ֶΣ�c_outfundcode����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.5     2016-09-14 17:27                                       ���б�ta_truleinfo���޸��˱��ֶ����ͣ�c_ruleevent����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.5     2016-08-22 09:49                                       ���б�ta_tflowconfig�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.5     2016-07-19 20:25                                       ���б�ta_tbatchdealctl�������˱��ֶΣ�c_maxbatchno�������б�ta_tbatchdealctl�������˱��ֶΣ�c_minbatchno����                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.5     2017-09-14 15:56                                       ���б�_processinstancedefinition�������˱��ֶΣ�c_longtacode����                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.5     2016-07-30 10:41                                       ��ǰ��ta_tsynctablelog������������ idx_tsynctablelog_cdate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.5     2016-07-30 10:37                                       ��ǰ��ta_tsynctablelog�����������ֶ�˳��Ϊ��c_flowstep,c_tablename,d_cdate,c_fundcode,c_agencyno,c_trusteecode,c_managercode,c_databaseno,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.5     2016-08-19 16:27                                       ���б�ta_tuserevent�������˱��ֶΣ�c_autodealflag����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.5     2016-07-23 15:41                                       ��ǰ��ta_tuserevent�����������ֶ�˳������pk_userevent:������������ֶ�˳��Ϊ��c_usereventtype,c_fundcode,d_cdate,c_agencyno,c_trusteecode,c_managercode,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                     
-- V1.0.5.5     2016-09-18 10:04                                       ���б�ta_thintinfo�������˱��ֶΣ�c_hintoptmode����                                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.5     2016-09-18 10:06                                       ���б�ta_thintlog�������˱��ֶΣ�c_hintoptmode�������б�ta_thintlog�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.4     2016-07-18 14:36                                       ���б�ta_tflowinfo�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.4     2016-06-20 11:23                                       ���б�ta_tflowinfo�������˱��ֶΣ�c_contentcode����                                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.4     2016-06-05 11:54                                       ���б�ta_tflowinfo�������˱��ֶΣ�c_fundbackflag�������б�ta_tflowinfo�������˱��ֶΣ�c_agcbackflag�������б�ta_tflowinfo�������˱��ֶΣ�c_mgrbackflag����                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.4     2016-07-18 14:57                                       ���б�ta_tflowlog�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.4     2016-06-20 11:28                                       ���б�ta_tflowlog�������˱��ֶΣ�c_contentcode����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.4     2016-06-05 11:52                                       ���б�ta_tflowlog�������˱��ֶΣ�c_fundbackflag�������б�ta_tflowlog�������˱��ֶΣ�c_agcbackflag�������б�ta_tflowlog�������˱��ֶΣ�c_mgrbackflag����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.4     2016-06-05 11:52                                       ���б�ta_tflowlog�������˱��ֶΣ�c_fundbackflag�������б�ta_tflowlog�������˱��ֶΣ�c_agcbackflag�������б�ta_tflowlog�������˱��ֶΣ�c_mgrbackflag����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.4     2016-07-16 15:09                                       ���б�ta_tbatchdealctl�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.4     2016-05-27 18:48                                       �޸�������uidx_thintlog,�����ֶ��޸�Ϊ��(c_instanceid,d_cdate,c_flowstep,c_flowno,c_hintno,c_tacode,c_tenantid,l_no),��������޸�Ϊ��null,����Ψһ���޸�Ϊ����Ψһ,��������������Ϊ:��������.                                                                                                                                                                                                                                                                                         
-- V1.0.5.4     2016-05-27 18:38                                       ���б�ta_thintlog�������˱��ֶΣ�l_no����                                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.4     2016-06-20 11:16                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.4     2016-06-20 11:21                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.4     2016-06-21 09:04                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.3     2016-05-23 17:22                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-05-17 22:13                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-05-18 16:43                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-06-05 10:21                                       ��ǰ��ta_tbackinstancelist������������ c_instanceid,c_tenanti��;                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-06-05 10:20                                       ���б�ta_tbackinstancelist�������˱��ֶΣ�c_tenantid�������б�ta_tbackinstancelist�������˱��ֶΣ�c_instanceid����                                                                                                                                                                                                                                                                                                                                                                    
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ��ע 
-- V1.0.5.2     2017-06-05 13:41                                       ���б�ta_tliquidatetrusteedetail�������˱��ֶΣ�f_interest����                                                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2017-06-22 17:36                                       ���б�ta_tstaticsharesstat�������˱��ֶΣ�f_frozenshares����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.2     2017-03-22 09:06                                       ���б�ta_tstaticsharesstat�������˱��ֶΣ�f_newincome����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.2     2017-06-05 13:41                                       ���б�ta_tliquidateagency�������˱��ֶΣ�f_interest����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.2     2017-02-20 09:08                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-29 21:01                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_busin:[d_cdate,c_businflag]��;                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2016-07-29 20:57                                       ��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_1��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_2��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_3��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_4��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_5��;                                                                                                                                                                                    
-- V1.0.5.1     2016-07-29 16:57                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_5:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-07-29 16:54                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_4:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-07-29 16:53                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_3:[d_cdate,c_businflag,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-07-29 16:52                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_2:[d_cdate,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-07-29 16:49                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_1:[d_cdate,c_businflag,c_fundcode,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.1     2016-07-27 09:38                                       ���б�ta_trequeststat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-07-29 20:58                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_busin:[d_cdate,c_businflag]��;                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2016-07-29 20:43                                       ��ǰ��ta_tconfirmstat��ɾ���˱�������idx_tconfirmstat_1��;��ǰ��ta_tconfirmstat��ɾ���˱�������idx_tconfirmstat_2��;                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-07-29 16:05                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_2:[d_cdate,c_businflag,c_liqbatchno,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.1     2016-07-29 15:55                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_1:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-07-26 17:33                                       ���б�ta_tconfirmstat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-09-02 11:55                                       ���б�ta_tsalestat�������˱��ֶΣ�f_managerfee����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-09-02 11:55                                       ���б�ta_tsalestat��ɾ���˱��ֶΣ�f_managefare����                                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-08-09 10:16                                       ��ǰ��ta_tsalestat������������ idx_tsalestat_cdate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2016-07-29 20:55                                       ��ǰ��ta_tliquidatetrusteedetail��ɾ���˱�������idx_tliqtrusteedetail��;                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-29 16:22                                       ��ǰ��ta_tliquidatetrusteedetail������������ idx_tliqtrusteedetail:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-26 20:10                                       ���б�ta_tliquidatetrusteedetail�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-05-26 11:25                                       ��ǰ��ta_tliquidatetrusteedetail������������ d_cdate,c_fundcode,c_businflag,c_agencyno,d_needdate,c_databaseno,c_tenanti��;                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.1     2016-07-29 20:54                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate2:[d_requestdate]��;                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-29 20:53                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate1:[c_fundcode]��;                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-07-29 20:53                                       ��ǰ��ta_tfundtrusteeliquidate��ɾ���˱�������idx_tfundtrusteeliquidate��;                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-07-29 16:18                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate:[c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-07-26 20:11                                       ���б�ta_tfundtrusteeliquidate�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-10-19 19:24                                       ���б�ta_tdividendstat�������˱��ֶΣ�l_successcount����                                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-08-10 14:09                                       ��ǰ��ta_tdividendstat��ɾ���˱�������idx_tdividendstat_cdate��;                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-08-10 14:08                                       ��ǰ��ta_tdividendstat�����������ֶ�˳��Ϊ��d_cdate,c_fundcode,c_agencyno,c_sharetype,c_bonustype,c_shareclass,d_senddate,d_distributedate,d_reinvestdate,c_dataflag,c_databaseno,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                             
-- V1.0.5.1     2016-07-29 20:59                                       ��ǰ��ta_tdividendstat������������ idx_tdividendstat_cdate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-07-29 20:42                                       ��ǰ��ta_tdividendstat��ɾ���˱�������idx_tdividendstat_liqno��;                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-29 14:52                                       ��ǰ��ta_tdividendstat������������ idx_tdividendstat_liqno:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-26 17:10                                       ���б�ta_tdividendstat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-06-18 11:21                                       ���б�ta_tdividendstat�������˱��ֶΣ�f_deductbalance����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1     2017-02-23 10:12                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinteresttax����                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2017-02-23 10:12                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinterestall����                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2017-02-22 10:04                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rshares_ch�������б�ta_tconfirmstatdetail�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2017-02-21 19:38                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_deductmngfare����                                                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-12-06 13:28                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinterest����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2016-11-07 10:45                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_balance�������б�ta_tconfirmstatdetail�������˱��ֶΣ�f_shares����                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2016-10-17 13:51                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_delaybalance�������б�ta_tconfirmstatdetail�������˱��ֶΣ�f_delayshares����                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1     2016-09-27 11:13                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�c_taflag����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-08-25 14:20                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tconfirmstat_outdate:[d_outputdate]��;                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-08-10 14:10                                       ��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_dcate��;                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-29 20:50                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_dcate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-07-29 20:49                                       ��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_liqno��;��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_busin��;                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.1     2016-07-29 15:59                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_busin:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-07-29 14:43                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_liqno:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-07-26 17:05                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.1     2016-11-14 15:36                                       ��ǰ��ta_ttailratio�����������ֶ�˳������pk_ttailratio:������������ֶ�˳��Ϊ��c_fundcode,c_agencyno,c_tailflag,d_tailbgdate,f_holdmin,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-08 09:57                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-09-26 21:03                                       ��ǰ��ta_tliquidateswitch������������ uidx_tliquidateswitch:[d_date,c_fundcode,c_othercode,c_agencyno,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-09-26 19:42                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-11-04 16:07                                       ���б�ta_tcheckresultstat�������˱��ֶΣ�c_fundacco�������б�ta_tcheckresultstat�������˱��ֶΣ�c_businflag����                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-11-07 10:59                                       ��ǰ��ta_tfundagencyliquidate������������ idx_tfundagecliq:[c_fundcode,c_agencyno,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ��ע 
-- V1.0.6.1     2016-10-15 11:05                                       ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_isreceivebroadcast����                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-09-07 15:29                                       ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_newnavdate����                                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2016-08-20 11:02                   �״�                ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_agencytype����                                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2017-04-14 19:27                                       ���б�ta_tcustexpbatch�������˱��ֶΣ�d_begindate�������б�ta_tcustexpbatch�������˱��ֶΣ�d_enddate����                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2016-11-14 19:57                                       ��ǰ��ta_tliqexpbatch�����������ֶ�˳��Ϊ��c_trusteecode,c_managercode,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1     2016-11-14 19:56                                       ��ǰ��ta_tliqexpbatch�����������ֶΣ�c_trusteecode����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2016-11-14 17:31                                       ��ǰ��ta_tliqexpbatch������������ c_managercode,c_tacode,c_tenanti��;                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-11-14 17:30                                       ��ǰ��ta_tliqexpbatch��ɾ���˱�������uidx_tliqexpbatch��;                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-06-16 10:59                                       ���б�ta_tcenterexpbatch�������˱��ֶΣ�d_zhzlcentralizedate����                                                                                                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2017-06-15 16:05                                       ���б�ta_tcenterexpbatch�������˱��ֶΣ�c_centralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�c_zhcentralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�c_zhzlcentralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�d_zhcentralizedate����                                                                                                                                                                                                                              
-- V1.0.6.1     2016-11-01 19:05                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�f_otherfee2����                                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2016-10-27 12:23                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2016-10-27 12:22                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2016-10-27 10:41                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2016-08-31 16:13                                       ���б�ta_tagencynavc4file�������˱��ֶΣ�f_unitprofittxt����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2016-08-31 16:13                                       ���б�ta_tagencynavc4file��ɾ���˱��ֶΣ�f_unitprofit����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2016-12-20 17:15                                       ���б�ta_tagencynav07file�������˱��ֶΣ�c_infundcode����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-05-22 18:45                                       ���б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_newtradeacco����                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-05-22 18:45                                       ���б�ta_tagencyreqnorstd01file��ɾ���˱��ֶΣ�c_othertradeacco����                                                                                                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2017-05-17 15:41                                       ���б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_oriidentityno�������б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_oricontno�������б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_contidcard18len����                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2017-02-15 17:20                                       ���б�ta_tliqredeemfile�������˱��ֶΣ�f_deductmngfare����                                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2017-02-16 09:37                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�f_rshares_ch�������б�ta_tliqadjustsharefile�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-02-16 09:31                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2017-02-16 09:30                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�f_rshares_ch����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2017-02-15 17:10                                       ���б�ta_tliqbonusfile�������˱��ֶΣ�f_aheadincome����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1     2017-02-16 14:26                                       ���б�ta_tliqswitchoutfile���޸��˱��ֶ������գ�f_otherfare����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2017-02-16 14:22                                       ���б�ta_tliqswitchoutfile�������˱��ֶΣ�f_otherfare����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-02-16 14:27                                       ���б�ta_tliqswitchfile���޸��˱��ֶ������գ�f_otherfare����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2017-02-16 14:21                                       ���б�ta_tliqswitchfile�������˱��ֶΣ�f_otherfare����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2017-02-16 09:35                                       ���б�ta_tliqincomefile�������˱��ֶΣ�f_endaccumshares����                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2017-02-16 09:23                                       ���б�ta_tliqincomefile�������˱��ֶΣ�f_endaccumshares����                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2016-11-07 17:14                                       ���б�ta_tcustconfirmfile��ɾ���˱��ֶΣ�l_serialno����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1     2016-11-07 17:13                                       ���б�ta_tcustconfirmfile�������˱��ֶΣ�l_serialnumber����                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2016-11-07 18:16                                       ���б�ta_tcustprofitcurrentfile��ɾ���˱��ֶΣ�l_serialno����                                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2016-11-07 18:14                                       ���б�ta_tcustprofitcurrentfile�������˱��ֶΣ�l_serialnumber����                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-06-01 17:28                                       ���б�ta_tcentralize92file�������˱��ֶΣ�c_nationality����                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2017-05-31 17:13                                       ���б�ta_tcentralize96file�������˱��ֶΣ�f_deductfare�������б�ta_tcentralize96file�������˱��ֶΣ�c_deductflag����                                                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2017-06-01 18:33                                       ���б�ta_tcentralizeg1file�������˱��ֶΣ�f_taxratio�������б�ta_tcentralizeg1file�������˱��ֶΣ�d_ratiodate����                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-06-01 18:12                                       ���б�ta_tcentralizet1file�������˱��ֶΣ�c_formalfundcode�������б�ta_tcentralizet1file�������˱��ֶΣ�c_priorsequence�������б�ta_tcentralizet1file�������˱��ֶΣ�f_leveragemultiple�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadname�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadbuscode�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadmancode����                                                                                                 
-- V1.0.6.1     2017-06-01 18:30                                       ���б�ta_tcentralizet2file�������˱��ֶΣ�f_leveragerate�������б�ta_tcentralizet2file�������˱��ֶΣ�f_leveragemultiple����                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2016-10-24 16:35                                       ��ǰ��ta_tsalequalify_tmp������������ idx_tsalequalify_tmp:[c_fundcode,c_agencyno]��;                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-10-24 14:25                                       ���б�ta_tsalequalify_tmp�������˱��ֶΣ�c_dataflag����                                                                                                                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1     2016-09-26 14:29                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.17    2016-06-21 11:17                                       ��ǰ��ta_tfilefield�����������ֶΣ�l_taidno����                                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.17    2016-08-05 21:50                                       �޸�������uidx_tmergercontrol,�����ֶ��޸�Ϊ��(c_gradefund,c_type,c_tenantid),��������޸�Ϊ��null,����Ψһ���޸�Ϊ����Ψһ,��������������Ϊ:��������.                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.17    2016-08-05 21:49                                       ��ǰ��ta_tmergercontrol������������ uidx_tmergecontrol:[c_gradefund,c_type,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.17    2016-08-05 21:48                                       ��ǰ��ta_tmergercontrol��ɾ���˱�������uidx_mergercontrol��;                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.17    2016-06-18 15:53                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�f_tafare����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.17    2016-06-18 15:58                                       ���б�ta_tliqredeemfile�������˱��ֶΣ�f_ductmanagerfare�������б�ta_tliqredeemfile�������˱��ֶΣ�f_profitbalance����                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.17    2016-06-18 15:56                                       ���б�ta_tliqbonusfile�������˱��ֶΣ�f_profitbalance����                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.17    2016-06-04 15:50                                       ���б�ta_tcustfundinfofile�������˱��ֶΣ�c_pensionregistcode����                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.17    2016-06-03 17:44                                       ���б�ta_tcustaccofile�������˱��ֶΣ�c_risklevel����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.17    2016-06-03 17:43                                       ���б�ta_tcustaccorequestfile�������˱��ֶΣ�c_risklevel����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.17    2016-06-04 15:49                                       ���б�ta_tcustdividendfile�������˱��ֶΣ�f_unitprofit2����                                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.17    2016-06-23 16:27                                       ���б�ta_tcustecontractfile�����������ֶΣ�c_custodiancode->c_trusteecode����                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.17    2016-06-23 11:05                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.17    2016-08-03 16:24                                       ��ǰ��ta_totccustinfo��ɾ���˱�������idx_totccustinfo��;                                                                                                                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.17    2016-08-03 15:50                                       ��ǰ��ta_totccustinfo������������ idx_totccustinfo:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.17    2016-08-03 16:24                                       ��ǰ��ta_totcshareinfo��ɾ���˱�������idx_totcshareinfo��;                                                                                                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.17    2016-08-03 16:07                                       ��ǰ��ta_totcshareinfo������������ idx_totcshareinfo:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.14    2016-05-27 16:41                                       ���б�ta_tcentralize92file�������˱��ֶΣ�c_txtbillsendpass����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.13    2016-05-27 16:41                                       ���б�ta_tcentralize92file��ɾ���˱��ֶΣ�c_billsendpass����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.11    2016-05-26 11:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.8     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.7     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.6     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.5     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.4     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.3     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.2     2016-05-21 16:40                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.2     2016-05-17 20:49                                       ���б�ta_tcusttainfo_fundinfo�������˱��ֶΣ�l_netprecision����                                                                                                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.2     2016-05-18 16:10                                       ���б�ta_tcusttainfo_farezone�������˱��ֶΣ�f_maxbalance����                                                                                                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.2     2016-05-18 16:08                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.2     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.2     2016-05-20 08:42                                       ���б�ta_totcshareinfo���޸��˱��ֶ������գ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.1     2016-06-15 16:23                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-05-17 17:19                                       ���б�ta_totccustinfo��ɾ���˱��ֶΣ�c_databaseno����                                                                                                                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-05-17 17:22                                       ���б�ta_totcshareinfo�������˱��ֶΣ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-05-17 17:20                                       ���б�ta_totcshareinfo��ɾ���˱��ֶΣ�c_databaseno����                                                                                                                                                                                                                                                                                                                                                                                                                                


-- ������ ta_ttainfo(�Ǽǹ����˻�����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_ttainfo-�Ǽǹ����˻�����Ϣ��...';
DROP TABLE IF EXISTS ta_ttainfo;
CREATE TABLE ta_ttainfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_taname                       varchar(60)     DEFAULT ' '        NOT NULL,
	c_subtemplatecode              varchar(12)     DEFAULT ' '        NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
	c_tastatus                     varchar(1)      DEFAULT 'N'        NOT NULL,
	d_sysdate                      int             DEFAULT 0          NOT NULL,
	d_lastsysdate                  int             DEFAULT -1         NOT NULL,
	c_website                      varchar(30)     DEFAULT ' '        NOT NULL,
	c_servertel                    varchar(30)     DEFAULT ' '        NOT NULL,
	d_archivedate                  int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_ttainfo ON ta_ttainfo(c_tacode ASC ,c_tenantid ASC );

-- ������ ta_textparameter(TA�����˲�Ʒ��������չ������)�ĵ�ǰ��
SELECT 'Create Table ta_textparameter-TA�����˲�Ʒ��������չ������...';
DROP TABLE IF EXISTS ta_textparameter;
CREATE TABLE ta_textparameter
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT null       ,
	c_paramlevel                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_paramclass                   varchar(20)     DEFAULT ' '        NOT NULL,
	c_paramitem                    varchar(40)     DEFAULT ' '        NOT NULL,
	c_paramvalue                   varchar(255)    DEFAULT ' '        NOT NULL,
	c_paramtype                    varchar(50)     DEFAULT ' '        NOT NULL,
	c_valuebound                   varchar(100)    DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_usermodify                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        ,
	c_cryptflag                    varchar(1)      DEFAULT ' '        ,
	c_showclass                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_showsubclass                 varchar(40)     DEFAULT ' '        NOT NULL,
	l_order                        int             DEFAULT 0          NOT NULL,
	c_rules                        varchar(255)    DEFAULT ' '        ,
	c_messages                     varchar(255)    DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_textparameter ON ta_textparameter(c_paramitem ASC ,c_fundcode ASC ,c_agencyno ASC ,c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );
CREATE INDEX idx_textparameter_ta ON ta_textparameter(c_tacode ASC ,c_tenantid ASC );
CREATE INDEX idx_textparameter_mgr ON ta_textparameter(c_managercode ASC ,c_tenantid ASC );
CREATE INDEX idx_textparameter_fnd ON ta_textparameter(c_fundcode ASC ,c_tenantid ASC );
CREATE INDEX idx_textparameter_agc ON ta_textparameter(c_agencyno ASC ,c_tenantid ASC );

-- ������ ta_tmanagerinfo(�����˻�����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tmanagerinfo-�����˻�����Ϣ��...';
DROP TABLE IF EXISTS ta_tmanagerinfo;
CREATE TABLE ta_tmanagerinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_managername                  varchar(60)     DEFAULT ' '        NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
	c_managerstatus                varchar(1)      DEFAULT 'N'        NOT NULL,
	c_subtemplatecode              varchar(12)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tmanagerinfo ON ta_tmanagerinfo(c_managercode ASC ,c_tenantid ASC );

-- ������ ta_tagencyinfo(�����̻�����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tagencyinfo-�����̻�����Ϣ��...';
DROP TABLE IF EXISTS ta_tagencyinfo;
CREATE TABLE ta_tagencyinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_agencyname                   varchar(40)     DEFAULT ' '        NOT NULL,
	c_agencystatus                 varchar(1)      DEFAULT 'N'        NOT NULL,
	c_agencytype                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_comparetype                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT '400'      NOT NULL,
	c_centerflag                   varchar(1)      DEFAULT '1'        NOT NULL,
	c_multitradeacco               varchar(1)      DEFAULT ' '        NOT NULL,
	c_modifytradeacco              varchar(1)      DEFAULT ' '        NOT NULL,
	c_agencyenglishname            varchar(40)     DEFAULT ' '        NOT NULL,
	c_agencyaddress                varchar(80)     DEFAULT ' '        NOT NULL,
	c_agencyzipcode                varchar(6)      DEFAULT ' '        NOT NULL,
	c_agencycontact                varchar(8)      DEFAULT ' '        NOT NULL,
	c_agencyphone                  varchar(40)     DEFAULT ' '        NOT NULL,
	c_agencyfaxno                  varchar(40)     DEFAULT ' '        NOT NULL,
	c_agencyemail                  varchar(40)     DEFAULT ' '        NOT NULL,
	c_isdetail                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_sharetypes                   varchar(2)      DEFAULT 'A'        NOT NULL,
	c_ztgonestep                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_littledealtype               varchar(1)      DEFAULT ' '        NOT NULL,
	c_overtimetype                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_fundcodedealtype             varchar(1)      DEFAULT ' '        NOT NULL,
	c_dataissuetype                varchar(1)      DEFAULT ' '        NOT NULL,
	c_regmodifyinfo                varchar(1)      DEFAULT ' '        NOT NULL,
	c_cancelchktradeacco           varchar(1)      DEFAULT ' '        NOT NULL,
	c_subtemplatecode              varchar(12)     DEFAULT ' '        NOT NULL,
	c_notexpparamfiles             varchar(1)      DEFAULT '0'        NOT NULL,
	c_agecreditcode                varchar(18)     DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
	c_newnavdate                   varchar(1)      DEFAULT '0'        NOT NULL,
	c_isreceivebroadcast           varchar(1)      DEFAULT '0'        NOT NULL,
	c_openaccoflag                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_changeonstep                 varchar(1)      DEFAULT ' '        NOT NULL,
	l_cserialno                    int             DEFAULT 0          NOT NULL,
	c_preassign                    varchar(1)      DEFAULT '0'        NOT NULL,
	c_isexpnotfinished             varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tagencyinfo ON ta_tagencyinfo(c_agencyno ASC ,c_tenantid ASC );

-- ������ ta_tfundinfo(��Ʒ������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundinfo-��Ʒ������Ϣ��...';
DROP TABLE IF EXISTS ta_tfundinfo;
CREATE TABLE ta_tfundinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundname                     varchar(40)     DEFAULT ' '        NOT NULL,
	c_fundcharacter                varchar(80)     DEFAULT ' '        NOT NULL,
	c_fundstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_subtemplatecode              varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundtype                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_netvaluetype                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_launchtype                   varchar(1)      DEFAULT '1'        NOT NULL,
	c_investorientation            varchar(1)      DEFAULT ' '        NOT NULL,
	c_sharetypes                   varchar(2)      DEFAULT 'A'        NOT NULL,
	c_isetf                        varchar(1)      DEFAULT ' '        NOT NULL,
	c_isqdii                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_isforeigncurrency            varchar(1)      DEFAULT ' '        NOT NULL,
	c_isyuebao                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_isshortcyclefinance          varchar(1)      DEFAULT ' '        NOT NULL,
	c_isguarantedfund              varchar(1)      DEFAULT ' '        NOT NULL,
	c_isstructed                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_isgraded                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_fundenglishname              varchar(40)     DEFAULT ' '        NOT NULL,
	c_moneytype                    varchar(3)      DEFAULT '156'      NOT NULL,
	l_netprecision                 int             DEFAULT 4          NOT NULL,
	c_risklevel                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_issueprice                   decimal(7,4)    DEFAULT 1.0        NOT NULL,
	d_issuedate                    int             DEFAULT 0          NOT NULL,
	d_issueenddate                 int             DEFAULT 0          NOT NULL,
	d_setupdate                    int             DEFAULT 0          NOT NULL,
	f_maxissuebala                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_minissuebala                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	l_minaccocount                 int             DEFAULT 0          NOT NULL,
	l_maxaccocount                 int             DEFAULT 0          NOT NULL,
	f_maxredeemratio               decimal(9,8)    DEFAULT 0.1        NOT NULL,
	c_issuetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_factcollect                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	d_failuredate                  int             DEFAULT 0          NOT NULL,
	f_allotratio                   decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_bonustype                    varchar(1)      DEFAULT '1'        NOT NULL,
	c_sharedetail                  varchar(1)      DEFAULT '1'        NOT NULL,
	d_verificationdate             int             DEFAULT 0          NOT NULL,
	d_lastverificationdate         int             DEFAULT 0          NOT NULL,
	d_lastsubdate                  int             DEFAULT 0          NOT NULL,
	c_exptzjysetupdata             varchar(1)      DEFAULT ' '        NOT NULL,
	c_changefifo                   varchar(1)      DEFAULT '1'        NOT NULL,
	c_fixeddividway                varchar(1)      DEFAULT ' '        NOT NULL,
	c_autosetupflag                varchar(1)      DEFAULT '1'        NOT NULL,
	f_maxallotasset                decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxallotshares               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxallot                     decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_excessallot                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_extradealtype                varchar(1)      DEFAULT ' '        NOT NULL,
	c_exceedpart                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_maxaddbalance                decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_exceedflag                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_checkshare                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_checknetvalue                varchar(1)      DEFAULT ' '        NOT NULL,
	f_parvalue                     decimal(7,4)    DEFAULT 1.0        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
	c_factcollectresult            varchar(1)      DEFAULT ' '        NOT NULL,
	d_alimitenddate                int             DEFAULT 0          NOT NULL,
	d_contractbegdate              int             DEFAULT 0          NOT NULL,
	d_appenddate                   int             DEFAULT 0          ,
	d_lastmodify                   int             DEFAULT 0          ,
	f_managerratio                 decimal(9,8)    DEFAULT 0.0        NOT NULL,
	f_minasset                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_department                   varchar(2)      DEFAULT ' '        NOT NULL,
	c_nominalhold                  varchar(1)      DEFAULT ' '        NOT NULL,
	l_slimitday                    int             DEFAULT 0          NOT NULL,
	c_ispublishtotalvalue          varchar(1)      DEFAULT '1'        NOT NULL,
	l_periods                      int             DEFAULT 0          NOT NULL,
	c_isexpnotfinished             varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundinfo ON ta_tfundinfo(c_fundcode ASC ,c_tenantid ASC );
CREATE INDEX idx_tfundinfo_fundstatus ON ta_tfundinfo(c_fundstatus ASC ,c_liqbatchno ASC ,c_tenantid ASC );

-- ������ ta_tsalequalify(�����̴�����ϵ��)�ĵ�ǰ��
SELECT 'Create Table ta_tsalequalify-�����̴�����ϵ��...';
DROP TABLE IF EXISTS ta_tsalequalify;
CREATE TABLE ta_tsalequalify
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_issaleflag                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_subtemplatecode              varchar(12)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tsalequalify ON ta_tsalequalify(c_fundcode ASC ,c_agencyno ASC ,c_tenantid ASC );

-- ������ ta_tfundinfoprecision(��Ʒ���ȴ�����ʽ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundinfoprecision-��Ʒ���ȴ�����ʽ��...';
DROP TABLE IF EXISTS ta_tfundinfoprecision;
CREATE TABLE ta_tfundinfoprecision
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_farecltprecision             varchar(1)      DEFAULT ' '        NOT NULL,
	c_balanceprecision             varchar(1)      DEFAULT ' '        NOT NULL,
	c_shareprecision               varchar(1)      DEFAULT ' '        NOT NULL,
	c_bonusprecision               varchar(1)      DEFAULT ' '        NOT NULL,
	c_interestprecision            varchar(1)      DEFAULT ' '        NOT NULL,
	c_assetprecision               varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundinfoprecision ON ta_tfundinfoprecision(c_fundcode ASC ,c_tenantid ASC );

-- ������ ta_tshareclass(��Ʒ�ּ���Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tshareclass-��Ʒ�ּ���Ϣ��...';
DROP TABLE IF EXISTS ta_tshareclass;
CREATE TABLE ta_tshareclass
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_shareclass                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_classname                    varchar(40)     DEFAULT ' '        NOT NULL,
	f_minshare                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_gradefund                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_classtype                    varchar(1)      DEFAULT ' '        NOT NULL,
	l_minday                       int             DEFAULT 0          NOT NULL,
	l_maxday                       int             DEFAULT 0          NOT NULL,
	c_mergeaccountmode             varchar(1)      DEFAULT ' '        NOT NULL,
	c_expkjmerger                  varchar(1)      DEFAULT ' '        NOT NULL,
	f_maxshare                     decimal(16,2)   DEFAULT 99999999999999.00 NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tshareclass ON ta_tshareclass(c_fundcode ASC ,c_shareclass ASC ,c_tenantid DESC );

-- ������ ta_tfundtrustee(�й�����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundtrustee-�й�����Ϣ��...';
DROP TABLE IF EXISTS ta_tfundtrustee;
CREATE TABLE ta_tfundtrustee
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_trusteename                  varchar(40)     DEFAULT ' '        NOT NULL,
	c_iversion                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_format                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_norexpnoliqdata              varchar(1)      DEFAULT ' '        NOT NULL,
	c_t5ismultimgr                 varchar(1)      DEFAULT '0'        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundtrustee ON ta_tfundtrustee(c_trusteecode ASC ,c_tenantid ASC );

-- ������ ta_tfarebelong(���÷ֳɱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tfarebelong-���÷ֳɱ�...';
DROP TABLE IF EXISTS ta_tfarebelong;
CREATE TABLE ta_tfarebelong
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_faretype                     varchar(1)      DEFAULT ' '        NOT NULL,
	f_agencyratio                  decimal(9,8)    DEFAULT 0.0        NOT NULL,
	f_registratio                  decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_othercode                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_belongtype                   varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfarebelong ON ta_tfarebelong(c_fundcode ASC ,c_businflag ASC ,c_agencyno ASC ,c_faretype ASC ,c_othercode ASC ,c_tenantid ASC );

-- ������ ta_tfarezone(���ʶ����)�ĵ�ǰ��
SELECT 'Create Table ta_tfarezone-���ʶ����...';
DROP TABLE IF EXISTS ta_tfarezone;
CREATE TABLE ta_tfarezone
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_faretype                     varchar(1)      DEFAULT ' '        NOT NULL,
	f_minbalance                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxbalance                   decimal(16,2)   DEFAULT 99999999999999.99 NOT NULL,
	l_minpredays                   int             DEFAULT 0          NOT NULL,
	l_maxpredays                   int             DEFAULT 0          NOT NULL,
	l_minhold                      int             DEFAULT 0          NOT NULL,
	l_maxhold                      int             DEFAULT 2000000000 NOT NULL,
	f_ratio                        decimal(9,8)    DEFAULT 0.0        NOT NULL,
	f_minfare                      decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxfare                      decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_othercode                    varchar(12)     DEFAULT '*'        NOT NULL,
	c_othershare                   varchar(1)      DEFAULT '*'        NOT NULL,
	f_leastratio                   decimal(16,4)   DEFAULT 0.0        NOT NULL,
	d_cstartdate                   int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfarezone ON ta_tfarezone(c_fundcode ASC ,c_agencyno ASC ,c_sharetype ASC ,c_businflag ASC ,c_faretype ASC ,f_minbalance ASC ,f_maxbalance ASC ,l_minpredays ASC ,l_maxpredays ASC ,l_minhold ASC ,l_maxhold ASC ,c_othercode ASC ,c_othershare ASC ,d_cstartdate ASC ,c_tenantid ASC );

-- ������ ta_tfundbelongasset(������ʲ�������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundbelongasset-������ʲ�������Ϣ��...';
DROP TABLE IF EXISTS ta_tfundbelongasset;
CREATE TABLE ta_tfundbelongasset
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_othercode                    varchar(12)     DEFAULT ' '        NOT NULL,
	l_minday                       int             DEFAULT 0          NOT NULL,
	l_maxday                       int             DEFAULT 0          NOT NULL,
	f_ratio                        decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundbelongasset ON ta_tfundbelongasset(c_fundcode ASC ,c_businflag ASC ,c_othercode ASC ,l_minday ASC ,l_maxday ASC ,c_tenantid ASC );

-- ������ ta_tfundsetupinfo(���������Ϣ���ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tfundsetupinfo-���������Ϣ���ñ�...';
DROP TABLE IF EXISTS ta_tfundsetupinfo;
CREATE TABLE ta_tfundsetupinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_interesttype                 varchar(1)      DEFAULT ' '        NOT NULL,
	l_intereststartday             int             DEFAULT 0          NOT NULL,
	d_interestenddate              int             DEFAULT 0          NOT NULL,
	d_distributedate               int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundsetupinfo ON ta_tfundsetupinfo(c_fundcode ASC ,c_agencyno ASC ,c_tenantid ASC );

-- ������ ta_tagencyliquidateinfo(������������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tagencyliquidateinfo-������������Ϣ��...';
DROP TABLE IF EXISTS ta_tagencyliquidateinfo;
CREATE TABLE ta_tagencyliquidateinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_fundmethod                   varchar(2)      DEFAULT ' '        NOT NULL,
	l_liquidateallot               int             DEFAULT 0          NOT NULL,
	l_liquidateredeem              int             DEFAULT 0          NOT NULL,
	l_liquidatesub                 int             DEFAULT 0          NOT NULL,
	l_liquidatebonus               int             DEFAULT 0          NOT NULL,
	l_farebankaccono               int             DEFAULT 0          NOT NULL,
	l_liquidatefail                int             DEFAULT 0          NOT NULL,
	l_liquidateend                 int             DEFAULT 0          NOT NULL,
	l_liquidatechange              int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_agencyliquidateinfo ON ta_tagencyliquidateinfo(c_fundcode ASC ,c_agencyno ASC ,c_fundmethod ASC ,c_tenantid ASC );

-- ������ ta_tfundliquidateinfo(����������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundliquidateinfo-����������Ϣ��...';
DROP TABLE IF EXISTS ta_tfundliquidateinfo;
CREATE TABLE ta_tfundliquidateinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_othercode                    varchar(12)     DEFAULT ' '        NOT NULL,
	l_liquidatesub                 int             DEFAULT 0          NOT NULL,
	l_liquidateallot               int             DEFAULT 0          NOT NULL,
	l_liquidateredeem              int             DEFAULT 0          NOT NULL,
	l_liquidatebonus               int             DEFAULT 0          NOT NULL,
	l_liquidatechange              int             DEFAULT 0          NOT NULL,
	l_liquidatechangein            int             DEFAULT 0          NOT NULL,
	l_liquidatefail                int             DEFAULT 0          NOT NULL,
	l_liquidateend                 int             DEFAULT 0          NOT NULL,
	l_liquidatefare                int             DEFAULT 0          NOT NULL,
	c_needflag                     varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_fundliquidateinfo ON ta_tfundliquidateinfo(c_fundcode ASC ,c_agencyno ASC ,c_othercode ASC ,c_needflag ASC ,c_tenantid ASC );

-- ������ ta_ttemplateinfo(ģ����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_ttemplateinfo-ģ����Ϣ��...';
DROP TABLE IF EXISTS ta_ttemplateinfo;
CREATE TABLE ta_ttemplateinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_templatelevel                varchar(1)      DEFAULT ' '        NOT NULL,
	c_templatecode                 varchar(10)     DEFAULT ' '        NOT NULL,
	c_templatename                 varchar(50)     DEFAULT ' '        NOT NULL,
	c_memo                         varchar(60)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_templateinfo ON ta_ttemplateinfo(c_templatecode ASC ,c_tenantid ASC );

-- ������ ta_tsubtemplateinfo(��ģ����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tsubtemplateinfo-��ģ����Ϣ��...';
DROP TABLE IF EXISTS ta_tsubtemplateinfo;
CREATE TABLE ta_tsubtemplateinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_templatecode                 varchar(10)     DEFAULT ' '        NOT NULL,
	c_subtemplatecode              varchar(12)     DEFAULT ' '        NOT NULL,
	c_subtemplatename              varchar(50)     DEFAULT ' '        NOT NULL,
	c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tsubtemplateinfo ON ta_tsubtemplateinfo(c_subtemplatecode ASC ,c_tenantid ASC );
CREATE INDEX idx_tsubtemplateinfo ON ta_tsubtemplateinfo(c_templatecode ASC ,c_tenantid ASC );

-- ������ ta_tsubtemplatepara(��ģ����չ������)�ĵ�ǰ��
SELECT 'Create Table ta_tsubtemplatepara-��ģ����չ������...';
DROP TABLE IF EXISTS ta_tsubtemplatepara;
CREATE TABLE ta_tsubtemplatepara
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT null       ,
	c_subtemplatecode              varchar(12)     DEFAULT ' '        NOT NULL,
	c_paramlevel                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_paramclass                   varchar(20)     DEFAULT ' '        NOT NULL,
	c_paramitem                    varchar(40)     DEFAULT ' '        NOT NULL,
	c_paramvalue                   varchar(255)    DEFAULT ' '        NOT NULL,
	c_paramtype                    varchar(50)     DEFAULT ' '        NOT NULL,
	c_valuebound                   varchar(100)    DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_usermodify                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
	c_cryptflag                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_showclass                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_showsubclass                 varchar(40)     DEFAULT ' '        NOT NULL,
	l_order                        int             DEFAULT 0          NOT NULL,
	c_rules                        varchar(255)    DEFAULT ' '        NOT NULL,
	c_messages                     varchar(255)    DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tsubtemplatepara ON ta_tsubtemplatepara(c_paramitem ASC ,c_fundcode ASC ,c_agencyno ASC ,c_managercode ASC ,c_tacode ASC ,c_subtemplatecode ASC ,c_tenantid ASC );
CREATE INDEX idx_tsubtemplatepara_ta ON ta_tsubtemplatepara(c_tacode ASC ,c_tenantid ASC );
CREATE INDEX idx_tsubtemplatepara_mgr ON ta_tsubtemplatepara(c_managercode ASC ,c_tenantid ASC );
CREATE INDEX idx_tsubtemplatepara_fnd ON ta_tsubtemplatepara(c_fundcode ASC ,c_tenantid ASC );
CREATE INDEX idx_tsubtemplatepara_agc ON ta_tsubtemplatepara(c_agencyno ASC ,c_tenantid ASC );

-- ������ ta_tfundopenday(ר����Ʒ�������ڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tfundopenday-ר����Ʒ�������ڱ�...';
DROP TABLE IF EXISTS ta_tfundopenday;
CREATE TABLE ta_tfundopenday
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	c_openstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_allotmode                    varchar(1)      DEFAULT ' '        NOT NULL,
	d_allotcfmdate                 int             DEFAULT 0          NOT NULL,
	c_redeemmode                   varchar(1)      DEFAULT ' '        NOT NULL,
	d_redeemcfmdate                int             DEFAULT 0          NOT NULL,
	c_pcsbyoldonly                 varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundopenday ON ta_tfundopenday(d_begindate ASC ,c_fundcode ASC ,c_tenantid ASC );
CREATE INDEX idx_tfundopenday_fundcode ON ta_tfundopenday(c_fundcode ASC );

-- ������ ta_totcfarezone(OTCת�÷�����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_totcfarezone-OTCת�÷�����Ϣ��...';
DROP TABLE IF EXISTS ta_totcfarezone;
CREATE TABLE ta_totcfarezone
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_commissiontype               varchar(1)      DEFAULT ' '        NOT NULL,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        NOT NULL,
	c_otcfaretype                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_custtype                     varchar(1)      DEFAULT ' '        NOT NULL,
	f_minbalance                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxbalance                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	l_minhold                      int             DEFAULT 0          NOT NULL,
	l_maxhold                      int             DEFAULT 0          NOT NULL,
	f_ratio                        decimal(9,8)    DEFAULT 0.0        NOT NULL,
	f_minfare                      decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxfare                      decimal(16,2)   DEFAULT 0.0        NOT NULL,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_totcfarezone ON ta_totcfarezone(c_fundcode ASC ,c_sharetype ASC ,c_commissiontype ASC ,c_outbusinflag ASC ,c_otcfaretype ASC ,c_custtype ASC ,f_minbalance ASC ,f_maxbalance ASC ,l_minhold ASC ,l_maxhold ASC ,c_tenantid ASC );

-- ������ ta_totcliqudiate(OTCת������������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_totcliqudiate-OTCת������������Ϣ��...';
DROP TABLE IF EXISTS ta_totcliqudiate;
CREATE TABLE ta_totcliqudiate
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_settlementmode               varchar(1)      DEFAULT ' '        NOT NULL,
	c_commissiontype               varchar(1)      DEFAULT ' '        NOT NULL,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        NOT NULL,
	l_settlementdays               int             DEFAULT 0          NOT NULL,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_totcliqudiate ON ta_totcliqudiate(c_fundcode ASC ,c_sharetype ASC ,c_agencyno ASC ,c_commissiontype ASC ,c_outbusinflag ASC ,c_tenantid ASC );

-- ������ ta_tmpftschema(��������Ʒ������)�ĵ�ǰ��
SELECT 'Create Table ta_tmpftschema-��������Ʒ������...';
DROP TABLE IF EXISTS ta_tmpftschema;
CREATE TABLE ta_tmpftschema
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_excesspurchaselimit          varchar(1)      DEFAULT ' '        NOT NULL,
	c_largeredeemtype              varchar(1)      DEFAULT ' '        NOT NULL,
	c_accountcontroltype           varchar(1)      DEFAULT ' '        NOT NULL,
	c_ordermode                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_isautofundstatus             varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX idx_tmpftschema ON ta_tmpftschema(c_tenantid ASC ,c_tacode ASC ,c_fundcode ASC );

-- ������ ta_tstructuredschema(�ṹ���Ӳ�Ʒ��Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tstructuredschema-�ṹ���Ӳ�Ʒ��Ϣ��...';
DROP TABLE IF EXISTS ta_tstructuredschema;
CREATE TABLE ta_tstructuredschema
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_projectid                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundcodelist                 varchar(100)    DEFAULT ' '        NOT NULL,
	c_structuredtype               varchar(1)      DEFAULT ' '        NOT NULL,
	f_capitalratio                 int             DEFAULT 0          NOT NULL,
	c_calctotalasset               varchar(1)      DEFAULT ' '        NOT NULL,
	c_capitalordertype             varchar(1)      DEFAULT ' '        NOT NULL,
	c_exceedpart                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_standtype                    varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_childproduct ON ta_tstructuredschema(c_tenantid ASC ,c_tacode ASC ,c_fundcodelist ASC );

-- ������ ta_tstructuredproduct(�ṹ����Ʒ������)�ĵ�ǰ��
SELECT 'Create Table ta_tstructuredproduct-�ṹ����Ʒ������...';
DROP TABLE IF EXISTS ta_tstructuredproduct;
CREATE TABLE ta_tstructuredproduct
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_projectid                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_projectname                  varchar(40)     DEFAULT ' '        NOT NULL,
	c_desc                         varchar(255)    DEFAULT ' '        NOT NULL,
	c_raisestatus                  varchar(1)      DEFAULT ' '        NOT NULL,
	d_issueenddate                 int             DEFAULT 0          NOT NULL,
	c_capitalstdfundtype           varchar(1)      DEFAULT ' '        NOT NULL,
	c_needimptotalasset            varchar(1)      DEFAULT ' '        NOT NULL,
	f_minissuebala                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxissuebala                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	l_minaccocount                 int             DEFAULT 0          NOT NULL,
	l_maxaccocount                 int             DEFAULT 0          NOT NULL,
	f_maxallotasset                decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxallotshares               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxallot                     decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_excessallot                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_extradealtype                varchar(1)      DEFAULT ' '        NOT NULL,
	c_exceedpart                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_maxaddbalance                decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxredeemratio               decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_exceedflag                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_recalnetvalue                varchar(1)      DEFAULT ' '        NOT NULL,
	f_reduce                       decimal(7,4)    DEFAULT 0.0        NOT NULL,
	c_ratiocltmethod               varchar(1)      DEFAULT ' '        NOT NULL,
	f_add                          decimal(7,4)    DEFAULT 0.0        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tstructuredproduct ON ta_tstructuredproduct(c_tenantid ASC ,c_projectid ASC );

-- ������ ta_tmpftproduct(�������Ӳ�Ʒ����������)�ĵ�ǰ��
SELECT 'Create Table ta_tmpftproduct-�������Ӳ�Ʒ����������...';
DROP TABLE IF EXISTS ta_tmpftproduct;
CREATE TABLE ta_tmpftproduct
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_gradefund                    varchar(12)     DEFAULT ' '        NOT NULL,
	d_prdbgndate                   int             DEFAULT 0          NOT NULL,
	l_dueweeks                     int             DEFAULT 0          NOT NULL,
	l_duedays                      int             DEFAULT 0          NOT NULL,
	l_duesplitdays                 int             DEFAULT 0          NOT NULL,
	l_dueclosedays                 int             DEFAULT 0          NOT NULL,
	l_remindassertdays             int             DEFAULT 0          NOT NULL,
	l_splitschemadays              int             DEFAULT 0          NOT NULL,
	c_isfixproducts                varchar(1)      DEFAULT ' '        NOT NULL,
	c_firstvestfundcode            varchar(12)     DEFAULT ' '        NOT NULL,
	l_nonfixprdduedate             int             DEFAULT 0          NOT NULL,
	c_noworkdaydealtype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_dealallshareredeem           varchar(1)      DEFAULT ' '        NOT NULL,
	c_splitshareredeem             varchar(1)      DEFAULT ' '        NOT NULL,
	c_addsplitsharetype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
	f_splitnetvalue                decimal(7,4)    DEFAULT 0.0        NOT NULL,
	c_ordermode                    varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX idx_tmpftproduct ON ta_tmpftproduct(c_tenantid ASC ,c_tacode ASC ,c_fundcode ASC ,c_gradefund ASC );

-- ������ ta_tprofitproj(ҵ����ɷ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitproj-ҵ����ɷ�����...';
DROP TABLE IF EXISTS ta_tprofitproj;
CREATE TABLE ta_tprofitproj
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_deductcode                   varchar(6)      DEFAULT ' '        ,
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_istemplate                   varchar(1)      DEFAULT '0'        ,
	c_description                  varchar(2048)   DEFAULT ' '        ,
	c_spefield                     varchar(1024)   DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_deductmode                   varchar(1)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_mfundacco                    varchar(12)     DEFAULT ' '        ,
	c_deductalgo                   varchar(1)      DEFAULT '1'        ,
	c_yeardays                     varchar(1)      DEFAULT '0'        ,
	c_holddays                     varchar(1)      DEFAULT '0'        ,
	c_ratiotype                    varchar(1)      DEFAULT '0'        ,
	c_includefare                  varchar(1)      DEFAULT '0'        ,
	c_referblctype                 varchar(1)      DEFAULT '0'        ,
	c_profitallincome              varchar(1)      DEFAULT '0'        ,
	c_regression                   varchar(1)      DEFAULT '0'        ,
	c_deductmngfare                varchar(1)      DEFAULT '0'        ,
	c_returnfare                   varchar(1)      DEFAULT '0'        ,
	f_maxdeductscale               decimal(5,4)    DEFAULT 0.0        ,
	c_ductdateupdaterule           varchar(1)      DEFAULT '0'        ,
	c_dealflag                     varchar(1)      DEFAULT '0'        ,
	d_dealdate                     int             DEFAULT 0          ,
	d_begindate                    int             DEFAULT 0          ,
	d_enddate                      int             DEFAULT 0          ,
	c_deductname                   varchar(128)    DEFAULT ' '        ,
	c_calratiobytotalnet           varchar(1)      DEFAULT ' '        ,
	c_calcratiominuscapital        varchar(1)      DEFAULT ' '        ,
	f_fixedstandardnet             decimal(7,4)    DEFAULT 0.0        ,
	f_overtotalnav                 decimal(7,4)    DEFAULT 0.0        ,
	c_subsharepftfree              varchar(1)      DEFAULT ' '        ,
	c_mgraccosharesdealtype        varchar(1)      DEFAULT ' '        ,
	c_profitfundcode               varchar(6)      DEFAULT ' '        ,
	c_profitbalancedealtype        varchar(1)      DEFAULT ' '        ,
	c_mtradeacco                   varchar(24)     DEFAULT ' '        ,
	f_firstdeductovernav           decimal(7,4)    DEFAULT 0.0        ,
	c_autodealflag                 varchar(1)      DEFAULT '0'        ,
	c_indexcode                    varchar(20)     DEFAULT ' '        ,
	c_indexratiotozero             varchar(1)      DEFAULT ' '        ,
	c_custincomemode               varchar(1)      DEFAULT ' '        ,
	c_calconly                     varchar(1)      DEFAULT '0'        ,
	c_outfundcode                  varchar(12)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_ttprofitproj ON ta_tprofitproj(c_fundcode ASC ,d_dealdate ASC ,d_begindate ASC ,c_deductmode ASC ,c_calconly ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tprofitproj_bak(ҵ����ɷ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitproj_bak-ҵ����ɷ�����...';
DROP TABLE IF EXISTS ta_tprofitproj_bak;
CREATE TABLE ta_tprofitproj_bak
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_deductcode                   varchar(6)      DEFAULT ' '        ,
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_istemplate                   varchar(1)      DEFAULT '0'        ,
	c_description                  varchar(2048)   DEFAULT ' '        ,
	c_spefield                     varchar(1024)   DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_deductmode                   varchar(1)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_mfundacco                    varchar(12)     DEFAULT ' '        ,
	c_deductalgo                   varchar(1)      DEFAULT '1'        ,
	c_yeardays                     varchar(1)      DEFAULT '0'        ,
	c_holddays                     varchar(1)      DEFAULT '0'        ,
	c_ratiotype                    varchar(1)      DEFAULT '0'        ,
	c_includefare                  varchar(1)      DEFAULT '0'        ,
	c_referblctype                 varchar(1)      DEFAULT '0'        ,
	c_profitallincome              varchar(1)      DEFAULT '0'        ,
	c_regression                   varchar(1)      DEFAULT '0'        ,
	c_deductmngfare                varchar(1)      DEFAULT '0'        ,
	c_returnfare                   varchar(1)      DEFAULT '0'        ,
	f_maxdeductscale               decimal(5,4)    DEFAULT 0.0        ,
	c_ductdateupdaterule           varchar(1)      DEFAULT '0'        ,
	c_dealflag                     varchar(1)      DEFAULT '0'        ,
	d_dealdate                     int             DEFAULT 0          ,
	d_begindate                    int             DEFAULT 0          ,
	d_enddate                      int             DEFAULT 0          ,
	c_deductname                   varchar(128)    DEFAULT ' '        ,
	c_calratiobytotalnet           varchar(1)      DEFAULT ' '        ,
	c_calcratiominuscapital        varchar(1)      DEFAULT ' '        ,
	f_fixedstandardnet             decimal(7,4)    DEFAULT 0.0        ,
	f_overtotalnav                 decimal(7,4)    DEFAULT 0.0        ,
	c_subsharepftfree              varchar(1)      DEFAULT ' '        ,
	c_mgraccosharesdealtype        varchar(1)      DEFAULT ' '        ,
	c_profitfundcode               varchar(6)      DEFAULT ' '        ,
	c_profitbalancedealtype        varchar(1)      DEFAULT ' '        ,
	c_mtradeacco                   varchar(24)     DEFAULT ' '        ,
	f_firstdeductovernav           decimal(7,4)    DEFAULT 0.0        ,
	c_autodealflag                 varchar(1)      DEFAULT '0'        ,
	c_indexcode                    varchar(20)     DEFAULT ' '        ,
	c_indexratiotozero             varchar(1)      DEFAULT ' '        ,
	c_custincomemode               varchar(1)      DEFAULT ' '        ,
	c_calconly                     varchar(1)      DEFAULT '0'        ,
	c_outfundcode                  varchar(12)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_ttprofitproj ON ta_tprofitproj_bak(c_fundcode ASC ,d_dealdate ASC ,d_begindate ASC ,c_deductmode ASC ,c_calconly ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tprofitzone(ҵ����������)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitzone-ҵ����������...';
DROP TABLE IF EXISTS ta_tprofitzone;
CREATE TABLE ta_tprofitzone
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_deductsettype                varchar(1)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_custtype                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	f_minbalance                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxbalance                   decimal(16,2)   DEFAULT 999999999999.99 NOT NULL,
	l_minhold                      int             DEFAULT 0          NOT NULL,
	l_maxhold                      int             DEFAULT 9999       NOT NULL,
	f_minratio                     decimal(16,8)   DEFAULT 0.0        NOT NULL,
	f_maxratio                     decimal(16,8)   DEFAULT 99999999.99999999 NOT NULL,
	f_scale                        decimal(5,4)    DEFAULT 0.0        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	c_deductmode                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_dynamicflag                  varchar(1)      DEFAULT '0'        NOT NULL,
	f_minmultiple                  decimal(16,8)   DEFAULT 0.0        NOT NULL,
	f_maxmultiple                  decimal(16,8)   DEFAULT 99999999.99999999 NOT NULL,
	f_mindynamic                   decimal(16,8)   DEFAULT 0.0        NOT NULL,
	f_maxdynamic                   decimal(16,8)   DEFAULT 99999999.99999999 NOT NULL,
PRIMARY KEY(l_rowid)
);

-- ������ ta_tcityno(���б����)�ĵ�ǰ��
SELECT 'Create Table ta_tcityno-���б����...';
DROP TABLE IF EXISTS ta_tcityno;
CREATE TABLE ta_tcityno
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_cityno                       varchar(4)      DEFAULT ' '        NOT NULL,
	c_cityname                     varchar(16)     DEFAULT ' '        NOT NULL,
	c_province                     varchar(6)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tcityno ON ta_tcityno(c_cityno ASC ,c_tenantid ASC );

-- ������ ta_tagencyimpbatchschema(���������뵼�����η�����)�ĵ�ǰ��
SELECT 'Create Table ta_tagencyimpbatchschema-���������뵼�����η�����...';
DROP TABLE IF EXISTS ta_tagencyimpbatchschema;
CREATE TABLE ta_tagencyimpbatchschema
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_agencyexpbatchschema ON ta_tagencyimpbatchschema(c_agencyno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tfundenddeducttmp(����ҵ�����ͳ����ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundenddeducttmp-����ҵ�����ͳ����ʱ��...';
DROP TABLE IF EXISTS ta_tfundenddeducttmp;
CREATE TABLE ta_tfundenddeducttmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	f_fundendtotalprofit           decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_databaseno, c_tacode, c_tenantid)
);

-- ������ ta_tpriandsubfundschema(���ӻ��𷽰���)�ĵ�ǰ��
SELECT 'Create Table ta_tpriandsubfundschema-���ӻ��𷽰���...';
DROP TABLE IF EXISTS ta_tpriandsubfundschema;
CREATE TABLE ta_tpriandsubfundschema
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_subfundcode                  varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_dealbusintype                varchar(128)    DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tpriandsubfundscheme ON ta_tpriandsubfundschema(c_subfundcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tsubfundfare(�ӻ���̶����ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tsubfundfare-�ӻ���̶����ñ�...';
DROP TABLE IF EXISTS ta_tsubfundfare;
CREATE TABLE ta_tsubfundfare
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	f_subfare                      decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_status                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, d_cdate, c_tacode, c_tenantid)
);

-- ������ ta_tsubfundstat(�ӻ�����ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tsubfundstat-�ӻ�����ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tsubfundstat;
CREATE TABLE ta_tsubfundstat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_subfundcode                  varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	f_balance                      decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_shares                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(d_cdate, c_subfundcode, c_fundcode, c_fundacco, c_netno, c_agencyno, c_tradeacco, c_businflag, c_databaseno, c_tacode, c_tenantid)
);

-- ������ ta_tbreakcontractrdmrate(�������Ʋ�ƷΥԼ�˳������ʱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tbreakcontractrdmrate-�������Ʋ�ƷΥԼ�˳������ʱ�...';
DROP TABLE IF EXISTS ta_tbreakcontractrdmrate;
CREATE TABLE ta_tbreakcontractrdmrate
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	l_minhold                      int             DEFAULT 0          NOT NULL,
	l_maxhold                      int             DEFAULT 0          NOT NULL,
	c_interesttype                 varchar(1)      DEFAULT ' '        NOT NULL,
	f_ratio                        decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uindex_breakcontractrdm ON ta_tbreakcontractrdmrate(c_tenantid ASC ,c_tacode ASC ,c_fundcode ASC ,l_minhold ASC );

-- ������ ta_tfundopendayrule(ר����Ʒ�������ڹ����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundopendayrule-ר����Ʒ�������ڹ����...';
DROP TABLE IF EXISTS ta_tfundopendayrule;
CREATE TABLE ta_tfundopendayrule
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_openstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_cycletype                    varchar(1)      DEFAULT ' '        NOT NULL,
	l_days                         varchar(100)    DEFAULT ' '        NOT NULL,
	c_allotmode                    varchar(1)      DEFAULT ' '        NOT NULL,
	l_allotdays                    int             DEFAULT 0          NOT NULL,
	c_redeemmode                   varchar(1)      DEFAULT ' '        NOT NULL,
	l_redeemdays                   int             DEFAULT 0          NOT NULL,
	c_calopendaytype               varchar(1)      DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	c_restdaydealtype              varchar(1)      DEFAULT ' '        NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	l_mweek                        int             DEFAULT 0          NOT NULL,
	l_months                       varchar(100)    DEFAULT ' '        NOT NULL,
	l_weekn                        varchar(100)    DEFAULT ' '        NOT NULL,
	l_offset                       int             DEFAULT 0          NOT NULL,
	c_endincomedealtype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_isinvetrdm                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_getincometype                varchar(1)      DEFAULT ' '        NOT NULL,
	f_totalincome                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_calratiotype                 varchar(1)      DEFAULT ' '        NOT NULL,
	f_yearratio                    decimal(16,8)   DEFAULT 0.0        NOT NULL,
	c_yeardays                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_endsharedealtype             varchar(1)      DEFAULT ' '        NOT NULL,
	c_rollfund                     varchar(1)      DEFAULT ' '        NOT NULL,
	d_lastenddate                  int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundopendayrule ON ta_tfundopendayrule(c_tenantid ASC ,c_fundcode ASC ,c_openstatus ASC ,c_cycletype ASC ,d_begindate ASC ,d_enddate ASC );

-- ������ ta_vfundopendayrule(ר����Ʒ�������ڹ���չ����)�ĵ�ǰ��
SELECT 'Create Table ta_vfundopendayrule-ר����Ʒ�������ڹ���չ����...';
DROP TABLE IF EXISTS ta_vfundopendayrule;
CREATE TABLE ta_vfundopendayrule
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_openstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_cycletype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_allotmode                    varchar(1)      DEFAULT ' '        NOT NULL,
	l_allotdays                    int             DEFAULT 0          NOT NULL,
	l_redeemdays                   int             DEFAULT 0          NOT NULL,
	c_redeemmode                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_calopendaytype               varchar(1)      DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	c_restdaydealtype              varchar(1)      DEFAULT ' '        NOT NULL,
	l_oridays                      varchar(100)    DEFAULT ' '        NOT NULL,
	l_days                         varchar(100)    DEFAULT ' '        NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	l_mweek                        int             DEFAULT 0          NOT NULL,
	l_oriweekn                     varchar(100)    DEFAULT ' '        NOT NULL,
	l_weekn                        varchar(100)    DEFAULT ' '        NOT NULL,
	l_offset                       int             DEFAULT 0          NOT NULL,
	l_orimonths                    varchar(100)    DEFAULT ' '        NOT NULL,
	l_months                       varchar(100)    DEFAULT ' '        NOT NULL
);

-- ������ ta_vfundopendayrule_tmp(ר����Ʒ�������ڹ���չ����ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_vfundopendayrule_tmp-ר����Ʒ�������ڹ���չ����ʱ��...';
DROP TABLE IF EXISTS ta_vfundopendayrule_tmp;
CREATE TABLE ta_vfundopendayrule_tmp
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_openstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_cycletype                    varchar(1)      DEFAULT ' '        NOT NULL,
	l_days                         varchar(100)    DEFAULT ' '        NOT NULL,
	c_allotmode                    varchar(1)      DEFAULT ' '        NOT NULL,
	l_allotdays                    int             DEFAULT 0          NOT NULL,
	c_redeemmode                   varchar(1)      DEFAULT ' '        NOT NULL,
	l_redeemdays                   int             DEFAULT 0          NOT NULL,
	c_calopendaytype               varchar(1)      DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	c_restdaydealtype              varchar(1)      DEFAULT ' '        NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	l_mweek                        int             DEFAULT 0          NOT NULL,
	l_months                       varchar(100)    DEFAULT ' '        NOT NULL,
	l_weekn                        varchar(100)    DEFAULT ' '        NOT NULL,
	l_offset                       int             DEFAULT 0          NOT NULL,
	c_endincomedealtype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_isinvetrdm                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_getincometype                varchar(1)      DEFAULT ' '        NOT NULL,
	f_totalincome                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_calratiotype                 varchar(1)      DEFAULT ' '        NOT NULL,
	f_yearratio                    decimal(16,8)   DEFAULT 0.0        NOT NULL,
	c_yeardays                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_endsharedealtype             varchar(1)      DEFAULT ' '        NOT NULL,
	c_rollfund                     varchar(1)      DEFAULT ' '        NOT NULL,
	d_lastenddate                  int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);

-- ������ ta_tfundopenday_tmp(ר����Ʒ����������ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundopenday_tmp-ר����Ʒ����������ʱ��...';
DROP TABLE IF EXISTS ta_tfundopenday_tmp;
CREATE TABLE ta_tfundopenday_tmp
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	username                       varchar(20)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	c_openstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_allotmode                    varchar(1)      DEFAULT ' '        NOT NULL,
	d_allotcfmdate                 int             DEFAULT 0          NOT NULL,
	c_redeemmode                   varchar(1)      DEFAULT ' '        NOT NULL,
	d_redeemcfmdate                int             DEFAULT 0          NOT NULL,
	c_pcsbyoldonly                 varchar(1)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundopenday_tmp ON ta_tfundopenday_tmp(username ASC ,c_tenantid ASC ,c_fundcode ASC ,d_begindate ASC );

-- ������ ta_tnumber_tmp(���ָ�����ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tnumber_tmp-���ָ�����ʱ��...';
DROP TABLE IF EXISTS ta_tnumber_tmp;
CREATE TABLE ta_tnumber_tmp
(
	l_day                          varchar(3)      DEFAULT ' '        NOT NULL
);

-- ������ ta_tprotectinfo(�������𷽰���)�ĵ�ǰ��
SELECT 'Create Table ta_tprotectinfo-�������𷽰���...';
DROP TABLE IF EXISTS ta_tprotectinfo;
CREATE TABLE ta_tprotectinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	l_periods                      int             DEFAULT 0          NOT NULL,
	c_protcontext                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_dealtype                     varchar(1)      DEFAULT ' '        NOT NULL,
	d_protstartdate                int             DEFAULT 0          NOT NULL,
	d_protenddate                  int             DEFAULT 0          NOT NULL,
	d_interimstartdate             int             DEFAULT 0          NOT NULL,
	d_interimenddate               int             DEFAULT 0          NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	d_senddate                     int             DEFAULT 0          NOT NULL,
	d_splitdate                    int             DEFAULT 0          NOT NULL,
	c_caltype                      varchar(1)      DEFAULT ' '        NOT NULL,
	c_sgfundcode                   varchar(12)     DEFAULT ' '        NOT NULL,
	f_pronetvalue                  decimal(7,4)    DEFAULT 0.0        NOT NULL,
	c_nextcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_fareprotect                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_interestprotect              varchar(1)      DEFAULT ' '        NOT NULL,
	c_splitflag                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_nextevennetvalue             varchar(1)      DEFAULT ' '        NOT NULL,
	c_farereducetype               varchar(1)      DEFAULT ' '        NOT NULL,
	c_takecompensation             varchar(1)      DEFAULT ' '        NOT NULL,
	c_enddealflag                  varchar(1)      DEFAULT '0'        NOT NULL,
	c_nextdealflag                 varchar(1)      DEFAULT '0'        NOT NULL,
	d_investsenddate               int             DEFAULT 0          NOT NULL,
	c_protbalaincludebackfare      varchar(1)      DEFAULT ' '        NOT NULL,
	c_noprotectsharechgfare        varchar(1)      DEFAULT ' '        NOT NULL,
	d_endpaydate                   int             DEFAULT 0          NOT NULL,
	c_corpusallowbuy               varchar(1)      DEFAULT ' '        NOT NULL,
	c_corpusendfunddate            varchar(1)      DEFAULT ' '        NOT NULL,
	l_protectredeemfreedays        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE INDEX idx_protecinfo_fd_per ON ta_tprotectinfo(c_fundcode ASC ,l_periods ASC ,c_tenantid ASC );

-- ������ ta_tprotectendset(���������������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tprotectendset-���������������ñ�...';
DROP TABLE IF EXISTS ta_tprotectendset;
CREATE TABLE ta_tprotectendset
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	d_registdate                   int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX unidx_protectendset_fd_bd ON ta_tprotectendset(c_fundcode ASC ,d_begindate ASC ,c_tenantid ASC );

-- ������ ta_tindexinfo(ָ����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tindexinfo-ָ����Ϣ��...';
DROP TABLE IF EXISTS ta_tindexinfo;
CREATE TABLE ta_tindexinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_indexcode                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_indexname                    varchar(100)    DEFAULT ' '        NOT NULL,
	c_impflag                      varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_indexinfo ON ta_tindexinfo(c_indexcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tcycleproduct(�������Ʋ�Ʒ��)�ĵ�ǰ��
SELECT 'Create Table ta_tcycleproduct-�������Ʋ�Ʒ��...';
DROP TABLE IF EXISTS ta_tcycleproduct;
CREATE TABLE ta_tcycleproduct
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_productid                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_productname                  varchar(100)    DEFAULT ' '        NOT NULL,
	c_ismergeaccount               varchar(1)      DEFAULT ' '        NOT NULL,
	c_mergeaccountmode             varchar(1)      DEFAULT ' '        NOT NULL,
	c_ismergeinvest                varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tcycleproduct ON ta_tcycleproduct(c_productid ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tsubcycleproduct(���������Ӳ�Ʒ��)�ĵ�ǰ��
SELECT 'Create Table ta_tsubcycleproduct-���������Ӳ�Ʒ��...';
DROP TABLE IF EXISTS ta_tsubcycleproduct;
CREATE TABLE ta_tsubcycleproduct
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_productid                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_outfundcode                  varchar(12)     DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	d_startcalholdday              int             DEFAULT 0          NOT NULL,
	d_shareenddate                 int             DEFAULT 0          NOT NULL,
	c_iscalcinterest               varchar(1)      DEFAULT ' '        NOT NULL,
	l_begininterestdays            int             DEFAULT 0          NOT NULL,
	d_interestenddate              int             DEFAULT 0          NOT NULL,
	c_interesttype                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_yeardaystype                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_calratiotype                 varchar(1)      DEFAULT ' '        NOT NULL,
	f_yearratio                    decimal(16,8)   DEFAULT 0.0        NOT NULL,
	c_getincometype                varchar(1)      DEFAULT ' '        NOT NULL,
	f_totalincome                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_endsharedealtype             varchar(1)      DEFAULT ' '        NOT NULL,
	c_forcerdmmethod               varchar(1)      DEFAULT ' '        NOT NULL,
	c_nextcodeselecttype           varchar(1)      DEFAULT ' '        NOT NULL,
	c_nextcyclecode                varchar(20)     DEFAULT ' '        NOT NULL,
	c_endincomedealtype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_profitdatetype               varchar(1)      DEFAULT ' '        NOT NULL,
	c_dealdeducttype               varchar(1)      DEFAULT ' '        NOT NULL,
	c_mfundacco                    varchar(12)     DEFAULT ' '        NOT NULL,
	f_divratio                     decimal(5,4)    DEFAULT 0.0        NOT NULL,
	c_status                       varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tsubcycleproduct ON ta_tsubcycleproduct(c_fundcode ASC ,d_begindate ASC ,d_enddate ASC ,c_productid ASC ,c_tacode ASC ,c_tenantid ASC );
CREATE UNIQUE INDEX uidx_tsubcycleoutfundcode ON ta_tsubcycleproduct(c_outfundcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tratiozone(�������������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tratiozone-�������������ñ�...';
DROP TABLE IF EXISTS ta_tratiozone;
CREATE TABLE ta_tratiozone
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	f_minbalance                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_maxbalance                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	l_minhold                      int             DEFAULT 0          NOT NULL,
	l_maxhold                      int             DEFAULT 0          NOT NULL,
	f_expectratio                  decimal(9,8)    DEFAULT 0.0        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tratiozone ON ta_tratiozone(c_fundcode ASC ,d_begindate ASC ,d_enddate ASC ,f_minbalance ASC ,f_maxbalance ASC ,l_minhold ASC ,l_maxhold ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tmonthsalaryscheme(����֧����Ʒ������)�ĵ�ǰ��
SELECT 'Create Table ta_tmonthsalaryscheme-����֧����Ʒ������...';
DROP TABLE IF EXISTS ta_tmonthsalaryscheme;
CREATE TABLE ta_tmonthsalaryscheme
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_paystartday                  int             DEFAULT 0          NOT NULL,
	c_payfrequency                 varchar(1)      DEFAULT ' '        NOT NULL,
	l_payrdmmonth                  int             DEFAULT 0          NOT NULL,
	l_payrdmday                    int             DEFAULT 0          NOT NULL,
	l_fundsplitday                 int             DEFAULT 0          NOT NULL,
	f_payyearratio                 decimal(5,4)    DEFAULT 0.0        NOT NULL,
	l_payholdday                   int             DEFAULT 0          NOT NULL,
	f_payminshare                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_payrdmfare                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_payselect                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_payrdmalgorithm              varchar(1)      DEFAULT ' '        NOT NULL,
	c_paystatus                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_sharedetail                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_defaultcycle                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_isopendaypay                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_opendayrdmfare               varchar(1)      DEFAULT ' '        NOT NULL,
	c_opensettype                  varchar(1)      DEFAULT ' '        NOT NULL,
	f_runcycle                     int             DEFAULT 0          NOT NULL,
	f_openday                      int             DEFAULT 0          NOT NULL,
	c_limitopenday                 varchar(1)      DEFAULT ' '        NOT NULL,
	d_startday                     int             DEFAULT 0          NOT NULL,
	c_extendlimitday               varchar(1)      DEFAULT ' '        NOT NULL,
	c_nextstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaystatus                  varchar(1)      DEFAULT ' '        NOT NULL,
	d_lastpayday                   int             DEFAULT 0          NOT NULL,
	d_splitdate                    int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_monsalary ON ta_tmonthsalaryscheme(c_fundcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tmonthsalaryopenday(����֧�����ɿ��������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tmonthsalaryopenday-����֧�����ɿ��������ñ�...';
DROP TABLE IF EXISTS ta_tmonthsalaryopenday;
CREATE TABLE ta_tmonthsalaryopenday
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_startopenday                 int             DEFAULT 0          NOT NULL,
	d_endopenday                   int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_monthsalaryopenday ON ta_tmonthsalaryopenday(c_fundcode ASC ,d_startopenday ASC ,d_endopenday ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tprofitschema(�ֺ췽����)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitschema-�ֺ췽����...';
DROP TABLE IF EXISTS ta_tprofitschema;
CREATE TABLE ta_tprofitschema
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_schemacode                   varchar(20)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_registerdate                 int             DEFAULT 0          NOT NULL,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
	d_distributedate               int             DEFAULT 0          NOT NULL,
	d_reinvestdate                 int             DEFAULT 0          NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
	c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_profitratio                  decimal(5,4)    DEFAULT 0.0        NOT NULL,
	c_frzbalanceflag               varchar(1)      DEFAULT ' '        NOT NULL,
	c_frzsharesflag                varchar(1)      DEFAULT ' '        NOT NULL,
	c_frzforcereinvest             varchar(1)      DEFAULT ' '        NOT NULL,
	c_bonustype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_bonusmode                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_autodealflag                 varchar(1)      DEFAULT '1'        NOT NULL,
	c_frzbonussharedtl             varchar(1)      DEFAULT '0'        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tprofitschema_code ON ta_tprofitschema(c_schemacode ASC ,c_tenantid ASC ,c_tacode ASC );
CREATE INDEX idx_tprofitschema_fnd ON ta_tprofitschema(c_fundcode ASC ,c_tenantid ASC );
CREATE UNIQUE INDEX uidx_tprofitschema_date ON ta_tprofitschema(d_registerdate ASC ,c_fundcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tprofitschema_bak(�ֺ췽����)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitschema_bak-�ֺ췽����...';
DROP TABLE IF EXISTS ta_tprofitschema_bak;
CREATE TABLE ta_tprofitschema_bak
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_schemacode                   varchar(20)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_registerdate                 int             DEFAULT 0          NOT NULL,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
	d_distributedate               int             DEFAULT 0          NOT NULL,
	d_reinvestdate                 int             DEFAULT 0          NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
	c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_profitratio                  decimal(5,4)    DEFAULT 0.0        NOT NULL,
	c_frzbalanceflag               varchar(1)      DEFAULT ' '        NOT NULL,
	c_frzsharesflag                varchar(1)      DEFAULT ' '        NOT NULL,
	c_frzforcereinvest             varchar(1)      DEFAULT ' '        NOT NULL,
	c_bonustype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_bonusmode                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_autodealflag                 varchar(1)      DEFAULT '1'        NOT NULL,
	c_frzbonussharedtl             varchar(1)      DEFAULT '0'        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tprofitschema_code ON ta_tprofitschema_bak(c_schemacode ASC ,c_tenantid ASC ,c_tacode ASC );
CREATE INDEX idx_tprofitschema_fnd ON ta_tprofitschema_bak(c_fundcode ASC ,c_tenantid ASC );
CREATE UNIQUE INDEX uidx_tprofitschema_date ON ta_tprofitschema_bak(d_registerdate ASC ,c_fundcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tfundstatusday(����״̬��ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundstatusday-����״̬��ˮ��...';
DROP TABLE IF EXISTS ta_tfundstatusday;
CREATE TABLE ta_tfundstatusday
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_fundstatusdate               int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_todaystatus                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaypcsstatus               varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaychgstatus               varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaytrfstatus               varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaysplitstatus             varchar(1)      DEFAULT ' '        NOT NULL,
	c_checkpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundstatusday_fnd ON ta_tfundstatusday(c_fundcode ASC ,d_fundstatusdate ASC ,c_tenantid ASC );
CREATE INDEX idx_tfundstatusday_dcdate ON ta_tfundstatusday(c_fundcode ASC ,d_cdate ASC ,c_tenantid ASC );

-- ������ ta_tfundstatusday_chk(����״̬��ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundstatusday_chk-����״̬��ˮ��...';
DROP TABLE IF EXISTS ta_tfundstatusday_chk;
CREATE TABLE ta_tfundstatusday_chk
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_fundstatusdate               int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_todaystatus                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaypcsstatus               varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaychgstatus               varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaytrfstatus               varchar(1)      DEFAULT ' '        NOT NULL,
	c_todaysplitstatus             varchar(1)      DEFAULT ' '        NOT NULL,
	c_checkpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundstatusday_fnd ON ta_tfundstatusday_chk(c_fundcode ASC ,d_fundstatusdate ASC ,c_tenantid ASC );
CREATE INDEX idx_tfundstatusday_dcdate ON ta_tfundstatusday_chk(c_fundcode ASC ,d_cdate ASC ,c_tenantid ASC );

-- ������ ta_tnetvalueday(��Ʒ��ֵ��ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tnetvalueday-��Ʒ��ֵ��ˮ��...';
DROP TABLE IF EXISTS ta_tnetvalueday;
CREATE TABLE ta_tnetvalueday
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_netvaluedate                 int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	f_netvalue                     decimal(7,4)    DEFAULT 1.0        NOT NULL,
	f_lasttotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_lasttotalasset               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_asucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_rsucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_vastflag                     varchar(1)      DEFAULT ' '        NOT NULL,
	f_encashratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
	f_changeratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_excessflag                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_subscriberatio               decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_inputpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
	c_checkpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
	f_fundtotalincome              decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_incomeunit                   decimal(10,5)   DEFAULT 0.0        NOT NULL,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        NOT NULL,
	f_incomeratio                  decimal(9,6)    DEFAULT 0.0        NOT NULL,
	f_servicefare                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_assign                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_unassign                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_growthrate                   decimal(9,8)    DEFAULT 0.0        NOT NULL,
	f_managefare                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	d_exportdate                   int             DEFAULT 0          NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_flowcode                     varchar(3)      DEFAULT ' '        NOT NULL,
	f_lastunassign                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_structuredratio              decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
	d_filedate                     int             DEFAULT 0          NOT NULL,
	f_filetotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_structuredtotalasset         decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_offsetincome                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_exchangerate                 decimal(7,4)    DEFAULT 0.0        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE INDEX uidx_tnetvalueday ON ta_tnetvalueday(c_fundcode ASC ,d_netvaluedate ASC ,c_tenantid ASC );
CREATE UNIQUE INDEX idx_tnetvalueday ON ta_tnetvalueday(c_fundcode ASC ,d_cdate DESC ,c_tenantid ASC );
CREATE INDEX idx_tnetvalueday_dcate ON ta_tnetvalueday(d_cdate ASC );

-- ������ ta_tnetvalueday_chk(��Ʒ��ֵ��ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tnetvalueday_chk-��Ʒ��ֵ��ˮ��...';
DROP TABLE IF EXISTS ta_tnetvalueday_chk;
CREATE TABLE ta_tnetvalueday_chk
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_netvaluedate                 int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	f_netvalue                     decimal(7,4)    DEFAULT 1.0        NOT NULL,
	f_lasttotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_lasttotalasset               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_asucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_rsucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_vastflag                     varchar(1)      DEFAULT ' '        NOT NULL,
	f_encashratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
	f_changeratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_excessflag                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_subscriberatio               decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_inputpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
	c_checkpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
	f_fundtotalincome              decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_incomeunit                   decimal(10,5)   DEFAULT 0.0        NOT NULL,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        NOT NULL,
	f_incomeratio                  decimal(9,6)    DEFAULT 0.0        NOT NULL,
	f_servicefare                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_assign                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_unassign                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_growthrate                   decimal(9,8)    DEFAULT 0.0        NOT NULL,
	f_managefare                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	d_exportdate                   int             DEFAULT 0          NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_flowcode                     varchar(3)      DEFAULT ' '        NOT NULL,
	f_lastunassign                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_structuredratio              decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
	d_filedate                     int             DEFAULT 0          NOT NULL,
	f_filetotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_structuredtotalasset         decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_offsetincome                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_exchangerate                 decimal(7,4)    DEFAULT 0.0        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE INDEX uidx_tnetvalueday ON ta_tnetvalueday_chk(c_fundcode ASC ,d_netvaluedate ASC ,c_tenantid ASC );
CREATE UNIQUE INDEX idx_tnetvalueday ON ta_tnetvalueday_chk(c_fundcode ASC ,d_cdate DESC ,c_tenantid ASC );
CREATE INDEX idx_tnetvalueday_dcate ON ta_tnetvalueday_chk(d_cdate ASC );

-- ������ ta_tnetvalueday_tmp(��Ʒ��ֵ��ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tnetvalueday_tmp-��Ʒ��ֵ��ˮ��...';
DROP TABLE IF EXISTS ta_tnetvalueday_tmp;
CREATE TABLE ta_tnetvalueday_tmp
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_netvaluedate                 int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	f_netvalue                     decimal(7,4)    DEFAULT 1.0        NOT NULL,
	f_lasttotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_lasttotalasset               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_asucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_rsucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_vastflag                     varchar(1)      DEFAULT ' '        NOT NULL,
	f_encashratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
	f_changeratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_excessflag                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_subscriberatio               decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_inputpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
	c_checkpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
	f_fundtotalincome              decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_incomeunit                   decimal(10,5)   DEFAULT 0.0        NOT NULL,
	f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        NOT NULL,
	f_incomeratio                  decimal(9,6)    DEFAULT 0.0        NOT NULL,
	f_servicefare                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_assign                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_unassign                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_growthrate                   decimal(9,8)    DEFAULT 0.0        NOT NULL,
	f_managefare                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_protectbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	d_exportdate                   int             DEFAULT 0          NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_flowcode                     varchar(3)      DEFAULT ' '        NOT NULL,
	f_lastunassign                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_structuredratio              decimal(9,8)    DEFAULT 1.0        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
	d_filedate                     int             DEFAULT 0          NOT NULL,
	f_filetotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_structuredtotalasset         decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_offsetincome                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_exchangerate                 decimal(7,4)    DEFAULT 0.0        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE INDEX uidx_tnetvalueday ON ta_tnetvalueday_tmp(c_fundcode ASC ,d_netvaluedate ASC ,c_tenantid ASC );
CREATE UNIQUE INDEX idx_tnetvalueday ON ta_tnetvalueday_tmp(c_fundcode ASC ,d_cdate DESC ,c_tenantid ASC );
CREATE INDEX idx_tnetvalueday_dcate ON ta_tnetvalueday_tmp(d_cdate ASC );

-- ������ ta_tfundstatusschema(����״̬Ԥ�跽����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundstatusschema-����״̬Ԥ�跽����...';
DROP TABLE IF EXISTS ta_tfundstatusschema;
CREATE TABLE ta_tfundstatusschema
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	d_fundstatusdate               int             DEFAULT 0          NOT NULL,
	f_netvalue                     decimal(7,4)    DEFAULT 0.0        NOT NULL,
	d_lastmodify                   int             DEFAULT 0          NOT NULL,
	c_autofundstatusflag           varchar(1)      DEFAULT ' '        NOT NULL,
	c_iscovernetvalue              varchar(1)      DEFAULT '0'        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tfundstatusschema ON ta_tfundstatusschema(c_fundcode ASC ,d_fundstatusdate ASC ,c_tenantid ASC );

-- ������ ta_tbulletin(������Ϣ��ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tbulletin-������Ϣ��ˮ��...';
DROP TABLE IF EXISTS ta_tbulletin;
CREATE TABLE ta_tbulletin
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	l_no                           bigint          DEFAULT 0          NOT NULL,
	d_bulldate                     int             DEFAULT 0          NOT NULL,
	c_bulltype                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_bulltitle                    varchar(255)    DEFAULT ' '        NOT NULL,
	l_bulllength                   int             DEFAULT 0          NOT NULL,
	c_bullcontent                  varchar(4000)   DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_bulletin ON ta_tbulletin(c_fundcode ASC ,d_bulldate ASC ,c_bulltype ASC ,c_tenantid ASC );

-- ������ ta_tfundendproj(��Ʒ���̷�����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundendproj-��Ʒ���̷�����...';
DROP TABLE IF EXISTS ta_tfundendproj;
CREATE TABLE ta_tfundendproj
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundendmode                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_fundendbizflag               varchar(3)      DEFAULT ' '        NOT NULL,
	f_fundendallotbalance          decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_fundendnav                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
	c_fundendprofitflag            varchar(1)      DEFAULT ' '        NOT NULL,
	d_contractenddate              int             DEFAULT 0          NOT NULL,
	f_profittotalnav               decimal(7,4)    DEFAULT 0.0        NOT NULL,
	f_fundendtotalprofit           decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_exportnavdealtype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_fundendtype                  varchar(1)      DEFAULT ' '        NOT NULL,
	f_fundendratio                 decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_needcalallotbalance          varchar(1)      DEFAULT ' '        NOT NULL,
	c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
	d_lastmodify                   int             DEFAULT 0          NOT NULL,
	c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_frozenfundend                varchar(1)      DEFAULT ' '        NOT NULL,
	c_isneeddeal                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_outfundcode                  varchar(12)     DEFAULT ' '        NOT NULL,
	c_sysmkrecordflag              varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_fundendproj ON ta_tfundendproj(c_fundcode ASC ,d_cdate ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tfundendproj_bak(��Ʒ���̷�����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundendproj_bak-��Ʒ���̷�����...';
DROP TABLE IF EXISTS ta_tfundendproj_bak;
CREATE TABLE ta_tfundendproj_bak
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundendmode                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_fundendbizflag               varchar(3)      DEFAULT ' '        NOT NULL,
	f_fundendallotbalance          decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_fundendnav                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
	c_fundendprofitflag            varchar(1)      DEFAULT ' '        NOT NULL,
	d_contractenddate              int             DEFAULT 0          NOT NULL,
	f_profittotalnav               decimal(7,4)    DEFAULT 0.0        NOT NULL,
	f_fundendtotalprofit           decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_exportnavdealtype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_fundendtype                  varchar(1)      DEFAULT ' '        NOT NULL,
	f_fundendratio                 decimal(9,8)    DEFAULT 0.0        NOT NULL,
	c_needcalallotbalance          varchar(1)      DEFAULT ' '        NOT NULL,
	c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
	d_lastmodify                   int             DEFAULT 0          NOT NULL,
	c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_frozenfundend                varchar(1)      DEFAULT ' '        NOT NULL,
	c_isneeddeal                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_outfundcode                  varchar(12)     DEFAULT ' '        NOT NULL,
	c_sysmkrecordflag              varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_fundendproj ON ta_tfundendproj_bak(c_fundcode ASC ,d_cdate ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tsplitschema(��ַ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tsplitschema-��ַ�����...';
DROP TABLE IF EXISTS ta_tsplitschema;
CREATE TABLE ta_tsplitschema
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_splitdate                    int             DEFAULT 0          NOT NULL,
	f_unitsplit                    decimal(12,9)   DEFAULT 0.0        NOT NULL,
	c_splitdealflag                varchar(1)      DEFAULT ' '        NOT NULL,
	f_splitnetvalue                decimal(7,4)    DEFAULT 0.0        NOT NULL,
	c_splittype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_splitfundasset               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_isdealtail                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_splittail                    decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_dealallshareredeem           varchar(1)      DEFAULT ' '        NOT NULL,
	c_splitshareredeem             varchar(1)      DEFAULT ' '        NOT NULL,
	c_addsplitsharetype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
	d_lastmodify                   int             DEFAULT 0          NOT NULL,
	c_splitreason                  varchar(1)      DEFAULT '0'        ,
	c_sysmkrecordflag              varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tsplitschema ON ta_tsplitschema(c_fundcode ASC ,d_splitdate ASC ,c_tenantid ASC );

-- ������ ta_tsplitschema_bak(��ַ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tsplitschema_bak-��ַ�����...';
DROP TABLE IF EXISTS ta_tsplitschema_bak;
CREATE TABLE ta_tsplitschema_bak
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_splitdate                    int             DEFAULT 0          NOT NULL,
	f_unitsplit                    decimal(12,9)   DEFAULT 0.0        NOT NULL,
	c_splitdealflag                varchar(1)      DEFAULT ' '        NOT NULL,
	f_splitnetvalue                decimal(7,4)    DEFAULT 0.0        NOT NULL,
	c_splittype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_splitfundasset               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_isdealtail                   varchar(1)      DEFAULT ' '        NOT NULL,
	f_splittail                    decimal(16,2)   DEFAULT 0.0        NOT NULL,
	c_dealallshareredeem           varchar(1)      DEFAULT ' '        NOT NULL,
	c_splitshareredeem             varchar(1)      DEFAULT ' '        NOT NULL,
	c_addsplitsharetype            varchar(1)      DEFAULT ' '        NOT NULL,
	c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
	d_lastmodify                   int             DEFAULT 0          NOT NULL,
	c_splitreason                  varchar(1)      DEFAULT '0'        ,
	c_sysmkrecordflag              varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_tsplitschema ON ta_tsplitschema_bak(c_fundcode ASC ,d_splitdate ASC ,c_tenantid ASC );

-- ������ ta_tmpftduecalendar(������������������)�ĵ�ǰ��
SELECT 'Create Table ta_tmpftduecalendar-������������������...';
DROP TABLE IF EXISTS ta_tmpftduecalendar;
CREATE TABLE ta_tmpftduecalendar
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_gradefund                    varchar(12)     DEFAULT ' '        NOT NULL,
	d_firstbegindate               int             DEFAULT 0          NOT NULL,
	d_duedate                      int             DEFAULT 0          NOT NULL,
	d_splitschemadate              int             DEFAULT 0          NOT NULL,
	d_splitdate                    int             DEFAULT 0          NOT NULL,
	c_isnormalflag                 varchar(1)      DEFAULT ' '        NOT NULL,
	d_assetshintdate               int             DEFAULT 0          NOT NULL,
	d_fundenddate                  int             DEFAULT 0          NOT NULL,
	d_fundendshcemadate            int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX idx_tmpftduecalendar ON ta_tmpftduecalendar(c_tenantid ASC ,c_tacode ASC ,c_fundcode ASC ,c_gradefund ASC ,d_firstbegindate ASC ,d_duedate ASC );

-- ������ ta_tunprocessedlog(�����ɵ�������ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tunprocessedlog-�����ɵ�������ˮ��...';
DROP TABLE IF EXISTS ta_tunprocessedlog;
CREATE TABLE ta_tunprocessedlog
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_flag                         varchar(1)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL
);
CREATE INDEX idx_tunprocessedlog ON ta_tunprocessedlog(c_tenantid ASC ,c_tacode ASC ,c_fundcode ASC ,c_flag ASC ,d_cdate ASC );

-- ������ ta_tsplitassetsfile(������ʲ������)�ĵ�ǰ��
SELECT 'Create Table ta_tsplitassetsfile-������ʲ������...';
DROP TABLE IF EXISTS ta_tsplitassetsfile;
CREATE TABLE ta_tsplitassetsfile
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_splitdate                    int             DEFAULT 0          NOT NULL,
	f_splitfundasset               decimal(16,2)   DEFAULT 0.0        NOT NULL,
	d_importdate                   int             DEFAULT 0          NOT NULL
);
CREATE UNIQUE INDEX idx_tsplitassetsfile ON ta_tsplitassetsfile(c_tenantid ASC ,c_tacode ASC ,c_fundcode ASC ,d_splitdate ASC );

-- ������ ta_tfundissuefailproj(��Ʒ����ʧ�ܷ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundissuefailproj-��Ʒ����ʧ�ܷ�����...';
DROP TABLE IF EXISTS ta_tfundissuefailproj;
CREATE TABLE ta_tfundissuefailproj
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_tenantid)
);
CREATE INDEX idx_liqbatchno ON ta_tfundissuefailproj(d_cdate ASC ,c_liqbatchno ASC );

-- ������ ta_tfundissuefailproj_bak(��Ʒ����ʧ�ܷ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundissuefailproj_bak-��Ʒ����ʧ�ܷ�����...';
DROP TABLE IF EXISTS ta_tfundissuefailproj_bak;
CREATE TABLE ta_tfundissuefailproj_bak
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_tenantid)
);
CREATE INDEX idx_liqbatchno ON ta_tfundissuefailproj_bak(d_cdate ASC ,c_liqbatchno ASC );

-- ������ ta_tstructureratioshares(����������ȷ�Ϸݶ�)�ĵ�ǰ��
SELECT 'Create Table ta_tstructureratioshares-����������ȷ�Ϸݶ�...';
DROP TABLE IF EXISTS ta_tstructureratioshares;
CREATE TABLE ta_tstructureratioshares
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_projectid                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundcodelist                 varchar(100)    DEFAULT ' '        NOT NULL,
	c_structuredtype               varchar(1)      DEFAULT ' '        NOT NULL,
	f_shares                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
	f_nottarealshares              decimal(16,2)   DEFAULT 0.0        NOT NULL,
PRIMARY KEY(l_rowid)
);

-- ������ ta_tbackfundday(���շѻ���״̬��)�ĵ�ǰ��
SELECT 'Create Table ta_tbackfundday-���շѻ���״̬��...';
DROP TABLE IF EXISTS ta_tbackfundday;
CREATE TABLE ta_tbackfundday
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_begindate                    int             DEFAULT 0          NOT NULL,
	d_enddate                      int             DEFAULT 0          NOT NULL,
	c_todaystatus                  varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE INDEX idx_tbackfundday ON ta_tbackfundday(c_fundcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tindexmarket(ָ�������)�ĵ�ǰ��
SELECT 'Create Table ta_tindexmarket-ָ�������...';
DROP TABLE IF EXISTS ta_tindexmarket;
CREATE TABLE ta_tindexmarket
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_indextype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_indexcode                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_indexname                    varchar(100)    DEFAULT ' '        NOT NULL,
	d_indexdate                    int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	f_indexprice                   decimal(18,5)   DEFAULT 0.0        NOT NULL,
	c_indexmemo                    varchar(100)    DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_indexmarket ON ta_tindexmarket(d_indexdate ASC ,c_indexcode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tindexmarket_tmp(ָ�������)�ĵ�ǰ��
SELECT 'Create Table ta_tindexmarket_tmp-ָ�������...';
DROP TABLE IF EXISTS ta_tindexmarket_tmp;
CREATE TABLE ta_tindexmarket_tmp
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_indextype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_indexcode                    varchar(20)     DEFAULT ' '        NOT NULL,
	c_indexname                    varchar(100)    DEFAULT ' '        NOT NULL,
	d_indexdate                    int             DEFAULT 0          NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	f_indexprice                   decimal(18,5)   DEFAULT 0.0        NOT NULL,
	c_indexmemo                    varchar(100)    DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_indexmarket ON ta_tindexmarket_tmp(d_indexdate ASC ,c_indexcode ASC ,c_tacode ASC ,c_tenantid ASC );

