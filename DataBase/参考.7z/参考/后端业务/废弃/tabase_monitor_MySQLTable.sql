-- -------------------------------------------
-- SQLfile   : tabase_monitor_MySQLTable.sql
-- Notes    : SQL�ű�
-- -------------------------------------------
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                 ��ע 
-- V1.0.5.6     2017-08-15 10:40                                       ���б�ta_tuserevent�������˱��ֶΣ�c_outfundcode����                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.5     2016-09-14 17:27                                       ���б�ta_truleinfo���޸��˱��ֶ����ͣ�c_ruleevent����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.5     2016-08-22 09:49                                       ���б�ta_tflowconfig�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                          
-- V1.0.5.5     2016-07-19 20:25                                       ���б�ta_tbatchdealctl�������˱��ֶΣ�c_maxbatchno�������б�ta_tbatchdealctl�������˱��ֶΣ�c_minbatchno����                                                                                                                                                                                                                                                                                  
-- V1.0.5.5     2017-09-14 15:56                                       ���б�_processinstancedefinition�������˱��ֶΣ�c_longtacode����                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.5     2016-07-30 10:41                                       ��ǰ��ta_tsynctablelog������������ idx_tsynctablelog_cdate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.5     2016-07-30 10:37                                       ��ǰ��ta_tsynctablelog�����������ֶ�˳��Ϊ��c_flowstep,c_tablename,d_cdate,c_fundcode,c_agencyno,c_trusteecode,c_managercode,c_databaseno,c_tacode,c_tenantid����                                                                                                                                                                                                                             
-- V1.0.5.5     2016-08-19 16:27                                       ���б�ta_tuserevent�������˱��ֶΣ�c_autodealflag����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.5     2016-07-23 15:41                                       ��ǰ��ta_tuserevent�����������ֶ�˳������pk_userevent:������������ֶ�˳��Ϊ��c_usereventtype,c_fundcode,d_cdate,c_agencyno,c_trusteecode,c_managercode,c_tacode,c_tenantid����                                                                                                                                                                                                             
-- V1.0.5.5     2016-09-18 10:04                                       ���б�ta_thintinfo�������˱��ֶΣ�c_hintoptmode����                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.5     2016-09-18 10:06                                       ���б�ta_thintlog�������˱��ֶΣ�c_hintoptmode�������б�ta_thintlog�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                           
-- V1.0.5.4     2016-07-18 14:36                                       ���б�ta_tflowinfo�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.4     2016-06-20 11:23                                       ���б�ta_tflowinfo�������˱��ֶΣ�c_contentcode����                                                                                                                                                                                                                                                                                                                                           
-- V1.0.5.4     2016-06-05 11:54                                       ���б�ta_tflowinfo�������˱��ֶΣ�c_fundbackflag�������б�ta_tflowinfo�������˱��ֶΣ�c_agcbackflag�������б�ta_tflowinfo�������˱��ֶΣ�c_mgrbackflag����                                                                                                                                                                                                                                    
-- V1.0.5.4     2016-07-18 14:57                                       ���б�ta_tflowlog�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.4     2016-06-20 11:28                                       ���б�ta_tflowlog�������˱��ֶΣ�c_contentcode����                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.4     2016-06-05 11:52                                       ���б�ta_tflowlog�������˱��ֶΣ�c_fundbackflag�������б�ta_tflowlog�������˱��ֶΣ�c_agcbackflag�������б�ta_tflowlog�������˱��ֶΣ�c_mgrbackflag����                                                                                                                                                                                                                                       
-- V1.0.5.4     2016-06-05 11:52                                       ���б�ta_tflowlog�������˱��ֶΣ�c_fundbackflag�������б�ta_tflowlog�������˱��ֶΣ�c_agcbackflag�������б�ta_tflowlog�������˱��ֶΣ�c_mgrbackflag����                                                                                                                                                                                                                                       
-- V1.0.5.4     2016-07-16 15:09                                       ���б�ta_tbatchdealctl�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.4     2016-05-27 18:48                                       �޸�������uidx_thintlog,�����ֶ��޸�Ϊ��(c_instanceid,d_cdate,c_flowstep,c_flowno,c_hintno,c_tacode,c_tenantid,l_no),��������޸�Ϊ��null,����Ψһ���޸�Ϊ����Ψһ,��������������Ϊ:��������.                                                                                                                                                                                                 
-- V1.0.5.4     2016-05-27 18:38                                       ���б�ta_thintlog�������˱��ֶΣ�l_no����                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.4     2016-06-20 11:16                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.4     2016-06-20 11:21                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.4     2016-06-21 09:04                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.3     2016-05-23 17:22                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-05-17 22:13                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-05-18 16:43                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-06-05 10:21                                       ��ǰ��ta_tbackinstancelist������������ c_instanceid,c_tenanti��;                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-06-05 10:20                                       ���б�ta_tbackinstancelist�������˱��ֶΣ�c_tenantid�������б�ta_tbackinstancelist�������˱��ֶΣ�c_instanceid����                                                                                                                                                                                                                                                                            
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                 ��ע 
-- V1.0.5.2     2017-06-05 13:41                                       ���б�ta_tliquidatetrusteedetail�������˱��ֶΣ�f_interest����                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.2     2017-06-22 17:36                                       ���б�ta_tstaticsharesstat�������˱��ֶΣ�f_frozenshares����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.2     2017-03-22 09:06                                       ���б�ta_tstaticsharesstat�������˱��ֶΣ�f_newincome����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.2     2017-06-05 13:41                                       ���б�ta_tliquidateagency�������˱��ֶΣ�f_interest����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.2     2017-02-20 09:08                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-07-29 21:01                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_busin:[d_cdate,c_businflag]��;                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1     2016-07-29 20:57                                       ��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_1��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_2��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_3��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_4��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_5��;                                                                                            
-- V1.0.5.1     2016-07-29 16:57                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_5:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-29 16:54                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_4:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-07-29 16:53                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_3:[d_cdate,c_businflag,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-29 16:52                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_2:[d_cdate,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-07-29 16:49                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_1:[d_cdate,c_businflag,c_fundcode,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-07-27 09:38                                       ���б�ta_trequeststat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-07-29 20:58                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_busin:[d_cdate,c_businflag]��;                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1     2016-07-29 20:43                                       ��ǰ��ta_tconfirmstat��ɾ���˱�������idx_tconfirmstat_1��;��ǰ��ta_tconfirmstat��ɾ���˱�������idx_tconfirmstat_2��;                                                                                                                                                                                                                                                                          
-- V1.0.5.1     2016-07-29 16:05                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_2:[d_cdate,c_businflag,c_liqbatchno,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                   
-- V1.0.5.1     2016-07-29 15:55                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_1:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-26 17:33                                       ���б�ta_tconfirmstat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-09-02 11:55                                       ���б�ta_tsalestat�������˱��ֶΣ�f_managerfee����                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-09-02 11:55                                       ���б�ta_tsalestat��ɾ���˱��ֶΣ�f_managefare����                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-08-09 10:16                                       ��ǰ��ta_tsalestat������������ idx_tsalestat_cdate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-07-29 20:55                                       ��ǰ��ta_tliquidatetrusteedetail��ɾ���˱�������idx_tliqtrusteedetail��;                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-29 16:22                                       ��ǰ��ta_tliquidatetrusteedetail������������ idx_tliqtrusteedetail:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-26 20:10                                       ���б�ta_tliquidatetrusteedetail�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-05-26 11:25                                       ��ǰ��ta_tliquidatetrusteedetail������������ d_cdate,c_fundcode,c_businflag,c_agencyno,d_needdate,c_databaseno,c_tenanti��;                                                                                                                                                                                                                                                                   
-- V1.0.5.1     2016-07-29 20:54                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate2:[d_requestdate]��;                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-29 20:53                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate1:[c_fundcode]��;                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-07-29 20:53                                       ��ǰ��ta_tfundtrusteeliquidate��ɾ���˱�������idx_tfundtrusteeliquidate��;                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-07-29 16:18                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate:[c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-07-26 20:11                                       ���б�ta_tfundtrusteeliquidate�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-10-19 19:24                                       ���б�ta_tdividendstat�������˱��ֶΣ�l_successcount����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-08-10 14:09                                       ��ǰ��ta_tdividendstat��ɾ���˱�������idx_tdividendstat_cdate��;                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-08-10 14:08                                       ��ǰ��ta_tdividendstat�����������ֶ�˳��Ϊ��d_cdate,c_fundcode,c_agencyno,c_sharetype,c_bonustype,c_shareclass,d_senddate,d_distributedate,d_reinvestdate,c_dataflag,c_databaseno,c_tacode,c_tenantid����                                                                                                                                                                                     
-- V1.0.5.1     2016-07-29 20:59                                       ��ǰ��ta_tdividendstat������������ idx_tdividendstat_cdate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2016-07-29 20:42                                       ��ǰ��ta_tdividendstat��ɾ���˱�������idx_tdividendstat_liqno��;                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-29 14:52                                       ��ǰ��ta_tdividendstat������������ idx_tdividendstat_liqno:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-26 17:10                                       ���б�ta_tdividendstat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-06-18 11:21                                       ���б�ta_tdividendstat�������˱��ֶΣ�f_deductbalance����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2017-02-23 10:12                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinteresttax����                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2017-02-23 10:12                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinterestall����                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2017-02-22 10:04                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rshares_ch�������б�ta_tconfirmstatdetail�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2017-02-21 19:38                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_deductmngfare����                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-12-06 13:28                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinterest����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-11-07 10:45                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_balance�������б�ta_tconfirmstatdetail�������˱��ֶΣ�f_shares����                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-10-17 13:51                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_delaybalance�������б�ta_tconfirmstatdetail�������˱��ֶΣ�f_delayshares����                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2016-09-27 11:13                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�c_taflag����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2016-08-25 14:20                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tconfirmstat_outdate:[d_outputdate]��;                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-08-10 14:10                                       ��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_dcate��;                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-07-29 20:50                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_dcate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-07-29 20:49                                       ��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_liqno��;��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_busin��;                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-07-29 15:59                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_busin:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-07-29 14:43                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_liqno:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-26 17:05                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.1     2016-11-14 15:36                                       ��ǰ��ta_ttailratio�����������ֶ�˳������pk_ttailratio:������������ֶ�˳��Ϊ��c_fundcode,c_agencyno,c_tailflag,d_tailbgdate,f_holdmin,c_tacode,c_tenantid����                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-08 09:57                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-09-26 21:03                                       ��ǰ��ta_tliquidateswitch������������ uidx_tliquidateswitch:[d_date,c_fundcode,c_othercode,c_agencyno,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-09-26 19:42                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-11-04 16:07                                       ���б�ta_tcheckresultstat�������˱��ֶΣ�c_fundacco�������б�ta_tcheckresultstat�������˱��ֶΣ�c_businflag����                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-11-07 10:59                                       ��ǰ��ta_tfundagencyliquidate������������ idx_tfundagecliq:[c_fundcode,c_agencyno,c_tenantid]��;                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                 ��ע 
-- V1.0.6.1     2016-10-15 11:05                                       ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_isreceivebroadcast����                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2016-09-07 15:29                                       ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_newnavdate����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-08-20 11:02                   �״�                ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_agencytype����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2017-04-14 19:27                                       ���б�ta_tcustexpbatch�������˱��ֶΣ�d_begindate�������б�ta_tcustexpbatch�������˱��ֶΣ�d_enddate����                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-11-14 19:57                                       ��ǰ��ta_tliqexpbatch�����������ֶ�˳��Ϊ��c_trusteecode,c_managercode,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2016-11-14 19:56                                       ��ǰ��ta_tliqexpbatch�����������ֶΣ�c_trusteecode����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1     2016-11-14 17:31                                       ��ǰ��ta_tliqexpbatch������������ c_managercode,c_tacode,c_tenanti��;                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2016-11-14 17:30                                       ��ǰ��ta_tliqexpbatch��ɾ���˱�������uidx_tliqexpbatch��;                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-06-16 10:59                                       ���б�ta_tcenterexpbatch�������˱��ֶΣ�d_zhzlcentralizedate����                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2017-06-15 16:05                                       ���б�ta_tcenterexpbatch�������˱��ֶΣ�c_centralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�c_zhcentralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�c_zhzlcentralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�d_zhcentralizedate����                                                                                                                                      
-- V1.0.6.1     2016-11-01 19:05                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�f_otherfee2����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-10-27 12:23                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-10-27 12:22                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-10-27 10:41                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-08-31 16:13                                       ���б�ta_tagencynavc4file�������˱��ֶΣ�f_unitprofittxt����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-08-31 16:13                                       ���б�ta_tagencynavc4file��ɾ���˱��ֶΣ�f_unitprofit����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-12-20 17:15                                       ���б�ta_tagencynav07file�������˱��ֶΣ�c_infundcode����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-05-22 18:45                                       ���б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_newtradeacco����                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-05-22 18:45                                       ���б�ta_tagencyreqnorstd01file��ɾ���˱��ֶΣ�c_othertradeacco����                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2017-05-17 15:41                                       ���б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_oriidentityno�������б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_oricontno�������б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_contidcard18len����                                                                                                                                                                                          
-- V1.0.6.1     2017-02-15 17:20                                       ���б�ta_tliqredeemfile�������˱��ֶΣ�f_deductmngfare����                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2017-02-16 09:37                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�f_rshares_ch�������б�ta_tliqadjustsharefile�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-02-16 09:31                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2017-02-16 09:30                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�f_rshares_ch����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2017-02-15 17:10                                       ���б�ta_tliqbonusfile�������˱��ֶΣ�f_aheadincome����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2017-02-16 14:26                                       ���б�ta_tliqswitchoutfile���޸��˱��ֶ������գ�f_otherfare����                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1     2017-02-16 14:22                                       ���б�ta_tliqswitchoutfile�������˱��ֶΣ�f_otherfare����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-02-16 14:27                                       ���б�ta_tliqswitchfile���޸��˱��ֶ������գ�f_otherfare����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2017-02-16 14:21                                       ���б�ta_tliqswitchfile�������˱��ֶΣ�f_otherfare����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1     2017-02-16 09:35                                       ���б�ta_tliqincomefile�������˱��ֶΣ�f_endaccumshares����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2017-02-16 09:23                                       ���б�ta_tliqincomefile�������˱��ֶΣ�f_endaccumshares����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2016-11-07 17:14                                       ���б�ta_tcustconfirmfile��ɾ���˱��ֶΣ�l_serialno����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-11-07 17:13                                       ���б�ta_tcustconfirmfile�������˱��ֶΣ�l_serialnumber����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2016-11-07 18:16                                       ���б�ta_tcustprofitcurrentfile��ɾ���˱��ֶΣ�l_serialno����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-11-07 18:14                                       ���б�ta_tcustprofitcurrentfile�������˱��ֶΣ�l_serialnumber����                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-06-01 17:28                                       ���б�ta_tcentralize92file�������˱��ֶΣ�c_nationality����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2017-05-31 17:13                                       ���б�ta_tcentralize96file�������˱��ֶΣ�f_deductfare�������б�ta_tcentralize96file�������˱��ֶΣ�c_deductflag����                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2017-06-01 18:33                                       ���б�ta_tcentralizeg1file�������˱��ֶΣ�f_taxratio�������б�ta_tcentralizeg1file�������˱��ֶΣ�d_ratiodate����                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-06-01 18:12                                       ���б�ta_tcentralizet1file�������˱��ֶΣ�c_formalfundcode�������б�ta_tcentralizet1file�������˱��ֶΣ�c_priorsequence�������б�ta_tcentralizet1file�������˱��ֶΣ�f_leveragemultiple�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadname�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadbuscode�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadmancode����         
-- V1.0.6.1     2017-06-01 18:30                                       ���б�ta_tcentralizet2file�������˱��ֶΣ�f_leveragerate�������б�ta_tcentralizet2file�������˱��ֶΣ�f_leveragemultiple����                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-10-24 16:35                                       ��ǰ��ta_tsalequalify_tmp������������ idx_tsalequalify_tmp:[c_fundcode,c_agencyno]��;                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2016-10-24 14:25                                       ���б�ta_tsalequalify_tmp�������˱��ֶΣ�c_dataflag����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-09-26 14:29                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-06-21 11:17                                       ��ǰ��ta_tfilefield�����������ֶΣ�l_taidno����                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.17    2016-08-05 21:50                                       �޸�������uidx_tmergercontrol,�����ֶ��޸�Ϊ��(c_gradefund,c_type,c_tenantid),��������޸�Ϊ��null,����Ψһ���޸�Ϊ����Ψһ,��������������Ϊ:��������.                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-08-05 21:49                                       ��ǰ��ta_tmergercontrol������������ uidx_tmergecontrol:[c_gradefund,c_type,c_tenantid]��;                                                                                                                                                                                                                                                                                                     
-- V1.0.5.17    2016-08-05 21:48                                       ��ǰ��ta_tmergercontrol��ɾ���˱�������uidx_mergercontrol��;                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.17    2016-06-18 15:53                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�f_tafare����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.17    2016-06-18 15:58                                       ���б�ta_tliqredeemfile�������˱��ֶΣ�f_ductmanagerfare�������б�ta_tliqredeemfile�������˱��ֶΣ�f_profitbalance����                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-06-18 15:56                                       ���б�ta_tliqbonusfile�������˱��ֶΣ�f_profitbalance����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.17    2016-06-04 15:50                                       ���б�ta_tcustfundinfofile�������˱��ֶΣ�c_pensionregistcode����                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.17    2016-06-03 17:44                                       ���б�ta_tcustaccofile�������˱��ֶΣ�c_risklevel����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.17    2016-06-03 17:43                                       ���б�ta_tcustaccorequestfile�������˱��ֶΣ�c_risklevel����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.17    2016-06-04 15:49                                       ���б�ta_tcustdividendfile�������˱��ֶΣ�f_unitprofit2����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.17    2016-06-23 16:27                                       ���б�ta_tcustecontractfile�����������ֶΣ�c_custodiancode->c_trusteecode����                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.17    2016-06-23 11:05                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-08-03 16:24                                       ��ǰ��ta_totccustinfo��ɾ���˱�������idx_totccustinfo��;                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.17    2016-08-03 15:50                                       ��ǰ��ta_totccustinfo������������ idx_totccustinfo:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.17    2016-08-03 16:24                                       ��ǰ��ta_totcshareinfo��ɾ���˱�������idx_totcshareinfo��;                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.17    2016-08-03 16:07                                       ��ǰ��ta_totcshareinfo������������ idx_totcshareinfo:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.14    2016-05-27 16:41                                       ���б�ta_tcentralize92file�������˱��ֶΣ�c_txtbillsendpass����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.13    2016-05-27 16:41                                       ���б�ta_tcentralize92file��ɾ���˱��ֶΣ�c_billsendpass����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.11    2016-05-26 11:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.8     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.7     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.6     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.5     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.4     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.3     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-21 16:40                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-17 20:49                                       ���б�ta_tcusttainfo_fundinfo�������˱��ֶΣ�l_netprecision����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.2     2016-05-18 16:10                                       ���б�ta_tcusttainfo_farezone�������˱��ֶΣ�f_maxbalance����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.2     2016-05-18 16:08                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.2     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-20 08:42                                       ���б�ta_totcshareinfo���޸��˱��ֶ������գ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-06-15 16:23                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-05-17 17:19                                       ���б�ta_totccustinfo��ɾ���˱��ֶΣ�c_databaseno����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-05-17 17:22                                       ���б�ta_totcshareinfo�������˱��ֶΣ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-05-17 17:20                                       ���б�ta_totcshareinfo��ɾ���˱��ֶΣ�c_databaseno����                                                                                                                                                                                                                                                                                                                                        


-- ������ ta_tflowinfo(���̶����)�ĵ�ǰ��
SELECT 'Create Table ta_tflowinfo-���̶����...';
DROP TABLE IF EXISTS ta_tflowinfo;
CREATE TABLE ta_tflowinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	c_callno                       varchar(40)     DEFAULT ' '        NOT NULL,
	c_flowdeftype                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_flowinstype                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_flowfundtype                 varchar(6)      DEFAULT ' '        ,
	processSubType                 varchar(100)    DEFAULT ' '        ,
	c_caption                      varchar(100)    DEFAULT ' '        ,
	c_virtualflowno                varchar(60)     DEFAULT ' '        ,
	c_specialflownoflag            varchar(1)      DEFAULT '0'        ,
	c_fundbackflag                 varchar(1)      DEFAULT ' '        ,
	c_agcbackflag                  varchar(1)      DEFAULT ' '        ,
	c_mgrbackflag                  varchar(1)      DEFAULT ' '        ,
	c_contentcode                  varchar(6)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(c_flowno, c_flowstep, c_tenantid)
);

-- ������ ta_tserviceinfo(����������ѷ�������ֲ���������棩)�ĵ�ǰ��
SELECT 'Create Table ta_tserviceinfo-����������ѷ�������ֲ���������棩...';
DROP TABLE IF EXISTS ta_tserviceinfo;
CREATE TABLE ta_tserviceinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_callno                       varchar(40)     DEFAULT ' '        NOT NULL,
	c_svcname                      varchar(100)    DEFAULT ' '        NOT NULL,
	c_functionno                   varchar(10)     DEFAULT ' '        NOT NULL,
	l_no                           bigint          DEFAULT 0          NOT NULL,
	c_isbasedb                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_inputparam                   varchar(255)    DEFAULT ' '        NOT NULL,
	c_outputparam                  varchar(255)    DEFAULT ' '        NOT NULL,
	c_caption                      varchar(100)    DEFAULT ' '        NOT NULL
);
CREATE UNIQUE INDEX pk_tserviceinfo ON ta_tserviceinfo(c_callno ASC ,l_no ASC ,c_tenantid ASC );

-- ������ ta_truleinfo(�����������)�ĵ�ǰ��
SELECT 'Create Table ta_truleinfo-�����������...';
DROP TABLE IF EXISTS ta_truleinfo;
CREATE TABLE ta_truleinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_ruleno                       varchar(30)     DEFAULT ' '        NOT NULL,
	c_ruletype                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_ruleevent                    varchar(40)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        ,
	c_caption                      varchar(100)    DEFAULT ' '        ,
PRIMARY KEY(c_ruleno, c_tenantid)
);

-- ������ ta_tflowconfig(���������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tflowconfig-���������ñ�...';
DROP TABLE IF EXISTS ta_tflowconfig;
CREATE TABLE ta_tflowconfig
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
	c_isused                       varchar(1)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
PRIMARY KEY(c_tacode, c_flowno, c_tenantid)
);

-- ������ ta_truleconfig(�����������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_truleconfig-�����������ñ�...';
DROP TABLE IF EXISTS ta_truleconfig;
CREATE TABLE ta_truleconfig
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	c_ruleno                       varchar(30)     DEFAULT ' '        NOT NULL,
	l_no                           bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_flowno, c_flowstep, c_ruleno, c_tenantid)
);

-- ������ ta_tflowlog(���̼�ؼ�¼��)�ĵ�ǰ��
SELECT 'Create Table ta_tflowlog-���̼�ؼ�¼��...';
DROP TABLE IF EXISTS ta_tflowlog;
CREATE TABLE ta_tflowlog
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_instanceid                   varchar(20)     DEFAULT ' '        NOT NULL,
	c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	c_flowinstype                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_callno                       varchar(40)     DEFAULT ' '        NOT NULL,
	c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
	processSubType                 varchar(100)    DEFAULT ' '        NOT NULL,
	c_fundbackflag                 varchar(1)      DEFAULT ' '        ,
	c_agcbackflag                  varchar(1)      DEFAULT ' '        ,
	c_mgrbackflag                  varchar(1)      DEFAULT ' '        ,
	c_contentcode                  varchar(6)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_instanceid, c_flowno, c_flowstep, c_tacode, c_tenantid)
);
CREATE INDEX idx_tflowlog_biz ON ta_tflowlog(c_flowno ASC ,c_flowstep ASC ,c_fundcode ASC ,c_agencyno ASC ,c_trusteecode ASC ,c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tservicelog(�����ؼ�¼�����ѷ�������ֲ���������棩)�ĵ�ǰ��
SELECT 'Create Table ta_tservicelog-�����ؼ�¼�����ѷ�������ֲ���������棩...';
DROP TABLE IF EXISTS ta_tservicelog;
CREATE TABLE ta_tservicelog
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_instanceid                   varchar(20)     DEFAULT ' '        NOT NULL,
	c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	c_flowinstype                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_callno                       varchar(40)     DEFAULT ' '        NOT NULL,
	l_no                           bigint          DEFAULT 0          NOT NULL,
	c_svcname                      varchar(100)    DEFAULT ' '        NOT NULL,
	c_functionno                   varchar(10)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_agencyno, c_trusteecode, c_flowno, c_flowstep, c_callno, l_no, c_databaseno, c_tacode, c_tenantid)
);

-- ������ ta_tbatchdealctl(����״̬����)�ĵ�ǰ��
SELECT 'Create Table ta_tbatchdealctl-����״̬����...';
DROP TABLE IF EXISTS ta_tbatchdealctl;
CREATE TABLE ta_tbatchdealctl
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_runstatus                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
	c_maxbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
	c_minbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
PRIMARY KEY(c_tacode, c_tenantid)
);

-- ������ processinstancedefinition(��������ʵ�������)�ĵ�ǰ��
SELECT 'Create Table processinstancedefinition-��������ʵ�������...';
DROP TABLE IF EXISTS processinstancedefinition;
CREATE TABLE processinstancedefinition
(
	id                             int             NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_instanceid                   varchar(20)     DEFAULT ' '        ,
	deploymentUnit                 varchar(255)    DEFAULT ' '        ,
	executeData                    varchar(255)    DEFAULT ' '        ,
	executeMode                    varchar(255)    DEFAULT ' '        ,
	processId                      varchar(255)    DEFAULT ' '        ,
	processType                    varchar(255)    DEFAULT ' '        ,
	internalInstanceId             int             DEFAULT 0          ,
	c_longtacode                   varchar(40)     DEFAULT ' '        ,
	c_supinstanceid                varchar(20)     DEFAULT ' '        ,
	c_backendinstanceid            varchar(255)    DEFAULT ' '        ,
PRIMARY KEY(id)
);
CREATE INDEX index_flowprocess ON processinstancedefinition(c_tenantid ASC ,c_instanceid ASC ,processType ASC );

-- ������ ta_tsynctablelog(����ͬ����¼��־��)�ĵ�ǰ��
SELECT 'Create Table ta_tsynctablelog-����ͬ����¼��־��...';
DROP TABLE IF EXISTS ta_tsynctablelog;
CREATE TABLE ta_tsynctablelog
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_tablename                    varchar(80)     DEFAULT ' '        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_flowstep, c_tablename, d_cdate, c_fundcode, c_agencyno, c_trusteecode, c_managercode, c_databaseno, c_tacode, c_tenantid)
);
CREATE INDEX idx_tsynctablelog_cdate ON ta_tsynctablelog(d_cdate ASC );

-- ������ ta_tflowinstanceinfo(����ʵ����ϵ��)�ĵ�ǰ��
SELECT 'Create Table ta_tflowinstanceinfo-����ʵ����ϵ��...';
DROP TABLE IF EXISTS ta_tflowinstanceinfo;
CREATE TABLE ta_tflowinstanceinfo
(
	c_instanceid                   varchar(20)     DEFAULT ' '        NOT NULL,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	processType                    varchar(255)    DEFAULT ' '        NOT NULL,
	executeData                    varchar(255)    DEFAULT ' '        NOT NULL,
	processSubType                 varchar(100)    DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_instanceid)
);
CREATE INDEX index_flowinstance ON ta_tflowinstanceinfo(c_tenantid ASC ,c_tacode ASC ,c_managercode ASC ,c_trusteecode ASC ,c_fundcode ASC ,c_agencyno ASC ,d_cdate ASC );

-- ������ ta_tbasesynctablelog(��������ͬ����¼��־��)�ĵ�ǰ��
SELECT 'Create Table ta_tbasesynctablelog-��������ͬ����¼��־��...';
DROP TABLE IF EXISTS ta_tbasesynctablelog;
CREATE TABLE ta_tbasesynctablelog
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_tablename                    varchar(80)     DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_tacode, c_managercode, c_trusteecode, c_fundcode, c_agencyno, c_tablename, d_cdate, c_flowstep)
);

-- ������ ta_tuserevent(�˹������¼���)�ĵ�ǰ��
SELECT 'Create Table ta_tuserevent-�˹������¼���...';
DROP TABLE IF EXISTS ta_tuserevent;
CREATE TABLE ta_tuserevent
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_usereventtype                varchar(30)     DEFAULT ' '        NOT NULL,
	c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
	c_outfundcode                  varchar(12)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX pk_userevent ON ta_tuserevent(c_usereventtype ASC ,c_fundcode ASC ,d_cdate ASC ,c_agencyno ASC ,c_trusteecode ASC ,c_managercode ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_thintinfo(��ʾ��Ϣ�����)�ĵ�ǰ��
SELECT 'Create Table ta_thintinfo-��ʾ��Ϣ�����...';
DROP TABLE IF EXISTS ta_thintinfo;
CREATE TABLE ta_thintinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_hintno                       varchar(30)     DEFAULT ' '        NOT NULL,
	c_hintdescribe                 varchar(500)    DEFAULT ' '        ,
	c_hintlevel                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_hintsqlcode                  varchar(8)      DEFAULT ' '        ,
	c_hintopturl                   varchar(255)    DEFAULT ' '        ,
	c_hintoptmode                  varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_hintno, c_tenantid)
);

-- ������ ta_thintconfig(��ʾ��Ϣ���ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_thintconfig-��ʾ��Ϣ���ñ�...';
DROP TABLE IF EXISTS ta_thintconfig;
CREATE TABLE ta_thintconfig
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	c_hintno                       varchar(30)     DEFAULT ' '        NOT NULL,
	c_hinttime                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_describe                     varchar(100)    DEFAULT ' '        ,
	l_order                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_hintno, c_flowstep, c_flowno, c_tacode, c_tenantid)
);

-- ������ ta_thintlog(��ʾ��Ϣ��־��)�ĵ�ǰ��
SELECT 'Create Table ta_thintlog-��ʾ��Ϣ��־��...';
DROP TABLE IF EXISTS ta_thintlog;
CREATE TABLE ta_thintlog
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
	c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
	c_instanceid                   varchar(20)     DEFAULT ' '        NOT NULL,
	c_hintno                       varchar(30)     DEFAULT ' '        NOT NULL,
	c_hintmemo                     varchar(4000)   DEFAULT ' '        NOT NULL,
	c_hintopturl                   varchar(255)    DEFAULT ' '        NOT NULL,
	c_hintlevel                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_hintisread                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_isneeddeal                   varchar(1)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	l_no                           bigint          DEFAULT 0          NOT NULL,
	c_hintoptmode                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
	d_inserttime                   datetime        DEFAULT 0          NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_thintlog ON ta_thintlog(c_instanceid ASC ,d_cdate ASC ,c_flowstep ASC ,c_flowno ASC ,c_hintno ASC ,c_tacode ASC ,c_tenantid ASC ,l_no ASC );

-- ������ ta_tasynflowlog(�첽���̵�����־��)�ĵ�ǰ��
SELECT 'Create Table ta_tasynflowlog-�첽���̵�����־��...';
DROP TABLE IF EXISTS ta_tasynflowlog;
CREATE TABLE ta_tasynflowlog
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_uid                          varchar(100)    DEFAULT ' '        NOT NULL,
	c_status                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	error_code                     varchar(8)      DEFAULT ' '        NOT NULL,
	error_reason                   varchar(500)    DEFAULT ' '        NOT NULL
);
CREATE INDEX pk_tasynflowlog ON ta_tasynflowlog(c_uid ASC );

-- ������ ta_tbackinstancelist(�ظ���������ʵ����)�ĵ�ǰ��
SELECT 'Create Table ta_tbackinstancelist-�ظ���������ʵ����...';
DROP TABLE IF EXISTS ta_tbackinstancelist;
CREATE TABLE ta_tbackinstancelist
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_instanceid                   varchar(20)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_instanceid, c_tenantid)
);

-- ������ ta_tmonitorgroup(�����ҵ���)�ĵ�ǰ��
SELECT 'Create Table ta_tmonitorgroup-�����ҵ���...';
DROP TABLE IF EXISTS ta_tmonitorgroup;
CREATE TABLE ta_tmonitorgroup
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_groupcode                    varchar(3)      DEFAULT ' '        NOT NULL,
	c_groupname                    varchar(20)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_groupcode, c_tenantid)
);

-- ������ ta_tmonitorcontent(������ݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tmonitorcontent-������ݱ�...';
DROP TABLE IF EXISTS ta_tmonitorcontent;
CREATE TABLE ta_tmonitorcontent
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_groupcode                    varchar(3)      DEFAULT ' '        NOT NULL,
	c_contentcode                  varchar(6)      DEFAULT ' '        NOT NULL,
	c_contentname                  varchar(30)     DEFAULT ' '        NOT NULL,
	c_contenttype                  varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_contentcode, c_groupcode, c_tacode, c_tenantid)
);

-- ������ ta_tmonitortradestat(����ͳ�Ƽ����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tmonitortradestat-����ͳ�Ƽ����Ϣ��...';
DROP TABLE IF EXISTS ta_tmonitortradestat;
CREATE TABLE ta_tmonitortradestat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_menucode                     varchar(50)     DEFAULT ' '        NOT NULL,
	c_showname                     varchar(50)     DEFAULT ' '        NOT NULL,
	l_order                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_businflag, c_tacode, c_tenantid)
);

-- ������ ta_tmonitorb2s(��ת�������⵽�ֿ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tmonitorb2s-��ת�������⵽�ֿ�����...';
DROP TABLE IF EXISTS ta_tmonitorb2s;
CREATE TABLE ta_tmonitorb2s
(
	c_timestamp                    varchar(80)     DEFAULT ' '        NOT NULL,
	c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_timestamp)
);

-- ������ ta_tmonitors2b(��ת���Ʒֿ⵽��������)�ĵ�ǰ��
SELECT 'Create Table ta_tmonitors2b-��ת���Ʒֿ⵽��������...';
DROP TABLE IF EXISTS ta_tmonitors2b;
CREATE TABLE ta_tmonitors2b
(
	c_timestamp                    varchar(80)     DEFAULT ' '        NOT NULL,
	c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_timestamp)
);

