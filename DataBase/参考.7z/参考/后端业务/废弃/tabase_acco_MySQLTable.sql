-- -------------------------------------------
-- SQLfile   : tabase_acco_MySQLTable.sql
-- Author   : Administrator
-- Date     : 2017-11-28
-- Notes    : SQL�ű�
-- -------------------------------------------
-- �޸İ汾    �޸�����            �޸ĵ�         �޸���    ������    �޸�����    ��ע 
-- V1.0.3.0    2016-10-11 18:14                                       �½���Դ         


-- ������ ta_tcustomerinfotmp(�˻����ϻ����)�ĵ�ǰ��
SELECT 'Create Table ta_tcustomerinfotmp-�˻����ϻ����...';
DROP TABLE IF EXISTS ta_tcustomerinfotmp;
CREATE TABLE ta_tcustomerinfotmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_idnovaliddate                int             DEFAULT 0          ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_sex                          char(1)         DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_corpname                     varchar(40)     DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_contype                      char(1)         DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_contidcard18len              char(1)         DEFAULT ' '        ,
	c_billsendflag                 char(1)         DEFAULT ' '        ,
	c_callcenter                   char(1)         DEFAULT ' '        ,
	c_internet                     char(1)         DEFAULT ' '        ,
	c_billsendpass                 char(1)         DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_lawidtype                    char(1)         DEFAULT ' '        ,
	c_lawidno                      varchar(20)     DEFAULT ' '        ,
	c_broker                       varchar(12)     DEFAULT ' '        ,
	c_recommender                  varchar(40)     DEFAULT ' '        ,
	c_recommendertype              char(1)         DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	c_actcode                      varchar(3)      DEFAULT ' '        ,
	c_backreason                   varchar(60)     DEFAULT ' '        ,
	c_hometelno                    varchar(32)     DEFAULT ' '        ,
	c_minorflag                    char(1)         DEFAULT ' '        ,
	c_transacttype                 char(1)         DEFAULT ' '        ,
	d_contidnovaliddate            int             DEFAULT 0          ,
	d_lawidnovaliddate             int             DEFAULT 0          ,
	c_risklevel                    char(1)         DEFAULT ' '        ,
	c_managerange                  varchar(2)      DEFAULT ' '        ,
	c_controlholder                varchar(80)     DEFAULT ' '        ,
	c_actualcontroller             varchar(80)     DEFAULT ' '        ,
	c_marital                      char(1)         DEFAULT ' '        ,
	l_familynum                    tinyint         DEFAULT 0          ,
	f_penates                      decimal(16,2)   DEFAULT 0.0        ,
	c_mediahobby                   char(1)         DEFAULT ' '        ,
	c_institutiontype              char(1)         DEFAULT ' '        ,
	c_englishfirstname             varchar(20)     DEFAULT ' '        ,
	c_englishfamilyname            varchar(20)     DEFAULT ' '        ,
	c_industry                     varchar(4)      DEFAULT ' '        ,
	c_companychar                  varchar(4)      DEFAULT ' '        ,
	f_employeenum                  decimal(16,2)   DEFAULT 0.0        ,
	c_hobbytype                    varchar(2)      DEFAULT ' '        ,
	c_province                     varchar(6)      DEFAULT ' '        ,
	c_city                         varchar(6)      DEFAULT ' '        ,
	c_county                       varchar(6)      DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	c_liqbatchno                   char(1)         DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_tenantid)
);

