-- ������ ta_tagencybizlimit(������ҵ�����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencybizlimit-������ҵ�����Ʊ�...';
DROP TABLE IF EXISTS ta_tagencybizlimit;
create table ta_tagencybizlimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tagencybizlimit on ta_tagencybizlimit(c_outbusinflag, c_agencyno, c_netno, c_fundcode, c_sharetype, c_tenantid);

-- ������ ta_tidtypebizlimit(֤������ҵ�����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tidtypebizlimit-֤������ҵ�����Ʊ�...';
DROP TABLE IF EXISTS ta_tidtypebizlimit;
create table ta_tidtypebizlimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tidtypebizlimit on ta_tidtypebizlimit(c_outbusinflag, c_identitype, c_fundcode, c_agencyno, c_custtype, c_tenantid);

-- ������ ta_tagebizlimit(����ҵ�����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagebizlimit-����ҵ�����Ʊ�...';
DROP TABLE IF EXISTS ta_tagebizlimit;
create table ta_tagebizlimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    l_minage                       int             DEFAULT 0          ,
    l_maxage                       int             DEFAULT 0          ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tagebizlimit on ta_tagebizlimit(c_outbusinflag, l_minage, c_fundcode, c_tacode, c_tenantid);

-- ������ ta_tarlimit(��Ʒ�����������Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tarlimit-��Ʒ�����������Ʊ�...';
DROP TABLE IF EXISTS ta_tarlimit;
create table ta_tarlimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    f_ominbala                     decimal(16,2)   DEFAULT 0.0        ,
    f_stepbala                     decimal(16,2)   DEFAULT 0.0        ,
    f_omaxbala                     decimal(16,2)   DEFAULT 0.0        ,
    f_hmaxratio                    decimal(9,8)    DEFAULT 0.0        ,
    f_hmaxbala                     decimal(16,2)   DEFAULT 0.0        ,
    f_rminshares                   decimal(16,2)   DEFAULT 0.0        ,
    f_hminshares                   decimal(16,2)   DEFAULT 0.0        ,
    f_cminshares                   decimal(16,2)   DEFAULT 0.0        ,
    f_rationminbala                decimal(16,2)   DEFAULT 0.0        ,
    f_switchinbala                 decimal(16,2)   DEFAULT 0.0        ,
    f_rationredeemmin              decimal(16,2)   DEFAULT 0.0        ,
    f_gradediff                    decimal(16,2)   DEFAULT 0.0        ,
    f_hminbala                     decimal(16,2)   DEFAULT 0.0        ,
    f_maxbidsamount                decimal(16,2)   DEFAULT 0.0        ,
    f_maxsumbidsamount             decimal(16,2)   DEFAULT 0.0        ,
    f_maxredsvol                   decimal(16,2)   DEFAULT 0.0        ,
    f_maxsumredsvol                decimal(16,2)   DEFAULT 0.0        ,
    f_rationmaxbala                decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tarlimit on ta_tarlimit(c_fundcode, c_agencyno, c_custtype, c_tacode, c_tenantid);

-- ������ ta_tstatusbizlimit(����״̬ҵ�����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tstatusbizlimit-����״̬ҵ�����Ʊ�...';
DROP TABLE IF EXISTS ta_tstatusbizlimit;
create table ta_tstatusbizlimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    l_limitno                      int             DEFAULT 0          ,
    c_fundstatus                   varchar(1)      DEFAULT ' '        ,
    c_describe                     varchar(100)    DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tstatusbizlimit on ta_tstatusbizlimit(c_fundstatus, c_fundcode, c_outbusinflag, c_tacode, c_tenantid);

-- ������ ta_tsblmtexcept(����״̬ҵ�������ų���)�ĵ�ǰ��
SELECT 'Create Table ta_tsblmtexcept-����״̬ҵ�������ų���...';
DROP TABLE IF EXISTS ta_tsblmtexcept;
create table ta_tsblmtexcept (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    l_limitno                      int             DEFAULT 0          ,
    c_fundstatus                   varchar(1)      DEFAULT ' '        ,
    c_bcrdmflag                    varchar(1)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create index idx_sblmtexcept on ta_tsblmtexcept(l_limitno, c_fundstatus, c_tenantid);

-- ������ ta_tchangelimit(��Ʒת�����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tchangelimit-��Ʒת�����Ʊ�...';
DROP TABLE IF EXISTS ta_tchangelimit;
create table ta_tchangelimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tchangelimit on ta_tchangelimit(c_fundcode, c_othercode, c_agencyno, c_sharetype, c_othershare, c_tenantid);

-- ������ ta_trationcontrol(���ڶ���Э����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_trationcontrol-���ڶ���Э����Ʊ�...';
DROP TABLE IF EXISTS ta_trationcontrol;
create table ta_trationcontrol (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_flag                         varchar(1)      DEFAULT ' '        ,
    c_incfproc                     varchar(1)      DEFAULT ' '        ,
    l_definterval                  int             DEFAULT 0          ,
    c_exceedmode                   varchar(1)      DEFAULT ' '        ,
    c_diffrate                     varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_trationcontrol on ta_trationcontrol(c_fundcode, c_agencyno, c_sharetype, c_tacode, c_tenantid);

-- ������ ta_trationagio(���ڶ���Э���Żݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_trationagio-���ڶ���Э���Żݱ�...';
DROP TABLE IF EXISTS ta_trationagio;
create table ta_trationagio (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_begindate                    int             DEFAULT 0          ,
    d_enddate                      int             DEFAULT 0          ,
    d_validbgndate                 int             DEFAULT 0          ,
    d_validenddate                 int             DEFAULT 0          ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
    l_mintimes                     int             DEFAULT 0          ,
    l_maxtimes                     int             DEFAULT 0          ,
    f_minbalance                   decimal(16,2)   DEFAULT 0.0        ,
    f_maxbalance                   decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_trationagio on ta_trationagio(c_fundcode, c_agencyno, c_sharetype, d_begindate, d_validbgndate, l_mintimes, f_minbalance, c_tenantid);

-- ������ ta_tclerklist(����˾Ա���б�)�ĵ�ǰ��
SELECT 'Create Table ta_tclerklist-����˾Ա���б�...';
DROP TABLE IF EXISTS ta_tclerklist;
create table ta_tclerklist (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_managercode                  varchar(10)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_flag                         varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tclerklist on ta_tclerklist(c_fundacco, c_identityno, c_custname, c_identitype, c_managercode, c_tacode, c_tenantid);

-- ������ ta_tsaleagio(�����Żݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tsaleagio-�����Żݱ�...';
DROP TABLE IF EXISTS ta_tsaleagio;
create table ta_tsaleagio (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    d_salestartdate                int             DEFAULT 0          ,
    d_saleenddate                  int             DEFAULT 0          ,
    f_saleminbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_salemaxbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_saleagio                     decimal(5,4)    DEFAULT 0.0        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tsaleagio on ta_tsaleagio(c_fundacco, c_fundcode, c_businflag, c_sharetype, c_agencyno, c_netno, d_salestartdate, f_saleminbalance, c_tenantid);

-- ������ ta_tchangetimefavor(ת�������Żݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tchangetimefavor-ת�������Żݱ�...';
DROP TABLE IF EXISTS ta_tchangetimefavor;
create table ta_tchangetimefavor (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    l_times                        int             DEFAULT 0          ,
    c_favortype                    varchar(1)      DEFAULT ' '        ,
    f_favorratio                   decimal(16,4)   DEFAULT 0.0        ,
    c_multifavor                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tchangetimefavor on ta_tchangetimefavor(c_fundcode, c_sharetype, c_othercode, c_othershare, c_tenantid);

-- ������ ta_tclerklimit(�ڲ�Ա�����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tclerklimit-�ڲ�Ա�����Ʊ�...';
DROP TABLE IF EXISTS ta_tclerklimit;
create table ta_tclerklimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    d_limitstartdate               int             DEFAULT 0          ,
    c_limitbusiness                varchar(40)     DEFAULT ' '        ,
    c_limitsource                  varchar(20)     DEFAULT ' '        ,
    c_limitcondition               varchar(1)      DEFAULT ' '        ,
    c_clerklimitdays               varchar(5)      DEFAULT ' '        ,
    c_clerktype                    varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tclerklimit on ta_tclerklimit(c_fundcode, d_limitstartdate, c_clerktype, c_limitbusiness, c_limitsource, c_tenantid, c_tacode);

-- ������ ta_tblacklist(��������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tblacklist-��������Ϣ��...';
DROP TABLE IF EXISTS ta_tblacklist;
create table ta_tblacklist (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_level                        varchar(1)      DEFAULT ' '        ,
    c_flag                         varchar(1)      DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index idx_tblacklist_4ele on ta_tblacklist(c_identityno, c_identitype, c_custtype, c_custname, c_fundacco, c_tacode, c_tenantid);
create index idx_tblacklist_acco on ta_tblacklist(c_fundacco, c_tenantid);

-- ������ ta_tblklevellimit(�������������Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tblklevellimit-�������������Ʊ�...';
DROP TABLE IF EXISTS ta_tblklevellimit;
create table ta_tblklevellimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_level                        varchar(1)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_managercode                  varchar(10)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tblklevellimit on ta_tblklevellimit(c_outbusinflag, c_managercode, c_tacode, c_level, c_tenantid);

-- ������ ta_tissuegroup(��Ʒ���з�����Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tissuegroup-��Ʒ���з�����Ϣ��...';
DROP TABLE IF EXISTS ta_tissuegroup;
create table ta_tissuegroup (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    f_quota                        decimal(16,2)   DEFAULT 0.0        ,
    c_issuetype                    varchar(1)      DEFAULT ' '        ,
    f_havesubmount                 decimal(16,2)   DEFAULT 0.0        ,
    l_havesubaccomount             int             DEFAULT 0          ,
    d_lastsubdate                  int             DEFAULT 0          ,
    f_lastsubmount                 decimal(16,2)   DEFAULT 0.0        ,
    f_subratio                     decimal(9,8)    DEFAULT 0.0        ,
    f_factcollect                  decimal(16,2)   DEFAULT 0.0        ,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_tenantid, c_databaseno)
);

-- ������ ta_tshrcfmschema(�ݶ�����ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tshrcfmschema-�ݶ�����ñ�...';
DROP TABLE IF EXISTS ta_tshrcfmschema;
create table ta_tshrcfmschema (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    l_tnconfirm                    int             DEFAULT 0          ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tshrcfmschema on ta_tshrcfmschema(c_fundcode, c_agencyno, c_businflag, c_tenantid);

-- ������ ta_tagencyserialno(������ȷ����ˮ�ű�)�ĵ�ǰ��
SELECT 'Create Table ta_tagencyserialno-������ȷ����ˮ�ű�...';
DROP TABLE IF EXISTS ta_tagencyserialno;
create table ta_tagencyserialno (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    l_serialno                     bigint          DEFAULT 0          ,
PRIMARY KEY(c_agencyno, c_tacode, c_tenantid)
);

-- ������ ta_tcalcvtfeeconfig(ת���Ѽ������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcalcvtfeeconfig-ת���Ѽ������ñ�...';
DROP TABLE IF EXISTS ta_tcalcvtfeeconfig;
create table ta_tcalcvtfeeconfig (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_investorientation            varchar(1)      DEFAULT ' '        ,
    c_otherinvorit                 varchar(1)      DEFAULT ' '        ,
    c_calmode                      varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_ratiomode                    varchar(1)      DEFAULT ' '        ,
    c_refbalmode                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tcalcvtfeeconfig on ta_tcalcvtfeeconfig(c_sharetype, c_investorientation, c_otherinvorit, c_agencyno, c_tacode, c_tenantid);

-- ������ ta_tsequence(������ˮ�ű�)�ĵ�ǰ��
SELECT 'Create Table ta_tsequence-������ˮ�ű�...';
DROP TABLE IF EXISTS ta_tsequence;
create table ta_tsequence (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_sqnname                      varchar(20)     DEFAULT ' '        NOT NULL,
    l_sqncurrval                   int             DEFAULT 1          ,
PRIMARY KEY(c_sqnname, c_tacode, c_tenantid)
);

-- ������ ta_tspecfundfavour(ת���Ż�����-������)�ĵ�ǰ��
SELECT 'Create Table ta_tspecfundfavour-ת���Ż�����-������...';
DROP TABLE IF EXISTS ta_tspecfundfavour;
create table ta_tspecfundfavour (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_tradetype                    varchar(1)      DEFAULT ' '        ,
    c_orisource                    varchar(1)      DEFAULT ' '        ,
    c_sourcetype                   varchar(1)      DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    l_minbalance                   int             DEFAULT 0          ,
    l_maxbalance                   int             DEFAULT 0          ,
    l_minhold                      int             DEFAULT 0          ,
    l_maxhold                      int             DEFAULT 0          ,
    d_favourbgndate                int             DEFAULT 0          ,
    d_favourenddate                int             DEFAULT 0          ,
    c_favortype                    varchar(1)      DEFAULT ' '        ,
    c_faretype                     varchar(1)      DEFAULT ' '        ,
    f_favorratio                   decimal(16,4)   DEFAULT 0.0        ,
    l_times                        int             DEFAULT 0          ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_specfundfavour on ta_tspecfundfavour(c_fundcode, c_businflag, c_sharetype, c_agencyno, c_fundmethod, c_tradetype, c_orisource, c_sourcetype, c_othercode, c_othershare, l_minbalance, l_minhold, d_favourbgndate, c_tenantid, c_favortype, c_faretype);

-- ������ ta_tfundpropfavour(ת���Ż�����-�����)�ĵ�ǰ��
SELECT 'Create Table ta_tfundpropfavour-ת���Ż�����-�����...';
DROP TABLE IF EXISTS ta_tfundpropfavour;
create table ta_tfundpropfavour (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_investorientation            varchar(1)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_tradetype                    varchar(1)      DEFAULT ' '        ,
    c_orisource                    varchar(1)      DEFAULT ' '        ,
    c_sourcetype                   varchar(1)      DEFAULT ' '        ,
    c_otherinvorit                 varchar(1)      DEFAULT ' '        ,
    l_minbalance                   int             DEFAULT 0          ,
    l_maxbalance                   int             DEFAULT 0          ,
    l_minhold                      int             DEFAULT 0          ,
    l_maxhold                      int             DEFAULT 0          ,
    d_favourbgndate                int             DEFAULT 0          ,
    d_favourenddate                int             DEFAULT 0          ,
    c_faretype                     varchar(1)      DEFAULT ' '        ,
    f_favorratio                   decimal(16,4)   DEFAULT 0.0        ,
    c_favortype                    varchar(1)      DEFAULT ' '        ,
    l_times                        int             DEFAULT 0          ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_fundpropfavour on ta_tfundpropfavour(c_investorientation, c_businflag, c_agencyno, c_otherinvorit, c_fundmethod, c_tradetype, c_orisource, c_sourcetype, l_minbalance, l_minhold, d_favourbgndate, c_faretype, c_favortype, c_tacode, c_tenantid);

-- ������ ta_tagiolimit(�ۿ����Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tagiolimit-�ۿ����Ʊ�...';
DROP TABLE IF EXISTS ta_tagiolimit;
create table ta_tagiolimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_faretype                     varchar(1)      DEFAULT ' '        ,
    f_agencyagio                   decimal(5,4)    DEFAULT 0.0        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tagiolimit on ta_tagiolimit(c_fundcode, c_agencyno, c_businflag, c_faretype, c_sharetype, c_tacode, c_tenantid);

-- ������ ta_tfundmanagerlist(������������Ʒ�б�)�ĵ�ǰ��
SELECT 'Create Table ta_tfundmanagerlist-������������Ʒ�б�...';
DROP TABLE IF EXISTS ta_tfundmanagerlist;
create table ta_tfundmanagerlist (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_managercode                  varchar(10)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tfundmanagerlist on ta_tfundmanagerlist(c_fundacco, c_identitype, c_identityno, c_custname, c_managercode, c_fundcode, c_tacode, c_tenantid);

-- ������ ta_tchangetimes(ת��������)�ĵ�ǰ��
SELECT 'Create Table ta_tchangetimes-ת��������...';
DROP TABLE IF EXISTS ta_tchangetimes;
create table ta_tchangetimes (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_othercode                    varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_othershare                   varchar(1)      DEFAULT ' '        NOT NULL,
    l_changetime                   int             DEFAULT 0          ,
    d_appenddate                   int             DEFAULT 0          ,
    l_lastchangetime               int             DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_fundcode, c_sharetype, c_othercode, c_othershare, c_tacode, c_tenantid)
);

-- ������ ta_tfaarlimit(�������Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tfaarlimit-�������Ʊ�...';
DROP TABLE IF EXISTS ta_tfaarlimit;
create table ta_tfaarlimit (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_faaragencytype               varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    f_maxallotbala                 decimal(16,2)   DEFAULT 0.0        ,
    c_largechangelimit             varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tfaarlimit on ta_tfaarlimit(c_fundcode, c_custtype, c_agencyno, c_faaragencytype, c_tenantid);

-- ������ ta_tbatchbookredeem(����ԤԼ������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tbatchbookredeem-����ԤԼ������ñ�...';
DROP TABLE IF EXISTS ta_tbatchbookredeem;
create table ta_tbatchbookredeem (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_startregistdate              int             DEFAULT 0          ,
    d_endregistdate                int             DEFAULT 0          ,
    d_redeemdate                   int             DEFAULT 0          ,
    c_flag                         varchar(1)      DEFAULT ' '        ,
    c_launchbydetail               varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tbatchbookredeem on ta_tbatchbookredeem(c_fundcode, d_redeemdate, c_agencyno, c_sharetype, c_tenantid);

-- ������ ta_tbackfundlist(���˲�Ʒ�б�)�ĵ�ǰ��
SELECT 'Create Table ta_tbackfundlist-���˲�Ʒ�б�...';
DROP TABLE IF EXISTS ta_tbackfundlist;
create table ta_tbackfundlist (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_isneedback                   varchar(1)      DEFAULT ' '        ,
    c_backflag                     varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_backtrgtype                  varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(d_cdate, c_fundcode, c_managercode, c_tacode, c_tenantid)
);

-- ������ ta_tbackagclist(�����̻����б�)�ĵ�ǰ��
SELECT 'Create Table ta_tbackagclist-�����̻����б�...';
DROP TABLE IF EXISTS ta_tbackagclist;
create table ta_tbackagclist (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(d_cdate, c_agencyno, c_tacode, c_tenantid, c_databaseno)
);

-- ������ ta_tbasebackagclist(���������̻����б�)�ĵ�ǰ��
SELECT 'Create Table ta_tbasebackagclist-���������̻����б�...';
DROP TABLE IF EXISTS ta_tbasebackagclist;
create table ta_tbasebackagclist (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(d_cdate, c_agencyno, c_tacode, c_tenantid)
);

-- ������ ta_tfundbackcrt(��Ʒ������ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundbackcrt-��Ʒ������ˮ��...';
DROP TABLE IF EXISTS ta_tfundbackcrt;
create table ta_tfundbackcrt (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    l_serialno                     bigint          NOT NULL AUTO_INCREMENT,
PRIMARY KEY(l_serialno)
);

-- ������ ta_tagcbackcrt(�����̻�����ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tagcbackcrt-�����̻�����ˮ��...';
DROP TABLE IF EXISTS ta_tagcbackcrt;
create table ta_tagcbackcrt (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    l_serialno                     bigint          NOT NULL AUTO_INCREMENT,
PRIMARY KEY(l_serialno)
);

-- ������ ta_tbackbatchlist(���������б�)�ĵ�ǰ��
SELECT 'Create Table ta_tbackbatchlist-���������б�...';
DROP TABLE IF EXISTS ta_tbackbatchlist;
create table ta_tbackbatchlist (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
    c_reqbackflag                  varchar(1)      DEFAULT ' '        ,
    c_fdybackflag                  varchar(1)      DEFAULT ' '        ,
    c_otcreqbackflag               varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(d_cdate, c_tacode, c_tenantid)
);

-- ������ ta_tbatchbackcrt(�����λ�����ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tbatchbackcrt-�����λ�����ˮ��...';
DROP TABLE IF EXISTS ta_tbatchbackcrt;
create table ta_tbatchbackcrt (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
    l_serialno                     bigint          NOT NULL AUTO_INCREMENT,
    l_backenddate                  int             DEFAULT 0          ,
    l_backendtime                  int             DEFAULT 0          ,
PRIMARY KEY(l_serialno)
);

-- ������ ta_tbakconfig(�������ñ�)�ĵ�ǰ��
SELECT 'Create Table ta_tbakconfig-�������ñ�...';
DROP TABLE IF EXISTS ta_tbakconfig;
create table ta_tbakconfig (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_tablename                    varchar(80)     DEFAULT ' '        ,
    c_tabletype                    varchar(1)      DEFAULT ' '        ,
    c_histablename                 varchar(80)     DEFAULT ' '        ,
    c_viewtablename                varchar(80)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);

-- ������ ta_taccorequest(�˻������)�ĵ�ǰ��
SELECT 'Create Table ta_taccorequest-�˻������...';
DROP TABLE IF EXISTS ta_taccorequest;
create table ta_taccorequest (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_taflag                       varchar(1)      DEFAULT '0'        ,
    c_address                      varchar(120)    DEFAULT ' '        ,
    c_instrepridcode               varchar(30)     DEFAULT ' '        ,
    c_instrepridtype               varchar(1)      DEFAULT ' '        ,
    c_lawname                      varchar(20)     DEFAULT ' '        ,
    d_lawidnovaliddate             int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_zipcode                      varchar(6)      DEFAULT ' '        ,
    c_contno                       varchar(30)     DEFAULT ' '        ,
    c_contype                      varchar(1)      DEFAULT ' '        ,
    c_contact                      varchar(20)     DEFAULT ' '        ,
    c_birthday                     varchar(8)      DEFAULT ' '        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_education                    varchar(3)      DEFAULT ' '        ,
    c_email                        varchar(40)     DEFAULT ' '        ,
    c_faxno                        varchar(24)     DEFAULT ' '        ,
    c_vocation                     varchar(3)      DEFAULT ' '        ,
    c_hometelno                    varchar(32)     DEFAULT ' '        ,
    c_annualearnings               varchar(8)      DEFAULT ' '        ,
    c_mobileno                     varchar(32)     DEFAULT ' '        ,
    c_corptel                      varchar(32)     DEFAULT ' '        ,
    c_shortname                    varchar(20)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_sex                          varchar(1)      DEFAULT ' '        ,
    c_phone                        varchar(32)     DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_minorflag                    varchar(1)      DEFAULT ' '        ,
    c_billsendflag                 varchar(1)      DEFAULT ' '        ,
    c_transacttype                 varchar(1)      DEFAULT ' '        ,
    c_shacco                       varchar(10)     DEFAULT ' '        ,
    c_szacco                       varchar(10)     DEFAULT ' '        ,
    c_newtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_nameinbank                   varchar(60)     DEFAULT ' '        ,
    c_bankacco                     varchar(30)     DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_deliverway                   varchar(8)      DEFAULT ' '        ,
    c_nationality                  varchar(3)      DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_corpname                     varchar(40)     DEFAULT ' '        ,
    d_idnovaliddate                int             DEFAULT 0          ,
    d_contidnovaliddate            int             DEFAULT 0          ,
    c_risklevel                    varchar(1)      DEFAULT ' '        ,
    c_managerange                  varchar(2)      DEFAULT ' '        ,
    c_controlholder                varchar(80)     DEFAULT ' '        ,
    c_actualcontroller             varchar(80)     DEFAULT ' '        ,
    c_marital                      varchar(1)      DEFAULT ' '        ,
    l_familynum                    int             DEFAULT 0          ,
    f_penates                      decimal(16,2)   DEFAULT 0.0        ,
    c_mediahobby                   varchar(1)      DEFAULT ' '        ,
    c_institutiontype              varchar(1)      DEFAULT ' '        ,
    c_englishfirstname             varchar(20)     DEFAULT ' '        ,
    c_englishfamilyname            varchar(20)     DEFAULT ' '        ,
    c_industry                     varchar(4)      DEFAULT ' '        ,
    c_companychar                  varchar(4)      DEFAULT ' '        ,
    f_employeenum                  decimal(16,2)   DEFAULT 0.0        ,
    c_hobbytype                    varchar(2)      DEFAULT ' '        ,
    c_province                     varchar(6)      DEFAULT ' '        ,
    c_city                         varchar(6)      DEFAULT ' '        ,
    c_county                       varchar(6)      DEFAULT ' '        ,
    c_recommender                  varchar(40)     DEFAULT ' '        ,
    c_recommendertype              varchar(1)      DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_contidcard18len              varchar(1)      DEFAULT ' '        ,
    c_callcenter                   varchar(1)      DEFAULT ' '        ,
    c_internet                     varchar(1)      DEFAULT ' '        ,
    c_billsendpass                 varchar(1)      DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cause                        varchar(4)      DEFAULT '0000'     ,
    c_lawidtype                    varchar(1)      DEFAULT ' '        ,
    c_lawidno                      varchar(30)     DEFAULT ' '        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_lawfileno                    varchar(128)    DEFAULT ' '        ,
    c_auditflag                    varchar(1)      DEFAULT ' '        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    d_cdate                        int             DEFAULT 0          ,
    c_oriidentityno                varchar(30)     DEFAULT ' '        ,
    c_oricontno                    varchar(30)     DEFAULT ' '        ,
    c_newbusinflag                 varchar(2)      DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_datasourceflag               varchar(1)      DEFAULT ' '        ,
    c_officalcode                  varchar(9)      DEFAULT ' '        ,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
    c_broadcastflag                varchar(1)      DEFAULT ' '        ,
    d_outputdate                   int             DEFAULT 0          ,
    c_accounttype                  varchar(1)      DEFAULT ' '        ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index uidx_taccorequest on ta_taccorequest(c_requestno, d_requestdate, c_agencyno, c_tacode, c_tenantid);
create index idx_taccorequest_idno on ta_taccorequest(c_identityno);
create index idx_taccorequest_trdacco on ta_taccorequest(c_tradeacco);
create index idx_taccorequest_date on ta_taccorequest(d_requestdate, c_agencyno);
create index idx_taccorequest_cdate on ta_taccorequest(d_cdate);

-- ������ ta_taccorequest_his(�˻������)�ĵ�ǰ��
SELECT 'Create Table ta_taccorequest_his-�˻������...';
DROP TABLE IF EXISTS ta_taccorequest_his;
create table ta_taccorequest_his (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_taflag                       varchar(1)      DEFAULT '0'        ,
    c_address                      varchar(120)    DEFAULT ' '        ,
    c_instrepridcode               varchar(30)     DEFAULT ' '        ,
    c_instrepridtype               varchar(1)      DEFAULT ' '        ,
    c_lawname                      varchar(20)     DEFAULT ' '        ,
    d_lawidnovaliddate             int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_zipcode                      varchar(6)      DEFAULT ' '        ,
    c_contno                       varchar(30)     DEFAULT ' '        ,
    c_contype                      varchar(1)      DEFAULT ' '        ,
    c_contact                      varchar(20)     DEFAULT ' '        ,
    c_birthday                     varchar(8)      DEFAULT ' '        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_education                    varchar(3)      DEFAULT ' '        ,
    c_email                        varchar(40)     DEFAULT ' '        ,
    c_faxno                        varchar(24)     DEFAULT ' '        ,
    c_vocation                     varchar(3)      DEFAULT ' '        ,
    c_hometelno                    varchar(32)     DEFAULT ' '        ,
    c_annualearnings               varchar(8)      DEFAULT ' '        ,
    c_mobileno                     varchar(32)     DEFAULT ' '        ,
    c_corptel                      varchar(32)     DEFAULT ' '        ,
    c_shortname                    varchar(20)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_sex                          varchar(1)      DEFAULT ' '        ,
    c_phone                        varchar(32)     DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_minorflag                    varchar(1)      DEFAULT ' '        ,
    c_billsendflag                 varchar(1)      DEFAULT ' '        ,
    c_transacttype                 varchar(1)      DEFAULT ' '        ,
    c_shacco                       varchar(10)     DEFAULT ' '        ,
    c_szacco                       varchar(10)     DEFAULT ' '        ,
    c_newtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_nameinbank                   varchar(60)     DEFAULT ' '        ,
    c_bankacco                     varchar(30)     DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_deliverway                   varchar(8)      DEFAULT ' '        ,
    c_nationality                  varchar(3)      DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_corpname                     varchar(40)     DEFAULT ' '        ,
    d_idnovaliddate                int             DEFAULT 0          ,
    d_contidnovaliddate            int             DEFAULT 0          ,
    c_risklevel                    varchar(1)      DEFAULT ' '        ,
    c_managerange                  varchar(2)      DEFAULT ' '        ,
    c_controlholder                varchar(80)     DEFAULT ' '        ,
    c_actualcontroller             varchar(80)     DEFAULT ' '        ,
    c_marital                      varchar(1)      DEFAULT ' '        ,
    l_familynum                    int             DEFAULT 0          ,
    f_penates                      decimal(16,2)   DEFAULT 0.0        ,
    c_mediahobby                   varchar(1)      DEFAULT ' '        ,
    c_institutiontype              varchar(1)      DEFAULT ' '        ,
    c_englishfirstname             varchar(20)     DEFAULT ' '        ,
    c_englishfamilyname            varchar(20)     DEFAULT ' '        ,
    c_industry                     varchar(4)      DEFAULT ' '        ,
    c_companychar                  varchar(4)      DEFAULT ' '        ,
    f_employeenum                  decimal(16,2)   DEFAULT 0.0        ,
    c_hobbytype                    varchar(2)      DEFAULT ' '        ,
    c_province                     varchar(6)      DEFAULT ' '        ,
    c_city                         varchar(6)      DEFAULT ' '        ,
    c_county                       varchar(6)      DEFAULT ' '        ,
    c_recommender                  varchar(40)     DEFAULT ' '        ,
    c_recommendertype              varchar(1)      DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_contidcard18len              varchar(1)      DEFAULT ' '        ,
    c_callcenter                   varchar(1)      DEFAULT ' '        ,
    c_internet                     varchar(1)      DEFAULT ' '        ,
    c_billsendpass                 varchar(1)      DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cause                        varchar(4)      DEFAULT '0000'     ,
    c_lawidtype                    varchar(1)      DEFAULT ' '        ,
    c_lawidno                      varchar(30)     DEFAULT ' '        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_lawfileno                    varchar(128)    DEFAULT ' '        ,
    c_auditflag                    varchar(1)      DEFAULT ' '        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    d_cdate                        int             DEFAULT 0          ,
    c_oriidentityno                varchar(30)     DEFAULT ' '        ,
    c_oricontno                    varchar(30)     DEFAULT ' '        ,
    c_newbusinflag                 varchar(2)      DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_datasourceflag               varchar(1)      DEFAULT ' '        ,
    c_officalcode                  varchar(9)      DEFAULT ' '        ,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
    c_broadcastflag                varchar(1)      DEFAULT ' '        ,
    d_outputdate                   int             DEFAULT 0          ,
    c_accounttype                  varchar(1)      DEFAULT ' '        ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index uidx_taccorequest_0 on ta_taccorequest_his(c_requestno, d_requestdate, c_agencyno, c_tacode, c_tenantid);
create index idx_taccorequest_idno_0 on ta_taccorequest_his(c_identityno);
create index idx_taccorequest_trdacco_0 on ta_taccorequest_his(c_tradeacco);
create index idx_taccorequest_date_0 on ta_taccorequest_his(d_requestdate, c_agencyno);
create index idx_taccorequest_cdate_0 on ta_taccorequest_his(d_cdate);

-- ������ ta_taccoconfirm(�˻�ȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_taccoconfirm-�˻�ȷ�ϱ�...';
DROP TABLE IF EXISTS ta_taccoconfirm;
create table ta_taccoconfirm (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_shortname                    varchar(20)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    d_idnovaliddate                int             DEFAULT 0          ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_zipcode                      varchar(6)      DEFAULT ' '        ,
    c_address                      varchar(120)    DEFAULT ' '        ,
    c_phone                        varchar(32)     DEFAULT ' '        ,
    c_faxno                        varchar(24)     DEFAULT ' '        ,
    c_mobileno                     varchar(32)     DEFAULT ' '        ,
    c_email                        varchar(40)     DEFAULT ' '        ,
    c_sex                          varchar(1)      DEFAULT ' '        ,
    c_birthday                     varchar(8)      DEFAULT ' '        ,
    c_vocation                     varchar(3)      DEFAULT ' '        ,
    c_education                    varchar(3)      DEFAULT ' '        ,
    c_annualearnings               varchar(8)      DEFAULT ' '        ,
    c_corpname                     varchar(40)     DEFAULT ' '        ,
    c_corptel                      varchar(32)     DEFAULT ' '        ,
    c_contact                      varchar(20)     DEFAULT ' '        ,
    c_contype                      varchar(1)      DEFAULT ' '        ,
    c_contno                       varchar(30)     DEFAULT ' '        ,
    c_contidcard18len              varchar(1)      DEFAULT ' '        ,
    c_billsendflag                 varchar(1)      DEFAULT ' '        ,
    c_callcenter                   varchar(1)      DEFAULT ' '        ,
    c_internet                     varchar(1)      DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_billsendpass                 varchar(1)      DEFAULT ' '        ,
    c_lawname                      varchar(20)     DEFAULT ' '        ,
    c_lawidtype                    varchar(1)      DEFAULT ' '        ,
    c_lawidno                      varchar(30)     DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_bankacco                     varchar(30)     DEFAULT ' '        ,
    c_nameinbank                   varchar(60)     DEFAULT ' '        ,
    c_accounttype                  varchar(1)      DEFAULT ' '        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_recommender                  varchar(40)     DEFAULT ' '        ,
    c_recommendertype              varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    c_lawfileno                    varchar(128)    DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_newtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_deliverway                   varchar(8)      DEFAULT ' '        ,
    c_taflag                       varchar(1)      DEFAULT ' '        ,
    c_auditflag                    varchar(1)      DEFAULT ' '        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    d_outputdate                   int             DEFAULT 0          ,
    c_broadcastflag                varchar(1)      DEFAULT ' '        ,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
    c_instrepridcode               varchar(30)     DEFAULT ' '        ,
    c_instrepridtype               varchar(1)      DEFAULT ' '        ,
    c_hometelno                    varchar(32)     DEFAULT ' '        ,
    c_shacco                       varchar(10)     DEFAULT ' '        ,
    c_szacco                       varchar(10)     DEFAULT ' '        ,
    c_minorflag                    varchar(1)      DEFAULT ' '        ,
    c_transacttype                 varchar(1)      DEFAULT ' '        ,
    d_contidnovaliddate            int             DEFAULT 0          ,
    d_lawidnovaliddate             int             DEFAULT 0          ,
    c_risklevel                    varchar(1)      DEFAULT ' '        ,
    c_managerange                  varchar(2)      DEFAULT ' '        ,
    c_controlholder                varchar(80)     DEFAULT ' '        ,
    c_actualcontroller             varchar(80)     DEFAULT ' '        ,
    c_marital                      varchar(1)      DEFAULT ' '        ,
    l_familynum                    int             DEFAULT 0          ,
    f_penates                      decimal(16,2)   DEFAULT 0.0        ,
    c_mediahobby                   varchar(1)      DEFAULT ' '        ,
    c_institutiontype              varchar(1)      DEFAULT ' '        ,
    c_englishfirstname             varchar(20)     DEFAULT ' '        ,
    c_englishfamilyname            varchar(20)     DEFAULT ' '        ,
    c_industry                     varchar(4)      DEFAULT ' '        ,
    c_companychar                  varchar(4)      DEFAULT ' '        ,
    f_employeenum                  decimal(16,2)   DEFAULT 0.0        ,
    c_hobbytype                    varchar(2)      DEFAULT ' '        ,
    c_province                     varchar(6)      DEFAULT ' '        ,
    c_city                         varchar(6)      DEFAULT ' '        ,
    c_county                       varchar(6)      DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_nationality                  varchar(3)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_officalcode                  varchar(9)      DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    c_oriidentityno                varchar(30)     DEFAULT ' '        ,
    c_oricontno                    varchar(30)     DEFAULT ' '        ,
    c_newbusinflag                 varchar(2)      DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_datasourceflag               varchar(1)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        
);
create index pk_taccoconfirm on ta_taccoconfirm(c_requestno, c_agencyno, d_requestdate, c_tacode, c_tenantid);
create index idx_taccoconfirm_cdate on ta_taccoconfirm(d_cdate, c_tenantid);
create index idx_taccoconfirm_fundacco on ta_taccoconfirm(c_fundacco, c_tenantid);
create index idx_taccoconfirm_id on ta_taccoconfirm(c_identityno, c_identitype, c_tenantid);
create index idx_taccoconfirm_outdate on ta_taccoconfirm(d_outputdate, c_tenantid);
create index idx_taccoconfirm_agc on ta_taccoconfirm(c_agencyno);
create index idx_taccoconfirm_tenantid on ta_taccoconfirm(c_tenantid, c_tacode);
create index uidx_accoconfirm_cserialno on ta_taccoconfirm(c_cserialno, c_tenantid);

-- ������ ta_taccoconfirm_his(�˻�ȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_taccoconfirm_his-�˻�ȷ�ϱ�...';
DROP TABLE IF EXISTS ta_taccoconfirm_his;
create table ta_taccoconfirm_his (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_shortname                    varchar(20)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    d_idnovaliddate                int             DEFAULT 0          ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_zipcode                      varchar(6)      DEFAULT ' '        ,
    c_address                      varchar(120)    DEFAULT ' '        ,
    c_phone                        varchar(32)     DEFAULT ' '        ,
    c_faxno                        varchar(24)     DEFAULT ' '        ,
    c_mobileno                     varchar(32)     DEFAULT ' '        ,
    c_email                        varchar(40)     DEFAULT ' '        ,
    c_sex                          varchar(1)      DEFAULT ' '        ,
    c_birthday                     varchar(8)      DEFAULT ' '        ,
    c_vocation                     varchar(3)      DEFAULT ' '        ,
    c_education                    varchar(3)      DEFAULT ' '        ,
    c_annualearnings               varchar(8)      DEFAULT ' '        ,
    c_corpname                     varchar(40)     DEFAULT ' '        ,
    c_corptel                      varchar(32)     DEFAULT ' '        ,
    c_contact                      varchar(20)     DEFAULT ' '        ,
    c_contype                      varchar(1)      DEFAULT ' '        ,
    c_contno                       varchar(30)     DEFAULT ' '        ,
    c_contidcard18len              varchar(1)      DEFAULT ' '        ,
    c_billsendflag                 varchar(1)      DEFAULT ' '        ,
    c_callcenter                   varchar(1)      DEFAULT ' '        ,
    c_internet                     varchar(1)      DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_billsendpass                 varchar(1)      DEFAULT ' '        ,
    c_lawname                      varchar(20)     DEFAULT ' '        ,
    c_lawidtype                    varchar(1)      DEFAULT ' '        ,
    c_lawidno                      varchar(30)     DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_bankacco                     varchar(30)     DEFAULT ' '        ,
    c_nameinbank                   varchar(60)     DEFAULT ' '        ,
    c_accounttype                  varchar(1)      DEFAULT ' '        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_recommender                  varchar(40)     DEFAULT ' '        ,
    c_recommendertype              varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    c_lawfileno                    varchar(128)    DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_newtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_deliverway                   varchar(8)      DEFAULT ' '        ,
    c_taflag                       varchar(1)      DEFAULT ' '        ,
    c_auditflag                    varchar(1)      DEFAULT ' '        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    d_outputdate                   int             DEFAULT 0          ,
    c_broadcastflag                varchar(1)      DEFAULT ' '        ,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
    c_instrepridcode               varchar(30)     DEFAULT ' '        ,
    c_instrepridtype               varchar(1)      DEFAULT ' '        ,
    c_hometelno                    varchar(32)     DEFAULT ' '        ,
    c_shacco                       varchar(10)     DEFAULT ' '        ,
    c_szacco                       varchar(10)     DEFAULT ' '        ,
    c_minorflag                    varchar(1)      DEFAULT ' '        ,
    c_transacttype                 varchar(1)      DEFAULT ' '        ,
    d_contidnovaliddate            int             DEFAULT 0          ,
    d_lawidnovaliddate             int             DEFAULT 0          ,
    c_risklevel                    varchar(1)      DEFAULT ' '        ,
    c_managerange                  varchar(2)      DEFAULT ' '        ,
    c_controlholder                varchar(80)     DEFAULT ' '        ,
    c_actualcontroller             varchar(80)     DEFAULT ' '        ,
    c_marital                      varchar(1)      DEFAULT ' '        ,
    l_familynum                    int             DEFAULT 0          ,
    f_penates                      decimal(16,2)   DEFAULT 0.0        ,
    c_mediahobby                   varchar(1)      DEFAULT ' '        ,
    c_institutiontype              varchar(1)      DEFAULT ' '        ,
    c_englishfirstname             varchar(20)     DEFAULT ' '        ,
    c_englishfamilyname            varchar(20)     DEFAULT ' '        ,
    c_industry                     varchar(4)      DEFAULT ' '        ,
    c_companychar                  varchar(4)      DEFAULT ' '        ,
    f_employeenum                  decimal(16,2)   DEFAULT 0.0        ,
    c_hobbytype                    varchar(2)      DEFAULT ' '        ,
    c_province                     varchar(6)      DEFAULT ' '        ,
    c_city                         varchar(6)      DEFAULT ' '        ,
    c_county                       varchar(6)      DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_nationality                  varchar(3)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_officalcode                  varchar(9)      DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    c_oriidentityno                varchar(30)     DEFAULT ' '        ,
    c_oricontno                    varchar(30)     DEFAULT ' '        ,
    c_newbusinflag                 varchar(2)      DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_datasourceflag               varchar(1)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        
);
create index pk_taccoconfirm_0 on ta_taccoconfirm_his(c_requestno, c_agencyno, d_requestdate, c_tacode, c_tenantid);
create index idx_taccoconfirm_cdate_0 on ta_taccoconfirm_his(d_cdate, c_tenantid);
create index idx_taccoconfirm_fundacco_0 on ta_taccoconfirm_his(c_fundacco, c_tenantid);
create index idx_taccoconfirm_id_0 on ta_taccoconfirm_his(c_identityno, c_identitype, c_tenantid);
create index idx_taccoconfirm_outdate_0 on ta_taccoconfirm_his(d_outputdate, c_tenantid);
create index idx_taccoconfirm_agc_0 on ta_taccoconfirm_his(c_agencyno);
create index idx_taccoconfirm_tenantid_0 on ta_taccoconfirm_his(c_tenantid, c_tacode);
create index uidx_accoconfirm_cserialno_0 on ta_taccoconfirm_his(c_cserialno, c_tenantid);

-- ������ ta_trequest(���������)�ĵ�ǰ��
SELECT 'Create Table ta_trequest-���������...';
DROP TABLE IF EXISTS ta_trequest;
create table ta_trequest (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    d_requesttime                  int             DEFAULT 0          ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    f_agio                         decimal(5,4)    DEFAULT 1.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    d_hopedate                     int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    f_totalbackendload             decimal(16,2)   DEFAULT 0.0        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_factdate                     int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_rationvariety                varchar(5)      DEFAULT ' '        ,
    c_rationserialno               varchar(5)      DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    c_protocolno                   varchar(20)     DEFAULT ' '        ,
    d_protocolbegindate            int             DEFAULT 0          ,
    d_protocolenddate              int             DEFAULT 0          ,
    l_rationdate                   int             DEFAULT 0          ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_rationpurpose                varchar(40)     DEFAULT ' '        ,
    l_rationfrequency              int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    c_rationtimeunit               varchar(1)      DEFAULT ' '        ,
    f_rationnum                    decimal(16,2)   DEFAULT 0.0        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 1.0        ,
    c_combcode                     varchar(6)      DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    f_oriagio                      decimal(5,4)    DEFAULT 1.0        ,
    c_taflag                       varchar(1)      DEFAULT '0'        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cause                        varchar(4)      DEFAULT '0000'     ,
    d_date                         int             DEFAULT 0          ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    d_cdate                        int             DEFAULT 0          ,
    f_confirmratio                 decimal(9,8)    DEFAULT 1.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    c_freezeno                     varchar(128)    DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_improperredeem               varchar(1)      DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    d_registdate                   int             DEFAULT 0          ,
    f_confirmedbalance             decimal(16,2)   DEFAULT 0.0        ,
    f_confirmedshares              decimal(16,2)   DEFAULT 0.0        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_nodealflag                   varchar(1)      DEFAULT '0'        ,
    f_reqrdmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_manualtradefare              decimal(16,2)   DEFAULT 0.0        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index uidx_trequest on ta_trequest(c_requestno, d_requestdate, c_agencyno, c_tacode, c_tenantid);
create index idx_request on ta_trequest(c_fundacco, c_businflag, c_tacode, c_tenantid);
create index idx_trequest_fnd on ta_trequest(c_fundcode);
create index idx_trequest_date on ta_trequest(d_date);
create index idx_trequest_biz on ta_trequest(c_businflag, c_chkstatus);
create index idx_trequest_cdate on ta_trequest(d_cdate);

-- ������ ta_trequest_his(���������)�ĵ�ǰ��
SELECT 'Create Table ta_trequest_his-���������...';
DROP TABLE IF EXISTS ta_trequest_his;
create table ta_trequest_his (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    d_requesttime                  int             DEFAULT 0          ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    f_agio                         decimal(5,4)    DEFAULT 1.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    d_hopedate                     int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    f_totalbackendload             decimal(16,2)   DEFAULT 0.0        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_factdate                     int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_rationvariety                varchar(5)      DEFAULT ' '        ,
    c_rationserialno               varchar(5)      DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    c_protocolno                   varchar(20)     DEFAULT ' '        ,
    d_protocolbegindate            int             DEFAULT 0          ,
    d_protocolenddate              int             DEFAULT 0          ,
    l_rationdate                   int             DEFAULT 0          ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_rationpurpose                varchar(40)     DEFAULT ' '        ,
    l_rationfrequency              int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    c_rationtimeunit               varchar(1)      DEFAULT ' '        ,
    f_rationnum                    decimal(16,2)   DEFAULT 0.0        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 1.0        ,
    c_combcode                     varchar(6)      DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    f_oriagio                      decimal(5,4)    DEFAULT 1.0        ,
    c_taflag                       varchar(1)      DEFAULT '0'        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cause                        varchar(4)      DEFAULT '0000'     ,
    d_date                         int             DEFAULT 0          ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    d_cdate                        int             DEFAULT 0          ,
    f_confirmratio                 decimal(9,8)    DEFAULT 1.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    c_freezeno                     varchar(128)    DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_improperredeem               varchar(1)      DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    d_registdate                   int             DEFAULT 0          ,
    f_confirmedbalance             decimal(16,2)   DEFAULT 0.0        ,
    f_confirmedshares              decimal(16,2)   DEFAULT 0.0        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_nodealflag                   varchar(1)      DEFAULT '0'        ,
    f_reqrdmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_manualtradefare              decimal(16,2)   DEFAULT 0.0        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index uidx_trequest_0 on ta_trequest_his(c_requestno, d_requestdate, c_agencyno, c_tacode, c_tenantid);
create index idx_request_0 on ta_trequest_his(c_fundacco, c_businflag, c_tacode, c_tenantid);
create index idx_trequest_fnd_0 on ta_trequest_his(c_fundcode);
create index idx_trequest_date_0 on ta_trequest_his(d_date);
create index idx_trequest_biz_0 on ta_trequest_his(c_businflag, c_chkstatus);
create index idx_trequest_cdate_0 on ta_trequest_his(d_cdate);

-- ������ ta_tconfirm(����ȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirm-����ȷ�ϱ�...';
DROP TABLE IF EXISTS ta_tconfirm;
create table ta_tconfirm (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
    f_interest                     decimal(16,2)   DEFAULT 0.0        ,
    f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
    f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
    f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
    c_taflag                       varchar(1)      DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_requestendflag               varchar(1)      DEFAULT '0'        ,
    f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
    f_chshare                      decimal(16,2)   DEFAULT 0.0        ,
    f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    f_confirmratio                 decimal(9,8)    DEFAULT 1.0        ,
    f_oritradefare                 decimal(16,2)   DEFAULT 0.0        ,
    f_oritafare                    decimal(16,2)   DEFAULT 0.0        ,
    f_oribackfare                  decimal(16,2)   DEFAULT 0.0        ,
    f_oriotherfare1                decimal(16,2)   DEFAULT 0.0        ,
    f_oribreachfare                decimal(16,2)   DEFAULT 0.0        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    d_hopedate                     int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_freezeno                     varchar(128)    DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_protocolno                   varchar(20)     DEFAULT ' '        ,
    l_rationdate                   int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    d_protocolenddate              int             DEFAULT 0          ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_bourseflag                   varchar(1)      DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    c_combcode                     varchar(6)      DEFAULT ' '        ,
    f_returnfare                   decimal(16,2)   DEFAULT 0.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_auditflag                    varchar(1)      DEFAULT ' '        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    c_improperredeem               varchar(1)      DEFAULT ' '        ,
    f_punishratio                  decimal(5,4)    DEFAULT 0.0        ,
    c_maintradeacco                varchar(24)     DEFAULT ' '        ,
    d_registdate                   int             DEFAULT 0          ,
    d_originaldate                 int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    c_orifundcode                  varchar(6)      DEFAULT ' '        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_rationvariety                varchar(5)      DEFAULT ' '        ,
    c_rationserialno               varchar(5)      DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    d_protocolbegindate            int             DEFAULT 0          ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_rationpurpose                varchar(40)     DEFAULT ' '        ,
    l_rationfrequency              int             DEFAULT 0          ,
    c_rationtimeunit               varchar(1)      DEFAULT ' '        ,
    f_rationnum                    decimal(16,2)   DEFAULT 0.0        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    d_factdate                     int             DEFAULT 0          ,
    d_outputdate                   int             DEFAULT 0          ,
    d_reqoutputdate                int             DEFAULT 0          ,
    f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
    c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
    f_deductmngfare                decimal(16,2)   DEFAULT 0.0        ,
    f_rshares_ch                   decimal(16,2)   DEFAULT 0.0        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    f_reqrdmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
    c_chkstatus                    varchar(1)      DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    c_shareclass                   varchar(1)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 0.0        ,
    f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
    f_oribackfareagio              decimal(5,4)    DEFAULT 0.0        ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tconfirm_busin on ta_tconfirm(c_businflag, c_tenantid);
create index idx_tconfirm_cdate on ta_tconfirm(d_cdate, c_tenantid);
create index idx_tconfirm_fundacco on ta_tconfirm(c_fundacco, c_tenantid);
create index idx_tconfirm_fundcode on ta_tconfirm(c_fundcode, c_tenantid);
create index idx_tconfirm_reqdate on ta_tconfirm(d_requestdate, c_tenantid);
create index idx_tconfirm_outdate on ta_tconfirm(d_outputdate, c_tenantid);
create index uidx_tconfirm_requestno on ta_tconfirm(c_requestno, c_tacode, c_tenantid);

-- ������ sett_ta_tconfirm(����ȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table sett_ta_tconfirm-����ȷ�ϱ�...';
DROP TABLE IF EXISTS sett_ta_tconfirm;
create table sett_ta_tconfirm (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
    f_interest                     decimal(16,2)   DEFAULT 0.0        ,
    f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
    f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
    f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
    c_taflag                       varchar(1)      DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_requestendflag               varchar(1)      DEFAULT '0'        ,
    f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
    f_chshare                      decimal(16,2)   DEFAULT 0.0        ,
    f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    f_confirmratio                 decimal(9,8)    DEFAULT 1.0        ,
    f_oritradefare                 decimal(16,2)   DEFAULT 0.0        ,
    f_oritafare                    decimal(16,2)   DEFAULT 0.0        ,
    f_oribackfare                  decimal(16,2)   DEFAULT 0.0        ,
    f_oriotherfare1                decimal(16,2)   DEFAULT 0.0        ,
    f_oribreachfare                decimal(16,2)   DEFAULT 0.0        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    d_hopedate                     int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_freezeno                     varchar(128)    DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_protocolno                   varchar(20)     DEFAULT ' '        ,
    l_rationdate                   int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    d_protocolenddate              int             DEFAULT 0          ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_bourseflag                   varchar(1)      DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    c_combcode                     varchar(6)      DEFAULT ' '        ,
    f_returnfare                   decimal(16,2)   DEFAULT 0.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_auditflag                    varchar(1)      DEFAULT ' '        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    c_improperredeem               varchar(1)      DEFAULT ' '        ,
    f_punishratio                  decimal(5,4)    DEFAULT 0.0        ,
    c_maintradeacco                varchar(24)     DEFAULT ' '        ,
    d_registdate                   int             DEFAULT 0          ,
    d_originaldate                 int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    c_orifundcode                  varchar(6)      DEFAULT ' '        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_rationvariety                varchar(5)      DEFAULT ' '        ,
    c_rationserialno               varchar(5)      DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    d_protocolbegindate            int             DEFAULT 0          ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_rationpurpose                varchar(40)     DEFAULT ' '        ,
    l_rationfrequency              int             DEFAULT 0          ,
    c_rationtimeunit               varchar(1)      DEFAULT ' '        ,
    f_rationnum                    decimal(16,2)   DEFAULT 0.0        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    d_factdate                     int             DEFAULT 0          ,
    d_outputdate                   int             DEFAULT 0          ,
    d_reqoutputdate                int             DEFAULT 0          ,
    f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
    c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
    f_deductmngfare                decimal(16,2)   DEFAULT 0.0        ,
    f_rshares_ch                   decimal(16,2)   DEFAULT 0.0        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    f_reqrdmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
    c_chkstatus                    varchar(1)      DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    c_shareclass                   varchar(1)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 0.0        ,
    f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
    f_oribackfareagio              decimal(5,4)    DEFAULT 0.0        ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tconfirm_busin_0 on sett_ta_tconfirm(c_businflag, c_tenantid);
create index idx_tconfirm_cdate_0 on sett_ta_tconfirm(d_cdate, c_tenantid);
create index idx_tconfirm_fundacco_0 on sett_ta_tconfirm(c_fundacco, c_tenantid);
create index idx_tconfirm_fundcode_0 on sett_ta_tconfirm(c_fundcode, c_tenantid);
create index idx_tconfirm_reqdate_0 on sett_ta_tconfirm(d_requestdate, c_tenantid);
create index idx_tconfirm_outdate_0 on sett_ta_tconfirm(d_outputdate, c_tenantid);
create index uidx_tconfirm_requestno_0 on sett_ta_tconfirm(c_requestno, c_tacode, c_tenantid);

-- ������ ta_tconfirm_his(����ȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirm_his-����ȷ�ϱ�...';
DROP TABLE IF EXISTS ta_tconfirm_his;
create table ta_tconfirm_his (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
    f_interest                     decimal(16,2)   DEFAULT 0.0        ,
    f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
    f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
    f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
    c_taflag                       varchar(1)      DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_requestendflag               varchar(1)      DEFAULT '0'        ,
    f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
    f_chshare                      decimal(16,2)   DEFAULT 0.0        ,
    f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    f_confirmratio                 decimal(9,8)    DEFAULT 1.0        ,
    f_oritradefare                 decimal(16,2)   DEFAULT 0.0        ,
    f_oritafare                    decimal(16,2)   DEFAULT 0.0        ,
    f_oribackfare                  decimal(16,2)   DEFAULT 0.0        ,
    f_oriotherfare1                decimal(16,2)   DEFAULT 0.0        ,
    f_oribreachfare                decimal(16,2)   DEFAULT 0.0        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    d_hopedate                     int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_freezeno                     varchar(128)    DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_protocolno                   varchar(20)     DEFAULT ' '        ,
    l_rationdate                   int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    d_protocolenddate              int             DEFAULT 0          ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_bourseflag                   varchar(1)      DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    c_combcode                     varchar(6)      DEFAULT ' '        ,
    f_returnfare                   decimal(16,2)   DEFAULT 0.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_auditflag                    varchar(1)      DEFAULT ' '        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    c_improperredeem               varchar(1)      DEFAULT ' '        ,
    f_punishratio                  decimal(5,4)    DEFAULT 0.0        ,
    c_maintradeacco                varchar(24)     DEFAULT ' '        ,
    d_registdate                   int             DEFAULT 0          ,
    d_originaldate                 int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    c_orifundcode                  varchar(6)      DEFAULT ' '        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_rationvariety                varchar(5)      DEFAULT ' '        ,
    c_rationserialno               varchar(5)      DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    d_protocolbegindate            int             DEFAULT 0          ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_rationpurpose                varchar(40)     DEFAULT ' '        ,
    l_rationfrequency              int             DEFAULT 0          ,
    c_rationtimeunit               varchar(1)      DEFAULT ' '        ,
    f_rationnum                    decimal(16,2)   DEFAULT 0.0        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    d_factdate                     int             DEFAULT 0          ,
    d_outputdate                   int             DEFAULT 0          ,
    d_reqoutputdate                int             DEFAULT 0          ,
    f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
    c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
    f_deductmngfare                decimal(16,2)   DEFAULT 0.0        ,
    f_rshares_ch                   decimal(16,2)   DEFAULT 0.0        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    f_reqrdmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_protectbalance               decimal(16,2)   DEFAULT 0.0        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
    c_chkstatus                    varchar(1)      DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    c_shareclass                   varchar(1)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 0.0        ,
    f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
    f_oribackfareagio              decimal(5,4)    DEFAULT 0.0        ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tconfirm_busin_1 on ta_tconfirm_his(c_businflag, c_tenantid);
create index idx_tconfirm_cdate_1 on ta_tconfirm_his(d_cdate, c_tenantid);
create index idx_tconfirm_fundacco_1 on ta_tconfirm_his(c_fundacco, c_tenantid);
create index idx_tconfirm_fundcode_1 on ta_tconfirm_his(c_fundcode, c_tenantid);
create index idx_tconfirm_reqdate_1 on ta_tconfirm_his(d_requestdate, c_tenantid);
create index idx_tconfirm_outdate_1 on ta_tconfirm_his(d_outputdate, c_tenantid);
create index uidx_tconfirm_requestno_1 on ta_tconfirm_his(c_requestno, c_tacode, c_tenantid);

-- ������ ta_tconfirmdetail(����ȷ����ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirmdetail-����ȷ����ϸ��...';
DROP TABLE IF EXISTS ta_tconfirmdetail;
create table ta_tconfirmdetail (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialnototal               varchar(20)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    d_registdate                   int             DEFAULT 0          ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_apportionfare                decimal(16,2)   DEFAULT 0.0        ,
    f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
    f_assignedincome               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
    f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_fundtraderatio               decimal(9,8)    DEFAULT 0.0        ,
    c_cserialnoout                 varchar(20)     DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tconfirmdetail_acco on ta_tconfirmdetail(c_fundacco, c_tenantid);
create index idx_tconfirmdetail_totalno on ta_tconfirmdetail(c_cserialnototal, c_tenantid);
create index idx_tconfirmdetail_cdate on ta_tconfirmdetail(d_cdate);

-- ������ ta_tconfirmdetail_his(����ȷ����ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirmdetail_his-����ȷ����ϸ��...';
DROP TABLE IF EXISTS ta_tconfirmdetail_his;
create table ta_tconfirmdetail_his (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialnototal               varchar(20)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    d_registdate                   int             DEFAULT 0          ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_apportionfare                decimal(16,2)   DEFAULT 0.0        ,
    f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
    f_assignedincome               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
    f_fundfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_fundtraderatio               decimal(9,8)    DEFAULT 0.0        ,
    c_cserialnoout                 varchar(20)     DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tconfirmdetail_acco_0 on ta_tconfirmdetail_his(c_fundacco, c_tenantid);
create index idx_tconfirmdetail_totalno_0 on ta_tconfirmdetail_his(c_cserialnototal, c_tenantid);
create index idx_tconfirmdetail_cdate_0 on ta_tconfirmdetail_his(d_cdate);

-- ������ ta_tsubsconfirm(�Ϲ�ȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tsubsconfirm-�Ϲ�ȷ�ϱ�...';
DROP TABLE IF EXISTS ta_tsubsconfirm;
create table ta_tsubsconfirm (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
    c_bourseflag                   varchar(1)      DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    f_oricfmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_orireqshares                 decimal(16,2)   DEFAULT 0.0        ,
    f_totalbackendload             decimal(16,2)   DEFAULT 0.0        ,
    f_confirmratio                 decimal(9,8)    DEFAULT 0.0        ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    l_pageno                       int             DEFAULT 0          ,
    c_dealstatus                   varchar(1)      DEFAULT ' '        ,
    f_manualtradefare              decimal(16,2)   DEFAULT 0.0        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tsubsconfirm_fundcode on ta_tsubsconfirm(c_fundcode, c_fundacco);
create index idx_tsubsconfirm_cdate on ta_tsubsconfirm(d_cdate, c_fundcode);

-- ������ ta_tverification(�������ݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tverification-�������ݱ�...';
DROP TABLE IF EXISTS ta_tverification;
create table ta_tverification (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_interest                     decimal(16,2)   DEFAULT 0.0        ,
    f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_custno                       varchar(12)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
    f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 0.0        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
    f_confirmratio                 decimal(9,8)    DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
    f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
    f_oriagio                      decimal(5,4)    DEFAULT 0.0        ,
    f_oribackfare                  decimal(16,2)   DEFAULT 0.0        ,
    f_oribreachfare                decimal(16,2)   DEFAULT 0.0        ,
    f_oriotherfare1                decimal(16,2)   DEFAULT 0.0        ,
    f_oritafare                    decimal(16,2)   DEFAULT 0.0        ,
    f_oritradefare                 decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
    f_punishratio                  decimal(5,4)    DEFAULT 0.0        ,
    f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
    f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
    f_lastshares                   decimal(16,2)   DEFAULT 0.0        ,
    f_lastfreezeshares             decimal(16,2)   DEFAULT 0.0        ,
    f_purchaseratio                decimal(9,8)    DEFAULT 0.0        ,
    f_agencyratio                  decimal(9,8)    DEFAULT 0.0        ,
    f_traderatio                   decimal(9,8)    DEFAULT 0.0        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    f_evennetvalue                 decimal(7,4)    DEFAULT 0.0        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tverification_6ele on ta_tverification(c_fundacco, c_tradeacco, c_fundcode);

-- ������ ta_totherrequest(�������������)�ĵ�ǰ��
SELECT 'Create Table ta_totherrequest-�������������...';
DROP TABLE IF EXISTS ta_totherrequest;
create table ta_totherrequest (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_stockacco                    varchar(10)     DEFAULT ' '        ,
    c_seat                         varchar(6)      DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_phone                        varchar(32)     DEFAULT ' '        ,
    c_mobileno                     varchar(32)     DEFAULT ' '        ,
    c_address                      varchar(120)    DEFAULT ' '        ,
    c_zipcode                      varchar(6)      DEFAULT ' '        ,
    c_email                        varchar(40)     DEFAULT ' '        ,
    c_contact                      varchar(20)     DEFAULT ' '        ,
    c_contype                      varchar(1)      DEFAULT ' '        ,
    c_contno                       varchar(30)     DEFAULT ' '        ,
    c_bankacco                     varchar(30)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(d_date, c_agencyno, c_requestno, c_tenantid)
);
create index idx_totherrequest_date on ta_totherrequest(d_date, c_tenantid);

-- ������ ta_tration(���ڶ���Э���)�ĵ�ǰ��
SELECT 'Create Table ta_tration-���ڶ���Э���...';
DROP TABLE IF EXISTS ta_tration;
create table ta_tration (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_rationno                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    d_date                         int             DEFAULT 0          ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    l_rationdate                   int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    d_protocolenddate              int             DEFAULT 0          ,
    l_delay                        int             DEFAULT 0          ,
    l_allowfail                    int             DEFAULT 0          ,
    d_lastdate                     int             DEFAULT 0          ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
    c_flag                         varchar(1)      DEFAULT ' '        ,
    l_times                        int             DEFAULT 0          ,
    f_totalallotbalance            decimal(16,2)   DEFAULT 0.0        ,
    f_totalreedemshares            decimal(16,2)   DEFAULT 0.0        ,
    c_defaultrationflag            varchar(1)      DEFAULT ' '        ,
    d_lastrequestdate              int             DEFAULT 0          ,
    f_realagio                     decimal(5,4)    DEFAULT 0.0        ,
    d_firstconfirmdate             int             DEFAULT 0          ,
    f_oribalance                   decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundacco, c_rationno, c_tradeacco, c_agencyno, c_netno, c_fundcode, c_sharetype, c_tenantid)
);

-- ������ ta_tration_bak(���ڶ���Э���)�ĵ�ǰ��
SELECT 'Create Table ta_tration_bak-���ڶ���Э���...';
DROP TABLE IF EXISTS ta_tration_bak;
create table ta_tration_bak (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_rationno                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    d_date                         int             DEFAULT 0          ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    l_rationdate                   int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    d_protocolenddate              int             DEFAULT 0          ,
    l_delay                        int             DEFAULT 0          ,
    l_allowfail                    int             DEFAULT 0          ,
    d_lastdate                     int             DEFAULT 0          ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
    c_flag                         varchar(1)      DEFAULT ' '        ,
    l_times                        int             DEFAULT 0          ,
    f_totalallotbalance            decimal(16,2)   DEFAULT 0.0        ,
    f_totalreedemshares            decimal(16,2)   DEFAULT 0.0        ,
    c_defaultrationflag            varchar(1)      DEFAULT ' '        ,
    d_lastrequestdate              int             DEFAULT 0          ,
    f_realagio                     decimal(5,4)    DEFAULT 0.0        ,
    d_firstconfirmdate             int             DEFAULT 0          ,
    f_oribalance                   decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundacco, c_rationno, c_tradeacco, c_agencyno, c_netno, c_fundcode, c_sharetype, c_tenantid)
);

-- ������ ta_tbasesharestat(�ֿ�����ݶ�ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tbasesharestat-�ֿ�����ݶ�ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tbasesharestat;
create table ta_tbasesharestat (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
    c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_flowstep, c_fundcode, d_cdate, c_databaseno, c_tacode, c_tenantid)
);

-- ������ ta_tbasebalancedis(�����ܽ���̯��)�ĵ�ǰ��
SELECT 'Create Table ta_tbasebalancedis-�����ܽ���̯��...';
DROP TABLE IF EXISTS ta_tbasebalancedis;
create table ta_tbasebalancedis (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
    f_floorbalance                 decimal(10,9)   DEFAULT 0.0        ,
    c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundcode, c_flowstep, d_cdate, c_databaseno, c_tacode, c_tenantid)
);

-- ������ ta_tbreachrdmbooking(ΥԼ���ԤԼ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tbreachrdmbooking-ΥԼ���ԤԼ�����...';
DROP TABLE IF EXISTS ta_tbreachrdmbooking;
create table ta_tbreachrdmbooking (
    c_bookserialno                 varchar(20)     DEFAULT ' '        NOT NULL,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    d_appenddate                   int             DEFAULT 0          ,
    d_bookreqdate                  int             DEFAULT 0          ,
    f_bookshare                    decimal(16,2)   DEFAULT 0.0        ,
    c_taflag                       varchar(1)      DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    c_bookstatus                   varchar(1)      DEFAULT ' '        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
PRIMARY KEY(c_bookserialno, c_tacode, c_tenantid)
);

-- ������ ta_tfundinvest(��������Ҹ�ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tfundinvest-��������Ҹ�ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tfundinvest;
create table ta_tfundinvest (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
    f_fundtotalincome              decimal(16,2)   DEFAULT 0.0        ,
    l_incomemount                  int             DEFAULT 0          ,
    l_minusincomemount             int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, d_cdate, c_databaseno, c_tacode, c_tenantid)
);

-- ������ ta_ttransfercommissioncfm(OTCת��ί�гɽ���ϸȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_ttransfercommissioncfm-OTCת��ί�гɽ���ϸȷ�ϱ�...';
DROP TABLE IF EXISTS ta_ttransfercommissioncfm;
create table ta_ttransfercommissioncfm (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_commissionid                 varchar(24)     DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_outfundcode                  varchar(12)     DEFAULT ' '        ,
    c_issuecode                    varchar(8)      DEFAULT ' '        ,
    c_fundno                       varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_otctacode                    varchar(8)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_commissiontype               varchar(1)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_interest                     decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_handlecharge                 decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_fare                         decimal(16,2)   DEFAULT 0.0        ,
    f_agencyfee                    decimal(16,2)   DEFAULT 0.0        ,
    f_settlefee                    decimal(16,2)   DEFAULT 0.0        ,
    f_supervisionfee               decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee1                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee2                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee3                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee4                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee5                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee6                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee7                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee8                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee9                    decimal(16,2)   DEFAULT 0.0        ,
    c_liqudiateserialno            varchar(14)     DEFAULT ' '        ,
    c_credittradeflag              varchar(1)      DEFAULT ' '        ,
    c_eveningupflag                varchar(1)      DEFAULT ' '        ,
    c_otcfundtype                  varchar(2)      DEFAULT ' '        ,
    c_settlementmode               varchar(1)      DEFAULT ' '        ,
    c_stockquality                 varchar(2)      DEFAULT ' '        ,
    c_moneytype                    varchar(3)      DEFAULT ' '        ,
    c_otctradetype                 varchar(2)      DEFAULT ' '        ,
    d_liqudiatedate                int             DEFAULT 0          ,
    d_settlementdate               int             DEFAULT 0          ,
    d_senddate                     int             DEFAULT 0          ,
    f_netbala                      decimal(16,2)   DEFAULT 0.0        ,
    f_liqudiatebalance             decimal(16,2)   DEFAULT 0.0        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_otccause                     varchar(40)     DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_targettacode                 varchar(8)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_totccommissioncfm1 on ta_ttransfercommissioncfm(d_cdate);

-- ������ ta_ttransfercommissioncfm_his(OTCת��ί�гɽ���ϸȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_ttransfercommissioncfm_his-OTCת��ί�гɽ���ϸȷ�ϱ�...';
DROP TABLE IF EXISTS ta_ttransfercommissioncfm_his;
create table ta_ttransfercommissioncfm_his (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_commissionid                 varchar(24)     DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_outfundcode                  varchar(12)     DEFAULT ' '        ,
    c_issuecode                    varchar(8)      DEFAULT ' '        ,
    c_fundno                       varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_otctacode                    varchar(8)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_commissiontype               varchar(1)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_interest                     decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_handlecharge                 decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_fare                         decimal(16,2)   DEFAULT 0.0        ,
    f_agencyfee                    decimal(16,2)   DEFAULT 0.0        ,
    f_settlefee                    decimal(16,2)   DEFAULT 0.0        ,
    f_supervisionfee               decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee1                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee2                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee3                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee4                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee5                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee6                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee7                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee8                    decimal(16,2)   DEFAULT 0.0        ,
    f_otherfee9                    decimal(16,2)   DEFAULT 0.0        ,
    c_liqudiateserialno            varchar(14)     DEFAULT ' '        ,
    c_credittradeflag              varchar(1)      DEFAULT ' '        ,
    c_eveningupflag                varchar(1)      DEFAULT ' '        ,
    c_otcfundtype                  varchar(2)      DEFAULT ' '        ,
    c_settlementmode               varchar(1)      DEFAULT ' '        ,
    c_stockquality                 varchar(2)      DEFAULT ' '        ,
    c_moneytype                    varchar(3)      DEFAULT ' '        ,
    c_otctradetype                 varchar(2)      DEFAULT ' '        ,
    d_liqudiatedate                int             DEFAULT 0          ,
    d_settlementdate               int             DEFAULT 0          ,
    d_senddate                     int             DEFAULT 0          ,
    f_netbala                      decimal(16,2)   DEFAULT 0.0        ,
    f_liqudiatebalance             decimal(16,2)   DEFAULT 0.0        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_otccause                     varchar(40)     DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_targettacode                 varchar(8)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_totccommissioncfm1_0 on ta_ttransfercommissioncfm_his(d_cdate);

-- ������ ta_ttransfercommission(OTCת��ί�гɽ���ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_ttransfercommission-OTCת��ί�гɽ���ϸ��...';
DROP TABLE IF EXISTS ta_ttransfercommission;
create table ta_ttransfercommission (
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_commissionid                 varchar(24)     DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    c_outfundcode                  varchar(12)     DEFAULT ' '        ,
    c_issuecode                    varchar(8)      DEFAULT ' '        ,
    c_fundno                       varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_otctacode                    varchar(8)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_commissiontype               varchar(1)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_targettacode                 varchar(8)      DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_otccause                     varchar(40)     DEFAULT ' '        ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    l_pageno                       int             DEFAULT 0          
);
create unique index idx_ttransfercommission on ta_ttransfercommission(c_requestno, c_commissionid, c_agencyno, d_requestdate, c_tacode, c_tenantid);
create index idx_ttransfercom_cdate on ta_ttransfercommission(d_cdate);

-- ������ ta_ttransfercommission_his(OTCת��ί�гɽ���ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_ttransfercommission_his-OTCת��ί�гɽ���ϸ��...';
DROP TABLE IF EXISTS ta_ttransfercommission_his;
create table ta_ttransfercommission_his (
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_commissionid                 varchar(24)     DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    c_outfundcode                  varchar(12)     DEFAULT ' '        ,
    c_issuecode                    varchar(8)      DEFAULT ' '        ,
    c_fundno                       varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_otctacode                    varchar(8)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_commissiontype               varchar(1)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_targettacode                 varchar(8)      DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_otccause                     varchar(40)     DEFAULT ' '        ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    l_pageno                       int             DEFAULT 0          
);
create unique index idx_ttransfercommission_0 on ta_ttransfercommission_his(c_requestno, c_commissionid, c_agencyno, d_requestdate, c_tacode, c_tenantid);
create index idx_ttransfercom_cdate_0 on ta_ttransfercommission_his(d_cdate);

-- ������ ta_trequestshrfrzxlsfile(�����ݶ��ⶳ�ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_trequestshrfrzxlsfile-�����ݶ��ⶳ�ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_trequestshrfrzxlsfile;
create table ta_trequestshrfrzxlsfile (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_lawfileno                    varchar(128)    DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_importdate                   int             DEFAULT 0          ,
    c_lanchstatus                  varchar(1)      DEFAULT ' '        ,
    c_errorno                      int             DEFAULT 0          ,
    c_errordetail                  varchar(60)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);

-- ������ ta_trequestadjshrxlsfile(����ǿ��ǿ���ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_trequestadjshrxlsfile-����ǿ��ǿ���ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_trequestadjshrxlsfile;
create table ta_trequestadjshrxlsfile (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    d_importdate                   int             DEFAULT 0          ,
    c_lanchstatus                  varchar(1)      DEFAULT ' '        ,
    c_errorno                      int             DEFAULT 0          ,
    c_errordetail                  varchar(60)     DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(l_rowid)
);

-- ������ ta_trequestuntsfxlsfile(�����ǽ��׹����ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_trequestuntsfxlsfile-�����ǽ��׹����ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_trequestuntsfxlsfile;
create table ta_trequestuntsfxlsfile (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_lanchstatus                  varchar(1)      DEFAULT ' '        ,
    d_importdate                   int             DEFAULT 0          ,
    c_errorno                      int             DEFAULT 0          ,
    c_errordetail                  varchar(60)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);

-- ������ ta_trequestrdmxlsfile(����ǿ������ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_trequestrdmxlsfile-����ǿ������ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_trequestrdmxlsfile;
create table ta_trequestrdmxlsfile (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    d_importdate                   int             DEFAULT 0          ,
    c_lanchstatus                  varchar(1)      DEFAULT ' '        ,
    c_errorno                      int             DEFAULT 0          ,
    c_errordetail                  varchar(60)     DEFAULT ' '        ,
    f_reqrdmbalance                decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(l_rowid)
);

-- ������ ta_trequestbonusxlsfile(�����ֽ�ֺ��ļ��ӿڱ�)�ĵ�ǰ��
SELECT 'Create Table ta_trequestbonusxlsfile-�����ֽ�ֺ��ļ��ӿڱ�...';
DROP TABLE IF EXISTS ta_trequestbonusxlsfile;
create table ta_trequestbonusxlsfile (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    d_distributedate               int             DEFAULT 0          ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    f_profittotalshares            decimal(16,2)   DEFAULT 0.0        ,
    f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
    f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
    f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    d_importdate                   int             DEFAULT 0          ,
PRIMARY KEY(l_rowid)
);

-- ������ ta_tmanualresult(�˹���Ԥ�����)�ĵ�ǰ��
SELECT 'Create Table ta_tmanualresult-�˹���Ԥ�����...';
DROP TABLE IF EXISTS ta_tmanualresult;
create table ta_tmanualresult (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_manualtype                   varchar(1)      DEFAULT ' '        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    f_agio                         decimal(5,4)    DEFAULT 0.0        ,
    f_confirmratio                 decimal(9,8)    DEFAULT 0.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    c_contype                      varchar(1)      DEFAULT ' '        ,
    c_contno                       varchar(30)     DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    f_manualtradefare              decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tmanualresult on ta_tmanualresult(c_requestno, d_requestdate, c_agencyno, c_tacode, c_tenantid);

-- ������ ta_tmanualschema(�˹���Ԥ������)�ĵ�ǰ��
SELECT 'Create Table ta_tmanualschema-�˹���Ԥ������...';
DROP TABLE IF EXISTS ta_tmanualschema;
create table ta_tmanualschema (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_manualtype                   varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    d_inputdate                    int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_manualschema on ta_tmanualschema(d_inputdate, c_manualtype, c_liqbatchno, c_tacode, c_tenantid);

-- ������ ta_ttecntrctrequest(���Ӻ�ͬ�����)�ĵ�ǰ��
SELECT 'Create Table ta_ttecntrctrequest-���Ӻ�ͬ�����...';
DROP TABLE IF EXISTS ta_ttecntrctrequest;
create table ta_ttecntrctrequest (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_contracttype                 varchar(1)      DEFAULT ' '        ,
    c_contractno                   varchar(26)     DEFAULT ' '        NOT NULL,
    c_confirmstatusmanager         varchar(1)      DEFAULT ' '        ,
    c_confirmstatuscustod          varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundmanagercode              varchar(2)      DEFAULT ' '        ,
    c_trusteecode                  varchar(3)      DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    d_signdate                     int             DEFAULT 0          ,
    d_signtime                     int             DEFAULT 0          ,
    c_signchannel                  varchar(1)      DEFAULT ' '        ,
    c_signmachine                  varchar(60)     DEFAULT ' '        ,
    c_opernetno                    varchar(22)     DEFAULT ' '        ,
    c_notesagent                   varchar(64)     DEFAULT ' '        ,
    c_notesmanager                 varchar(64)     DEFAULT ' '        ,
    c_notescustod                  varchar(64)     DEFAULT ' '        ,
    d_importdate                   int             DEFAULT 0          ,
    d_cdate                        int             DEFAULT 0          ,
    c_caption                      varchar(100)    DEFAULT ' '        ,
    c_encserialno                  varchar(12)     DEFAULT ' '        ,
    c_postzd                       varchar(1)      DEFAULT ' '        ,
    c_address                      varchar(120)    DEFAULT ' '        ,
    c_postcode                     varchar(10)     DEFAULT ' '        ,
    c_postemail                    varchar(48)     DEFAULT ' '        ,
    c_mobileno                     varchar(32)     DEFAULT ' '        ,
    c_telno                        varchar(32)     DEFAULT ' '        ,
    c_cardno                       varchar(22)     DEFAULT ' '        ,
    d_modifydatemanager            int             DEFAULT 0          ,
    d_modifydatecustod             int             DEFAULT 0          ,
    d_modifydateagent              int             DEFAULT 0          ,
    c_issignriskboard              varchar(1)      DEFAULT ' '        ,
    c_isriskmatching               varchar(1)      DEFAULT ' '        ,
    c_riskabilityresult            varchar(1)      DEFAULT ' '        ,
    c_abnormalflag                 varchar(1)      DEFAULT ' '        ,
    c_redundanceflag               varchar(1)      DEFAULT ' '        ,
    c_checktype                    varchar(1)      DEFAULT ' '        ,
    c_correcttype                  varchar(1)      DEFAULT ' '        ,
    c_oriconfirmstatusmanager      varchar(1)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_srctype                      varchar(1)      DEFAULT ' '        ,
    c_busincode                    varchar(3)      DEFAULT ' '        ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_flowflag                     varchar(1)      DEFAULT ' '        ,
    f_fare                         decimal(16,2)   DEFAULT 0.0        ,
    c_notes                        varchar(64)     DEFAULT ' '        ,
    c_signtype                     varchar(1)      DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_reservedfield1               varchar(20)     DEFAULT ' '        ,
    c_reservedfield2               varchar(20)     DEFAULT ' '        ,
    c_reservedfield3               varchar(30)     DEFAULT ' '        ,
    f_reservedfield4               decimal(16,2)   DEFAULT 0.0        ,
    f_reservedfield5               decimal(16,2)   DEFAULT 0.0        ,
    c_contractversion              varchar(3)      DEFAULT ' '        ,
    c_oriidentityno                varchar(30)     DEFAULT ' '        ,
PRIMARY KEY(c_contractno, c_tenantid, c_tacode)
);
create index idx_econtrct_fundacco on ta_ttecntrctrequest(c_fundcode, c_fundacco, c_agencyno, c_tacode);

-- ������ ta_tecontractconfirm(���Ӻ�ͬȷ�ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tecontractconfirm-���Ӻ�ͬȷ�ϱ�...';
DROP TABLE IF EXISTS ta_tecontractconfirm;
create table ta_tecontractconfirm (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_contracttype                 varchar(1)      DEFAULT ' '        ,
    c_contractno                   varchar(26)     DEFAULT ' '        NOT NULL,
    c_confirmstatusmanager         varchar(1)      DEFAULT ' '        ,
    c_confirmstatuscustod          varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundmanagercode              varchar(2)      DEFAULT ' '        ,
    c_trusteecode                  varchar(3)      DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    d_signdate                     int             DEFAULT 0          ,
    d_signtime                     int             DEFAULT 0          ,
    c_signchannel                  varchar(1)      DEFAULT ' '        ,
    c_signmachine                  varchar(60)     DEFAULT ' '        ,
    c_opernetno                    varchar(22)     DEFAULT ' '        ,
    c_notesagent                   varchar(64)     DEFAULT ' '        ,
    c_notesmanager                 varchar(64)     DEFAULT ' '        ,
    c_notescustod                  varchar(64)     DEFAULT ' '        ,
    d_importdate                   int             DEFAULT 0          ,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_caption                      varchar(100)    DEFAULT ' '        ,
    c_encserialno                  varchar(12)     DEFAULT ' '        ,
    c_postzd                       varchar(1)      DEFAULT ' '        ,
    c_address                      varchar(120)    DEFAULT ' '        ,
    c_postcode                     varchar(10)     DEFAULT ' '        ,
    c_postemail                    varchar(48)     DEFAULT ' '        ,
    c_mobileno                     varchar(32)     DEFAULT ' '        ,
    c_telno                        varchar(32)     DEFAULT ' '        ,
    c_cardno                       varchar(22)     DEFAULT ' '        ,
    d_modifydatemanager            int             DEFAULT 0          ,
    d_modifydatecustod             int             DEFAULT 0          ,
    d_modifydateagent              int             DEFAULT 0          ,
    c_issignriskboard              varchar(1)      DEFAULT ' '        ,
    c_isriskmatching               varchar(1)      DEFAULT ' '        ,
    c_riskabilityresult            varchar(1)      DEFAULT ' '        ,
    c_abnormalflag                 varchar(1)      DEFAULT ' '        ,
    c_redundanceflag               varchar(1)      DEFAULT ' '        ,
    c_checktype                    varchar(1)      DEFAULT ' '        ,
    c_correcttype                  varchar(1)      DEFAULT ' '        ,
    c_notes                        varchar(64)     DEFAULT ' '        ,
    c_busincode                    varchar(3)      DEFAULT ' '        ,
    c_oriconfirmstatusmanager      varchar(1)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_contractversion              varchar(3)      DEFAULT ' '        ,
    c_signtype                     varchar(1)      DEFAULT ' '        ,
    c_reservedfield1               varchar(20)     DEFAULT ' '        ,
    c_reservedfield2               varchar(20)     DEFAULT ' '        ,
    c_reservedfield3               varchar(30)     DEFAULT ' '        ,
    f_reservedfield4               decimal(16,2)   DEFAULT 0.0        ,
    f_reservedfield5               decimal(16,2)   DEFAULT 0.0        ,
    c_srctype                      varchar(1)      DEFAULT ' '        ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(c_contractno, d_cdate, c_tenantid, c_tacode)
);

-- ������ ta_tneedgradeinfo(��������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tneedgradeinfo-��������Ϣ��...';
DROP TABLE IF EXISTS ta_tneedgradeinfo;
create table ta_tneedgradeinfo (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_unicode                      varchar(12)     DEFAULT ' '        ,
    c_classtype                    varchar(1)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
    c_oriclass                     varchar(1)      DEFAULT 'A'        ,
    c_judgeclass                   varchar(1)      DEFAULT 'A'        ,
    c_newclass                     varchar(1)      DEFAULT 'A'        ,
    c_newcode                      varchar(12)     DEFAULT ' '        
);

-- ������ ta_tupgradecurrents(��������ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tupgradecurrents-��������ˮ��...';
DROP TABLE IF EXISTS ta_tupgradecurrents;
create table ta_tupgradecurrents (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_oriclass                     varchar(1)      DEFAULT 'A'        ,
    c_shareclass                   varchar(1)      DEFAULT ' '        ,
    c_newcode                      varchar(12)     DEFAULT ' '        ,
    c_unicode                      varchar(12)     DEFAULT ' '        ,
    c_upgradeserialno              varchar(14)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_agencyno, c_upgradeserialno, c_tacode, c_tenantid)
);
create index idx_tupgradecurrents on ta_tupgradecurrents(c_fundacco, c_agencyno, c_netno, c_tradeacco);
create index idx_tupgradecurrents_cdate on ta_tupgradecurrents(d_cdate);

-- ������ ta_tneedgradeinfo_shrcdt(�������ݶ���ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tneedgradeinfo_shrcdt-�������ݶ���ˮ��...';
DROP TABLE IF EXISTS ta_tneedgradeinfo_shrcdt;
create table ta_tneedgradeinfo_shrcdt (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        
);

-- ������ ta_tneedgradeinfo_tmp1(��������Ϣ��ʱ��1)�ĵ�ǰ��
SELECT 'Create Table ta_tneedgradeinfo_tmp1-��������Ϣ��ʱ��1...';
DROP TABLE IF EXISTS ta_tneedgradeinfo_tmp1;
create table ta_tneedgradeinfo_tmp1 (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_unicode                      varchar(12)     DEFAULT ' '        ,
    c_classtype                    varchar(1)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    c_investorientation            varchar(1)      DEFAULT ' '        ,
    c_upgradeflag                  varchar(1)      DEFAULT ' '        ,
    c_oriclass                     varchar(1)      DEFAULT 'A'        ,
    c_shareclass                   varchar(1)      DEFAULT ' '        
);

-- ������ ta_tneedgradeinfo_tmp2(��������Ϣ��ʱ��2)�ĵ�ǰ��
SELECT 'Create Table ta_tneedgradeinfo_tmp2-��������Ϣ��ʱ��2...';
DROP TABLE IF EXISTS ta_tneedgradeinfo_tmp2;
create table ta_tneedgradeinfo_tmp2 (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_unicode                      varchar(12)     DEFAULT ' '        ,
    c_classtype                    varchar(1)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
    c_oriclass                     varchar(1)      DEFAULT 'A'        ,
    c_judgeclass                   varchar(1)      DEFAULT 'A'        
);

-- ������ ta_tneedgradeinfo_tmp3(��������Ϣ��ʱ��3)�ĵ�ǰ��
SELECT 'Create Table ta_tneedgradeinfo_tmp3-��������Ϣ��ʱ��3...';
DROP TABLE IF EXISTS ta_tneedgradeinfo_tmp3;
create table ta_tneedgradeinfo_tmp3 (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_newclass                     varchar(1)      DEFAULT 'A'        
);

-- ������ ta_tservicedealflag(��������־��)�ĵ�ǰ��
SELECT 'Create Table ta_tservicedealflag-��������־��...';
DROP TABLE IF EXISTS ta_tservicedealflag;
create table ta_tservicedealflag (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_servicecode                  varchar(64)     DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_dealflag                     varchar(1)      DEFAULT ' '        
);
create unique index uidx_tservicedealflag on ta_tservicedealflag(c_servicecode, d_cdate, c_fundcode, c_tacode, c_tenantid);

-- ������ ta_tincomeinvest_fund(����Ҹ���Ʒ��)�ĵ�ǰ��
SELECT 'Create Table ta_tincomeinvest_fund-����Ҹ���Ʒ��...';
DROP TABLE IF EXISTS ta_tincomeinvest_fund;
create table ta_tincomeinvest_fund (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_managercode                  varchar(10)     DEFAULT ' '        ,
PRIMARY KEY(c_fundcode, c_tacode, c_tenantid)
);

-- ������ ta_tecntrctverifyresult(���Ӻ�ͬ�˹��˶Խ����)�ĵ�ǰ��
SELECT 'Create Table ta_tecntrctverifyresult-���Ӻ�ͬ�˹��˶Խ����...';
DROP TABLE IF EXISTS ta_tecntrctverifyresult;
create table ta_tecntrctverifyresult (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_contractno                   varchar(26)     DEFAULT ' '        NOT NULL,
    c_confirmstatusmanager         varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_notes                        varchar(64)     DEFAULT ' '        ,
    c_checktype                    varchar(1)      DEFAULT ' '        ,
    c_correcttype                  varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(c_contractno, c_tacode, c_tenantid)
);

-- ������ ta_tlittleshrforcerdmtmp1(С�ݶ�ǿ����ʱ��1)�ĵ�ǰ��
SELECT 'Create Table ta_tlittleshrforcerdmtmp1-С�ݶ�ǿ����ʱ��1...';
DROP TABLE IF EXISTS ta_tlittleshrforcerdmtmp1;
create table ta_tlittleshrforcerdmtmp1 (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_flag                         varchar(1)      DEFAULT ' '        ,
    c_businflags                   varchar(80)     DEFAULT ' '        
);
create unique index uidx_tlittleshrforrdm on ta_tlittleshrforcerdmtmp1(c_fundcode, c_tacode, c_tenantid);

-- ������ ta_tlittleshrforcerdmtmp2(С�ݶ�ǿ����ʱ��2)�ĵ�ǰ��
SELECT 'Create Table ta_tlittleshrforcerdmtmp2-С�ݶ�ǿ����ʱ��2...';
DROP TABLE IF EXISTS ta_tlittleshrforcerdmtmp2;
create table ta_tlittleshrforcerdmtmp2 (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    f_hminshares                   decimal(16,2)   DEFAULT 0.0        
);
create unique index uidx_littleshrforrdmtmp2 on ta_tlittleshrforcerdmtmp2(c_fundcode, c_custtype, c_tacode, c_tenantid);

-- ������ ta_tlittleshrforcerdmtmp3(С�ݶ�ǿ���м��3)�ĵ�ǰ��
SELECT 'Create Table ta_tlittleshrforcerdmtmp3-С�ݶ�ǿ���м��3...';
DROP TABLE IF EXISTS ta_tlittleshrforcerdmtmp3;
create table ta_tlittleshrforcerdmtmp3 (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    f_totalrealshares              decimal(16,2)   DEFAULT 0.0        ,
    f_totalincome                  decimal(16,2)   DEFAULT 0.0        
);
create unique index uidx_littleshrforrdmtmp3 on ta_tlittleshrforcerdmtmp3(c_fundacco, c_fundcode, c_agencyno, c_tacode, c_tenantid);

-- ������ split_tmp(�����ʱ��)�ĵ�ǰ��
SELECT 'Create Table split_tmp-�����ʱ��...';
DROP TABLE IF EXISTS split_tmp;
create table split_tmp (
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    f_bonusbalance                 decimal(16,2)   DEFAULT 0.0        ,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
    l_pageno                       int             DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_tradeacco, c_netno, c_sharetype, c_fundcode, c_agencyno, c_tenantid, c_tacode, c_cserialno)
);
create index idx_spltmp_fundcode on split_tmp(c_fundcode);

-- ������ splitfrozen_tmp(��ֶ�����ʱ��)�ĵ�ǰ��
SELECT 'Create Table splitfrozen_tmp-��ֶ�����ʱ��...';
DROP TABLE IF EXISTS splitfrozen_tmp;
create table splitfrozen_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_frozendate                   int             DEFAULT 0          ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    c_freezetype                   varchar(1)      DEFAULT ' '        ,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_frozenrightflag              varchar(1)      DEFAULT ' '        ,
    f_balanceright                 decimal(16,2)   DEFAULT 0.0        ,
    f_shareright                   decimal(16,2)   DEFAULT 0.0        ,
    c_taflag                       varchar(1)      DEFAULT ' '        ,
    d_lastmodify                   int             DEFAULT 0          ,
    c_unfreezeflag                 varchar(1)      DEFAULT ' '        ,
    f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
    d_appenddate                   int             DEFAULT 0          ,
    f_lastbalance                  decimal(16,2)   DEFAULT 0.0        ,
    l_pageno                       int             DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_splfrotmp_fundcode on splitfrozen_tmp(c_fundcode);

-- ������ splitredeem_tmp(��ز����ʱ��)�ĵ�ǰ��
SELECT 'Create Table splitredeem_tmp-��ز����ʱ��...';
DROP TABLE IF EXISTS splitredeem_tmp;
create table splitredeem_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    f_lastfreezeshares             decimal(16,2)   DEFAULT 0.0        ,
    l_pageno                       int             DEFAULT 0          ,
    f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        ,
    f_lastrealshares               decimal(16,2)   DEFAULT 0.0        ,
    f_totalshares                  decimal(16,2)   DEFAULT 0.0        ,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
    f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundacco, c_tradeacco, c_fundcode, c_sharetype, c_agencyno, c_netno, c_cserialno, c_tenantid)
);
create index idx_serialno on splitredeem_tmp(c_cserialno, c_tenantid);

-- ������ ta_tcommissionacco(ʵʱ����ί�б�)�ĵ�ǰ��
SELECT 'Create Table ta_tcommissionacco-ʵʱ����ί�б�...';
DROP TABLE IF EXISTS ta_tcommissionacco;
create table ta_tcommissionacco (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_taflag                       varchar(1)      DEFAULT '0'        ,
    c_address                      varchar(120)    DEFAULT ' '        ,
    c_instrepridcode               varchar(30)     DEFAULT ' '        ,
    c_instrepridtype               varchar(1)      DEFAULT ' '        ,
    c_lawname                      varchar(20)     DEFAULT ' '        ,
    d_lawidnovaliddate             int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_zipcode                      varchar(6)      DEFAULT ' '        ,
    c_contno                       varchar(30)     DEFAULT ' '        ,
    c_contype                      varchar(1)      DEFAULT ' '        ,
    c_contact                      varchar(20)     DEFAULT ' '        ,
    c_birthday                     varchar(8)      DEFAULT ' '        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_education                    varchar(3)      DEFAULT ' '        ,
    c_email                        varchar(40)     DEFAULT ' '        ,
    c_faxno                        varchar(24)     DEFAULT ' '        ,
    c_vocation                     varchar(3)      DEFAULT ' '        ,
    c_hometelno                    varchar(32)     DEFAULT ' '        ,
    c_annualearnings               varchar(8)      DEFAULT ' '        ,
    c_mobileno                     varchar(32)     DEFAULT ' '        ,
    c_corptel                      varchar(32)     DEFAULT ' '        ,
    c_shortname                    varchar(20)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_sex                          varchar(1)      DEFAULT ' '        ,
    c_phone                        varchar(32)     DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_minorflag                    varchar(1)      DEFAULT ' '        ,
    c_billsendflag                 varchar(1)      DEFAULT ' '        ,
    c_transacttype                 varchar(1)      DEFAULT ' '        ,
    c_shacco                       varchar(10)     DEFAULT ' '        ,
    c_szacco                       varchar(10)     DEFAULT ' '        ,
    c_newtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_nameinbank                   varchar(60)     DEFAULT ' '        ,
    c_bankacco                     varchar(30)     DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_deliverway                   varchar(8)      DEFAULT ' '        ,
    c_nationality                  varchar(3)      DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_corpname                     varchar(40)     DEFAULT ' '        ,
    d_idnovaliddate                int             DEFAULT 0          ,
    d_contidnovaliddate            int             DEFAULT 0          ,
    c_risklevel                    varchar(1)      DEFAULT ' '        ,
    c_managerange                  varchar(2)      DEFAULT ' '        ,
    c_controlholder                varchar(80)     DEFAULT ' '        ,
    c_actualcontroller             varchar(80)     DEFAULT ' '        ,
    c_marital                      varchar(1)      DEFAULT ' '        ,
    l_familynum                    int             DEFAULT 0          ,
    f_penates                      decimal(16,2)   DEFAULT 0.0        ,
    c_mediahobby                   varchar(1)      DEFAULT ' '        ,
    c_institutiontype              varchar(1)      DEFAULT ' '        ,
    c_englishfirstname             varchar(20)     DEFAULT ' '        ,
    c_englishfamilyname            varchar(20)     DEFAULT ' '        ,
    c_industry                     varchar(4)      DEFAULT ' '        ,
    c_companychar                  varchar(4)      DEFAULT ' '        ,
    f_employeenum                  decimal(16,2)   DEFAULT 0.0        ,
    c_hobbytype                    varchar(2)      DEFAULT ' '        ,
    c_province                     varchar(6)      DEFAULT ' '        ,
    c_city                         varchar(6)      DEFAULT ' '        ,
    c_county                       varchar(6)      DEFAULT ' '        ,
    c_recommender                  varchar(40)     DEFAULT ' '        ,
    c_recommendertype              varchar(1)      DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_contidcard18len              varchar(1)      DEFAULT ' '        ,
    c_callcenter                   varchar(1)      DEFAULT ' '        ,
    c_internet                     varchar(1)      DEFAULT ' '        ,
    c_billsendpass                 varchar(1)      DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cause                        varchar(4)      DEFAULT '0000'     ,
    c_lawidtype                    varchar(1)      DEFAULT ' '        ,
    c_lawidno                      varchar(30)     DEFAULT ' '        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_lawfileno                    varchar(128)    DEFAULT ' '        ,
    c_auditflag                    varchar(1)      DEFAULT ' '        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    d_date                         int             DEFAULT 0          ,
    d_cdate                        int             DEFAULT 0          ,
    c_oriidentityno                varchar(30)     DEFAULT ' '        ,
    c_oricontno                    varchar(30)     DEFAULT ' '        ,
    c_newbusinflag                 varchar(2)      DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_datasourceflag               varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(c_cserialno, c_tenantid)
);

-- ������ ta_tnominalholdreq(������������)�ĵ�ǰ��
SELECT 'Create Table ta_tnominalholdreq-������������...';
DROP TABLE IF EXISTS ta_tnominalholdreq;
create table ta_tnominalholdreq (
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    c_identitype                   varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    c_custname                     varchar(120)    DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    d_registdate                   int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_nodealflag                   varchar(1)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_importflag                   varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_cserialno, c_tenantid)
);
create index idx_tnominalholdreq_cdate on ta_tnominalholdreq(d_cdate);

-- ������ ta_tshortcycletmp(����������ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tshortcycletmp-����������ʱ��...';
DROP TABLE IF EXISTS ta_tshortcycletmp;
create table ta_tshortcycletmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    f_offsetincome                 decimal(16,2)   DEFAULT 0.0        ,
    c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_tacode, c_databaseno, c_fundcode, d_cdate, c_liqbatchno, c_businflag)
);

-- ������ ta_taccoconfirmroll(�˻�ȷ�ϻع���)�ĵ�ǰ��
SELECT 'Create Table ta_taccoconfirmroll-�˻�ȷ�ϻع���...';
DROP TABLE IF EXISTS ta_taccoconfirmroll;
create table ta_taccoconfirmroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    l_id                           int             DEFAULT 0          NOT NULL,
PRIMARY KEY(l_id)
);

-- ������ ta_tscalectlconfirmstat(��ģ���ƽ���ȷ��ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tscalectlconfirmstat-��ģ���ƽ���ȷ��ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tscalectlconfirmstat;
create table ta_tscalectlconfirmstat (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
    f_todaysubbalance              decimal(16,2)   DEFAULT 0.0        ,
    f_todaypcsbalance              decimal(16,2)   DEFAULT 0.0        ,
    f_todaychginshares             decimal(16,2)   DEFAULT 0.0        ,
    f_todayrdmshares               decimal(16,2)   DEFAULT 0.0        ,
    f_todaychgoutshares            decimal(16,2)   DEFAULT 0.0        ,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    l_totalacconum                 int             DEFAULT 0          ,
    l_hisacconum                   int             DEFAULT 0          ,
    f_hissubbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_todayrationbalance           decimal(16,2)   DEFAULT 0.0        ,
    f_nottarealshares              decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundcode, c_agencyno, d_cdate, c_databaseno, c_tenantid)
);

-- ������ ta_tscalectlreqsyn(��ģ���ƽ��������)�ĵ�ǰ��
SELECT 'Create Table ta_tscalectlreqsyn-��ģ���ƽ��������...';
DROP TABLE IF EXISTS ta_tscalectlreqsyn;
create table ta_tscalectlreqsyn (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    c_isnewaddacco                 varchar(1)      DEFAULT ' '        ,
    c_isallout                     varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    d_requestdate                  int             DEFAULT 0          ,
    d_requesttime                  int             DEFAULT 0          ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    f_oricfmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_oricfmshares                 decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_cserialno, c_databaseno, c_tenantid)
);
create index idx_tscalectlreqsyn on ta_tscalectlreqsyn(c_fundcode, c_agencyno, c_businflag, d_cdate, c_tacode, c_tenantid);

-- ������ ta_tscalectlhisacconum(��ģ������ʷ�˻�����)�ĵ�ǰ��
SELECT 'Create Table ta_tscalectlhisacconum-��ģ������ʷ�˻�����...';
DROP TABLE IF EXISTS ta_tscalectlhisacconum;
create table ta_tscalectlhisacconum (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    l_hisacconum                   int             DEFAULT 0          ,
    d_cdate                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_fundcode, c_agencyno, d_cdate, c_databaseno, c_tenantid)
);

-- ������ ta_tscalectlhissub(��ģ������ʷ���Ϲ���)�ĵ�ǰ��
SELECT 'Create Table ta_tscalectlhissub-��ģ������ʷ���Ϲ���...';
DROP TABLE IF EXISTS ta_tscalectlhissub;
create table ta_tscalectlhissub (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    f_hissubbalance                decimal(16,2)   DEFAULT 0.0        ,
    d_cdate                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_fundcode, c_agencyno, d_cdate, c_databaseno, c_tenantid)
);

-- ������ ta_tscalecontrolrule(��ģ���ƹ����)�ĵ�ǰ��
SELECT 'Create Table ta_tscalecontrolrule-��ģ���ƹ����...';
DROP TABLE IF EXISTS ta_tscalecontrolrule;
create table ta_tscalecontrolrule (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    l_maxaccocount                 int             DEFAULT 0          ,
    f_maxissuebala                 decimal(16,2)   DEFAULT 0.0        ,
    f_maxallotasset                decimal(16,2)   DEFAULT 0.0        ,
    f_maxallotshares               decimal(16,2)   DEFAULT 0.0        ,
    f_maxallot                     decimal(9,8)    DEFAULT 0.0        ,
    c_excessallot                  varchar(1)      DEFAULT ' '        ,
    c_extradealtype                varchar(1)      DEFAULT ' '        ,
    c_exceedpart                   varchar(1)      DEFAULT ' '        ,
    f_maxaddbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_maxredeem                    decimal(9,8)    DEFAULT 0.0        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_schemetype                   varchar(1)      DEFAULT ' '        ,
    l_no                           bigint          DEFAULT 0          ,
    l_minaccocount                 int             DEFAULT 0          ,
    f_minissuebala                 decimal(16,2)   DEFAULT 0.0        ,
    c_gradefund                    varchar(12)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_gradefund, c_agencyno, d_cdate, c_tenantid)
);
create index idx_tscalecontrolrule_fund on ta_tscalecontrolrule(c_fundcode, c_tacode, c_tenantid);

-- ������ ta_tscalecontrol(��ģ���Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tscalecontrol-��ģ���Ʊ�...';
DROP TABLE IF EXISTS ta_tscalecontrol;
create table ta_tscalecontrol (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_controltype                  varchar(1)      DEFAULT ' '        NOT NULL,
    f_validbalance                 decimal(16,2)   DEFAULT 0.0        ,
    f_validshares                  decimal(16,2)   DEFAULT 0.0        ,
    l_validacconum                 int             DEFAULT 0          ,
    f_allotbalance                 decimal(16,2)   DEFAULT 0.0        ,
    f_allotshares                  decimal(16,2)   DEFAULT 0.0        ,
    l_allotaccocount               int             DEFAULT 0          ,
    c_ordertype                    varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    f_validrdmshares               decimal(16,2)   DEFAULT 0.0        ,
    f_redeemshares                 decimal(16,2)   DEFAULT 0.0        ,
    f_redemratio                   decimal(9,8)    DEFAULT 1.0        ,
    f_cfmratio                     decimal(9,8)    DEFAULT 1.0        ,
PRIMARY KEY(c_fundcode, c_agencyno, c_controltype, d_cdate, c_tenantid)
);

-- ������ ta_tscalecontrolfailedlist(��ģ����ʧ���嵥��)�ĵ�ǰ��
SELECT 'Create Table ta_tscalecontrolfailedlist-��ģ����ʧ���嵥��...';
DROP TABLE IF EXISTS ta_tscalecontrolfailedlist;
create table ta_tscalecontrolfailedlist (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_chkstatus                    varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(c_cserialno, c_databaseno, c_tenantid)
);

-- ������ scale_littleshares_tmp(��ģ����С�ݶ�ǿ����Ҫ����ʱ��)�ĵ�ǰ��
SELECT 'Create Table scale_littleshares_tmp-��ģ����С�ݶ�ǿ����Ҫ����ʱ��...';
DROP TABLE IF EXISTS scale_littleshares_tmp;
create table scale_littleshares_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
PRIMARY KEY(d_cdate, c_fundacco, c_tradeacco, c_fundcode, c_sharetype, c_agencyno, c_netno, c_tenantid)
);

-- ������ ta_totcacconumstat(OTC�˻���ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_totcacconumstat-OTC�˻���ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_totcacconumstat;
create table ta_totcacconumstat (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    l_totalacconum                 int             DEFAULT 0          ,
    l_maxaccocount                 int             DEFAULT 0          ,
PRIMARY KEY(c_fundcode, c_databaseno, c_tacode, c_tenantid)
);

-- ������ ta_tdealflag(��Ʒ������־��)�ĵ�ǰ��
SELECT 'Create Table ta_tdealflag-��Ʒ������־��...';
DROP TABLE IF EXISTS ta_tdealflag;
create table ta_tdealflag (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_instanceid                   varchar(20)     DEFAULT ' '        NOT NULL,
    l_shardingno                   int             DEFAULT 0          NOT NULL,
    c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_tacode, c_fundcode)
);

commit;
