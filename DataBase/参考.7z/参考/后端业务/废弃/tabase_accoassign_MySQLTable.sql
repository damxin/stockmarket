-- -------------------------------------------
-- SQLfile   : tabase_accoassign_MySQLTable.sql
-- Notes    : SQL�ű�
-- -------------------------------------------


-- ������ ta_taccoassign(�˺ŷ����)�ĵ�ǰ��
SELECT 'Create Table ta_taccoassign-�˺ŷ����...';
DROP TABLE IF EXISTS ta_taccoassign;
CREATE TABLE ta_taccoassign
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_custtype                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_identitype                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_identityno                   varchar(30)     DEFAULT ' '        NOT NULL,
	c_idcard18len                  varchar(1)      DEFAULT ' '        NOT NULL,
	c_custname                     varchar(120)    DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_accostatus                   varchar(1)      DEFAULT ' '        NOT NULL,
	d_appenddate                   int             DEFAULT 0          NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundacco, c_tenantid)
);
CREATE UNIQUE INDEX idx_taccoassignment_normal ON ta_taccoassign(c_identityno ASC ,c_custname ASC ,c_identitype ASC ,c_custtype ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_taccocommission(�˺ŷ���ʵʱί�б�)�ĵ�ǰ��
SELECT 'Create Table ta_taccocommission-�˺ŷ���ʵʱί�б�...';
DROP TABLE IF EXISTS ta_taccocommission;
CREATE TABLE ta_taccocommission
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_requestno                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_appenddate                   int             DEFAULT 0          NOT NULL,
	c_custname                     varchar(120)    DEFAULT ' '        NOT NULL,
	c_custtype                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_identitype                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_identityno                   varchar(30)     DEFAULT ' '        NOT NULL,
	c_idcard18len                  varchar(1)      DEFAULT ' '        NOT NULL
);
CREATE INDEX idx_taccoassigncrt ON ta_taccocommission(c_tradeacco ASC ,c_agencyno ASC ,c_netno ASC ,c_tacode ASC ,c_tenantid ASC );

