-- ������ ta_taccoserialno(�˻����б�)�ĵ�ǰ��
SELECT 'Create Table ta_taccoserialno-�˻����б�...';
DROP TABLE IF EXISTS ta_taccoserialno;
create table ta_taccoserialno (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_serialnotype                 varchar(1)      DEFAULT ' '        NOT NULL,
    l_serialno                     bigint          DEFAULT 0          NOT NULL,
    l_lastserialno                 bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_serialnotype, c_tacode, c_tenantid)
);

-- ������ ta_accoinfoloadtmp(�����˺���Ϣ�����м��)�ĵ�ǰ��
SELECT 'Create Table ta_accoinfoloadtmp-�����˺���Ϣ�����м��...';
DROP TABLE IF EXISTS ta_accoinfoloadtmp;
create table ta_accoinfoloadtmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
    l_shardingno                   int             DEFAULT 0          NOT NULL
);
create index idx_accoinfoloadtmp on ta_accoinfoloadtmp(c_fundacco, c_loadpoint, l_shardingno);

-- ������ ta_acconetloadtmp(�˻���������м��)�ĵ�ǰ��
SELECT 'Create Table ta_acconetloadtmp-�˻���������м��...';
DROP TABLE IF EXISTS ta_acconetloadtmp;
create table ta_acconetloadtmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_loadpoint                    varchar(100)    DEFAULT ' '        ,
    c_datastyle                    varchar(30)     DEFAULT ' '        ,
    l_shardingno                   int             DEFAULT 0          
);
create index idx_acconetloadtmp on ta_acconetloadtmp(c_fundacco, c_tradeacco, c_netno, c_agencyno, c_tacode, c_tenantid);

-- ������ ta_requestloadtmp(������������м��)�ĵ�ǰ��
SELECT 'Create Table ta_requestloadtmp-������������м��...';
DROP TABLE IF EXISTS ta_requestloadtmp;
create table ta_requestloadtmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    l_shardingno                   int             DEFAULT 0          
);
create index idx_requestloadtmp on ta_requestloadtmp(c_fundacco, c_tradeacco, c_fundcode, c_sharetype, c_agencyno, c_netno, c_tacode, c_tenantid);

-- ������ ta_requestloadtmp_0(������������м��0)�ĵ�ǰ��
SELECT 'Create Table ta_requestloadtmp_0-������������м��0...';
DROP TABLE IF EXISTS ta_requestloadtmp_0;
create table ta_requestloadtmp_0 (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    l_shardingno                   int             DEFAULT 0          ,
    l_reqserialno                  bigint          DEFAULT 0          ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        
);
create index idx_requestloadtmp_0 on ta_requestloadtmp_0(c_fundacco, c_tradeacco, c_fundcode, c_sharetype, c_agencyno, c_netno, c_tacode, c_tenantid);
create index idx_reqserialno on ta_requestloadtmp_0(l_reqserialno);
create index idx_request_loadtmp_0_biz on ta_requestloadtmp_0(c_businflag, c_tacode, c_tenantid, l_shardingno);

-- ������ ta_requestloadtmp_s(������������м��s)�ĵ�ǰ��
SELECT 'Create Table ta_requestloadtmp_s-������������м��s...';
DROP TABLE IF EXISTS ta_requestloadtmp_s;
create table ta_requestloadtmp_s (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    l_shardingno                   int             DEFAULT 0          ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        
);
create index idx_requestloadtmp_s on ta_requestloadtmp_s(c_fundacco, c_tradeacco, c_fundcode, c_sharetype, c_agencyno, c_netno, c_tacode, c_tenantid);

-- ������ ta_taccoinfoload(�˻���Ϣ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_taccoinfoload-�˻���Ϣ���ر�...';
DROP TABLE IF EXISTS ta_taccoinfoload;
create table ta_taccoinfoload (
    c_flag                         varchar(1)      DEFAULT ' '        NOT NULL,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_custtype                     varchar(1)      DEFAULT ' '        NOT NULL,
    c_custname                     varchar(120)    DEFAULT ' '        NOT NULL,
    c_shortname                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_identitype                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_identityno                   varchar(30)     DEFAULT ' '        NOT NULL,
    c_idcard18len                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_accostatus                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_freezecause                  varchar(1)      DEFAULT ' '        NOT NULL,
    d_opendate                     int             DEFAULT 0          NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    c_modifyinfo                   varchar(2)      DEFAULT ' '        NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL
);

-- ������ ta_taccoinforoll(�˻���Ϣ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_taccoinforoll-�˻���Ϣ�ع���...';
DROP TABLE IF EXISTS ta_taccoinforoll;
create table ta_taccoinforoll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_taccoinfotmp(�˻���Ϣ�м��)�ĵ�ǰ��
SELECT 'Create Table ta_taccoinfotmp-�˻���Ϣ�м��...';
DROP TABLE IF EXISTS ta_taccoinfotmp;
create table ta_taccoinfotmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_idcard18len                  varchar(1)      DEFAULT ' '        ,
    c_identityno                   varchar(30)     DEFAULT ' '        ,
    d_lastmodify                   int             DEFAULT 0          ,
    c_adrmflag                     varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(c_fundacco, c_tacode, c_tenantid)
);

-- ������ ta_tacconet_bak(�˻����㱸�ݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tacconet_bak-�˻����㱸�ݱ�...';
DROP TABLE IF EXISTS ta_tacconet_bak;
create table ta_tacconet_bak (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_tradeaccostatus              varchar(1)      DEFAULT ' '        NOT NULL,
    c_tradeaccobak                 varchar(24)     DEFAULT ' '        NOT NULL,
    c_childnetno                   varchar(9)      DEFAULT ' '        NOT NULL,
    c_bankno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_bankacco                     varchar(30)     DEFAULT ' '        NOT NULL,
    c_nameinbank                   varchar(60)     DEFAULT ' '        NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
    d_bakdate                      int             DEFAULT 0          NOT NULL,
    c_officalcode                  varchar(9)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_fundacco, c_netno, c_agencyno, c_tradeacco, c_liqbatchno, d_bakdate, c_tacode, c_tenantid)
);

-- ������ ta_tacconetload(�˻�������ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tacconetload-�˻�������ر�...';
DROP TABLE IF EXISTS ta_tacconetload;
create table ta_tacconetload (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_tradeaccostatus              varchar(1)      DEFAULT ' '        NOT NULL,
    c_tradeaccobak                 varchar(24)     DEFAULT ' '        NOT NULL,
    c_childnetno                   varchar(9)      DEFAULT ' '        NOT NULL,
    c_bankno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_bankacco                     varchar(30)     DEFAULT ' '        NOT NULL,
    c_nameinbank                   varchar(60)     DEFAULT ' '        NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL
);

-- ������ ta_tacconetroll(�˻�����ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tacconetroll-�˻�����ع���...';
DROP TABLE IF EXISTS ta_tacconetroll;
create table ta_tacconetroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tacconettmp(�˻������м��)�ĵ�ǰ��
SELECT 'Create Table ta_tacconettmp-�˻������м��...';
DROP TABLE IF EXISTS ta_tacconettmp;
create table ta_tacconettmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_tradeaccostatus              varchar(1)      DEFAULT ' '        ,
    c_tradeaccobak                 varchar(24)     DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_bankacco                     varchar(30)     DEFAULT ' '        ,
    c_nameinbank                   varchar(60)     DEFAULT ' '        ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
    c_adrmflag                     varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(c_fundacco, c_tradeacco, c_agencyno, c_netno, c_tacode, c_tenantid)
);
create index idx_tacconettmp on ta_tacconettmp(c_tradeacco);

-- ������ ta_taccorequest_bak(�˻����뱸�ݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_taccorequest_bak-�˻����뱸�ݱ�...';
DROP TABLE IF EXISTS ta_taccorequest_bak;
create table ta_taccorequest_bak (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_chkstatus                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_status                       varchar(1)      DEFAULT ' '        NOT NULL,
    c_cause                        varchar(4)      DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL
);
create unique index uidx_taccorequest_bak on ta_taccorequest_bak(c_cserialno, c_flowno, c_tenantid, c_tacode);

-- ������ ta_taccorequestroll(�˻�����ع���)�ĵ�ǰ��
SELECT 'Create Table ta_taccorequestroll-�˻�����ع���...';
DROP TABLE IF EXISTS ta_taccorequestroll;
create table ta_taccorequestroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_taccoserialno_load(�˻����м��ر�)�ĵ�ǰ��
SELECT 'Create Table ta_taccoserialno_load-�˻����м��ر�...';
DROP TABLE IF EXISTS ta_taccoserialno_load;
create table ta_taccoserialno_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_serialnotype                 varchar(1)      DEFAULT ' '        NOT NULL,
    l_serialno                     bigint          DEFAULT 0          NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
    l_lastserialno                 bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_datastyle, c_loadpoint, c_serialnotype, c_tacode, c_tenantid)
);

-- ������ ta_taccoserialno_tmp(�˻������м��)�ĵ�ǰ��
SELECT 'Create Table ta_taccoserialno_tmp-�˻������м��...';
DROP TABLE IF EXISTS ta_taccoserialno_tmp;
create table ta_taccoserialno_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_serialnotype                 varchar(1)      DEFAULT ' '        NOT NULL,
    l_serialno                     bigint          DEFAULT 0          NOT NULL,
    l_maxserialno                  bigint          DEFAULT 0          NOT NULL,
    l_lastserialno                 bigint          DEFAULT 0          NOT NULL
);
create index idx_taccoserialno_tmp on ta_taccoserialno_tmp(c_serialnotype, c_tacode, c_tenantid);

-- ������ ta_taccoserialnoload(�˻����м��ر�load)�ĵ�ǰ��
SELECT 'Create Table ta_taccoserialnoload-�˻����м��ر�load...';
DROP TABLE IF EXISTS ta_taccoserialnoload;
create table ta_taccoserialnoload (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_serialnotype                 varchar(1)      DEFAULT ' '        NOT NULL,
    l_serialno                     bigint          DEFAULT 0          NOT NULL,
    l_lastserialno                 bigint          DEFAULT 0          NOT NULL
);

-- ������ ta_taccoserialnotmp(�˻������м��tmp)�ĵ�ǰ��
SELECT 'Create Table ta_taccoserialnotmp-�˻������м��tmp...';
DROP TABLE IF EXISTS ta_taccoserialnotmp;
create table ta_taccoserialnotmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_serialnotype                 varchar(1)      DEFAULT ' '        NOT NULL,
    l_serialno                     bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_serialnotype, c_tacode, c_tenantid)
);

-- ������ ta_tbonusfrozendetail_load(�ֺ춳����ϸ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tbonusfrozendetail_load-�ֺ춳����ϸ���ر�...';
DROP TABLE IF EXISTS ta_tbonusfrozendetail_load;
create table ta_tbonusfrozendetail_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_bonuscserailno               varchar(20)     DEFAULT ' '        NOT NULL,
    c_frozencserailno              varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_unfreezeflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    f_unfrozenshares               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_unfrozencserialno            varchar(20)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL,
    l_shardingno                   int             DEFAULT 0          NOT NULL
);

-- ������ ta_tbonusfrozendetail_tmp(�ֺ춳����ϸ�м��)�ĵ�ǰ��
SELECT 'Create Table ta_tbonusfrozendetail_tmp-�ֺ춳����ϸ�м��...';
DROP TABLE IF EXISTS ta_tbonusfrozendetail_tmp;
create table ta_tbonusfrozendetail_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_unfreezeflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    c_unfrozencserialno            varchar(20)     DEFAULT ' '        NOT NULL
);

-- ������ ta_tbonusfrozendetailroll(�ֺ춳����ϸ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tbonusfrozendetailroll-�ֺ춳����ϸ�ع���...';
DROP TABLE IF EXISTS ta_tbonusfrozendetailroll;
create table ta_tbonusfrozendetailroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          ,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL
);

-- ������ ta_tbreachrdmbooking_load(ΥԼ���������ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tbreachrdmbooking_load-ΥԼ���������ر�...';
DROP TABLE IF EXISTS ta_tbreachrdmbooking_load;
create table ta_tbreachrdmbooking_load (
    c_bookserialno                 varchar(20)     DEFAULT ' '        NOT NULL,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    d_appenddate                   int             DEFAULT 0          NOT NULL,
    d_bookreqdate                  int             DEFAULT 0          NOT NULL,
    f_bookshare                    decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_taflag                       varchar(1)      DEFAULT ' '        NOT NULL,
    c_exceedflag                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_bookstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL,
    l_reqserialno                  bigint          DEFAULT 0          NOT NULL,
    l_shardingno                   int             DEFAULT 0          NOT NULL
);

-- ������ ta_tbreachrdmbookingroll(ΥԼ�������ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tbreachrdmbookingroll-ΥԼ�������ع���...';
DROP TABLE IF EXISTS ta_tbreachrdmbookingroll;
create table ta_tbreachrdmbookingroll (
    c_bookserialno                 varchar(20)     DEFAULT ' '        NOT NULL,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tconfirm_stattmp(����ȷ��stattmp��)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirm_stattmp-����ȷ��stattmp��...';
DROP TABLE IF EXISTS ta_tconfirm_stattmp;
create table ta_tconfirm_stattmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_status                       varchar(1)      DEFAULT ' '        NOT NULL,
    c_chkstatus                    varchar(1)      DEFAULT ' '        NOT NULL,
    total_count                    int             DEFAULT 0          NOT NULL
);
create index idx_tconfirm_stattmp on ta_tconfirm_stattmp(d_cdate, c_chkstatus, c_tacode, c_tenantid);

-- ������ ta_tconfirm_tmp(����ȷ��tmp��)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirm_tmp-����ȷ��tmp��...';
DROP TABLE IF EXISTS ta_tconfirm_tmp;
create table ta_tconfirm_tmp (
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
    f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
    f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
    f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
    f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
    f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
    f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
    f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
    f_interest                     decimal(16,2)   DEFAULT 0.0        ,
    f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
    f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
    f_netvalue                     decimal(7,4)    DEFAULT 0.0        ,
    f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
    c_status                       varchar(1)      DEFAULT ' '        ,
    c_cause                        varchar(4)      DEFAULT ' '        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
    f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    f_confirmratio                 decimal(9,8)    DEFAULT 0.0        ,
    f_oritradefare                 decimal(16,2)   DEFAULT 0.0        ,
    f_oritafare                    decimal(16,2)   DEFAULT 0.0        ,
    f_oribackfare                  decimal(16,2)   DEFAULT 0.0        ,
    f_oriotherfare1                decimal(16,2)   DEFAULT 0.0        ,
    f_oribreachfare                decimal(16,2)   DEFAULT 0.0        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 0.0        ,
    c_shareclass                   varchar(1)      DEFAULT ' '        ,
    c_bourseflag                   varchar(1)      DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_returnfare                   decimal(16,2)   DEFAULT 0.0        ,
    f_punishratio                  decimal(5,4)    DEFAULT 0.0        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_outputdate                   int             DEFAULT 0          ,
    d_reqoutputdate                int             DEFAULT 0          ,
    f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
    f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    c_requestendflag               varchar(1)      DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    l_reqserialno                  bigint          DEFAULT 0          
);
create unique index uidx_tconfirm_tmp on ta_tconfirm_tmp(l_reqserialno, c_businflag);

-- ������ ta_tconfirmdetailroll(ȷ����ϸ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirmdetailroll-ȷ����ϸ�ع���...';
DROP TABLE IF EXISTS ta_tconfirmdetailroll;
create table ta_tconfirmdetailroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tconfirmroll(ȷ�ϻع���)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirmroll-ȷ�ϻع���...';
DROP TABLE IF EXISTS ta_tconfirmroll;
create table ta_tconfirmroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tcustomerinfo_bak(�ͻ����ϱ��ݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustomerinfo_bak-�ͻ����ϱ��ݱ�...';
DROP TABLE IF EXISTS ta_tcustomerinfo_bak;
create table ta_tcustomerinfo_bak (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    d_idnovaliddate                int             DEFAULT 0          NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    c_zipcode                      varchar(6)      DEFAULT ' '        NOT NULL,
    c_address                      varchar(120)    DEFAULT ' '        NOT NULL,
    c_phone                        varchar(32)     DEFAULT ' '        NOT NULL,
    c_faxno                        varchar(24)     DEFAULT ' '        NOT NULL,
    c_mobileno                     varchar(32)     DEFAULT ' '        NOT NULL,
    c_email                        varchar(40)     DEFAULT ' '        NOT NULL,
    c_sex                          varchar(1)      DEFAULT ' '        NOT NULL,
    c_birthday                     varchar(8)      DEFAULT ' '        NOT NULL,
    c_vocation                     varchar(3)      DEFAULT ' '        NOT NULL,
    c_education                    varchar(3)      DEFAULT ' '        NOT NULL,
    c_annualearnings               varchar(8)      DEFAULT ' '        NOT NULL,
    c_corpname                     varchar(40)     DEFAULT ' '        NOT NULL,
    c_corptel                      varchar(32)     DEFAULT ' '        NOT NULL,
    c_contact                      varchar(20)     DEFAULT ' '        NOT NULL,
    c_contype                      varchar(1)      DEFAULT ' '        NOT NULL,
    c_contno                       varchar(30)     DEFAULT ' '        NOT NULL,
    c_contidcard18len              varchar(1)      DEFAULT ' '        NOT NULL,
    c_billsendflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    c_callcenter                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_internet                     varchar(1)      DEFAULT ' '        NOT NULL,
    c_billsendpass                 varchar(1)      DEFAULT ' '        NOT NULL,
    c_nationality                  varchar(3)      DEFAULT ' '        NOT NULL,
    c_lawname                      varchar(20)     DEFAULT ' '        NOT NULL,
    c_lawidtype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_lawidno                      varchar(30)     DEFAULT ' '        NOT NULL,
    c_broker                       varchar(12)     DEFAULT ' '        NOT NULL,
    c_recommender                  varchar(40)     DEFAULT ' '        NOT NULL,
    c_recommendertype              varchar(1)      DEFAULT ' '        NOT NULL,
    c_cityno                       varchar(4)      DEFAULT ' '        NOT NULL,
    c_actcode                      varchar(3)      DEFAULT ' '        NOT NULL,
    c_backreason                   varchar(60)     DEFAULT ' '        NOT NULL,
    c_hometelno                    varchar(32)     DEFAULT ' '        NOT NULL,
    c_minorflag                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_transacttype                 varchar(1)      DEFAULT ' '        NOT NULL,
    d_contidnovaliddate            int             DEFAULT 0          NOT NULL,
    d_lawidnovaliddate             int             DEFAULT 0          NOT NULL,
    c_risklevel                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_managerange                  varchar(2)      DEFAULT ' '        NOT NULL,
    c_controlholder                varchar(80)     DEFAULT ' '        NOT NULL,
    c_actualcontroller             varchar(80)     DEFAULT ' '        NOT NULL,
    c_marital                      varchar(1)      DEFAULT ' '        NOT NULL,
    l_familynum                    int             DEFAULT 0          NOT NULL,
    f_penates                      decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_mediahobby                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_institutiontype              varchar(1)      DEFAULT ' '        NOT NULL,
    c_englishfirstname             varchar(20)     DEFAULT ' '        NOT NULL,
    c_englishfamilyname            varchar(20)     DEFAULT ' '        NOT NULL,
    c_industry                     varchar(4)      DEFAULT ' '        NOT NULL,
    c_companychar                  varchar(4)      DEFAULT ' '        NOT NULL,
    f_employeenum                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_hobbytype                    varchar(2)      DEFAULT ' '        NOT NULL,
    c_province                     varchar(6)      DEFAULT ' '        NOT NULL,
    c_city                         varchar(6)      DEFAULT ' '        NOT NULL,
    c_county                       varchar(6)      DEFAULT ' '        NOT NULL,
    c_specialcode                  varchar(20)     DEFAULT ' '        NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
    d_bakdate                      int             DEFAULT 0          NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_fundacco, c_liqbatchno, d_bakdate, c_tacode, c_tenantid)
);

-- ������ ta_tcustomerinforoll(�˻����ϻع���)�ĵ�ǰ��
SELECT 'Create Table ta_tcustomerinforoll-�˻����ϻع���...';
DROP TABLE IF EXISTS ta_tcustomerinforoll;
create table ta_tcustomerinforoll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tdividenddetail_load(�ֺ���ϸ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tdividenddetail_load-�ֺ���ϸ���ر�...';
DROP TABLE IF EXISTS ta_tdividenddetail_load;
create table ta_tdividenddetail_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    d_registerdate                 int             DEFAULT 0          ,
    d_distributedate               int             DEFAULT 0          ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    f_profittotalshares            decimal(16,2)   DEFAULT 0.0        ,
    f_unitprofit                   decimal(7,4)    DEFAULT 0.0        ,
    f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
    f_profittax                    decimal(16,2)   DEFAULT 0.0        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
    f_reinvestbalance              decimal(16,2)   DEFAULT 0.0        ,
    f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
    f_reinvestnetvalue             decimal(7,4)    DEFAULT 0.0        ,
    f_reinvestfare                 decimal(16,2)   DEFAULT 0.0        ,
    d_reinvestdate                 int             DEFAULT 0          ,
    f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
    c_accostatus                   varchar(1)      DEFAULT ' '        ,
    f_profitratio                  decimal(5,4)    DEFAULT 0.0        ,
    d_outputdate                   int             DEFAULT 0          ,
    c_shareclass                   varchar(1)      DEFAULT ' '        ,
    c_registerstatus               varchar(1)      DEFAULT ' '        ,
    c_frzdtlcserialno              varchar(20)     DEFAULT ' '        ,
    c_schemacode                   varchar(20)     DEFAULT ' '        ,
    f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_lastreinvestfare             decimal(16,2)   DEFAULT 0.0        ,
    f_lastreinvestnetvalue         decimal(7,4)    DEFAULT 0.0        ,
    f_lastreinvestshares           decimal(16,2)   DEFAULT 0.0        ,
    f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        ,
    d_orioutputdate                int             DEFAULT 0          ,
    c_oriregisterstatus            varchar(1)      DEFAULT ' '        ,
    f_lastdeductbalance            decimal(16,2)   DEFAULT 0.0        ,
    c_loadpoint                    varchar(100)    DEFAULT ' '        ,
    c_datastyle                    varchar(30)     DEFAULT ' '        ,
    c_flowno                       varchar(60)     DEFAULT ' '        ,
    l_beginid                      bigint          DEFAULT 0          ,
    l_shardingno                   int             DEFAULT 0          
);
create index idx_tdividendload_serialno on ta_tdividenddetail_load(c_cserialno, c_tacode, c_tenantid);
create index idx_tdividendload_lp on ta_tdividenddetail_load(c_loadpoint, c_tacode, c_tenantid);

-- ������ ta_tdividenddetailroll(�ֺ���ϸ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tdividenddetailroll-�ֺ���ϸ�ع���...';
DROP TABLE IF EXISTS ta_tdividenddetailroll;
create table ta_tdividenddetailroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    d_reinvestdate                 int             DEFAULT 0          NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_texchangerate_tmp(����tmp��)�ĵ�ǰ��
SELECT 'Create Table ta_texchangerate_tmp-����tmp��...';
DROP TABLE IF EXISTS ta_texchangerate_tmp;
create table ta_texchangerate_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    d_date                         int             DEFAULT 0          NOT NULL,
    c_moneytype                    varchar(3)      DEFAULT ' '        NOT NULL,
    f_exchangerate                 decimal(7,4)    DEFAULT 0.0        NOT NULL
);

-- ������ ta_tflowbegintime(���̿�ʼʱ���)�ĵ�ǰ��
SELECT 'Create Table ta_tflowbegintime-���̿�ʼʱ���...';
DROP TABLE IF EXISTS ta_tflowbegintime;
create table ta_tflowbegintime (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_tablename                    varchar(80)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_flowno, c_tablename, c_tacode, c_tenantid)
);

-- ������ ta_tflowlog_load(������־���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tflowlog_load-������־���ر�...';
DROP TABLE IF EXISTS ta_tflowlog_load;
create table ta_tflowlog_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_instanceid                   varchar(20)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
    c_flowinstype                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_callno                       varchar(40)     DEFAULT ' '        NOT NULL,
    c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
    c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
    processSubType                 varchar(100)    DEFAULT ' '        NOT NULL,
    c_fundbackflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    c_agcbackflag                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_mgrbackflag                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_contentcode                  varchar(6)      DEFAULT ' '        NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_flowno2                      varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_instanceid, c_flowno, c_flowstep, c_flowno2, c_tacode, c_tenantid)
);
create index idx_tflowlogloadbiz on ta_tflowlog_load(c_flowno, c_flowstep, c_fundcode, c_agencyno, c_trusteecode, c_managercode, c_tacode, c_tenantid);

-- ������ ta_tfrozendetail_load(������ϸ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tfrozendetail_load-������ϸ���ر�...';
DROP TABLE IF EXISTS ta_tfrozendetail_load;
create table ta_tfrozendetail_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    d_frozendate                   int             DEFAULT 0          NOT NULL,
    c_requestno                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_freezecause                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_freezetype                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_freezeenddate                int             DEFAULT 0          NOT NULL,
    c_frozenrightflag              varchar(1)      DEFAULT ' '        NOT NULL,
    f_balanceright                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_shareright                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_taflag                       varchar(1)      DEFAULT ' '        NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    c_unfreezeflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    f_frozenincome                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_appenddate                   int             DEFAULT 0          NOT NULL,
    f_lastbalance                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastfrozenincome             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastbalanceright             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastshareright               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_orilastmodify                int             DEFAULT 0          NOT NULL,
    c_oriunfreezeflag              varchar(1)      DEFAULT ' '        NOT NULL,
    f_orilastbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL,
    l_shardingno                   int             DEFAULT 0          NOT NULL,
    l_incserno                     bigint          DEFAULT 0          NOT NULL
);

-- ������ ta_tfrozendetail_tmp(������ϸtmp��)�ĵ�ǰ��
SELECT 'Create Table ta_tfrozendetail_tmp-������ϸtmp��...';
DROP TABLE IF EXISTS ta_tfrozendetail_tmp;
create table ta_tfrozendetail_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    d_frozendate                   int             DEFAULT 0          NOT NULL,
    c_requestno                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_freezecause                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_freezetype                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_freezeenddate                int             DEFAULT 0          NOT NULL,
    c_frozenrightflag              varchar(1)      DEFAULT ' '        NOT NULL,
    f_balanceright                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_shareright                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_taflag                       varchar(1)      DEFAULT ' '        NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    c_unfreezeflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    f_frozenincome                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_appenddate                   int             DEFAULT 0          NOT NULL,
    f_lastbalance                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastfrozenincome             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastbalanceright             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastshareright               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_orilastmodify                int             DEFAULT 0          NOT NULL,
    c_oriunfreezeflag              varchar(1)      DEFAULT ' '        NOT NULL,
    f_orilastbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL
);

-- ������ ta_tfrozendetailroll(������ϸ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tfrozendetailroll-������ϸ�ع���...';
DROP TABLE IF EXISTS ta_tfrozendetailroll;
create table ta_tfrozendetailroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          ,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL
);

-- ������ ta_tfundendproj_load(�������̷������ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tfundendproj_load-�������̷������ر�...';
DROP TABLE IF EXISTS ta_tfundendproj_load;
create table ta_tfundendproj_load (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_fundendmode                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_fundendbizflag               varchar(3)      DEFAULT ' '        NOT NULL,
    f_fundendallotbalance          decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_fundendnav                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
    c_fundendprofitflag            varchar(1)      DEFAULT ' '        NOT NULL,
    d_contractenddate              int             DEFAULT 0          NOT NULL,
    f_profittotalnav               decimal(7,4)    DEFAULT 0.0        NOT NULL,
    f_fundendtotalprofit           decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_exportnavdealtype            varchar(1)      DEFAULT ' '        NOT NULL,
    c_fundendtype                  varchar(1)      DEFAULT ' '        NOT NULL,
    f_fundendratio                 decimal(9,8)    DEFAULT 0.0        NOT NULL,
    c_needcalallotbalance          varchar(1)      DEFAULT ' '        NOT NULL,
    c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    c_frozenfundend                varchar(1)      DEFAULT ' '        NOT NULL,
    c_isneeddeal                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
create unique index uidx_fundendprojload on ta_tfundendproj_load(c_fundcode, c_flowno, c_loadpoint, c_datastyle, d_cdate, c_tacode, c_tenantid);

-- ������ ta_tfundinfotmp(��Ʒ������Ϣ��ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundinfotmp-��Ʒ������Ϣ��ʱ��...';
DROP TABLE IF EXISTS ta_tfundinfotmp;
create table ta_tfundinfotmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_fundstatus                   varchar(1)      DEFAULT ' '        ,
    d_failuredate                  int             DEFAULT 0          ,
    d_lastmodify                   int             DEFAULT 0          ,
    f_maxallot                     decimal(9,8)    DEFAULT 0.0        ,
    d_lastverificationdate         int             DEFAULT 0          ,
    d_setupdate                    int             DEFAULT 0          ,
    f_factcollect                  decimal(16,2)   DEFAULT 0.0        ,
    c_factcollectresult            varchar(1)      DEFAULT ' '        ,
    f_allotratio                   decimal(9,8)    DEFAULT 0.0        ,
    d_lastsubdate                  int             DEFAULT 0          
);
create unique index uidx_tfundinfotmp on ta_tfundinfotmp(c_fundcode, c_tenantid);
create index idx_tfundinfofundstatustmp on ta_tfundinfotmp(c_tenantid);

-- ������ ta_tfundstatusday_load(����״̬��ˮ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tfundstatusday_load-����״̬��ˮ���ر�...';
DROP TABLE IF EXISTS ta_tfundstatusday_load;
create table ta_tfundstatusday_load (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_fundstatusdate               int             DEFAULT 0          NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_todaystatus                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_todaypcsstatus               varchar(1)      DEFAULT ' '        NOT NULL,
    c_todaychgstatus               varchar(1)      DEFAULT ' '        NOT NULL,
    c_todaytrfstatus               varchar(1)      DEFAULT ' '        NOT NULL,
    c_todaysplitstatus             varchar(1)      DEFAULT ' '        NOT NULL,
    c_checkpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tfundstatusdaytmp_fnd on ta_tfundstatusday_load(c_fundcode, c_flowno, d_fundstatusdate, c_tenantid);
create index idx_tfundstatusdayt_dcdate on ta_tfundstatusday_load(c_fundcode, d_cdate, c_tenantid);

-- ������ ta_thintlog_load(��ʾ��Ϣ��־���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_thintlog_load-��ʾ��Ϣ��־���ر�...';
DROP TABLE IF EXISTS ta_thintlog_load;
create table ta_thintlog_load (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_flowstep                     varchar(60)     DEFAULT ' '        NOT NULL,
    c_instanceid                   varchar(20)     DEFAULT ' '        NOT NULL,
    c_hintno                       varchar(30)     DEFAULT ' '        NOT NULL,
    c_hintmemo                     varchar(4000)   DEFAULT ' '        NOT NULL,
    c_hintopturl                   varchar(255)    DEFAULT ' '        NOT NULL,
    c_hintlevel                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_hintisread                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_isneeddeal                   varchar(1)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    l_no                           bigint          DEFAULT 0          NOT NULL,
    c_hintoptmode                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_flowno2                      varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
create unique index uidx_thintlog_load on ta_thintlog_load(c_flowno2, c_instanceid, d_cdate, c_flowstep, c_flowno, c_hintno, c_tacode, c_tenantid, l_no);

-- ������ ta_tinterfacelog_load(�ӿ���־���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tinterfacelog_load-�ӿ���־���ر�...';
DROP TABLE IF EXISTS ta_tinterfacelog_load;
create table ta_tinterfacelog_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_ioflow                       varchar(20)     DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_dealcode                     varchar(20)     DEFAULT ' '        NOT NULL,
    d_finishdate                   int             DEFAULT 0          NOT NULL,
    d_finishtime                   int             DEFAULT 0          NOT NULL,
    d_dealtime                     int             DEFAULT 0          NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_dealflag                     varchar(1)      DEFAULT ' '        NOT NULL,
    c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_flowno, c_ioflow, d_cdate, c_dealcode, c_managercode, c_liqbatchno, c_tenantid, c_tacode)
);

-- ������ ta_tnetvalueday_load(��Ʒ��ֵ��ˮ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tnetvalueday_load-��Ʒ��ֵ��ˮ���ر�...';
DROP TABLE IF EXISTS ta_tnetvalueday_load;
create table ta_tnetvalueday_load (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_netvaluedate                 int             DEFAULT 0          NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    f_netvalue                     decimal(7,4)    DEFAULT 1.0        NOT NULL,
    f_lasttotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lasttotalasset               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_asucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_rsucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_vastflag                     varchar(1)      DEFAULT ' '        NOT NULL,
    f_encashratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
    f_changeratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
    c_excessflag                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_subscriberatio               decimal(9,8)    DEFAULT 1.0        NOT NULL,
    c_inputpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
    c_checkpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
    f_fundtotalincome              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_incomeunit                   decimal(10,5)   DEFAULT 0.0        NOT NULL,
    f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        NOT NULL,
    f_incomeratio                  decimal(9,6)    DEFAULT 0.0        NOT NULL,
    f_servicefare                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_assign                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_unassign                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_growthrate                   decimal(9,8)    DEFAULT 0.0        NOT NULL,
    f_managefare                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_protectbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_exportdate                   int             DEFAULT 0          NOT NULL,
    c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
    c_flowcode                     varchar(3)      DEFAULT ' '        NOT NULL,
    f_lastunassign                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_structuredratio              decimal(9,8)    DEFAULT 1.0        NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        NOT NULL,
    d_filedate                     int             DEFAULT 0          NOT NULL,
    f_filetotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_structuredtotalasset         decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
create index uidx_tnetvalueday_load on ta_tnetvalueday_load(c_fundcode, d_netvaluedate, c_tenantid);
create unique index idx_tnetvalueday_load on ta_tnetvalueday_load(c_flowno, c_loadpoint, c_datastyle, c_fundcode, d_cdate, c_tenantid);
create index idx_tnetvaluedayload_dcate on ta_tnetvalueday_load(d_cdate);

-- ������ ta_tnetvalueday_uftinsert(��Ʒ��ֵ��ˮuft�����)�ĵ�ǰ��
SELECT 'Create Table ta_tnetvalueday_uftinsert-��Ʒ��ֵ��ˮuft�����...';
DROP TABLE IF EXISTS ta_tnetvalueday_uftinsert;
create table ta_tnetvalueday_uftinsert (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_netvaluedate                 int             DEFAULT 0          NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    f_netvalue                     decimal(7,4)    DEFAULT 1.0        NOT NULL,
    f_lasttotalshare               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lasttotalasset               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_asucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_rsucceed                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_vastflag                     varchar(1)      DEFAULT ' '        NOT NULL,
    f_encashratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
    f_changeratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
    c_excessflag                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_subscriberatio               decimal(9,8)    DEFAULT 1.0        NOT NULL,
    f_fundtotalincome              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_incomeunit                   decimal(10,5)   DEFAULT 0.0        NOT NULL,
    f_totalnetvalue                decimal(7,4)    DEFAULT 0.0        NOT NULL,
    f_incomeratio                  decimal(9,6)    DEFAULT 0.0        NOT NULL,
    f_servicefare                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_assign                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_unassign                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_growthrate                   decimal(9,8)    DEFAULT 0.0        NOT NULL,
    f_managefare                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_protectbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_exportdate                   int             DEFAULT 0          NOT NULL,
    c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
    c_flowcode                     varchar(3)      DEFAULT ' '        NOT NULL,
    f_lastunassign                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_structuredratio              decimal(9,8)    DEFAULT 1.0        NOT NULL,
PRIMARY KEY(d_cdate, c_fundcode, c_tacode, c_tenantid)
);

-- ������ ta_tnetvaluedaytmp(��Ʒ��ֵ��ˮ��ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tnetvaluedaytmp-��Ʒ��ֵ��ˮ��ʱ��...';
DROP TABLE IF EXISTS ta_tnetvaluedaytmp;
create table ta_tnetvaluedaytmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_netvaluedate                 int             DEFAULT 0          NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_vastflag                     varchar(1)      DEFAULT ' '        NOT NULL,
    f_encashratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
    f_changeratio                  decimal(9,8)    DEFAULT 1.0        NOT NULL,
    c_excessflag                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_subscriberatio               decimal(9,8)    DEFAULT 1.0        NOT NULL,
    f_servicefare                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_assign                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_unassign                     decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_growthrate                   decimal(9,8)    DEFAULT 0.0        NOT NULL,
    f_managefare                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_protectbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_exportdate                   int             DEFAULT 0          NOT NULL,
    f_structuredratio              decimal(9,8)    DEFAULT 1.0        NOT NULL,
PRIMARY KEY(d_cdate, c_fundcode, c_tacode, c_tenantid)
);

-- ������ ta_tprofitcurrentsroll(ҵ����ɻع���ˮ��)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitcurrentsroll-ҵ����ɻع���ˮ��...';
DROP TABLE IF EXISTS ta_tprofitcurrentsroll;
create table ta_tprofitcurrentsroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tprofitproj_bak(ҵ����ɷ������ݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitproj_bak-ҵ����ɷ������ݱ�...';
DROP TABLE IF EXISTS ta_tprofitproj_bak;
create table ta_tprofitproj_bak (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_deductcode                   varchar(6)      DEFAULT ' '        ,
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_istemplate                   varchar(1)      DEFAULT '0'        ,
    c_description                  varchar(2048)   DEFAULT ' '        ,
    c_spefield                     varchar(1024)   DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_deductmode                   varchar(1)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_mfundacco                    varchar(12)     DEFAULT ' '        ,
    c_deductalgo                   varchar(1)      DEFAULT '1'        ,
    c_yeardays                     varchar(1)      DEFAULT '0'        ,
    c_holddays                     varchar(1)      DEFAULT '0'        ,
    c_ratiotype                    varchar(1)      DEFAULT '0'        ,
    c_includefare                  varchar(1)      DEFAULT '0'        ,
    c_referblctype                 varchar(1)      DEFAULT '0'        ,
    c_profitallincome              varchar(1)      DEFAULT '0'        ,
    c_regression                   varchar(1)      DEFAULT '0'        ,
    c_deductmngfare                varchar(1)      DEFAULT '0'        ,
    c_returnfare                   varchar(1)      DEFAULT '0'        ,
    f_maxdeductscale               decimal(5,4)    DEFAULT 0.0        ,
    c_ductdateupdaterule           varchar(1)      DEFAULT '0'        ,
    c_dealflag                     varchar(1)      DEFAULT '0'        ,
    d_dealdate                     int             DEFAULT 0          ,
    d_begindate                    int             DEFAULT 0          ,
    d_enddate                      int             DEFAULT 0          ,
    c_deductname                   varchar(128)    DEFAULT ' '        ,
    c_calratiobytotalnet           varchar(1)      DEFAULT ' '        ,
    c_calcratiominuscapital        varchar(1)      DEFAULT ' '        ,
    f_fixedstandardnet             decimal(7,4)    DEFAULT 0.0        ,
    f_overtotalnav                 decimal(7,4)    DEFAULT 0.0        ,
    c_subsharepftfree              varchar(1)      DEFAULT ' '        ,
    c_mgraccosharesdealtype        varchar(1)      DEFAULT ' '        ,
    c_profitfundcode               varchar(6)      DEFAULT ' '        ,
    c_profitbalancedealtype        varchar(1)      DEFAULT ' '        ,
    c_mtradeacco                   varchar(24)     DEFAULT ' '        ,
    f_firstdeductovernav           decimal(7,4)    DEFAULT 0.0        ,
    c_autodealflag                 varchar(1)      DEFAULT '0'        ,
    c_indexcode                    varchar(20)     DEFAULT ' '        ,
    c_indexratiotozero             varchar(1)      DEFAULT ' '        ,
    c_custincomemode               varchar(1)      DEFAULT ' '        ,
    c_calconly                     varchar(1)      DEFAULT '0'        ,
    c_outfundcode                  varchar(12)     DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
create unique index uidx_ttprofitproj_bak on ta_tprofitproj_bak(c_fundcode, d_dealdate, d_begindate, c_deductmode, c_calconly, c_tacode, c_tenantid);

-- ������ ta_tprofitproj_load(ҵ����ɷ������ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitproj_load-ҵ����ɷ������ر�...';
DROP TABLE IF EXISTS ta_tprofitproj_load;
create table ta_tprofitproj_load (
    c_deductcode                   varchar(6)      DEFAULT ' '        NOT NULL,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_istemplate                   varchar(1)      DEFAULT '0'        NOT NULL,
    c_description                  varchar(2048)   DEFAULT ' '        NOT NULL,
    c_spefield                     varchar(1024)   DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_deductmode                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_mfundacco                    varchar(12)     DEFAULT ' '        NOT NULL,
    c_deductalgo                   varchar(1)      DEFAULT '1'        NOT NULL,
    c_yeardays                     varchar(1)      DEFAULT '0'        NOT NULL,
    c_holddays                     varchar(1)      DEFAULT '0'        NOT NULL,
    c_ratiotype                    varchar(1)      DEFAULT '0'        NOT NULL,
    c_includefare                  varchar(1)      DEFAULT '0'        NOT NULL,
    c_referblctype                 varchar(1)      DEFAULT '0'        NOT NULL,
    c_profitallincome              varchar(1)      DEFAULT '0'        NOT NULL,
    c_regression                   varchar(1)      DEFAULT '0'        NOT NULL,
    c_deductmngfare                varchar(1)      DEFAULT '0'        NOT NULL,
    c_returnfare                   varchar(1)      DEFAULT '0'        NOT NULL,
    f_maxdeductscale               decimal(5,4)    DEFAULT 0.0        NOT NULL,
    c_ductdateupdaterule           varchar(1)      DEFAULT '0'        NOT NULL,
    c_dealflag                     varchar(1)      DEFAULT '0'        NOT NULL,
    d_dealdate                     int             DEFAULT 0          NOT NULL,
    d_begindate                    int             DEFAULT 0          NOT NULL,
    d_enddate                      int             DEFAULT 0          NOT NULL,
    c_deductname                   varchar(128)    DEFAULT ' '        NOT NULL,
    c_calratiobytotalnet           varchar(1)      DEFAULT ' '        NOT NULL,
    c_calcratiominuscapital        varchar(1)      DEFAULT ' '        NOT NULL,
    f_fixedstandardnet             decimal(7,4)    DEFAULT 0.0        NOT NULL,
    f_overtotalnav                 decimal(7,4)    DEFAULT 0.0        NOT NULL,
    c_subsharepftfree              varchar(1)      DEFAULT ' '        NOT NULL,
    c_mgraccosharesdealtype        varchar(1)      DEFAULT ' '        NOT NULL,
    c_profitfundcode               varchar(6)      DEFAULT ' '        NOT NULL,
    c_profitbalancedealtype        varchar(1)      DEFAULT ' '        NOT NULL,
    c_mtradeacco                   varchar(24)     DEFAULT ' '        NOT NULL,
    f_firstdeductovernav           decimal(7,4)    DEFAULT 0.0        NOT NULL,
    c_autodealflag                 varchar(1)      DEFAULT '0'        NOT NULL,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
create unique index uidx_ttprofitproj_load on ta_tprofitproj_load(c_fundcode, d_dealdate, d_begindate, c_deductmode, c_flowno, c_loadpoint, c_datastyle, c_tacode, c_tenantid);

-- ������ ta_tprofitschema_load(�ֺ췽�����ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitschema_load-�ֺ췽�����ر�...';
DROP TABLE IF EXISTS ta_tprofitschema_load;
create table ta_tprofitschema_load (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_schemacode                   varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    d_registerdate                 int             DEFAULT 0          NOT NULL,
    f_unitprofit                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
    d_distributedate               int             DEFAULT 0          NOT NULL,
    d_reinvestdate                 int             DEFAULT 0          NOT NULL,
    c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
    c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_profitratio                  decimal(5,4)    DEFAULT 0.0        NOT NULL,
    c_frzbalanceflag               varchar(1)      DEFAULT ' '        NOT NULL,
    c_frzsharesflag                varchar(1)      DEFAULT ' '        NOT NULL,
    c_frzforcereinvest             varchar(1)      DEFAULT ' '        NOT NULL,
    c_bonustype                    varchar(1)      DEFAULT ' '        NOT NULL,
    f_totalprofit                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_bonusmode                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_autodealflag                 varchar(1)      DEFAULT '1'        NOT NULL,
    c_frzbonussharedtl             varchar(1)      DEFAULT '0'        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
create unique index uidx_tprofitschemald_code on ta_tprofitschema_load(c_schemacode, c_flowno, c_loadpoint, c_datastyle, c_tenantid);
create index idx_tprofitschemaload_fnd on ta_tprofitschema_load(c_fundcode, c_flowno, c_loadpoint, c_datastyle, c_tenantid);

-- ������ ta_trationroll(���ڶ���Э��ع���)�ĵ�ǰ��
SELECT 'Create Table ta_trationroll-���ڶ���Э��ع���...';
DROP TABLE IF EXISTS ta_trationroll;
create table ta_trationroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_rationno                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_trequest_imp(��������IMP��)�ĵ�ǰ��
SELECT 'Create Table ta_trequest_imp-��������IMP��...';
DROP TABLE IF EXISTS ta_trequest_imp;
create table ta_trequest_imp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    d_requesttime                  int             DEFAULT 0          ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    f_agio                         decimal(5,4)    DEFAULT 1.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    d_hopedate                     int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    f_totalbackendload             decimal(16,2)   DEFAULT 0.0        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_factdate                     int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_rationvariety                varchar(5)      DEFAULT ' '        ,
    c_rationserialno               varchar(5)      DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    c_protocolno                   varchar(20)     DEFAULT ' '        ,
    d_protocolbegindate            int             DEFAULT 0          ,
    d_protocolenddate              int             DEFAULT 0          ,
    l_rationdate                   int             DEFAULT 0          ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_rationpurpose                varchar(40)     DEFAULT ' '        ,
    l_rationfrequency              int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    c_rationtimeunit               varchar(1)      DEFAULT ' '        ,
    f_rationnum                    decimal(16,2)   DEFAULT 0.0        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 1.0        ,
    c_combcode                     varchar(6)      DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    f_oriagio                      decimal(5,4)    DEFAULT 1.0        ,
    c_taflag                       varchar(1)      DEFAULT '0'        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cause                        varchar(4)      DEFAULT '0000'     ,
    d_date                         int             DEFAULT 0          ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    d_cdate                        int             DEFAULT 0          ,
    f_confirmratio                 decimal(9,8)    DEFAULT 1.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    c_freezeno                     varchar(128)    DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_improperredeem               varchar(1)      DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    d_registdate                   int             DEFAULT 0          ,
    f_confirmedbalance             decimal(16,2)   DEFAULT 0.0        ,
    f_confirmedshares              decimal(16,2)   DEFAULT 0.0        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_nodealflag                   varchar(1)      DEFAULT '0'        ,
    f_reqrdmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_manualtradefare              decimal(16,2)   DEFAULT 0.0        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    l_reqserialno                  bigint          DEFAULT 0          
);

-- ������ ta_trequest_imp_load(��������IMP���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_trequest_imp_load-��������IMP���ر�...';
DROP TABLE IF EXISTS ta_trequest_imp_load;
create table ta_trequest_imp_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    d_requesttime                  int             DEFAULT 0          ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    f_agio                         decimal(5,4)    DEFAULT 1.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    d_hopedate                     int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    f_totalbackendload             decimal(16,2)   DEFAULT 0.0        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_factdate                     int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_rationvariety                varchar(5)      DEFAULT ' '        ,
    c_rationserialno               varchar(5)      DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    c_protocolno                   varchar(20)     DEFAULT ' '        ,
    d_protocolbegindate            int             DEFAULT 0          ,
    d_protocolenddate              int             DEFAULT 0          ,
    l_rationdate                   int             DEFAULT 0          ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_rationpurpose                varchar(40)     DEFAULT ' '        ,
    l_rationfrequency              int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    c_rationtimeunit               varchar(1)      DEFAULT ' '        ,
    f_rationnum                    decimal(16,2)   DEFAULT 0.0        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 1.0        ,
    c_combcode                     varchar(6)      DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    f_oriagio                      decimal(5,4)    DEFAULT 1.0        ,
    c_taflag                       varchar(1)      DEFAULT '0'        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cause                        varchar(4)      DEFAULT '0000'     ,
    d_date                         int             DEFAULT 0          ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    d_cdate                        int             DEFAULT 0          ,
    f_confirmratio                 decimal(9,8)    DEFAULT 1.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    c_freezeno                     varchar(128)    DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_improperredeem               varchar(1)      DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    d_registdate                   int             DEFAULT 0          ,
    f_confirmedbalance             decimal(16,2)   DEFAULT 0.0        ,
    f_confirmedshares              decimal(16,2)   DEFAULT 0.0        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_nodealflag                   varchar(1)      DEFAULT '0'        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL
);
create index idx_trequest_imp_load_ta on ta_trequest_imp_load(c_tacode, c_tenantid);

-- ������ ta_trequest_improll(��������IMP�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_trequest_improll-��������IMP�ع���...';
DROP TABLE IF EXISTS ta_trequest_improll;
create table ta_trequest_improll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_requestno                    varchar(24)     DEFAULT ' '        NOT NULL,
    d_requestdate                  int             DEFAULT 0          NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL
);
create index uidx_trequest_improll on ta_trequest_improll(c_tenantid, c_tacode, c_requestno, d_requestdate, c_agencyno);

-- ������ ta_trequest_tmp(����������ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_trequest_tmp-����������ʱ��...';
DROP TABLE IF EXISTS ta_trequest_tmp;
create table ta_trequest_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_requestno                    varchar(24)     DEFAULT ' '        ,
    d_requestdate                  int             DEFAULT 0          ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_exceedflag                   varchar(1)      DEFAULT ' '        ,
    d_requesttime                  int             DEFAULT 0          ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    f_shares                       decimal(16,2)   DEFAULT 0.0        ,
    f_balance                      decimal(16,2)   DEFAULT 0.0        ,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    f_agio                         decimal(5,4)    DEFAULT 1.0        ,
    c_cityno                       varchar(4)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_orirequestno                 varchar(24)     DEFAULT ' '        ,
    d_hopedate                     int             DEFAULT 0          ,
    c_oricserialno                 varchar(20)     DEFAULT ' '        ,
    c_otheragency                  varchar(9)      DEFAULT ' '        ,
    f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
    c_othernetno                   varchar(9)      DEFAULT ' '        ,
    c_othertradeacco               varchar(24)     DEFAULT ' '        ,
    c_othercode                    varchar(12)     DEFAULT ' '        ,
    f_totalbackendload             decimal(16,2)   DEFAULT 0.0        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_factdate                     int             DEFAULT 0          ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    c_freezecause                  varchar(1)      DEFAULT ' '        ,
    d_freezeenddate                int             DEFAULT 0          ,
    c_rationvariety                varchar(5)      DEFAULT ' '        ,
    c_rationserialno               varchar(5)      DEFAULT ' '        ,
    c_rationtype                   varchar(1)      DEFAULT ' '        ,
    c_otheracco                    varchar(12)     DEFAULT ' '        ,
    c_childnetno                   varchar(9)      DEFAULT ' '        ,
    c_othershare                   varchar(1)      DEFAULT ' '        ,
    c_protocolno                   varchar(20)     DEFAULT ' '        ,
    d_protocolbegindate            int             DEFAULT 0          ,
    d_protocolenddate              int             DEFAULT 0          ,
    l_rationdate                   int             DEFAULT 0          ,
    c_broker                       varchar(12)     DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_rationpurpose                varchar(40)     DEFAULT ' '        ,
    l_rationfrequency              int             DEFAULT 0          ,
    c_rationterm                   varchar(8)      DEFAULT ' '        ,
    c_rationtimeunit               varchar(1)      DEFAULT ' '        ,
    f_rationnum                    decimal(16,2)   DEFAULT 0.0        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_backfareagio                 decimal(5,4)    DEFAULT 1.0        ,
    c_combcode                     varchar(6)      DEFAULT ' '        ,
    c_trademethod                  varchar(8)      DEFAULT ' '        ,
    c_businflag                    varchar(2)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_reqtradeacco                 varchar(24)     DEFAULT ' '        ,
    f_oriagio                      decimal(5,4)    DEFAULT 1.0        ,
    c_taflag                       varchar(1)      DEFAULT '0'        ,
    c_chkstatus                    varchar(1)      DEFAULT '0'        ,
    c_status                       varchar(1)      DEFAULT '0'        ,
    c_cause                        varchar(4)      DEFAULT '0000'     ,
    d_date                         int             DEFAULT 0          ,
    f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
    d_cdate                        int             DEFAULT 0          ,
    f_confirmratio                 decimal(9,8)    DEFAULT 1.0        ,
    f_price                        decimal(12,4)   DEFAULT 0.0        ,
    c_freezeno                     varchar(128)    DEFAULT ' '        ,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        ,
    c_transfarecause               varchar(1)      DEFAULT ' '        ,
    c_adjustcause                  varchar(1)      DEFAULT ' '        ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    c_improperredeem               varchar(1)      DEFAULT ' '        ,
    f_otherprice                   decimal(7,4)    DEFAULT 0.0        ,
    d_originaldate                 int             DEFAULT 0          ,
    c_liqbatchno                   varchar(1)      DEFAULT '1'        ,
    c_forceredemptiontype          varchar(1)      DEFAULT ' '        ,
    l_pageno                       int             DEFAULT 0          ,
    d_registdate                   int             DEFAULT 0          ,
    f_confirmedbalance             decimal(16,2)   DEFAULT 0.0        ,
    f_confirmedshares              decimal(16,2)   DEFAULT 0.0        ,
    c_operator                     varchar(16)     DEFAULT ' '        ,
    c_memo                         varchar(60)     DEFAULT ' '        ,
    c_nodealflag                   varchar(1)      DEFAULT '0'        ,
    f_reqrdmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_manualtradefare              decimal(16,2)   DEFAULT 0.0        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    l_reqserialno                  bigint          DEFAULT 0          ,
    l_shardingno                   int             DEFAULT 0          NOT NULL
);
create unique index idx_ta_trequestmp_serialno on ta_trequest_tmp(l_reqserialno);
create index idx_trequest_tmp_ta on ta_trequest_tmp(l_shardingno, c_tacode, c_tenantid, c_status);

-- ������ ta_trequest_uft(��������UFT��)�ĵ�ǰ��
SELECT 'Create Table ta_trequest_uft-��������UFT��...';
DROP TABLE IF EXISTS ta_trequest_uft;
create table ta_trequest_uft (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tsharecurrentsroll(�ݶ�仯��ˮ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tsharecurrentsroll-�ݶ�仯��ˮ�ع���...';
DROP TABLE IF EXISTS ta_tsharecurrentsroll;
create table ta_tsharecurrentsroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tsharedetail_load(�ݶ���ϸ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tsharedetail_load-�ݶ���ϸ���ر�...';
DROP TABLE IF EXISTS ta_tsharedetail_load;
create table ta_tsharedetail_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    c_sourcetype                   varchar(1)      DEFAULT ' '        ,
    f_remainshares                 decimal(16,2)   DEFAULT 0.0        ,
    d_registdate                   int             DEFAULT 0          ,
    f_oricfmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_oricfmshares                 decimal(16,2)   DEFAULT 0.0        ,
    f_orinetvalue                  decimal(7,4)    DEFAULT 0.0        ,
    c_orisource                    varchar(1)      DEFAULT ' '        ,
    f_ruleagio                     decimal(5,4)    DEFAULT 1.0        ,
    f_oriagio                      decimal(5,4)    DEFAULT 1.0        ,
    f_maxallotratio                decimal(5,4)    DEFAULT 0.0        ,
    f_minredeemratio               decimal(5,4)    DEFAULT 0.0        ,
    c_holdflag                     varchar(1)      DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_actcode                      varchar(3)      DEFAULT ' '        ,
    c_firstcserailno               varchar(20)     DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_managefare                   decimal(16,2)   DEFAULT 0.0        ,
    f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
    d_lastdeductdate               int             DEFAULT 0          ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    f_pendsubmit02shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit03shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit50shr              decimal(16,2)   DEFAULT 0.0        ,
    f_assignshare                  decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit13shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit16shr              decimal(16,2)   DEFAULT 0.0        ,
    f_lastremainshares             decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit14shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit15shr              decimal(16,2)   DEFAULT 0.0        ,
    f_lastincome                   decimal(16,2)   DEFAULT 0.0        ,
    d_orilastdeductdate            int             DEFAULT 0          ,
    f_costprice                    decimal(15,12)  DEFAULT 0.0        ,
    f_apportionratio               decimal(9,8)    DEFAULT 0.0        ,
    f_fareratio                    decimal(5,4)    DEFAULT 0.0        ,
    f_backfareratio                decimal(9,8)    DEFAULT 0.0        ,
    f_minbackratio                 decimal(5,4)    DEFAULT 0.0        ,
    l_incserno                     bigint          DEFAULT 0          ,
    c_loadpoint                    varchar(100)    DEFAULT ' '        ,
    c_datastyle                    varchar(30)     DEFAULT ' '        ,
    c_flowno                       varchar(60)     DEFAULT ' '        ,
    l_beginid                      bigint          DEFAULT 0          ,
    l_shardingno                   int             DEFAULT 0          
);
create index idx_tsharedetail_load on ta_tsharedetail_load(c_fundacco, c_agencyno, c_netno, c_tradeacco, c_fundcode, c_sharetype, c_tenantid);

-- ������ ta_tstaticshares_load(��̬�ݶ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tstaticshares_load-��̬�ݶ���ر�...';
DROP TABLE IF EXISTS ta_tstaticshares_load;
create table ta_tstaticshares_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    f_realshares                   decimal(16,2)   DEFAULT 0.0        ,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
    c_bonustype                    varchar(1)      DEFAULT ' '        ,
    d_lastmodify                   int             DEFAULT 0          ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    f_frozenincome                 decimal(16,2)   DEFAULT 0.0        ,
    c_custtype                     varchar(1)      DEFAULT ' '        ,
    f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
    c_invested                     varchar(1)      DEFAULT ' '        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    d_shrsubmitdate                int             DEFAULT 0          ,
    f_pendsubmit02shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit03shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit50shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmitfrzshr             decimal(16,2)   DEFAULT 0.0        ,
    f_assignshare                  decimal(16,2)   DEFAULT 0.0        ,
    f_bonusunit                    decimal(16,2)   DEFAULT 0.0        ,
    f_floorbalance                 decimal(10,9)   DEFAULT 0.0        ,
    f_pendsubmit13shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit16shr              decimal(16,2)   DEFAULT 0.0        ,
    f_lastrealshares               decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit14shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit15shr              decimal(16,2)   DEFAULT 0.0        ,
    c_shareclass                   varchar(1)      DEFAULT ' '        ,
    f_lastincome                   decimal(16,2)   DEFAULT 0.0        ,
    f_lastfrozenincome             decimal(16,2)   DEFAULT 0.0        ,
    f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        ,
    d_orilastmodify                int             DEFAULT 0          ,
    f_lastfloorbalance             decimal(10,9)   DEFAULT 0.0        ,
    c_oribonustype                 varchar(1)      DEFAULT ' '        ,
    l_incserno                     bigint          DEFAULT 0          ,
    c_loadpoint                    varchar(100)    DEFAULT ' '        ,
    c_datastyle                    varchar(30)     DEFAULT ' '        ,
    c_flowno                       varchar(60)     DEFAULT ' '        ,
    l_beginid                      bigint          DEFAULT 0          ,
    l_shardingno                   int             DEFAULT 0          
);
create index idx_tstaticshares_load on ta_tstaticshares_load(c_fundacco, c_tradeacco, c_fundcode, c_sharetype, c_agencyno, c_netno, c_tenantid, c_loadpoint);

-- ������ ta_tstaticshares_tmp(��̬�ݶ���ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tstaticshares_tmp-��̬�ݶ���ʱ��...';
DROP TABLE IF EXISTS ta_tstaticshares_tmp;
create table ta_tstaticshares_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    f_realshares                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_bonustype                    varchar(1)      DEFAULT ' '        NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    f_income                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_frozenincome                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_custtype                     varchar(1)      DEFAULT ' '        NOT NULL,
    f_newincome                    decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_invested                     varchar(1)      DEFAULT ' '        NOT NULL,
    c_specialcode                  varchar(20)     DEFAULT ' '        NOT NULL,
    d_shrsubmitdate                int             DEFAULT 0          NOT NULL,
    f_pendsubmit02shr              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_pendsubmit03shr              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_pendsubmit50shr              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_pendsubmitfrzshr             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_assignshare                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_bonusunit                    decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_floorbalance                 decimal(10,9)   DEFAULT 0.0        NOT NULL,
    f_pendsubmit13shr              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_pendsubmit16shr              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastrealshares               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_pendsubmit14shr              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_pendsubmit15shr              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_shareclass                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_lastincome                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastfrozenincome             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastfrozenshares             decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_orilastmodify                int             DEFAULT 0          NOT NULL,
    f_lastfloorbalance             decimal(10,9)   DEFAULT 0.0        NOT NULL,
    c_oribonustype                 varchar(1)      DEFAULT ' '        NOT NULL,
    f_protectbalance               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    l_incserno                     bigint          DEFAULT 0          NOT NULL,
    c_adrmflag                     varchar(1)      DEFAULT ' '        NOT NULL
);

-- ������ ta_tstaticsharesroll(��̬�ݶ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tstaticsharesroll-��̬�ݶ�ع���...';
DROP TABLE IF EXISTS ta_tstaticsharesroll;
create table ta_tstaticsharesroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          ,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL
);

-- ������ ta_tsubsconfirmroll(�Ϲ�ȷ�ϻع���)�ĵ�ǰ��
SELECT 'Create Table ta_tsubsconfirmroll-�Ϲ�ȷ�ϻع���...';
DROP TABLE IF EXISTS ta_tsubsconfirmroll;
create table ta_tsubsconfirmroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tsubsconfirmtmp(�Ϲ�ȷ����ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tsubsconfirmtmp-�Ϲ�ȷ����ʱ��...';
DROP TABLE IF EXISTS ta_tsubsconfirmtmp;
create table ta_tsubsconfirmtmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    c_dealstatus                   varchar(1)      DEFAULT ' '        ,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        
);

-- ������ ta_ttransfercommission_imp(OTCת��ί�гɽ���ϸIMP��)�ĵ�ǰ��
SELECT 'Create Table ta_ttransfercommission_imp-OTCת��ί�гɽ���ϸIMP��...';
DROP TABLE IF EXISTS ta_ttransfercommission_imp;
create table ta_ttransfercommission_imp (
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_commissionid                 varchar(24)     DEFAULT ' '        NOT NULL,
    c_requestno                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    d_date                         int             DEFAULT 0          NOT NULL,
    c_outfundcode                  varchar(12)     DEFAULT ' '        NOT NULL,
    c_issuecode                    varchar(8)      DEFAULT ' '        NOT NULL,
    c_fundno                       varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_otctacode                    varchar(8)      DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_commissiontype               varchar(1)      DEFAULT ' '        NOT NULL,
    c_outbusinflag                 varchar(3)      DEFAULT ' '        NOT NULL,
    f_price                        decimal(12,4)   DEFAULT 0.0        NOT NULL,
    f_shares                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_requestdate                  int             DEFAULT 0          NOT NULL,
    d_requesttime                  int             DEFAULT 0          NOT NULL,
    c_otheragency                  varchar(9)      DEFAULT ' '        NOT NULL,
    c_othernetno                   varchar(9)      DEFAULT ' '        NOT NULL,
    c_otheracco                    varchar(12)     DEFAULT ' '        NOT NULL,
    c_othertradeacco               varchar(24)     DEFAULT ' '        NOT NULL,
    c_targettacode                 varchar(8)      DEFAULT ' '        NOT NULL,
    c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_otccause                     varchar(40)     DEFAULT ' '        NOT NULL,
    c_oricserialno                 varchar(20)     DEFAULT ' '        NOT NULL,
    d_originaldate                 int             DEFAULT 0          NOT NULL,
    c_specialrequestflag           varchar(1)      DEFAULT ' '        NOT NULL,
    c_status                       varchar(1)      DEFAULT '0'        NOT NULL,
    c_chkstatus                    varchar(1)      DEFAULT '0'        NOT NULL,
    l_pageno                       int             DEFAULT 0          NOT NULL
);
create unique index uidx_ttransfercommissiont on ta_ttransfercommission_imp(c_tacode, c_tenantid, c_commissionid, c_requestno, c_agencyno, d_requestdate);

-- ������ ta_ttransfercommissionroll(OTCת��ί�гɽ���ϸ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_ttransfercommissionroll-OTCת��ί�гɽ���ϸ�ع���...';
DROP TABLE IF EXISTS ta_ttransfercommissionroll;
create table ta_ttransfercommissionroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_cserialno, c_loadpoint)
);

-- ������ ta_tunsenddividend_load(δ���ŷֺ���ϸ���ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tunsenddividend_load-δ���ŷֺ���ϸ���ر�...';
DROP TABLE IF EXISTS ta_tunsenddividend_load;
create table ta_tunsenddividend_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialnototal               varchar(20)     DEFAULT ' '        NOT NULL,
    d_registerdate                 int             DEFAULT 0          NOT NULL,
    d_distributedate               int             DEFAULT 0          NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    f_profittotalshares            decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_unitprofit                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
    f_totalprofit                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_bonustype                    varchar(1)      DEFAULT ' '        NOT NULL,
    f_profittax                    decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_realbalance                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_reinvestshares               decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_reinvestfare                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_reinvestdate                 int             DEFAULT 0          NOT NULL,
    f_reinvestnetvalue             decimal(7,4)    DEFAULT 0.0        NOT NULL,
    f_frozenbalance                decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_frozenshares                 decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_profitratio                  decimal(5,4)    DEFAULT 0.0        NOT NULL,
    c_delaycause                   varchar(1)      DEFAULT ' '        NOT NULL,
    d_senddate                     int             DEFAULT 0          NOT NULL,
    c_frozenno                     varchar(20)     DEFAULT ' '        NOT NULL,
    d_outputdate                   int             DEFAULT 0          NOT NULL,
    f_deductbalance                decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_schemacode                   varchar(20)     DEFAULT ' '        NOT NULL,
    c_oridelaycause                varchar(1)      DEFAULT ' '        NOT NULL,
    d_orisenddate                  int             DEFAULT 0          NOT NULL,
    f_lastfrozenbalance            decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_lastdeductbalance            decimal(16,2)   DEFAULT 0.0        NOT NULL,
    d_orioutputdate                int             DEFAULT 0          NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL,
    l_shardingno                   int             DEFAULT 0          NOT NULL
);

-- ������ ta_tunsenddividend_tmp(δ���ŷֺ���ϸ��ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tunsenddividend_tmp-δ���ŷֺ���ϸ��ʱ��...';
DROP TABLE IF EXISTS ta_tunsenddividend_tmp;
create table ta_tunsenddividend_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    f_frozenbalance                decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_delaycause                   varchar(1)      DEFAULT ' '        NOT NULL,
    d_senddate                     int             DEFAULT 0          NOT NULL,
PRIMARY KEY(c_tenantid, c_cserialno)
);

-- ������ ta_tunsenddividendroll(δ���ŷֺ���ϸ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tunsenddividendroll-δ���ŷֺ���ϸ�ع���...';
DROP TABLE IF EXISTS ta_tunsenddividendroll;
create table ta_tunsenddividendroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tupgradecurrentsroll(��������ˮ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tupgradecurrentsroll-��������ˮ�ع���...';
DROP TABLE IF EXISTS ta_tupgradecurrentsroll;
create table ta_tupgradecurrentsroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    f_shares                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_income                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_oriclass                     varchar(1)      DEFAULT 'A'        NOT NULL,
    c_shareclass                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_newcode                      varchar(12)     DEFAULT ' '        NOT NULL,
    c_unicode                      varchar(12)     DEFAULT ' '        NOT NULL,
    c_upgradeserialno              varchar(14)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_tacode, c_agencyno, c_upgradeserialno)
);
create index idx_tupgradecurrentsroll on ta_tupgradecurrentsroll(c_fundacco, c_agencyno, c_netno, c_tradeacco);
create index idx_upgradecurrents_dcate on ta_tupgradecurrentsroll(d_cdate);

-- ������ ta_tuserevent_load(�˹������¼����ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tuserevent_load-�˹������¼����ر�...';
DROP TABLE IF EXISTS ta_tuserevent_load;
create table ta_tuserevent_load (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_trusteecode                  varchar(3)      DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_usereventtype                varchar(30)     DEFAULT ' '        NOT NULL,
    c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
create unique index pk_userevent_load on ta_tuserevent_load(c_tenantid, c_tacode, c_managercode, c_fundcode, c_trusteecode, c_agencyno, d_cdate, c_usereventtype, c_flowno, c_loadpoint, c_datastyle);

-- ������ ta_ttransfercommissioncfmroll(OTCת��ί�гɽ���ϸCFM�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_ttransfercommissioncfmroll-OTCת��ί�гɽ���ϸCFM�ع���...';
DROP TABLE IF EXISTS ta_ttransfercommissioncfmroll;
create table ta_ttransfercommissioncfmroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          
);

-- ������ ta_tincome_preroll(Ԥ��������ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tincome_preroll-Ԥ��������ع���...';
DROP TABLE IF EXISTS ta_tincome_preroll;
create table ta_tincome_preroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_oricserialno                 varchar(20)     DEFAULT ' '        NOT NULL
);

-- ������ ta_tprofitschema_bak(�ֺ췽�����ݱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tprofitschema_bak-�ֺ췽�����ݱ�...';
DROP TABLE IF EXISTS ta_tprofitschema_bak;
create table ta_tprofitschema_bak (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_schemacode                   varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    d_registerdate                 int             DEFAULT 0          NOT NULL,
    f_unitprofit                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
    d_distributedate               int             DEFAULT 0          NOT NULL,
    d_reinvestdate                 int             DEFAULT 0          NOT NULL,
    c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
    c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_profitratio                  decimal(5,4)    DEFAULT 0.0        NOT NULL,
    c_frzbalanceflag               varchar(1)      DEFAULT ' '        NOT NULL,
    c_frzsharesflag                varchar(1)      DEFAULT ' '        NOT NULL,
    c_frzforcereinvest             varchar(1)      DEFAULT ' '        NOT NULL,
    c_bonustype                    varchar(1)      DEFAULT ' '        NOT NULL,
    f_totalprofit                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_bonusmode                    varchar(1)      DEFAULT ' '        NOT NULL,
    c_autodealflag                 varchar(1)      DEFAULT '1'        NOT NULL,
    c_frzbonussharedtl             varchar(1)      DEFAULT '0'        NOT NULL,
PRIMARY KEY(l_rowid)
);

-- ������ ta_trequestroll(����ع���)�ĵ�ǰ��
SELECT 'Create Table ta_trequestroll-����ع���...';
DROP TABLE IF EXISTS ta_trequestroll;
create table ta_trequestroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    l_id                           int             DEFAULT 0          ,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL
);

-- ������ ta_texchangerate(���ʱ�)�ĵ�ǰ��
SELECT 'Create Table ta_texchangerate-���ʱ�...';
DROP TABLE IF EXISTS ta_texchangerate;
create table ta_texchangerate (
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    d_date                         int             DEFAULT 0          NOT NULL,
    d_importdate                   int             DEFAULT 0          NOT NULL,
    f_exchangerate                 decimal(7,4)    DEFAULT 0.0        NOT NULL,
    c_moneytype                    varchar(3)      DEFAULT ' '        NOT NULL,
    c_inputpersonnel               varchar(16)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
create unique index uidx_texchangerate on ta_texchangerate(d_date, c_moneytype, c_tacode, c_tenantid);

-- ������ ta_tincnodbrange(�ݶ���������)�ĵ�ǰ��
SELECT 'Create Table ta_tincnodbrange-�ݶ���������...';
DROP TABLE IF EXISTS ta_tincnodbrange;
create table ta_tincnodbrange (
    c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
    c_serialnotype                 varchar(1)      DEFAULT ' '        NOT NULL,
    l_baseserialno                 bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_databaseno, c_serialnotype)
);

-- ������ ta_tration_load(���ڶ���Э����ر�)�ĵ�ǰ��
SELECT 'Create Table ta_tration_load-���ڶ���Э����ر�...';
DROP TABLE IF EXISTS ta_tration_load;
create table ta_tration_load (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_rationno                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
    c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
    c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
    d_date                         int             DEFAULT 0          NOT NULL,
    c_requestno                    varchar(24)     DEFAULT ' '        NOT NULL,
    c_rationtype                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_balance                      decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_shares                       decimal(16,2)   DEFAULT 0.0        NOT NULL,
    l_rationdate                   int             DEFAULT 0          NOT NULL,
    c_rationterm                   varchar(8)      DEFAULT ' '        NOT NULL,
    d_protocolenddate              int             DEFAULT 0          NOT NULL,
    l_delay                        int             DEFAULT 0          NOT NULL,
    l_allowfail                    int             DEFAULT 0          NOT NULL,
    d_lastdate                     int             DEFAULT 0          NOT NULL,
    f_agio                         decimal(5,4)    DEFAULT 0.0        NOT NULL,
    c_flag                         varchar(1)      DEFAULT ' '        NOT NULL,
    l_times                        int             DEFAULT 0          NOT NULL,
    f_totalallotbalance            decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_totalreedemshares            decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_defaultrationflag            varchar(1)      DEFAULT ' '        NOT NULL,
    d_lastrequestdate              int             DEFAULT 0          NOT NULL,
    f_realagio                     decimal(5,4)    DEFAULT 0.0        NOT NULL,
    d_firstconfirmdate             int             DEFAULT 0          NOT NULL,
    f_oribalance                   decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_loadpoint                    varchar(100)    DEFAULT ' '        NOT NULL,
    c_datastyle                    varchar(30)     DEFAULT ' '        NOT NULL,
    c_flowno                       varchar(60)     DEFAULT ' '        NOT NULL,
    l_beginid                      bigint          DEFAULT 0          NOT NULL,
    l_shardingno                   int             DEFAULT 0          NOT NULL
);

-- ������ ta_tfundendproj_tmp(�������̷�����ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundendproj_tmp-�������̷�����ʱ��...';
DROP TABLE IF EXISTS ta_tfundendproj_tmp;
create table ta_tfundendproj_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
    d_cdate                        int             DEFAULT 0          NOT NULL,
    c_fundendmode                  varchar(1)      DEFAULT ' '        NOT NULL,
    c_fundendbizflag               varchar(3)      DEFAULT ' '        NOT NULL,
    f_fundendallotbalance          decimal(16,2)   DEFAULT 0.0        NOT NULL,
    f_fundendnav                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
    c_fundendprofitflag            varchar(1)      DEFAULT ' '        NOT NULL,
    d_contractenddate              int             DEFAULT 0          NOT NULL,
    f_profittotalnav               decimal(7,4)    DEFAULT 0.0        NOT NULL,
    f_fundendtotalprofit           decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_exportnavdealtype            varchar(1)      DEFAULT ' '        NOT NULL,
    c_fundendtype                  varchar(1)      DEFAULT ' '        NOT NULL,
    f_fundendratio                 decimal(9,8)    DEFAULT 0.0        NOT NULL,
    c_needcalallotbalance          varchar(1)      DEFAULT ' '        NOT NULL,
    c_dealstatus                   varchar(1)      DEFAULT ' '        NOT NULL,
    c_describe                     varchar(100)    DEFAULT ' '        NOT NULL,
    d_lastmodify                   int             DEFAULT 0          NOT NULL,
    c_autodealflag                 varchar(1)      DEFAULT ' '        NOT NULL,
    c_frozenfundend                varchar(1)      DEFAULT ' '        NOT NULL,
    c_isneeddeal                   varchar(1)      DEFAULT ' '        NOT NULL,
    f_totalshares                  decimal(16,2)   DEFAULT 0.0        NOT NULL,
    c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(c_fundcode, d_cdate, c_tacode, c_tenantid)
);

-- ������ calsharesno(ͳ�Ʒݶ����к�)�ĵ�ǰ��
SELECT 'Create Table calsharesno-ͳ�Ʒݶ����к�...';
DROP TABLE IF EXISTS calsharesno;
create table calsharesno (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
    c_serialnotype                 varchar(1)      DEFAULT ' '        NOT NULL,
    l_baseserialno                 bigint          DEFAULT 0          NOT NULL,
    l_maxserialno                  bigint          DEFAULT 0          NOT NULL,
    l_dbincnomax                   bigint          DEFAULT 0          NOT NULL,
    l_purchaseincomax              bigint          DEFAULT 0          NOT NULL,
PRIMARY KEY(c_tenantid, c_tacode, c_serialnotype)
);

-- ������ ta_tsharedetailroll(�ݶ���ϸ�ع���)�ĵ�ǰ��
SELECT 'Create Table ta_tsharedetailroll-�ݶ���ϸ�ع���...';
DROP TABLE IF EXISTS ta_tsharedetailroll;
create table ta_tsharedetailroll (
    c_tenantid                     varchar(20)     DEFAULT ' '        ,
    c_cserialno                    varchar(20)     DEFAULT ' '        ,
    c_loadpoint                    varchar(100)    DEFAULT ' '        ,
    c_flowno                       varchar(60)     DEFAULT ' '        ,
    l_id                           int             DEFAULT 0          ,
    c_tacode                       varchar(2)      DEFAULT ' '        
);

-- ������ ta_tsharedetail_tmp(�ݶ���ϸ��ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tsharedetail_tmp-�ݶ���ϸ��ʱ��...';
DROP TABLE IF EXISTS ta_tsharedetail_tmp;
create table ta_tsharedetail_tmp (
    c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
    c_tacode                       varchar(2)      DEFAULT ' '        ,
    c_fundacco                     varchar(12)     DEFAULT ' '        ,
    c_agencyno                     varchar(9)      DEFAULT ' '        ,
    c_netno                        varchar(9)      DEFAULT ' '        ,
    c_tradeacco                    varchar(24)     DEFAULT ' '        ,
    c_fundcode                     varchar(12)     DEFAULT ' '        ,
    c_sharetype                    varchar(1)      DEFAULT ' '        ,
    d_cdate                        int             DEFAULT 0          ,
    c_cserialno                    varchar(20)     DEFAULT ' '        NOT NULL,
    c_sourcetype                   varchar(1)      DEFAULT ' '        ,
    f_remainshares                 decimal(16,2)   DEFAULT 0.0        ,
    d_registdate                   int             DEFAULT 0          ,
    f_oricfmbalance                decimal(16,2)   DEFAULT 0.0        ,
    f_oricfmshares                 decimal(16,2)   DEFAULT 0.0        ,
    f_orinetvalue                  decimal(7,4)    DEFAULT 0.0        ,
    c_orisource                    varchar(1)      DEFAULT ' '        ,
    f_ruleagio                     decimal(5,4)    DEFAULT 1.0        ,
    f_oriagio                      decimal(5,4)    DEFAULT 1.0        ,
    f_maxallotratio                decimal(5,4)    DEFAULT 0.0        ,
    f_minredeemratio               decimal(5,4)    DEFAULT 0.0        ,
    c_holdflag                     varchar(1)      DEFAULT ' '        ,
    c_acceptmode                   varchar(1)      DEFAULT ' '        ,
    c_actcode                      varchar(3)      DEFAULT ' '        ,
    c_firstcserailno               varchar(20)     DEFAULT ' '        ,
    c_fundmethod                   varchar(2)      DEFAULT ' '        ,
    c_bankno                       varchar(60)     DEFAULT ' '        ,
    c_subfundmethod                varchar(2)      DEFAULT ' '        ,
    f_managefare                   decimal(16,2)   DEFAULT 0.0        ,
    f_interestshare                decimal(16,2)   DEFAULT 0.0        ,
    d_lastdeductdate               int             DEFAULT 0          ,
    f_income                       decimal(16,2)   DEFAULT 0.0        ,
    f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
    c_specialcode                  varchar(20)     DEFAULT ' '        ,
    f_pendsubmit02shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit03shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit50shr              decimal(16,2)   DEFAULT 0.0        ,
    f_assignshare                  decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit13shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit16shr              decimal(16,2)   DEFAULT 0.0        ,
    f_lastremainshares             decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit14shr              decimal(16,2)   DEFAULT 0.0        ,
    f_pendsubmit15shr              decimal(16,2)   DEFAULT 0.0        ,
    f_lastincome                   decimal(16,2)   DEFAULT 0.0        ,
    d_orilastdeductdate            int             DEFAULT 0          ,
    f_costprice                    decimal(15,12)  DEFAULT 0.0        ,
    f_lastmanagefare               decimal(16,2)   DEFAULT 0.0        ,
    f_apportionratio               decimal(9,8)    DEFAULT 0.0        ,
    f_fareratio                    decimal(5,4)    DEFAULT 0.0        ,
    f_backfareratio                decimal(9,8)    DEFAULT 0.0        ,
    f_minbackratio                 decimal(5,4)    DEFAULT 0.0        ,
    f_orifareratio                 decimal(5,4)    DEFAULT 0.0        ,
    d_cyclestartdate               int             DEFAULT 0          ,
    d_cycleenddate                 int             DEFAULT 0          ,
    d_cyclenextdate                int             DEFAULT 0          ,
    l_cycle                        int             DEFAULT 0          ,
    f_evennetvalue                 decimal(7,4)    DEFAULT 0.0        ,
    c_protectflag                  varchar(1)      DEFAULT ' '        ,
    f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
    f_costfare                     decimal(16,2)   DEFAULT 0.0        ,
    c_lastoutfundcode              varchar(20)     DEFAULT ' '        ,
    f_redeemedbaseshr              decimal(16,2)   DEFAULT 0.0        ,
    l_incserno                     bigint          DEFAULT 0          ,
    c_adrmflag                     varchar(1)      DEFAULT ' '        
);


commit;
