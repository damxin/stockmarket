-- -------------------------------------------
-- SQLfile   : tatrade_account_MySQLTable.sql
-- Notes    : SQL�ű�
-- -------------------------------------------
-- �޸İ汾    �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                             ��ע 
-- V1.0.6.1    2016-10-12 19:54                                       ���б�ta_taccoinfo�������˱��ֶΣ�d_bakdate����                                                           
-- V1.0.6.1    2016-07-26 15:02                             �״�      ���б�ta_taccoinfo�������˱��ֶΣ�c_liqbatchno����                                                        
-- V1.0.6.1    2017-07-11 19:09                                       ���б�ta_tacconet�������˱��ֶΣ�c_officalcode����                                                        
-- V1.0.6.1    2016-10-12 19:55                                       ���б�ta_tacconet�������˱��ֶΣ�d_bakdate����                                                            
-- V1.0.6.1    2016-08-09 10:00                                       ��ǰ��ta_tacconet������������ idx_tacconet_ta:[c_tacode,c_tenantid]��;                                    
-- V1.0.6.1    2016-08-09 09:33                                       ��ǰ��ta_tacconet������������ idx_tacconet_trade:[c_tradeacco,c_agencyno,c_netno]��;                      
-- V1.0.6.1    2016-07-26 15:16                             �״�      ���б�ta_tacconet�������˱��ֶΣ�c_liqbatchno����                                                         
-- V1.0.6.1    2016-10-12 19:56                                       ���б�ta_tcustomerinfo�������˱��ֶΣ�d_bakdate����                                                       
-- V1.0.6.1    2016-07-26 15:19                             �״�      ���б�ta_tcustomerinfo�������˱��ֶΣ�c_liqbatchno����                                                    
-- V1.0.6.1    2016-11-15 10:47                                       ���б�ta_tmergernet��ɾ���˱��ֶΣ�c_cause����                                                            
-- V1.0.6.1    2016-11-15 10:46                                       ���б�ta_tmergernet�������˱��ֶΣ�c_memo����                                                             
-- V1.0.5.1    2016-06-15 15:37                                       ���ӱ�                                                                                                    
-- V1.0.5.1    2016-07-23 14:34                   �ؽ���    �ؽ���    ���ݱ�ta_tnetinfo���������˱��ֶΣ�c_netregdate->d_netregdate��                                           
-- V1.0.5.1    2016-06-27 19:07                   �ؽ���    �ؽ���    ���ݱ�ta_tnetinfo������������ pk_netinfo:[l_rowid],uidx_netinfo:[c_tenantid,c_agencyno,c_netno]��         
-- V1.0.5.1    2016-06-27 19:05                   �ؽ���    �ؽ���    ���ݱ�ta_tnetinfo�������˱��ֶΣ�l_rowid,c_tenantid��                                                     


-- ������ ta_taccoinfo(�����˻���)�ĵ�ǰ��
SELECT 'Create Table ta_taccoinfo-�����˻���...';
DROP TABLE IF EXISTS ta_taccoinfo;
CREATE TABLE ta_taccoinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_idcard18len                  varchar(1)      DEFAULT ' '        ,
	c_accostatus                   varchar(1)      DEFAULT '0'        ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	d_opendate                     int             DEFAULT 0          ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_modifyinfo                   varchar(2)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	d_bakdate                      int             DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_tenantid)
);

-- ������ ta_taccoinfo_bak(�����˻���)�ĵ�ǰ��
SELECT 'Create Table ta_taccoinfo_bak-�����˻���...';
DROP TABLE IF EXISTS ta_taccoinfo_bak;
CREATE TABLE ta_taccoinfo_bak
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_custtype                     varchar(1)      DEFAULT ' '        ,
	c_custname                     varchar(120)    DEFAULT ' '        ,
	c_shortname                    varchar(20)     DEFAULT ' '        ,
	c_identitype                   varchar(1)      DEFAULT ' '        ,
	c_identityno                   varchar(30)     DEFAULT ' '        ,
	c_idcard18len                  varchar(1)      DEFAULT ' '        ,
	c_accostatus                   varchar(1)      DEFAULT '0'        ,
	c_freezecause                  varchar(1)      DEFAULT ' '        ,
	d_opendate                     int             DEFAULT 0          ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_modifyinfo                   varchar(2)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	d_bakdate                      int             DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_tenantid)
);

-- ������ ta_tacconet(�ɽ��������)�ĵ�ǰ��
SELECT 'Create Table ta_tacconet-�ɽ��������...';
DROP TABLE IF EXISTS ta_tacconet;
CREATE TABLE ta_tacconet
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_tradeaccostatus              varchar(1)      DEFAULT 'O'        ,
	c_tradeaccobak                 varchar(24)     DEFAULT ' '        ,
	c_childnetno                   varchar(9)      DEFAULT ' '        ,
	c_bankno                       varchar(60)     DEFAULT ' '        ,
	c_bankacco                     varchar(30)     DEFAULT ' '        ,
	c_nameinbank                   varchar(60)     DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	d_bakdate                      int             DEFAULT 0          ,
	c_officalcode                  varchar(9)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_agencyno, c_netno, c_tradeacco, c_tenantid)
);
CREATE INDEX idx_tacconet_ta ON ta_tacconet(c_tacode ASC ,c_tenantid ASC );



-- ������ ta_tcustomerinfo(�˻����ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustomerinfo-�˻����ϱ�...';
DROP TABLE IF EXISTS ta_tcustomerinfo;
CREATE TABLE ta_tcustomerinfo
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_idnovaliddate                int             DEFAULT 0          ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_corpname                     varchar(40)     DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_contidcard18len              varchar(1)      DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	c_callcenter                   varchar(1)      DEFAULT ' '        ,
	c_internet                     varchar(1)      DEFAULT ' '        ,
	c_billsendpass                 varchar(1)      DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_lawidtype                    varchar(1)      DEFAULT ' '        ,
	c_lawidno                      varchar(30)     DEFAULT ' '        ,
	c_broker                       varchar(12)     DEFAULT ' '        ,
	c_recommender                  varchar(40)     DEFAULT ' '        ,
	c_recommendertype              varchar(1)      DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	c_actcode                      varchar(3)      DEFAULT ' '        ,
	c_backreason                   varchar(60)     DEFAULT ' '        ,
	c_hometelno                    varchar(32)     DEFAULT ' '        ,
	c_minorflag                    varchar(1)      DEFAULT ' '        ,
	c_transacttype                 varchar(1)      DEFAULT ' '        ,
	d_contidnovaliddate            int             DEFAULT 0          ,
	d_lawidnovaliddate             int             DEFAULT 0          ,
	c_risklevel                    varchar(1)      DEFAULT ' '        ,
	c_managerange                  varchar(2)      DEFAULT ' '        ,
	c_controlholder                varchar(80)     DEFAULT ' '        ,
	c_actualcontroller             varchar(80)     DEFAULT ' '        ,
	c_marital                      varchar(1)      DEFAULT ' '        ,
	l_familynum                    int             DEFAULT 0          ,
	f_penates                      decimal(16,2)   DEFAULT 0.0        ,
	c_mediahobby                   varchar(1)      DEFAULT ' '        ,
	c_institutiontype              varchar(1)      DEFAULT ' '        ,
	c_englishfirstname             varchar(20)     DEFAULT ' '        ,
	c_englishfamilyname            varchar(20)     DEFAULT ' '        ,
	c_industry                     varchar(4)      DEFAULT ' '        ,
	c_companychar                  varchar(4)      DEFAULT ' '        ,
	f_employeenum                  decimal(16,2)   DEFAULT 0.0        ,
	c_hobbytype                    varchar(2)      DEFAULT ' '        ,
	c_province                     varchar(6)      DEFAULT ' '        ,
	c_city                         varchar(6)      DEFAULT ' '        ,
	c_county                       varchar(6)      DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	d_bakdate                      int             DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_tenantid)
);

-- ������ ta_tcustomerinfo_bak(�˻����ϱ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcustomerinfo_bak-�˻����ϱ�...';
DROP TABLE IF EXISTS ta_tcustomerinfo_bak;
CREATE TABLE ta_tcustomerinfo_bak
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	d_idnovaliddate                int             DEFAULT 0          ,
	d_lastmodify                   int             DEFAULT 0          ,
	c_zipcode                      varchar(6)      DEFAULT ' '        ,
	c_address                      varchar(120)    DEFAULT ' '        ,
	c_phone                        varchar(32)     DEFAULT ' '        ,
	c_faxno                        varchar(24)     DEFAULT ' '        ,
	c_mobileno                     varchar(32)     DEFAULT ' '        ,
	c_email                        varchar(40)     DEFAULT ' '        ,
	c_sex                          varchar(1)      DEFAULT ' '        ,
	c_birthday                     varchar(8)      DEFAULT ' '        ,
	c_vocation                     varchar(3)      DEFAULT ' '        ,
	c_education                    varchar(3)      DEFAULT ' '        ,
	c_annualearnings               varchar(8)      DEFAULT ' '        ,
	c_corpname                     varchar(40)     DEFAULT ' '        ,
	c_corptel                      varchar(32)     DEFAULT ' '        ,
	c_contact                      varchar(20)     DEFAULT ' '        ,
	c_contype                      varchar(1)      DEFAULT ' '        ,
	c_contno                       varchar(30)     DEFAULT ' '        ,
	c_contidcard18len              varchar(1)      DEFAULT ' '        ,
	c_billsendflag                 varchar(1)      DEFAULT ' '        ,
	c_callcenter                   varchar(1)      DEFAULT ' '        ,
	c_internet                     varchar(1)      DEFAULT ' '        ,
	c_billsendpass                 varchar(1)      DEFAULT ' '        ,
	c_nationality                  varchar(3)      DEFAULT ' '        ,
	c_lawname                      varchar(20)     DEFAULT ' '        ,
	c_lawidtype                    varchar(1)      DEFAULT ' '        ,
	c_lawidno                      varchar(30)     DEFAULT ' '        ,
	c_broker                       varchar(12)     DEFAULT ' '        ,
	c_recommender                  varchar(40)     DEFAULT ' '        ,
	c_recommendertype              varchar(1)      DEFAULT ' '        ,
	c_cityno                       varchar(4)      DEFAULT ' '        ,
	c_actcode                      varchar(3)      DEFAULT ' '        ,
	c_backreason                   varchar(60)     DEFAULT ' '        ,
	c_hometelno                    varchar(32)     DEFAULT ' '        ,
	c_minorflag                    varchar(1)      DEFAULT ' '        ,
	c_transacttype                 varchar(1)      DEFAULT ' '        ,
	d_contidnovaliddate            int             DEFAULT 0          ,
	d_lawidnovaliddate             int             DEFAULT 0          ,
	c_risklevel                    varchar(1)      DEFAULT ' '        ,
	c_managerange                  varchar(2)      DEFAULT ' '        ,
	c_controlholder                varchar(80)     DEFAULT ' '        ,
	c_actualcontroller             varchar(80)     DEFAULT ' '        ,
	c_marital                      varchar(1)      DEFAULT ' '        ,
	l_familynum                    int             DEFAULT 0          ,
	f_penates                      decimal(16,2)   DEFAULT 0.0        ,
	c_mediahobby                   varchar(1)      DEFAULT ' '        ,
	c_institutiontype              varchar(1)      DEFAULT ' '        ,
	c_englishfirstname             varchar(20)     DEFAULT ' '        ,
	c_englishfamilyname            varchar(20)     DEFAULT ' '        ,
	c_industry                     varchar(4)      DEFAULT ' '        ,
	c_companychar                  varchar(4)      DEFAULT ' '        ,
	f_employeenum                  decimal(16,2)   DEFAULT 0.0        ,
	c_hobbytype                    varchar(2)      DEFAULT ' '        ,
	c_province                     varchar(6)      DEFAULT ' '        ,
	c_city                         varchar(6)      DEFAULT ' '        ,
	c_county                       varchar(6)      DEFAULT ' '        ,
	c_specialcode                  varchar(20)     DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	d_bakdate                      int             DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_tenantid)
);

-- ������ ta_tcustmgrrelation(�˻������˹�ϵ��)�ĵ�ǰ��
SELECT 'Create Table ta_tcustmgrrelation-�˻������˹�ϵ��...';
DROP TABLE IF EXISTS ta_tcustmgrrelation;
CREATE TABLE ta_tcustmgrrelation
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_managercode                  varchar(10)     DEFAULT ' '        NOT NULL,
	d_opendate                     int             DEFAULT 0          ,
	d_closedate                    int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
PRIMARY KEY(c_fundacco, c_managercode, c_tenantid)
);

-- ������ ta_tnetinfo(������Ϣ��)�ĵ�ǰ��
SELECT 'Create Table ta_tnetinfo-������Ϣ��...';
DROP TABLE IF EXISTS ta_tnetinfo;
CREATE TABLE ta_tnetinfo
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	c_netname                      varchar(40)     DEFAULT ' '        NOT NULL,
	c_cityno                       varchar(4)      DEFAULT ' '        NOT NULL,
	c_netaddress                   varchar(80)     DEFAULT ' '        NOT NULL,
	c_netzipcode                   varchar(6)      DEFAULT ' '        NOT NULL,
	c_netcontact                   varchar(8)      DEFAULT ' '        NOT NULL,
	c_netphone                     varchar(40)     DEFAULT ' '        NOT NULL,
	c_netfaxno                     varchar(40)     DEFAULT ' '        NOT NULL,
	d_netregdate                   int             DEFAULT 0          NOT NULL,
	c_netstatus                    varchar(1)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX uidx_netinfo ON ta_tnetinfo(c_tenantid ASC ,c_agencyno ASC ,c_netno ASC );

-- ������ ta_tmergernet(�������б�)�ĵ�ǰ��
SELECT 'Create Table ta_tmergernet-�������б�...';
DROP TABLE IF EXISTS ta_tmergernet;
CREATE TABLE ta_tmergernet
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno_old                    varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno_new                    varchar(9)      DEFAULT ' '        NOT NULL,
	c_tradeacco                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_othertradeacco               varchar(24)     DEFAULT ' '        NOT NULL,
	d_date                         int             DEFAULT 0          NOT NULL,
	d_requestdate                  int             DEFAULT 0          NOT NULL,
	c_taflag                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_status                       varchar(1)      DEFAULT ' '        NOT NULL,
	c_memo                         varchar(60)     DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_tenantid, c_tacode, c_fundacco, c_agencyno, c_netno_old, c_tradeacco)
);

