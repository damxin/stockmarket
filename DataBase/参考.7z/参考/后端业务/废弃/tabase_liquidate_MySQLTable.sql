-- -------------------------------------------
-- SQLfile   : tabase_liquidate_MySQLTable.sql
-- Notes    : SQL�ű�
-- -------------------------------------------
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                 ��ע 
-- V1.0.5.2     2017-06-05 13:41                                       ���б�ta_tliquidatetrusteedetail�������˱��ֶΣ�f_interest����                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.2     2017-06-22 17:36                                       ���б�ta_tstaticsharesstat�������˱��ֶΣ�f_frozenshares����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.2     2017-03-22 09:06                                       ���б�ta_tstaticsharesstat�������˱��ֶΣ�f_newincome����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.2     2017-06-05 13:41                                       ���б�ta_tliquidateagency�������˱��ֶΣ�f_interest����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.2     2017-02-20 09:08                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-07-29 21:01                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_busin:[d_cdate,c_businflag]��;                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1     2016-07-29 20:57                                       ��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_1��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_2��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_3��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_4��;��ǰ��ta_trequeststat��ɾ���˱�������idx_trequeststat_5��;                                                                                            
-- V1.0.5.1     2016-07-29 16:57                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_5:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-29 16:54                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_4:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-07-29 16:53                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_3:[d_cdate,c_businflag,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-29 16:52                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_2:[d_cdate,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-07-29 16:49                                       ��ǰ��ta_trequeststat������������ idx_trequeststat_1:[d_cdate,c_businflag,c_fundcode,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-07-27 09:38                                       ���б�ta_trequeststat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-07-29 20:58                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_busin:[d_cdate,c_businflag]��;                                                                                                                                                                                                                                                                                                             
-- V1.0.5.1     2016-07-29 20:43                                       ��ǰ��ta_tconfirmstat��ɾ���˱�������idx_tconfirmstat_1��;��ǰ��ta_tconfirmstat��ɾ���˱�������idx_tconfirmstat_2��;                                                                                                                                                                                                                                                                          
-- V1.0.5.1     2016-07-29 16:05                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_2:[d_cdate,c_businflag,c_liqbatchno,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                   
-- V1.0.5.1     2016-07-29 15:55                                       ��ǰ��ta_tconfirmstat������������ idx_tconfirmstat_1:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-26 17:33                                       ���б�ta_tconfirmstat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-09-02 11:55                                       ���б�ta_tsalestat�������˱��ֶΣ�f_managerfee����                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-09-02 11:55                                       ���б�ta_tsalestat��ɾ���˱��ֶΣ�f_managefare����                                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-08-09 10:16                                       ��ǰ��ta_tsalestat������������ idx_tsalestat_cdate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-07-29 20:55                                       ��ǰ��ta_tliquidatetrusteedetail��ɾ���˱�������idx_tliqtrusteedetail��;                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-29 16:22                                       ��ǰ��ta_tliquidatetrusteedetail������������ idx_tliqtrusteedetail:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-26 20:10                                       ���б�ta_tliquidatetrusteedetail�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-05-26 11:25                                       ��ǰ��ta_tliquidatetrusteedetail������������ d_cdate,c_fundcode,c_businflag,c_agencyno,d_needdate,c_databaseno,c_tenanti��;                                                                                                                                                                                                                                                                   
-- V1.0.5.1     2016-07-29 20:54                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate2:[d_requestdate]��;                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-29 20:53                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate1:[c_fundcode]��;                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-07-29 20:53                                       ��ǰ��ta_tfundtrusteeliquidate��ɾ���˱�������idx_tfundtrusteeliquidate��;                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-07-29 16:18                                       ��ǰ��ta_tfundtrusteeliquidate������������ idx_tfundtrusteeliquidate:[c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-07-26 20:11                                       ���б�ta_tfundtrusteeliquidate�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-10-19 19:24                                       ���б�ta_tdividendstat�������˱��ֶΣ�l_successcount����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-08-10 14:09                                       ��ǰ��ta_tdividendstat��ɾ���˱�������idx_tdividendstat_cdate��;                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-08-10 14:08                                       ��ǰ��ta_tdividendstat�����������ֶ�˳��Ϊ��d_cdate,c_fundcode,c_agencyno,c_sharetype,c_bonustype,c_shareclass,d_senddate,d_distributedate,d_reinvestdate,c_dataflag,c_databaseno,c_tacode,c_tenantid����                                                                                                                                                                                     
-- V1.0.5.1     2016-07-29 20:59                                       ��ǰ��ta_tdividendstat������������ idx_tdividendstat_cdate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2016-07-29 20:42                                       ��ǰ��ta_tdividendstat��ɾ���˱�������idx_tdividendstat_liqno��;                                                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-29 14:52                                       ��ǰ��ta_tdividendstat������������ idx_tdividendstat_liqno:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                      
-- V1.0.5.1     2016-07-26 17:10                                       ���б�ta_tdividendstat�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-06-18 11:21                                       ���б�ta_tdividendstat�������˱��ֶΣ�f_deductbalance����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2017-02-23 10:12                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinteresttax����                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2017-02-23 10:12                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinterestall����                                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2017-02-22 10:04                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rshares_ch�������б�ta_tconfirmstatdetail�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2017-02-21 19:38                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_deductmngfare����                                                                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-12-06 13:28                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_rejsubinterest����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-11-07 10:45                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_balance�������б�ta_tconfirmstatdetail�������˱��ֶΣ�f_shares����                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-10-17 13:51                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�f_delaybalance�������б�ta_tconfirmstatdetail�������˱��ֶΣ�f_delayshares����                                                                                                                                                                                                                                                                     
-- V1.0.5.1     2016-09-27 11:13                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�c_taflag����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.5.1     2016-08-25 14:20                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tconfirmstat_outdate:[d_outputdate]��;                                                                                                                                                                                                                                                                                                            
-- V1.0.5.1     2016-08-10 14:10                                       ��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_dcate��;                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-07-29 20:50                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_dcate:[d_cdate]��;                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.1     2016-07-29 20:49                                       ��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_liqno��;��ǰ��ta_tconfirmstatdetail��ɾ���˱�������idx_tcfmstatdetail_busin��;                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-07-29 15:59                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_busin:[d_cdate,c_businflag,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-07-29 14:43                                       ��ǰ��ta_tconfirmstatdetail������������ idx_tcfmstatdetail_liqno:[d_cdate,c_liqbatchno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                
-- V1.0.5.1     2016-07-26 17:05                                       ���б�ta_tconfirmstatdetail�������˱��ֶΣ�c_liqbatchno����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.1     2016-11-14 15:36                                       ��ǰ��ta_ttailratio�����������ֶ�˳������pk_ttailratio:������������ֶ�˳��Ϊ��c_fundcode,c_agencyno,c_tailflag,d_tailbgdate,f_holdmin,c_tacode,c_tenantid����                                                                                                                                                                                                                              
-- V1.0.5.1     2016-07-08 09:57                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-09-26 21:03                                       ��ǰ��ta_tliquidateswitch������������ uidx_tliquidateswitch:[d_date,c_fundcode,c_othercode,c_agencyno,c_databaseno,c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                    
-- V1.0.5.1     2016-09-26 19:42                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-11-04 16:07                                       ���б�ta_tcheckresultstat�������˱��ֶΣ�c_fundacco�������б�ta_tcheckresultstat�������˱��ֶΣ�c_businflag����                                                                                                                                                                                                                                                                               
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-11-07 10:59                                       ��ǰ��ta_tfundagencyliquidate������������ idx_tfundagecliq:[c_fundcode,c_agencyno,c_tenantid]��;                                                                                                                                                                                                                                                                                              
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-11-05 15:30                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- �޸İ汾     �޸�����            �޸ĵ�         �޸���    ������    �޸�����                                                                                                                                                                                                                                                                                                                                                                                 ��ע 
-- V1.0.6.1     2016-10-15 11:05                                       ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_isreceivebroadcast����                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2016-09-07 15:29                                       ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_newnavdate����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-08-20 11:02                   �״�                ���б�ta_tagencyexpbatch�������˱��ֶΣ�c_agencytype����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2017-04-14 19:27                                       ���б�ta_tcustexpbatch�������˱��ֶΣ�d_begindate�������б�ta_tcustexpbatch�������˱��ֶΣ�d_enddate����                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-11-14 19:57                                       ��ǰ��ta_tliqexpbatch�����������ֶ�˳��Ϊ��c_trusteecode,c_managercode,c_tacode,c_tenantid����                                                                                                                                                                                                                                                                                                
-- V1.0.6.1     2016-11-14 19:56                                       ��ǰ��ta_tliqexpbatch�����������ֶΣ�c_trusteecode����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1     2016-11-14 17:31                                       ��ǰ��ta_tliqexpbatch������������ c_managercode,c_tacode,c_tenanti��;                                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2016-11-14 17:30                                       ��ǰ��ta_tliqexpbatch��ɾ���˱�������uidx_tliqexpbatch��;                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-06-16 10:59                                       ���б�ta_tcenterexpbatch�������˱��ֶΣ�d_zhzlcentralizedate����                                                                                                                                                                                                                                                                                                                              
-- V1.0.6.1     2017-06-15 16:05                                       ���б�ta_tcenterexpbatch�������˱��ֶΣ�c_centralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�c_zhcentralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�c_zhzlcentralizetype�������б�ta_tcenterexpbatch�������˱��ֶΣ�d_zhcentralizedate����                                                                                                                                      
-- V1.0.6.1     2016-11-01 19:05                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�f_otherfee2����                                                                                                                                                                                                                                                                                                                                      
-- V1.0.6.1     2016-10-27 12:23                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-10-27 12:22                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-10-27 10:41                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�c_forceredemptiontype����                                                                                                                                                                                                                                                                                                                            
-- V1.0.6.1     2016-08-31 16:13                                       ���б�ta_tagencynavc4file�������˱��ֶΣ�f_unitprofittxt����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-08-31 16:13                                       ���б�ta_tagencynavc4file��ɾ���˱��ֶΣ�f_unitprofit����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2016-12-20 17:15                                       ���б�ta_tagencynav07file�������˱��ֶΣ�c_infundcode����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-05-22 18:45                                       ���б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_newtradeacco����                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-05-22 18:45                                       ���б�ta_tagencyreqnorstd01file��ɾ���˱��ֶΣ�c_othertradeacco����                                                                                                                                                                                                                                                                                                                           
-- V1.0.6.1     2017-05-17 15:41                                       ���б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_oriidentityno�������б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_oricontno�������б�ta_tagencyreqnorstd01file�������˱��ֶΣ�c_contidcard18len����                                                                                                                                                                                          
-- V1.0.6.1     2017-02-15 17:20                                       ���б�ta_tliqredeemfile�������˱��ֶΣ�f_deductmngfare����                                                                                                                                                                                                                                                                                                                                    
-- V1.0.6.1     2017-02-16 09:37                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�f_rshares_ch�������б�ta_tliqadjustsharefile�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-02-16 09:31                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�c_adjustcause����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2017-02-16 09:30                                       ���б�ta_tliqadjustsharefile�������˱��ֶΣ�f_rshares_ch����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2017-02-15 17:10                                       ���б�ta_tliqbonusfile�������˱��ֶΣ�f_aheadincome����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2017-02-16 14:26                                       ���б�ta_tliqswitchoutfile���޸��˱��ֶ������գ�f_otherfare����                                                                                                                                                                                                                                                                                                                               
-- V1.0.6.1     2017-02-16 14:22                                       ���б�ta_tliqswitchoutfile�������˱��ֶΣ�f_otherfare����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.6.1     2017-02-16 14:27                                       ���б�ta_tliqswitchfile���޸��˱��ֶ������գ�f_otherfare����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2017-02-16 14:21                                       ���б�ta_tliqswitchfile�������˱��ֶΣ�f_otherfare����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.6.1     2017-02-16 09:35                                       ���б�ta_tliqincomefile�������˱��ֶΣ�f_endaccumshares����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2017-02-16 09:23                                       ���б�ta_tliqincomefile�������˱��ֶΣ�f_endaccumshares����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2016-11-07 17:14                                       ���б�ta_tcustconfirmfile��ɾ���˱��ֶΣ�l_serialno����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-11-07 17:13                                       ���б�ta_tcustconfirmfile�������˱��ֶΣ�l_serialnumber����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2016-11-07 18:16                                       ���б�ta_tcustprofitcurrentfile��ɾ���˱��ֶΣ�l_serialno����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.6.1     2016-11-07 18:14                                       ���б�ta_tcustprofitcurrentfile�������˱��ֶΣ�l_serialnumber����                                                                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-06-01 17:28                                       ���б�ta_tcentralize92file�������˱��ֶΣ�c_nationality����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.6.1     2017-05-31 17:13                                       ���б�ta_tcentralize96file�������˱��ֶΣ�f_deductfare�������б�ta_tcentralize96file�������˱��ֶΣ�c_deductflag����                                                                                                                                                                                                                                                                          
-- V1.0.6.1     2017-06-01 18:33                                       ���б�ta_tcentralizeg1file�������˱��ֶΣ�f_taxratio�������б�ta_tcentralizeg1file�������˱��ֶΣ�d_ratiodate����                                                                                                                                                                                                                                                                             
-- V1.0.6.1     2017-06-01 18:12                                       ���б�ta_tcentralizet1file�������˱��ֶΣ�c_formalfundcode�������б�ta_tcentralizet1file�������˱��ֶΣ�c_priorsequence�������б�ta_tcentralizet1file�������˱��ֶΣ�f_leveragemultiple�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadname�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadbuscode�������б�ta_tcentralizet1file�������˱��ֶΣ�c_investadmancode����         
-- V1.0.6.1     2017-06-01 18:30                                       ���б�ta_tcentralizet2file�������˱��ֶΣ�f_leveragerate�������б�ta_tcentralizet2file�������˱��ֶΣ�f_leveragemultiple����                                                                                                                                                                                                                                                                  
-- V1.0.6.1     2016-10-24 16:35                                       ��ǰ��ta_tsalequalify_tmp������������ idx_tsalequalify_tmp:[c_fundcode,c_agencyno]��;                                                                                                                                                                                                                                                                                                         
-- V1.0.6.1     2016-10-24 14:25                                       ���б�ta_tsalequalify_tmp�������˱��ֶΣ�c_dataflag����                                                                                                                                                                                                                                                                                                                                       
-- V1.0.6.1     2016-09-26 14:29                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-06-21 11:17                                       ��ǰ��ta_tfilefield�����������ֶΣ�l_taidno����                                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.17    2016-08-05 21:50                                       �޸�������uidx_tmergercontrol,�����ֶ��޸�Ϊ��(c_gradefund,c_type,c_tenantid),��������޸�Ϊ��null,����Ψһ���޸�Ϊ����Ψһ,��������������Ϊ:��������.                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-08-05 21:49                                       ��ǰ��ta_tmergercontrol������������ uidx_tmergecontrol:[c_gradefund,c_type,c_tenantid]��;                                                                                                                                                                                                                                                                                                     
-- V1.0.5.17    2016-08-05 21:48                                       ��ǰ��ta_tmergercontrol��ɾ���˱�������uidx_mergercontrol��;                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.17    2016-06-18 15:53                                       ���б�ta_tagencycfm04file�������˱��ֶΣ�f_tafare����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.17    2016-06-18 15:58                                       ���б�ta_tliqredeemfile�������˱��ֶΣ�f_ductmanagerfare�������б�ta_tliqredeemfile�������˱��ֶΣ�f_profitbalance����                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-06-18 15:56                                       ���б�ta_tliqbonusfile�������˱��ֶΣ�f_profitbalance����                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.17    2016-06-04 15:50                                       ���б�ta_tcustfundinfofile�������˱��ֶΣ�c_pensionregistcode����                                                                                                                                                                                                                                                                                                                             
-- V1.0.5.17    2016-06-03 17:44                                       ���б�ta_tcustaccofile�������˱��ֶΣ�c_risklevel����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.17    2016-06-03 17:43                                       ���б�ta_tcustaccorequestfile�������˱��ֶΣ�c_risklevel����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.17    2016-06-04 15:49                                       ���б�ta_tcustdividendfile�������˱��ֶΣ�f_unitprofit2����                                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.17    2016-06-23 16:27                                       ���б�ta_tcustecontractfile�����������ֶΣ�c_custodiancode->c_trusteecode����                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.17    2016-06-23 11:05                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.17    2016-08-03 16:24                                       ��ǰ��ta_totccustinfo��ɾ���˱�������idx_totccustinfo��;                                                                                                                                                                                                                                                                                                                                      
-- V1.0.5.17    2016-08-03 15:50                                       ��ǰ��ta_totccustinfo������������ idx_totccustinfo:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                   
-- V1.0.5.17    2016-08-03 16:24                                       ��ǰ��ta_totcshareinfo��ɾ���˱�������idx_totcshareinfo��;                                                                                                                                                                                                                                                                                                                                    
-- V1.0.5.17    2016-08-03 16:07                                       ��ǰ��ta_totcshareinfo������������ idx_totcshareinfo:[c_tacode,c_tenantid]��;                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.14    2016-05-27 16:41                                       ���б�ta_tcentralize92file�������˱��ֶΣ�c_txtbillsendpass����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.13    2016-05-27 16:41                                       ���б�ta_tcentralize92file��ɾ���˱��ֶΣ�c_billsendpass����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.11    2016-05-26 11:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.8     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.7     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.6     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.5     2016-05-24 16:19                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.4     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.3     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-21 16:40                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-17 20:49                                       ���б�ta_tcusttainfo_fundinfo�������˱��ֶΣ�l_netprecision����                                                                                                                                                                                                                                                                                                                               
-- V1.0.5.2     2016-05-18 16:10                                       ���б�ta_tcusttainfo_farezone�������˱��ֶΣ�f_maxbalance����                                                                                                                                                                                                                                                                                                                                 
-- V1.0.5.2     2016-05-18 16:08                                                                                                                                                                                                                                                                                                                                                                                                                                     
-- V1.0.5.2     2016-05-24 16:18                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.2     2016-05-20 08:42                                       ���б�ta_totcshareinfo���޸��˱��ֶ������գ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                  
-- V1.0.5.1     2016-06-15 16:23                                       ���ӱ�                                                                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-05-17 17:19                                       ���б�ta_totccustinfo��ɾ���˱��ֶΣ�c_databaseno����                                                                                                                                                                                                                                                                                                                                         
-- V1.0.5.1     2016-05-17 17:22                                       ���б�ta_totcshareinfo�������˱��ֶΣ�d_lastmodify����                                                                                                                                                                                                                                                                                                                                        
-- V1.0.5.1     2016-05-17 17:20                                       ���б�ta_totcshareinfo��ɾ���˱��ֶΣ�c_databaseno����                                                                                                                                                                                                                                                                                                                                        


-- ������ ta_trequeststat(����������ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_trequeststat-����������ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_trequeststat;
CREATE TABLE ta_trequeststat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_othercode                    varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	l_reqcount                     int             DEFAULT 0          ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	l_validcount                   int             DEFAULT 0          ,
	f_validbalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_validshares                  decimal(16,2)   DEFAULT 0.0        ,
	f_rationbalance                decimal(16,2)   DEFAULT 0.0        ,
	l_invalidcount                 int             DEFAULT 0          ,
	f_invalidbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_invalidshares                decimal(16,2)   DEFAULT 0.0        ,
	l_postcount                    int             DEFAULT 0          ,
	f_postbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_postshares                   decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(d_cdate, c_fundcode, c_othercode, c_agencyno, c_businflag, c_databaseno, c_tenantid, c_tacode)
);
CREATE INDEX idx_trequeststat_busin ON ta_trequeststat(d_cdate ASC ,c_businflag ASC );

-- ������ ta_tconfirmstat(������ȷ��ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirmstat-������ȷ��ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tconfirmstat;
CREATE TABLE ta_tconfirmstat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	l_successcount                 int             DEFAULT 0          ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	l_failedcount                  int             DEFAULT 0          ,
	f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_cancelbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_cancelshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_delaybalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_delayshares                  decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
	f_interest                     decimal(16,2)   DEFAULT 0.0        ,
	f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
	f_incometax                    decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_oritradefare                 decimal(16,2)   DEFAULT 0.0        ,
	f_oritafare                    decimal(16,2)   DEFAULT 0.0        ,
	f_oribackfare                  decimal(16,2)   DEFAULT 0.0        ,
	f_oriotherfare1                decimal(16,2)   DEFAULT 0.0        ,
	f_oribreachfare                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalanceagio           decimal(16,2)   DEFAULT 0.0        ,
	f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
	f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
	f_returnfare                   decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_outputdate                   int             DEFAULT 0          ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        NOT NULL,
	d_requestdate                  int             DEFAULT 0          ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
	c_status                       varchar(1)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(d_cdate, c_fundcode, c_sharetype, c_agencyno, c_businflag, c_outbusinflag, c_databaseno, c_tenantid, c_tacode)
);
CREATE INDEX idx_tconfirmstat_busin ON ta_tconfirmstat(d_cdate ASC ,c_businflag ASC );

-- ������ ta_tsalestat(������ҵ��ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tsalestat-������ҵ��ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tsalestat;
CREATE TABLE ta_tsalestat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	d_holddate                     int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	f_holdshare                    decimal(16,2)   DEFAULT 0.0        ,
	f_holdbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_oriholdbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_holdratio                    decimal(9,8)    DEFAULT 0.0        ,
	f_servicefare                  decimal(16,2)   DEFAULT 0.0        ,
	f_holdincome                   decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestoribalance           decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_lastmodify                   int             DEFAULT 0          ,
	f_managerfee                   decimal(5,4)    DEFAULT 0.0        ,
PRIMARY KEY(d_holddate, d_cdate, c_fundcode, c_agencyno, c_databaseno, c_tenantid, c_tacode)
);
CREATE INDEX idx_tsalestat_cdate ON ta_tsalestat(d_cdate ASC );
CREATE INDEX idx_tsalestat_fundocde ON ta_tsalestat(c_fundcode ASC );

-- ������ ta_tsalestattoday(������ҵ��ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tsalestattoday-������ҵ��ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tsalestattoday;
CREATE TABLE ta_tsalestattoday
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	d_holddate                     int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	f_holdshare                    decimal(16,2)   DEFAULT 0.0        ,
	f_holdbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_oriholdbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_holdratio                    decimal(9,8)    DEFAULT 0.0        ,
	f_servicefare                  decimal(16,2)   DEFAULT 0.0        ,
	f_holdincome                   decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestoribalance           decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_lastmodify                   int             DEFAULT 0          ,
	f_managerfee                   decimal(5,4)    DEFAULT 0.0        ,
PRIMARY KEY(d_holddate, d_cdate, c_fundcode, c_agencyno, c_databaseno, c_tenantid, c_tacode)
);
CREATE INDEX idx_tsalestat_cdate ON ta_tsalestattoday(d_cdate ASC );
CREATE INDEX idx_tsalestat_fundocde ON ta_tsalestattoday(c_fundcode ASC );

-- ������ ta_tliquidatetrusteedetail(�й����ʽ�����ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tliquidatetrusteedetail-�й����ʽ�����ϸ��...';
DROP TABLE IF EXISTS ta_tliquidatetrusteedetail;
CREATE TABLE ta_tliquidatetrusteedetail
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_businflag                    varchar(2)      DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	d_date                         int             DEFAULT 0          ,
	d_needdate                     int             DEFAULT 0          NOT NULL,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
	f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
	f_incometax                    decimal(16,2)   DEFAULT 0.0        ,
	f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
	l_successcount                 int             DEFAULT 0          ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_fundbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_dividendbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_needbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
	f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
	d_outputdate                   int             DEFAULT 0          ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	f_interest                     decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(d_cdate, c_fundcode, c_businflag, c_agencyno, d_needdate, c_databaseno, c_tenantid)
);

-- ������ ta_tfundtrusteeliquidate(�����й��������)�ĵ�ǰ��
SELECT 'Create Table ta_tfundtrusteeliquidate-�����й��������...';
DROP TABLE IF EXISTS ta_tfundtrusteeliquidate;
CREATE TABLE ta_tfundtrusteeliquidate
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	l_tnconfirm                    int             DEFAULT 0          ,
	l_liquidatesub                 int             DEFAULT 0          ,
	l_liquidateallot               int             DEFAULT 0          ,
	l_liquidateredeem              int             DEFAULT 0          ,
	l_liquidateend                 int             DEFAULT 0          ,
	l_liquidatebonus               int             DEFAULT 0          ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        
);
CREATE INDEX idx_tfundtrusteeliquidate1 ON ta_tfundtrusteeliquidate(c_fundcode ASC );
CREATE INDEX idx_tfundtrusteeliquidate2 ON ta_tfundtrusteeliquidate(d_requestdate ASC );

-- ������ ta_tdividendstat(�ֺ�ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tdividendstat-�ֺ�ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tdividendstat;
CREATE TABLE ta_tdividendstat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_shareclass                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_totalprofit                  decimal(16,2)   DEFAULT 0.0        ,
	f_profittax                    decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestshares               decimal(16,2)   DEFAULT 0.0        ,
	f_realbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_reinvestfare                 decimal(16,2)   DEFAULT 0.0        ,
	f_unitprofit                   decimal(7,4)    DEFAULT 0.0        NOT NULL,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	d_senddate                     int             DEFAULT 0          NOT NULL,
	d_distributedate               int             DEFAULT 0          NOT NULL,
	d_reinvestdate                 int             DEFAULT 0          NOT NULL,
	c_dataflag                     varchar(1)      DEFAULT ' '        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	c_bonustype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_deductbalance                decimal(16,2)   DEFAULT 0.0        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	l_successcount                 int             DEFAULT 0          ,
PRIMARY KEY(d_cdate, c_fundcode, c_agencyno, c_sharetype, c_bonustype, c_shareclass, d_senddate, d_distributedate, d_reinvestdate, c_dataflag, c_databaseno, c_tacode, c_tenantid, f_unitprofit)
);

-- ������ ta_tconfirmstatdetail(ȷ��ͳ����ϸ��)�ĵ�ǰ��
SELECT 'Create Table ta_tconfirmstatdetail-ȷ��ͳ����ϸ��...';
DROP TABLE IF EXISTS ta_tconfirmstatdetail;
CREATE TABLE ta_tconfirmstatdetail
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	d_requestdate                  int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_fundname                     varchar(40)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_trusteecode                  varchar(3)      DEFAULT ' '        ,
	c_managercode                  varchar(10)     DEFAULT ' '        ,
	c_sharetype                    varchar(1)      DEFAULT ' '        ,
	f_balance                      decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	d_cdate                        int             DEFAULT 0          ,
	d_outputdate                   int             DEFAULT 0          ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_outbusinflag                 varchar(3)      DEFAULT ' '        ,
	c_status                       varchar(1)      DEFAULT ' '        ,
	f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
	f_interest                     decimal(16,2)   DEFAULT 0.0        ,
	f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
	f_incometax                    decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
	f_oritradefare                 decimal(16,2)   DEFAULT 0.0        ,
	f_oritafare                    decimal(16,2)   DEFAULT 0.0        ,
	f_oribackfare                  decimal(16,2)   DEFAULT 0.0        ,
	f_oriotherfare1                decimal(16,2)   DEFAULT 0.0        ,
	f_oribreachfare                decimal(16,2)   DEFAULT 0.0        ,
	f_confirmbalanceagio           decimal(16,2)   DEFAULT 0.0        ,
	f_chincome                     decimal(16,2)   DEFAULT 0.0        ,
	f_confirmincome                decimal(16,2)   DEFAULT 0.0        ,
	f_returnfare                   decimal(16,2)   DEFAULT 0.0        ,
	c_shareclass                   varchar(1)      DEFAULT ' '        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	c_outfundcode                  varchar(12)     DEFAULT ' '        ,
	l_successcount                 int             DEFAULT 0          ,
	l_failedcount                  int             DEFAULT 0          ,
	f_failedbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_failedshares                 decimal(16,2)   DEFAULT 0.0        ,
	f_cancelbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_cancelshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	c_taflag                       varchar(1)      DEFAULT '0'        ,
	f_delaybalance                 decimal(16,2)   DEFAULT 0.0        ,
	f_delayshares                  decimal(16,2)   DEFAULT 0.0        ,
	f_shares                       decimal(16,2)   DEFAULT 0.0        ,
	f_rejsubinterest               decimal(16,2)   DEFAULT 0.0        ,
	f_deductmngfare                decimal(16,2)   DEFAULT 0.0        ,
	f_rshares_ch                   decimal(16,2)   DEFAULT 0.0        ,
	c_adjustcause                  varchar(1)      DEFAULT ' '        ,
	f_rejsubinterestall            decimal(16,2)   DEFAULT 0.0        ,
	f_rejsubinteresttax            decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(l_rowid, c_databaseno)
);
CREATE INDEX idx_tconfirmstatdetail ON ta_tconfirmstatdetail(d_cdate ASC ,c_fundcode ASC ,c_tacode ASC ,c_tenantid ASC ,c_databaseno ASC );
CREATE INDEX idx_tconfirmstat_outdate ON ta_tconfirmstatdetail(d_outputdate ASC );

-- ������ ta_ttailratio(β��Ӷ�������)�ĵ�ǰ��
SELECT 'Create Table ta_ttailratio-β��Ӷ�������...';
DROP TABLE IF EXISTS ta_ttailratio;
CREATE TABLE ta_ttailratio
(
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_tailflag                     varchar(1)      DEFAULT ' '        ,
	d_tailbgdate                   int             DEFAULT 0          ,
	f_holdmin                      decimal(16,2)   DEFAULT 0.0        ,
	f_holdmax                      decimal(16,2)   DEFAULT 0.0        ,
	f_tailratio                    decimal(9,6)    DEFAULT 0.0        ,
	l_yeardays                     int             DEFAULT 0          ,
	f_mintailfare                  decimal(16,2)   DEFAULT 0.0        ,
	c_calculatetype                varchar(1)      DEFAULT ' '        ,
	c_tailsegment                  varchar(1)      DEFAULT ' '        ,
	c_updateflag                   varchar(1)      DEFAULT ' '        ,
PRIMARY KEY(l_rowid)
);
CREATE UNIQUE INDEX pk_ttailratio ON ta_ttailratio(c_fundcode ASC ,c_agencyno ASC ,c_tailflag ASC ,d_tailbgdate ASC ,f_holdmin ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tliquidateswitch(����ת�������)�ĵ�ǰ��
SELECT 'Create Table ta_tliquidateswitch-����ת�������...';
DROP TABLE IF EXISTS ta_tliquidateswitch;
CREATE TABLE ta_tliquidateswitch
(
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	l_rowid                        int(11)         NOT NULL AUTO_INCREMENT,
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	d_cdate                        int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_othercode                    varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_fundbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
	f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
	l_successcount                 int             DEFAULT 0          ,
	f_needbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_othershares                  decimal(16,2)   DEFAULT 0.0        ,
	d_changeincdate                int             DEFAULT 0          ,
PRIMARY KEY(l_rowid, c_databaseno)
);
CREATE INDEX idx_tliquidateswitch ON ta_tliquidateswitch(d_cdate ASC ,c_liqbatchno ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tstaticsharesstat(��̬�ݶ���Ϣͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tstaticsharesstat-��̬�ݶ���Ϣͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tstaticsharesstat;
CREATE TABLE ta_tstaticsharesstat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_shareclass                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_remainshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundcode, c_agencyno, c_shareclass, c_sharetype, c_tacode, c_tenantid, c_databaseno)
);

-- ������ ta_tstaticsharesdis(��̬�ݶ���Ϣͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tstaticsharesdis-��̬�ݶ���Ϣͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tstaticsharesdis;
CREATE TABLE ta_tstaticsharesdis
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_shareclass                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_sharetype                    varchar(1)      DEFAULT ' '        NOT NULL,
	f_income                       decimal(16,2)   DEFAULT 0.0        ,
	f_remainshares                 decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	f_newincome                    decimal(16,2)   DEFAULT 0.0        ,
	f_frozenshares                 decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(c_fundcode, c_agencyno, c_shareclass, c_sharetype, c_tacode, c_tenantid, c_databaseno)
);

-- ������ ta_tunsenddividendstat(δ���ŷֺ���ϸͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tunsenddividendstat-δ���ŷֺ���ϸͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tunsenddividendstat;
CREATE TABLE ta_tunsenddividendstat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	f_unfrozenbalance              decimal(16,2)   DEFAULT 0.0        ,
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
PRIMARY KEY(c_fundcode, c_agencyno, c_tacode, c_tenantid, c_databaseno)
);

-- ������ ta_tcheckresultstat(�����ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tcheckresultstat-�����ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tcheckresultstat;
CREATE TABLE ta_tcheckresultstat
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        NOT NULL,
	c_type                         varchar(1)      DEFAULT ' '        NOT NULL,
	c_databaseno                   varchar(5)      DEFAULT ' '        ,
	c_requestno                    varchar(24)     DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	c_netno                        varchar(9)      DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_memo                         varchar(60)     DEFAULT ' '        ,
PRIMARY KEY(c_requestno, c_type, d_cdate, c_tacode, c_liqbatchno, c_tenantid)
);

-- ������ ta_topenfundstructreport(����Ͷ���˽ṹ�ձ���)�ĵ�ǰ��
SELECT 'Create Table ta_topenfundstructreport-����Ͷ���˽ṹ�ձ���...';
DROP TABLE IF EXISTS ta_topenfundstructreport;
CREATE TABLE ta_topenfundstructreport
(
	c_databaseno                   varchar(5)      DEFAULT ' '        NOT NULL,
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	d_date                         int             DEFAULT 0          NOT NULL,
	f_fundtotalshare               decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencyshare             decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonshare             decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonstockshare        decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonmixshare          decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonbondshare         decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersoncurrencyshare     decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonqdshare           decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencystockshare        decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencymixshare          decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencybondshare         decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencycurrencyshare     decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencyqdshare           decimal(16,2)   DEFAULT 0.0        ,
	f_totaldirectshare             decimal(16,2)   DEFAULT 0.0        ,
	f_totalbankshare               decimal(16,2)   DEFAULT 0.0        ,
	f_totalbrokershare             decimal(16,2)   DEFAULT 0.0        ,
	f_totalstockshare              decimal(16,2)   DEFAULT 0.0        ,
	f_totalprofessionalshare       decimal(16,2)   DEFAULT 0.0        ,
	f_totalvalue                   decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonvalue             decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonstockvalue        decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonmixvalue          decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonbondvalue         decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersoncurrencyvalue     decimal(16,2)   DEFAULT 0.0        ,
	f_totalpersonqdvalue           decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencyvalue             decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencystockvalue        decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencymixvalue          decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencybondvalue         decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencycurrencyvalue     decimal(16,2)   DEFAULT 0.0        ,
	f_totalagencyqdvalue           decimal(16,2)   DEFAULT 0.0        ,
	f_totaldirectvalue             decimal(16,2)   DEFAULT 0.0        ,
	f_totalbankvalue               decimal(16,2)   DEFAULT 0.0        ,
	f_totalbrokervalue             decimal(16,2)   DEFAULT 0.0        ,
	f_totalstockvalue              decimal(16,2)   DEFAULT 0.0        ,
	f_totalprofessionalvalue       decimal(16,2)   DEFAULT 0.0        ,
	l_totalaccount                 int             DEFAULT 0          ,
	l_personaccount                int             DEFAULT 0          ,
	l_agencyaccount                int             DEFAULT 0          ,
	l_validaccount                 int             DEFAULT 0          ,
	l_validpersonaccount           int             DEFAULT 0          ,
	l_validagencyaccount           int             DEFAULT 0          ,
	l_tradeaccount                 int             DEFAULT 0          ,
	l_notradeaccount               int             DEFAULT 0          ,
PRIMARY KEY(d_date, c_databaseno, c_tenantid, c_tacode)
);

-- ������ ta_tliquidateagency(�������ʽ�������)�ĵ�ǰ��
SELECT 'Create Table ta_tliquidateagency-�������ʽ�������...';
DROP TABLE IF EXISTS ta_tliquidateagency;
CREATE TABLE ta_tliquidateagency
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	d_cdate                        int             DEFAULT 0          ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_businflag                    varchar(2)      DEFAULT ' '        ,
	d_date                         int             DEFAULT 0          ,
	f_tradefare                    decimal(16,2)   DEFAULT 0.0        ,
	f_tafare                       decimal(16,2)   DEFAULT 0.0        ,
	f_stamptax                     decimal(16,2)   DEFAULT 0.0        ,
	f_backfare                     decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare1                   decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare                   decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4agt                decimal(16,2)   DEFAULT 0.0        ,
	f_tradefare4fund               decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4agt                   decimal(16,2)   DEFAULT 0.0        ,
	f_tafare4fund                  decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4agt                 decimal(16,2)   DEFAULT 0.0        ,
	f_backfare4fund                decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14agt               decimal(16,2)   DEFAULT 0.0        ,
	f_otherfare14fund              decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4agt               decimal(16,2)   DEFAULT 0.0        ,
	f_breachfare4fund              decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4agt            decimal(16,2)   DEFAULT 0.0        ,
	f_profitbalance4fund           decimal(16,2)   DEFAULT 0.0        ,
	f_interesttax                  decimal(16,2)   DEFAULT 0.0        ,
	f_incometax                    decimal(16,2)   DEFAULT 0.0        ,
	f_totalfare                    decimal(16,2)   DEFAULT 0.0        ,
	l_successcount                 int             DEFAULT 0          ,
	f_confirmbalance               decimal(16,2)   DEFAULT 0.0        ,
	f_confirmshares                decimal(16,2)   DEFAULT 0.0        ,
	f_fundbalance                  decimal(16,2)   DEFAULT 0.0        ,
	f_frozenbalance                decimal(16,2)   DEFAULT 0.0        ,
	c_liqtype                      varchar(1)      DEFAULT ' '        ,
	d_needdate                     int             DEFAULT 0          ,
	f_needbalance                  decimal(16,2)   DEFAULT 0.0        ,
	c_fundmethod                   varchar(2)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        ,
	f_interest                     decimal(16,2)   DEFAULT 0.0        
);
CREATE INDEX idx_tliquidateagency ON ta_tliquidateagency(d_cdate ASC ,c_tacode ASC ,c_tenantid ASC );

-- ������ ta_tfundagencytodaytmp(�������ʽ������м��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundagencytodaytmp-�������ʽ������м��...';
DROP TABLE IF EXISTS ta_tfundagencytodaytmp;
CREATE TABLE ta_tfundagencytodaytmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        
);

-- ������ ta_tfundagencyliquidate(�������ʽ�������Ϣ�м��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundagencyliquidate-�������ʽ�������Ϣ�м��...';
DROP TABLE IF EXISTS ta_tfundagencyliquidate;
CREATE TABLE ta_tfundagencyliquidate
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	d_requestdate                  int             DEFAULT 0          ,
	c_subbalancetype               varchar(1)      DEFAULT ' '        ,
	c_fundmethod                   varchar(2)      DEFAULT ' '        ,
	c_allotliqtype                 varchar(1)      DEFAULT ' '        ,
	c_redeemliqtype                varchar(1)      DEFAULT ' '        ,
	l_liquidatesub                 int             DEFAULT 0          ,
	l_liquidateallot               int             DEFAULT 0          ,
	l_liquidateredeem              int             DEFAULT 0          ,
	l_liquidatebonus               int             DEFAULT 0          ,
	l_liquidatefail                int             DEFAULT 0          ,
	l_liquidateend                 int             DEFAULT 0          ,
	d_setupdate                    int             DEFAULT 0          ,
	c_firstflag                    varchar(1)      DEFAULT ' '        ,
	c_secondflag                   varchar(1)      DEFAULT ' '        ,
	c_affectbonus                  varchar(1)      DEFAULT ' '        ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        
);
CREATE INDEX idx_tfundagecliq ON ta_tfundagencyliquidate(c_fundcode ASC ,c_agencyno ASC ,c_tenantid ASC );

-- ������ ta_tfundagencyliqtmp(��Ʒ������������Ϣ��ʱ��)�ĵ�ǰ��
SELECT 'Create Table ta_tfundagencyliqtmp-��Ʒ������������Ϣ��ʱ��...';
DROP TABLE IF EXISTS ta_tfundagencyliqtmp;
CREATE TABLE ta_tfundagencyliqtmp
(
	c_tenantid                     varchar(20)     DEFAULT ' '        ,
	c_tacode                       varchar(2)      DEFAULT ' '        ,
	c_fundcode                     varchar(12)     DEFAULT ' '        ,
	c_agencyno                     varchar(9)      DEFAULT ' '        ,
	c_needflag                     varchar(1)      DEFAULT ' '        ,
	l_liquidateallot               int             DEFAULT 0          ,
	l_liquidateredeem              int             DEFAULT 0          ,
	l_liquidatebonus               int             DEFAULT 0          ,
	l_liquidatesub                 int             DEFAULT 0          ,
	l_liquidatefail                int             DEFAULT 0          ,
	l_liquidateend                 int             DEFAULT 0          ,
	l_liquidatefare                int             DEFAULT 0          ,
	l_liquidatechange              int             DEFAULT 0          ,
	c_liqbatchno                   varchar(1)      DEFAULT ' '        
);
CREATE INDEX idx_tfundagencyliqtmp ON ta_tfundagencyliqtmp(c_fundcode ASC ,c_agencyno ASC ,c_tenantid ASC );

-- ������ ta_tworkingcost(���շ�Ӫҵ�Է���ͳ�Ʊ�)�ĵ�ǰ��
SELECT 'Create Table ta_tworkingcost-���շ�Ӫҵ�Է���ͳ�Ʊ�...';
DROP TABLE IF EXISTS ta_tworkingcost;
CREATE TABLE ta_tworkingcost
(
	c_tenantid                     varchar(20)     DEFAULT ' '        NOT NULL,
	c_tacode                       varchar(2)      DEFAULT ' '        NOT NULL,
	c_fundcode                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_fundacco                     varchar(12)     DEFAULT ' '        NOT NULL,
	c_agencyno                     varchar(9)      DEFAULT ' '        NOT NULL,
	c_netno                        varchar(9)      DEFAULT ' '        NOT NULL,
	d_cdate                        int             DEFAULT 0          NOT NULL,
	f_costfare                     decimal(16,2)   DEFAULT 0.0        ,
PRIMARY KEY(d_cdate, c_fundacco, c_fundcode, c_agencyno, c_netno, c_tacode, c_tenantid)
);

