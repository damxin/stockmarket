-- oracle drop table if exists ʵ��mysql��drop table if exists

DELIMITER $$
    DROP PROCEDURE IF EXISTS dropifexists $$
    CREATE PROCEDURE dropifexists(IN p_table VARCHAR(100))
    BEGIN
         SET @drop_sql = CONCAT('DROP TABLE IF EXISTS `',p_table,'`');
         PREPARE stmt FROM @drop_sql;  
         EXECUTE stmt;  
         DEALLOCATE PREPARE stmt;  
    END$$
DELIMITER ;

