DROP FUNCTION IF EXISTS getreqserialno;   
DELIMITER $$
CREATE FUNCTION getreqserialno(dbno INT, rn INT)  
RETURNS BIGINT(20)
BEGIN  
    DECLARE difftime BIGINT(20);
    
    SET difftime = UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP('2017-11-16');
    
    SET difftime = difftime*4194304 + (2047-dbno)*2048 + rn;

    RETURN difftime;
   
END $$
DELIMITER ;