
SQL_PATH=$HOME/sql
SQL_TYPE=MySQLTable
echo use hs_tabase > $SQL_PATH/1.tmp

cat $SQL_PATH/*$SQL_TYPE.sql > $SQL_PATH/2.tmp
cat $SQL_PATH/1.tmp $SQL_PATH/2.tmp > $SQL_PATH/sqlfull.tmp
rm -rf $SQL_PATH/1.tmp
rm -rf $SQL_PATH/2.tmp


mysql -u hs_tabase -p hs_tabase < $SQL_PATH/sqlfull.tmp

